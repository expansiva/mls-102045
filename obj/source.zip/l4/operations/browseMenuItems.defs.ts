/// <mls fileReference="_102045_/l4/operations/browseMenuItems.defs.ts" enhancement="_blank"/>

export const operationBrowseMenuItems = {
  "operationId": "browseMenuItems",
  "title": "Consultar itens do cardápio",
  "actor": "gerente",
  "entity": "MenuItem",
  "kind": "query",
  "reads": [
    "MenuItem",
    "MenuCategory"
  ],
  "writes": [],
  "rulesApplied": [
    "simpleItemsOnly"
  ],
  "story": {
    "actor": "gerente",
    "goal": "Consultar a lista de itens do cardápio para revisar, editar ou decidir ativação de itens cadastrados.",
    "steps": [
      "O gerente abre a tela de gestão de cardápio.",
      "O sistema lista todos os itens do cardápio da empresa ativa com nome, categoria, preço, tipo e status.",
      "O gerente pode filtrar por status (rascunho, ativo, inativo) ou por categoria para localizar itens específicos."
    ],
    "outcome": "O gerente visualiza a lista completa de itens do cardápio e pode identificar quais itens precisam de ingredientes vinculados ou ativação."
  },
  "accessPattern": {
    "kind": "list",
    "entity": "MenuItem",
    "keyField": "MenuItem.menuItemId",
    "pagination": "optional",
    "selection": "none",
    "output": [
      "MenuItem.menuItemId",
      "MenuItem.name",
      "MenuItem.description",
      "MenuItem.menuCategoryId",
      "MenuItem.price",
      "MenuItem.itemType",
      "MenuItem.status",
      "MenuItem.activatedAt",
      "MenuItem.createdAt",
      "MenuItem.updatedAt"
    ]
  },
  "inputs": [
    {
      "inputId": "statusFilter",
      "fieldRef": "MenuItem.status",
      "required": false,
      "source": "userInput",
      "description": "Filtro opcional por status do item (draft, active, inactive) informado pelo gerente"
    },
    {
      "inputId": "menuCategoryIdFilter",
      "fieldRef": "MenuItem.menuCategoryId",
      "required": false,
      "source": "userInput",
      "description": "Filtro opcional por categoria do item informado pelo gerente"
    }
  ],
  "contextResolution": [
    {
      "targetRef": "MenuItem.menuCategoryId",
      "source": "businessContext",
      "originRef": "businessContext.activeCompanyId",
      "description": "O backend resolve o escopo da consulta limitando os itens do cardápio à empresa ativa da sessão do gerente"
    }
  ],
  "acceptanceAssertions": [
    "A lista retornada contém apenas itens do cardápio pertencentes à empresa ativa do gerente",
    "Cada item da lista exibe nome, categoria, preço, tipo (simple ou variant) e status (draft, active ou inactive)",
    "O filtro por status retorna apenas itens cujo status corresponde ao valor informado",
    "O filtro por categoria retorna apenas itens cujo menuCategoryId corresponde ao valor informado",
    "Itens do tipo variant aparecem na lista como itens separados conforme a regra de apenas itens simples suportados"
  ],
  "pageId": "menuItemLifecycle",
  "commandName": "browseMenuItems",
  "bffName": "cafeFlow.menuItemLifecycle.browseMenuItems",
  "capability": {
    "capabilityId": "menuItemLifecycle",
    "title": "Ciclo de vida do item de cardápio",
    "actor": "gerente",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationBrowseMenuItems;
