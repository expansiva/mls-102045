/// <mls fileReference="_102045_/l4/operations/viewOrderBoard.defs.ts" enhancement="_blank"/>

export const operationViewOrderBoard = {
  "operationId": "viewOrderBoard",
  "title": "Visualizar painel de pedidos",
  "actor": "atendente",
  "entity": "Order",
  "kind": "view",
  "reads": [
    "Order",
    "Shift"
  ],
  "writes": [],
  "rulesApplied": [
    "dashboardCurrentShiftOnly",
    "fifoKitchenQueue",
    "orderStatusFlow"
  ],
  "story": {
    "actor": "atendente",
    "goal": "Consultar o painel de status dos pedidos em andamento no turno atual para saber quais estão em preparo e quais já estão prontos.",
    "steps": [
      "O atendente abre o painel de pedidos no POS",
      "O sistema identifica o turno atualmente aberto e filtra apenas os pedidos daquele turno",
      "O sistema lista os pedidos ordenados por data de criação (ordem de chegada)",
      "O painel exibe cada pedido com seu status atual, tipo, mesa e indicador de prioridade"
    ],
    "outcome": "O atendente visualiza todos os pedidos do turno atual com seus respectivos status, podendo identificar quais estão em preparo e quais já estão prontos para entrega."
  },
  "accessPattern": {
    "kind": "list",
    "entity": "Order",
    "keyField": "Order.orderId",
    "pagination": "optional",
    "selection": "none",
    "output": [
      "Order.orderId",
      "Order.status",
      "Order.orderType",
      "Order.tableNumber",
      "Order.priority",
      "Order.priorityReason",
      "Order.receivedAt",
      "Order.inPreparationAt",
      "Order.readyAt",
      "Order.createdAt"
    ]
  },
  "inputs": [
    {
      "inputId": "shiftId",
      "fieldRef": "Order.shiftId",
      "required": true,
      "source": "activeLifecycleInstance",
      "description": "Turno atualmente aberto para filtrar apenas pedidos do turno corrente"
    }
  ],
  "contextResolution": [
    {
      "targetRef": "Order.shiftId",
      "source": "activeLifecycleInstance",
      "originRef": "Shift.shiftId",
      "description": "O backend resolve o turno atualmente aberto consultando a única Shift com status open e utiliza seu shiftId para filtrar os pedidos exibidos no painel"
    }
  ],
  "acceptanceAssertions": [
    "O painel exibe apenas pedidos cujo shiftId corresponde ao turno atualmente aberto",
    "Os pedidos são listados ordenados por Order.createdAt em ordem crescente (FIFO)",
    "Cada pedido no painel mostra seu status atual entre registered, received, inPreparation, ready ou delivered",
    "Pedidos com Order.priority verdadeiro são exibidos com indicador visual de priorização",
    "O painel não exibe pedidos de turnos anteriores ou fechados"
  ],
  "pageId": "orderLifecycle",
  "commandName": "viewOrderBoard",
  "bffName": "cafeFlow.orderLifecycle.viewOrderBoard",
  "capability": {
    "capabilityId": "orderLifecycle",
    "title": "Ciclo de vida do pedido",
    "actor": "atendente",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationViewOrderBoard;
