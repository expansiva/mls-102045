/// <mls fileReference="_102045_/l4/buildFlowFsm/operations/createWorkTask.defs.ts" enhancement="_blank"/>

export const operationCreateWorkTask = {
  "operationId": "createWorkTask",
  "title": "Create work task",
  "actors": [
    "projectManager"
  ],
  "entity": "WorkTask",
  "kind": "create",
  "reads": [
    "Project",
    "WorkTask"
  ],
  "writes": [
    "WorkTask"
  ],
  "rulesApplied": [
    "operationsRequireActiveProject",
    "singleTaskAssignment",
    "taskDueDateWithinSchedule"
  ],
  "story": {
    "actor": "projectManager",
    "goal": "Create a work task on an active project, assign it to one field worker, and set a due date within the project schedule",
    "steps": [
      "Select or confirm the active project the task belongs to",
      "Enter the task title and optional description",
      "Assign exactly one field worker",
      "Set a due date within the project start and end dates",
      "Confirm creation so the task is stored with status assigned"
    ],
    "outcome": "A new work task exists on the project, assigned to one field worker with status assigned and a valid due date, visible for field progress tracking"
  },
  "accessPattern": {
    "kind": "commandInput",
    "description": "Form input to create a work task on an active project with title, optional description, single worker assignment, and due date",
    "entity": "WorkTask",
    "keyField": "WorkTask.workTaskId",
    "pagination": "none",
    "selection": "none",
    "output": [
      "WorkTask.workTaskId",
      "WorkTask.projectId",
      "WorkTask.title",
      "WorkTask.description",
      "WorkTask.assignedWorkerId",
      "WorkTask.status",
      "WorkTask.dueDate",
      "WorkTask.createdAt",
      "WorkTask.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "workTaskId",
        "type": "string",
        "required": true,
        "fieldRef": "WorkTask.workTaskId"
      },
      {
        "name": "projectId",
        "type": "string",
        "required": true,
        "fieldRef": "WorkTask.projectId"
      },
      {
        "name": "title",
        "type": "string",
        "required": true,
        "fieldRef": "WorkTask.title"
      },
      {
        "name": "description",
        "type": "string",
        "required": false,
        "fieldRef": "WorkTask.description"
      },
      {
        "name": "assignedWorkerId",
        "type": "string",
        "required": true,
        "fieldRef": "WorkTask.assignedWorkerId"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "WorkTask.status"
      },
      {
        "name": "dueDate",
        "type": "string",
        "required": true,
        "fieldRef": "WorkTask.dueDate"
      },
      {
        "name": "createdAt",
        "type": "string",
        "required": true,
        "fieldRef": "WorkTask.createdAt"
      },
      {
        "name": "updatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "WorkTask.updatedAt"
      }
    ]
  },
  "inputs": [
    {
      "inputId": "projectId",
      "fieldRef": "WorkTask.projectId",
      "required": true,
      "source": "selectedEntity",
      "description": "Project the new work task belongs to"
    },
    {
      "inputId": "title",
      "fieldRef": "WorkTask.title",
      "required": true,
      "source": "userInput",
      "description": "Short name describing the work task"
    },
    {
      "inputId": "description",
      "fieldRef": "WorkTask.description",
      "required": false,
      "source": "userInput",
      "description": "Detailed scope or instructions for completing the task"
    },
    {
      "inputId": "assignedWorkerId",
      "fieldRef": "WorkTask.assignedWorkerId",
      "required": true,
      "source": "userInput",
      "description": "Identifier of the single field worker assigned to this task"
    },
    {
      "inputId": "dueDate",
      "fieldRef": "WorkTask.dueDate",
      "required": true,
      "source": "userInput",
      "description": "Date by which the task should be completed, within the project schedule"
    },
    {
      "inputId": "workTaskId",
      "fieldRef": "WorkTask.workTaskId",
      "required": true,
      "source": "systemDefault",
      "description": "System-generated primary identifier for the new work task"
    },
    {
      "inputId": "status",
      "fieldRef": "WorkTask.status",
      "required": true,
      "source": "systemDefault",
      "description": "Initial lifecycle status set to assigned on creation"
    },
    {
      "inputId": "createdAt",
      "fieldRef": "WorkTask.createdAt",
      "required": true,
      "source": "systemDefault",
      "description": "Timestamp when the work task is created"
    },
    {
      "inputId": "updatedAt",
      "fieldRef": "WorkTask.updatedAt",
      "required": true,
      "source": "systemDefault",
      "description": "Timestamp of the initial create update"
    }
  ],
  "contextResolution": [
    {
      "inputId": "projectId",
      "targetRef": "WorkTask.projectId",
      "source": "selectedEntity",
      "originRef": "Project.projectId",
      "description": "Resolve projectId from the project currently selected in the planning workspace"
    },
    {
      "inputId": "workTaskId",
      "targetRef": "WorkTask.workTaskId",
      "source": "systemDefault",
      "originRef": "systemDefault.uuid",
      "description": "Generate a new UUID for the work task primary key"
    },
    {
      "inputId": "status",
      "targetRef": "WorkTask.status",
      "source": "systemDefault",
      "originRef": "systemDefault.locale",
      "description": "Set initial status to the fixed value assigned on create"
    },
    {
      "inputId": "createdAt",
      "targetRef": "WorkTask.createdAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Stamp createdAt with the current server time"
    },
    {
      "inputId": "updatedAt",
      "targetRef": "WorkTask.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Stamp updatedAt with the current server time on create"
    }
  ],
  "acceptanceAssertions": [
    "After confirmation a WorkTask exists with the provided title, optional description, projectId, assignedWorkerId, and dueDate",
    "The created WorkTask has status assigned",
    "The project referenced by projectId must be in active status or creation is rejected",
    "assignedWorkerId references exactly one field worker; concurrent multi-worker assignment is not allowed",
    "dueDate falls within the referenced project's startDate and endDate or creation is rejected",
    "workTaskId, createdAt, and updatedAt are populated by the system on create",
    "The created task is available for the assigned field worker to view and for subsequent progress updates"
  ],
  "pageId": "workTaskLifecycle",
  "commandName": "createWorkTask",
  "bffName": "buildFlowFsm.workTaskLifecycle.createWorkTask",
  "capability": {
    "capabilityId": "workTaskLifecycle",
    "title": "Work task lifecycle",
    "actor": "projectManager",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationCreateWorkTask;
