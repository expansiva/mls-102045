/// <mls fileReference="_102045_/l4/buildFlowFsm/operations/queryInvoices.defs.ts" enhancement="_blank"/>

export const operationQueryInvoices = {
  "operationId": "queryInvoices",
  "title": "Browse invoices",
  "actors": [
    "billingStaff"
  ],
  "entity": "Invoice",
  "kind": "query",
  "reads": [
    "Invoice",
    "Project",
    "Client"
  ],
  "writes": [],
  "rulesApplied": [
    "invoiceScopeExternalPayment",
    "invoiceMustReferenceProjectAndClient",
    "clientBillingAccess"
  ],
  "story": {
    "actor": "billingStaff",
    "goal": "Browse existing invoices to find, review, and manage billing documents for projects",
    "steps": [
      "Open the invoices list",
      "Optionally filter by status, project, or client",
      "Scan invoice number, client, project, status, total amount, and dates",
      "Select an invoice to review or send"
    ],
    "outcome": "Billing staff sees the current set of invoices with key billing details so they can review drafts and track what has been sent to clients"
  },
  "accessPattern": {
    "kind": "list",
    "description": "Paginated list of invoices for billing staff to browse, filter, and select one for review or send",
    "entity": "Invoice",
    "keyField": "Invoice.invoiceId",
    "filters": [
      "Invoice.status",
      "Invoice.projectId",
      "Invoice.clientId"
    ],
    "sort": [
      "Invoice.createdAt",
      "Invoice.invoiceNumber"
    ],
    "pagination": "optional",
    "selection": "single",
    "output": [
      "Invoice.invoiceId",
      "Invoice.invoiceNumber",
      "Invoice.projectId",
      "Invoice.clientId",
      "Invoice.status",
      "Invoice.totalAmount",
      "Invoice.sentAt",
      "Invoice.createdAt",
      "Invoice.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "paginated",
    "fields": [
      {
        "name": "invoices",
        "type": "array",
        "required": true,
        "item": {
          "fields": [
            {
              "name": "invoiceId",
              "type": "string",
              "required": true,
              "fieldRef": "Invoice.invoiceId"
            },
            {
              "name": "invoiceNumber",
              "type": "string",
              "required": true,
              "fieldRef": "Invoice.invoiceNumber"
            },
            {
              "name": "projectId",
              "type": "string",
              "required": true,
              "fieldRef": "Invoice.projectId"
            },
            {
              "name": "clientId",
              "type": "string",
              "required": true,
              "fieldRef": "Invoice.clientId"
            },
            {
              "name": "status",
              "type": "string",
              "required": true,
              "fieldRef": "Invoice.status"
            },
            {
              "name": "totalAmount",
              "type": "number",
              "required": true,
              "fieldRef": "Invoice.totalAmount"
            },
            {
              "name": "sentAt",
              "type": "string",
              "required": false,
              "fieldRef": "Invoice.sentAt"
            },
            {
              "name": "createdAt",
              "type": "string",
              "required": true,
              "fieldRef": "Invoice.createdAt"
            },
            {
              "name": "updatedAt",
              "type": "string",
              "required": true,
              "fieldRef": "Invoice.updatedAt"
            }
          ]
        }
      },
      {
        "name": "total",
        "type": "number",
        "required": true
      }
    ]
  },
  "inputs": [
    {
      "inputId": "status",
      "fieldRef": "Invoice.status",
      "required": false,
      "source": "userInput",
      "description": "Optional filter by invoice lifecycle status (draft or sent)"
    },
    {
      "inputId": "projectId",
      "fieldRef": "Invoice.projectId",
      "required": false,
      "source": "userInput",
      "description": "Optional filter to invoices for a specific project"
    },
    {
      "inputId": "clientId",
      "fieldRef": "Invoice.clientId",
      "required": false,
      "source": "userInput",
      "description": "Optional filter to invoices for a specific client"
    },
    {
      "inputId": "page",
      "type": "number",
      "required": false,
      "source": "userInput",
      "description": "Optional page number for paginated results"
    },
    {
      "inputId": "pageSize",
      "type": "number",
      "required": false,
      "source": "userInput",
      "description": "Optional page size for paginated results"
    }
  ],
  "contextResolution": [],
  "acceptanceAssertions": [
    "Billing staff can list invoices with invoice number, project, client, status, total amount, and timestamps",
    "Results can be filtered by status, projectId, and clientId",
    "Each listed invoice references both a project and a client",
    "Draft and sent invoices are both visible so staff can review drafts and track what was sent",
    "The list supports optional pagination and single selection of an invoice for review or send",
    "Invoice data is presented as billing documents only; no payment or accounting fields are included"
  ],
  "pageId": "queryInvoices",
  "commandName": "queryInvoices",
  "bffName": "buildFlowFsm.queryInvoices.queryInvoices",
  "capability": {
    "capabilityId": "queryInvoices",
    "title": "Browse invoices",
    "actor": "billingStaff",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationQueryInvoices;
