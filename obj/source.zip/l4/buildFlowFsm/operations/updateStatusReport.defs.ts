/// <mls fileReference="_102045_/l4/buildFlowFsm/operations/updateStatusReport.defs.ts" enhancement="_blank"/>

export const operationUpdateStatusReport = {
  "operationId": "updateStatusReport",
  "title": "Edit status report content",
  "actors": [
    "projectManager"
  ],
  "entity": "StatusReport",
  "kind": "update",
  "reads": [
    "StatusReport"
  ],
  "writes": [
    "StatusReport"
  ],
  "rulesApplied": [
    "pmControlsStatusReportLifecycle"
  ],
  "story": {
    "actor": "projectManager",
    "goal": "Edit the AI-generated status report content and add notes before sharing with the client",
    "steps": [
      "Open an existing draft status report",
      "Review and edit the summary and overview sections as needed",
      "Add or update project manager notes",
      "Save the content changes"
    ],
    "outcome": "The status report content is updated with the project manager's edits and remains available for further review or sharing"
  },
  "accessPattern": {
    "kind": "commandInput",
    "description": "Form to edit narrative content and PM notes on a selected status report",
    "entity": "StatusReport",
    "keyField": "StatusReport.statusReportId",
    "pagination": "none",
    "selection": "single",
    "output": [
      "StatusReport.statusReportId",
      "StatusReport.projectId",
      "StatusReport.status",
      "StatusReport.reportPeriodStart",
      "StatusReport.reportPeriodEnd",
      "StatusReport.summary",
      "StatusReport.tasksOverview",
      "StatusReport.timeLogsOverview",
      "StatusReport.materialsOverview",
      "StatusReport.delayRiskAssessment",
      "StatusReport.pmNotes",
      "StatusReport.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "statusReportId",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.statusReportId"
      },
      {
        "name": "projectId",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.projectId"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.status"
      },
      {
        "name": "reportPeriodStart",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.reportPeriodStart"
      },
      {
        "name": "reportPeriodEnd",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.reportPeriodEnd"
      },
      {
        "name": "summary",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.summary"
      },
      {
        "name": "tasksOverview",
        "type": "string",
        "required": false,
        "fieldRef": "StatusReport.tasksOverview"
      },
      {
        "name": "timeLogsOverview",
        "type": "string",
        "required": false,
        "fieldRef": "StatusReport.timeLogsOverview"
      },
      {
        "name": "materialsOverview",
        "type": "string",
        "required": false,
        "fieldRef": "StatusReport.materialsOverview"
      },
      {
        "name": "delayRiskAssessment",
        "type": "string",
        "required": false,
        "fieldRef": "StatusReport.delayRiskAssessment"
      },
      {
        "name": "pmNotes",
        "type": "string",
        "required": false,
        "fieldRef": "StatusReport.pmNotes"
      },
      {
        "name": "updatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.updatedAt"
      }
    ]
  },
  "inputs": [
    {
      "inputId": "statusReportId",
      "fieldRef": "StatusReport.statusReportId",
      "required": true,
      "source": "routeParam",
      "description": "Identifier of the status report being edited"
    },
    {
      "inputId": "summary",
      "fieldRef": "StatusReport.summary",
      "required": true,
      "source": "userInput",
      "description": "Edited narrative summary of overall project status for the period"
    },
    {
      "inputId": "tasksOverview",
      "fieldRef": "StatusReport.tasksOverview",
      "required": false,
      "source": "userInput",
      "description": "Edited overview of task progress derived from work tasks"
    },
    {
      "inputId": "timeLogsOverview",
      "fieldRef": "StatusReport.timeLogsOverview",
      "required": false,
      "source": "userInput",
      "description": "Edited overview of hours logged from time logs"
    },
    {
      "inputId": "materialsOverview",
      "fieldRef": "StatusReport.materialsOverview",
      "required": false,
      "source": "userInput",
      "description": "Edited overview of material consumption"
    },
    {
      "inputId": "delayRiskAssessment",
      "fieldRef": "StatusReport.delayRiskAssessment",
      "required": false,
      "source": "userInput",
      "description": "Edited assessment of delay risks for the period"
    },
    {
      "inputId": "pmNotes",
      "fieldRef": "StatusReport.pmNotes",
      "required": false,
      "source": "userInput",
      "description": "Notes or edits added by the project manager during review"
    },
    {
      "inputId": "updatedAt",
      "fieldRef": "StatusReport.updatedAt",
      "required": true,
      "source": "systemDefault",
      "description": "Timestamp when the content edits are saved"
    }
  ],
  "contextResolution": [
    {
      "inputId": "statusReportId",
      "targetRef": "StatusReport.statusReportId",
      "source": "routeParam",
      "originRef": "routeParam.statusReportId",
      "description": "Resolved from the route parameter identifying the status report being edited"
    },
    {
      "inputId": "updatedAt",
      "targetRef": "StatusReport.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Server sets the last-update timestamp to the current time when saving content edits"
    }
  ],
  "acceptanceAssertions": [
    "After the project manager saves edits, the status report summary and overview fields reflect the submitted content",
    "When provided, the status report pmNotes field stores the project manager's review notes",
    "Only the project manager can edit status report content before sharing with the client",
    "The status report updatedAt timestamp is set to the time of the content save",
    "Editing report content does not share the report with the client or change lifecycle beyond the content update"
  ],
  "pageId": "updateStatusReport",
  "commandName": "updateStatusReport",
  "bffName": "buildFlowFsm.updateStatusReport.updateStatusReport",
  "capability": {
    "capabilityId": "updateStatusReport",
    "title": "Edit status report content",
    "actor": "projectManager",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationUpdateStatusReport;
