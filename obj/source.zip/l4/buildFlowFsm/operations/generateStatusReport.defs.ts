/// <mls fileReference="_102045_/l4/buildFlowFsm/operations/generateStatusReport.defs.ts" enhancement="_blank"/>

export const operationGenerateStatusReport = {
  "operationId": "generateStatusReport",
  "title": "Generate status report",
  "actors": [
    "projectManager"
  ],
  "entity": "StatusReport",
  "kind": "create",
  "reads": [
    "Project",
    "WorkTask",
    "TimeLog",
    "MaterialUsage",
    "StatusReport"
  ],
  "writes": [
    "StatusReport"
  ],
  "rulesApplied": [
    "statusReportGenerationSource",
    "pmControlsStatusReportLifecycle"
  ],
  "story": {
    "actor": "projectManager",
    "goal": "Generate an AI-assisted project status report from live tasks, time logs, and materials for a chosen period",
    "steps": [
      "Project manager opens a project and chooses to generate a status report",
      "Project manager provides the reporting period start and end dates",
      "System gathers live work tasks, time logs, and material usage for the project and period",
      "System calls the platform LLM proxy to produce summary, overviews, and delay-risk assessment",
      "System persists the new status report in draft state for PM review"
    ],
    "outcome": "A new StatusReport exists in draft status with AI-generated content derived from live project data, ready for the project manager to review"
  },
  "accessPattern": {
    "kind": "commandInput",
    "description": "Command form for the project manager to generate a new AI-assisted status report for the selected project and reporting period",
    "entity": "StatusReport",
    "keyField": "StatusReport.statusReportId",
    "pagination": "none",
    "selection": "none",
    "output": [
      "StatusReport.statusReportId",
      "StatusReport.projectId",
      "StatusReport.status",
      "StatusReport.reportPeriodStart",
      "StatusReport.reportPeriodEnd",
      "StatusReport.summary",
      "StatusReport.tasksOverview",
      "StatusReport.timeLogsOverview",
      "StatusReport.materialsOverview",
      "StatusReport.delayRiskAssessment",
      "StatusReport.generatedAt",
      "StatusReport.createdAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "statusReportId",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.statusReportId"
      },
      {
        "name": "projectId",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.projectId"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.status"
      },
      {
        "name": "reportPeriodStart",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.reportPeriodStart"
      },
      {
        "name": "reportPeriodEnd",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.reportPeriodEnd"
      },
      {
        "name": "summary",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.summary"
      },
      {
        "name": "tasksOverview",
        "type": "string",
        "required": false,
        "fieldRef": "StatusReport.tasksOverview"
      },
      {
        "name": "timeLogsOverview",
        "type": "string",
        "required": false,
        "fieldRef": "StatusReport.timeLogsOverview"
      },
      {
        "name": "materialsOverview",
        "type": "string",
        "required": false,
        "fieldRef": "StatusReport.materialsOverview"
      },
      {
        "name": "delayRiskAssessment",
        "type": "string",
        "required": false,
        "fieldRef": "StatusReport.delayRiskAssessment"
      },
      {
        "name": "generatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.generatedAt"
      },
      {
        "name": "createdAt",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.createdAt"
      },
      {
        "name": "updatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "StatusReport.updatedAt"
      }
    ]
  },
  "inputs": [
    {
      "inputId": "projectId",
      "fieldRef": "StatusReport.projectId",
      "required": true,
      "source": "selectedEntity",
      "description": "The project for which the status report is generated"
    },
    {
      "inputId": "reportPeriodStart",
      "fieldRef": "StatusReport.reportPeriodStart",
      "required": true,
      "source": "userInput",
      "description": "Start date of the reporting period covered by the status report"
    },
    {
      "inputId": "reportPeriodEnd",
      "fieldRef": "StatusReport.reportPeriodEnd",
      "required": true,
      "source": "userInput",
      "description": "End date of the reporting period covered by the status report"
    },
    {
      "inputId": "statusReportId",
      "fieldRef": "StatusReport.statusReportId",
      "required": true,
      "source": "systemDefault",
      "description": "System-generated primary identifier for the new status report"
    },
    {
      "inputId": "status",
      "fieldRef": "StatusReport.status",
      "required": true,
      "source": "systemDefault",
      "description": "Initial lifecycle status set to draft on generation"
    },
    {
      "inputId": "generatedAt",
      "fieldRef": "StatusReport.generatedAt",
      "required": true,
      "source": "systemDefault",
      "description": "Timestamp when the AI generated the initial report content"
    },
    {
      "inputId": "createdAt",
      "fieldRef": "StatusReport.createdAt",
      "required": true,
      "source": "systemDefault",
      "description": "Record creation timestamp"
    },
    {
      "inputId": "updatedAt",
      "fieldRef": "StatusReport.updatedAt",
      "required": true,
      "source": "systemDefault",
      "description": "Last update timestamp set at creation"
    }
  ],
  "contextResolution": [
    {
      "inputId": "projectId",
      "targetRef": "StatusReport.projectId",
      "source": "selectedEntity",
      "originRef": "Project.projectId",
      "description": "Resolved from the project currently selected in the project manager workspace"
    },
    {
      "inputId": "statusReportId",
      "targetRef": "StatusReport.statusReportId",
      "source": "systemDefault",
      "originRef": "systemDefault.uuid",
      "description": "Generated as a new UUID when the status report record is created"
    },
    {
      "inputId": "status",
      "targetRef": "StatusReport.status",
      "source": "systemDefault",
      "originRef": "systemDefault.locale",
      "description": "Set to draft by the create handler as the initial lifecycle state after AI generation"
    },
    {
      "inputId": "generatedAt",
      "targetRef": "StatusReport.generatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Set to the current server timestamp when the LLM finishes generating report content"
    },
    {
      "inputId": "createdAt",
      "targetRef": "StatusReport.createdAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Set to the current server timestamp when the status report record is persisted"
    },
    {
      "inputId": "updatedAt",
      "targetRef": "StatusReport.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Set to the current server timestamp when the status report record is persisted"
    }
  ],
  "acceptanceAssertions": [
    "After confirmation a new StatusReport exists with status draft for the selected project and the provided report period",
    "The StatusReport summary, tasksOverview, timeLogsOverview, materialsOverview, and delayRiskAssessment are populated from live WorkTask, TimeLog, and MaterialUsage data via the platform LLM proxy",
    "generatedAt, createdAt, and updatedAt are set to the generation time and statusReportId is a new system-assigned identifier",
    "Only the project manager can invoke generation; the report remains in draft until the PM reviews it"
  ],
  "pageId": "statusReportLifecycle",
  "commandName": "generateStatusReport",
  "bffName": "buildFlowFsm.statusReportLifecycle.generateStatusReport",
  "capability": {
    "capabilityId": "statusReportLifecycle",
    "title": "Status report lifecycle",
    "actor": "projectManager",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationGenerateStatusReport;
