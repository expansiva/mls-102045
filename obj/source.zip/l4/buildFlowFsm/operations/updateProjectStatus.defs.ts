/// <mls fileReference="_102045_/l4/buildFlowFsm/operations/updateProjectStatus.defs.ts" enhancement="_blank"/>

export const operationUpdateProjectStatus = {
  "operationId": "updateProjectStatus",
  "title": "Update project status",
  "actors": [
    "projectManager"
  ],
  "entity": "Project",
  "kind": "update",
  "reads": [
    "Project"
  ],
  "writes": [
    "Project"
  ],
  "rulesApplied": [
    "projectActivationRequiresCoreFields",
    "jobCostingRequiresBudgetAndSchedule",
    "operationsRequireActiveProject"
  ],
  "story": {
    "actor": "project manager",
    "goal": "Change the lifecycle status of a project so field work, costing, and billing stay aligned with whether the project is active, on hold, closed, or cancelled",
    "steps": [
      "Open the target project",
      "Select the new lifecycle status",
      "Provide hold or cancellation reason when required by the chosen status",
      "Confirm the status change"
    ],
    "outcome": "The project status is updated with any required reason and system timestamps, enabling or blocking field entries, tasks, and change orders according to the new status"
  },
  "accessPattern": {
    "kind": "commandInput",
    "description": "Command form to set a project's lifecycle status and optional hold or cancellation reason",
    "entity": "Project",
    "keyField": "Project.projectId",
    "pagination": "none",
    "selection": "single",
    "output": [
      "Project.projectId",
      "Project.name",
      "Project.status",
      "Project.holdReason",
      "Project.closedAt",
      "Project.cancelledAt",
      "Project.cancellationReason",
      "Project.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "projectId",
        "type": "string",
        "required": true,
        "fieldRef": "Project.projectId"
      },
      {
        "name": "name",
        "type": "string",
        "required": true,
        "fieldRef": "Project.name"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "Project.status"
      },
      {
        "name": "holdReason",
        "type": "string",
        "required": false,
        "fieldRef": "Project.holdReason"
      },
      {
        "name": "closedAt",
        "type": "string",
        "required": false,
        "fieldRef": "Project.closedAt"
      },
      {
        "name": "cancelledAt",
        "type": "string",
        "required": false,
        "fieldRef": "Project.cancelledAt"
      },
      {
        "name": "cancellationReason",
        "type": "string",
        "required": false,
        "fieldRef": "Project.cancellationReason"
      },
      {
        "name": "updatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "Project.updatedAt"
      }
    ]
  },
  "inputs": [
    {
      "inputId": "projectId",
      "fieldRef": "Project.projectId",
      "required": true,
      "source": "routeParam",
      "description": "Identifier of the project whose status is being updated"
    },
    {
      "inputId": "status",
      "fieldRef": "Project.status",
      "required": true,
      "source": "userInput",
      "description": "New lifecycle status for the project (registered, active, onHold, closed, or cancelled)"
    },
    {
      "inputId": "holdReason",
      "fieldRef": "Project.holdReason",
      "required": false,
      "source": "userInput",
      "description": "Reason recorded when the project is placed on hold"
    },
    {
      "inputId": "cancellationReason",
      "fieldRef": "Project.cancellationReason",
      "required": false,
      "source": "userInput",
      "description": "Reason recorded when the project is cancelled"
    }
  ],
  "contextResolution": [
    {
      "inputId": "projectId",
      "targetRef": "Project.projectId",
      "source": "routeParam",
      "originRef": "routeParam.projectId",
      "description": "Resolves the project id from the project detail route parameter"
    },
    {
      "targetRef": "Project.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Server timestamp applied whenever the status change is persisted"
    },
    {
      "targetRef": "Project.closedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Server timestamp set when the new status is closed"
    },
    {
      "targetRef": "Project.cancelledAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Server timestamp set when the new status is cancelled"
    }
  ],
  "acceptanceAssertions": [
    "After confirmation the project exists with the selected status value",
    "When status is set to active, the project must already have name, clientId, and siteAddress or the update is rejected",
    "When status is set to active, the project must already have budget, startDate, and endDate or the update is rejected",
    "When status is set to onHold, holdReason is stored on the project",
    "When status is set to closed, closedAt is set to the server timestamp",
    "When status is set to cancelled, cancelledAt is set to the server timestamp and cancellationReason is stored",
    "After any successful status change, updatedAt reflects the time of the update",
    "Only an active project status allows subsequent field entries, tasks, and change orders against the project"
  ],
  "pageId": "projectLifecycle",
  "commandName": "updateProjectStatus",
  "bffName": "buildFlowFsm.projectLifecycle.updateProjectStatus",
  "capability": {
    "capabilityId": "projectLifecycle",
    "title": "Project lifecycle",
    "actor": "projectManager",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationUpdateProjectStatus;
