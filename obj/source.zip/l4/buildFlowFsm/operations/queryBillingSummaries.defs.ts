/// <mls fileReference="_102045_/l4/buildFlowFsm/operations/queryBillingSummaries.defs.ts" enhancement="_blank"/>

export const operationQueryBillingSummaries = {
  "operationId": "queryBillingSummaries",
  "title": "Browse billing summaries",
  "actors": [
    "billingStaff"
  ],
  "entity": "BillingSummary",
  "kind": "query",
  "reads": [
    "BillingSummary",
    "Project"
  ],
  "writes": [],
  "rulesApplied": [
    "onlyApprovedChangeOrdersAffectCosting",
    "billingSummaryClientFacing"
  ],
  "story": {
    "actor": "billingStaff",
    "goal": "Browse existing billing summaries to find and open the cost breakdown for a project period",
    "steps": [
      "Open the billing summaries list",
      "Optionally filter by project and status",
      "Review period dates and labor, material, change-order, and total costs for each summary",
      "Select a summary to continue compiling or sharing"
    ],
    "outcome": "Billing staff sees a clear list of billing summaries with client-facing cost totals so they can pick the right record to work on"
  },
  "accessPattern": {
    "kind": "list",
    "description": "Paginated list of billing summaries for billing staff, filterable by project and lifecycle status",
    "entity": "BillingSummary",
    "keyField": "BillingSummary.billingSummaryId",
    "filters": [
      "BillingSummary.projectId",
      "BillingSummary.status"
    ],
    "sort": [
      "BillingSummary.periodStart",
      "BillingSummary.createdAt"
    ],
    "pagination": "optional",
    "selection": "single",
    "output": [
      "BillingSummary.billingSummaryId",
      "BillingSummary.projectId",
      "Project.name",
      "BillingSummary.status",
      "BillingSummary.periodStart",
      "BillingSummary.periodEnd",
      "BillingSummary.laborCost",
      "BillingSummary.materialCost",
      "BillingSummary.changeOrderCost",
      "BillingSummary.totalCost",
      "BillingSummary.sharedAt",
      "BillingSummary.createdAt",
      "BillingSummary.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "paginated",
    "fields": [
      {
        "name": "billingSummaries",
        "type": "array",
        "required": true,
        "item": {
          "fields": [
            {
              "name": "billingSummaryId",
              "type": "string",
              "required": true,
              "fieldRef": "BillingSummary.billingSummaryId"
            },
            {
              "name": "projectId",
              "type": "string",
              "required": true,
              "fieldRef": "BillingSummary.projectId"
            },
            {
              "name": "projectName",
              "type": "string",
              "required": true,
              "fieldRef": "Project.name"
            },
            {
              "name": "status",
              "type": "string",
              "required": true,
              "fieldRef": "BillingSummary.status"
            },
            {
              "name": "periodStart",
              "type": "string",
              "required": true,
              "fieldRef": "BillingSummary.periodStart"
            },
            {
              "name": "periodEnd",
              "type": "string",
              "required": true,
              "fieldRef": "BillingSummary.periodEnd"
            },
            {
              "name": "laborCost",
              "type": "number",
              "required": true,
              "fieldRef": "BillingSummary.laborCost"
            },
            {
              "name": "materialCost",
              "type": "number",
              "required": true,
              "fieldRef": "BillingSummary.materialCost"
            },
            {
              "name": "changeOrderCost",
              "type": "number",
              "required": true,
              "fieldRef": "BillingSummary.changeOrderCost"
            },
            {
              "name": "totalCost",
              "type": "number",
              "required": true,
              "fieldRef": "BillingSummary.totalCost"
            },
            {
              "name": "sharedAt",
              "type": "string",
              "required": false,
              "fieldRef": "BillingSummary.sharedAt"
            },
            {
              "name": "createdAt",
              "type": "string",
              "required": true,
              "fieldRef": "BillingSummary.createdAt"
            },
            {
              "name": "updatedAt",
              "type": "string",
              "required": true,
              "fieldRef": "BillingSummary.updatedAt"
            }
          ]
        }
      },
      {
        "name": "total",
        "type": "number",
        "required": true
      }
    ]
  },
  "inputs": [
    {
      "inputId": "projectId",
      "fieldRef": "BillingSummary.projectId",
      "required": false,
      "source": "userInput",
      "description": "Optional filter to list billing summaries for a specific project"
    },
    {
      "inputId": "status",
      "fieldRef": "BillingSummary.status",
      "required": false,
      "source": "userInput",
      "description": "Optional filter by billing summary lifecycle status (draft or shared)"
    },
    {
      "inputId": "page",
      "type": "number",
      "required": false,
      "source": "userInput",
      "description": "1-based page index for paginated results"
    },
    {
      "inputId": "pageSize",
      "type": "number",
      "required": false,
      "source": "userInput",
      "description": "Number of billing summaries per page"
    }
  ],
  "contextResolution": [],
  "acceptanceAssertions": [
    "Billing staff receives a paginated list of billing summaries with period dates and labor, material, change-order, and total costs for each item",
    "Each listed summary includes project identity (projectId and project name) so staff can tell which job the summary belongs to",
    "Listed cost totals reflect only approved change orders; pending or rejected change orders do not appear in changeOrderCost or totalCost",
    "Billing summary rows expose only client-facing cost fields and never internal material cost-code detail",
    "Optional filters by projectId and status narrow the list to matching BillingSummary records",
    "When page and pageSize are provided, the response total equals the full match count and billingSummaries contains at most pageSize items"
  ],
  "pageId": "queryBillingSummaries",
  "commandName": "queryBillingSummaries",
  "bffName": "buildFlowFsm.queryBillingSummaries.queryBillingSummaries",
  "capability": {
    "capabilityId": "queryBillingSummaries",
    "title": "Browse billing summaries",
    "actor": "billingStaff",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationQueryBillingSummaries;
