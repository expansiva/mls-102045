/// <mls fileReference="_102045_/l4/buildFlowFsm/operations/updateClient.defs.ts" enhancement="_blank"/>

export const operationUpdateClient = {
  "operationId": "updateClient",
  "title": "Update client",
  "actors": [
    "projectManager"
  ],
  "entity": "Client",
  "kind": "update",
  "reads": [
    "Client"
  ],
  "writes": [
    "Client"
  ],
  "rulesApplied": [],
  "story": {
    "actor": "projectManager",
    "goal": "Correct or complete an existing client record so project and billing communications use accurate contact details",
    "steps": [
      "Open the existing client record to edit",
      "Change name, company, email, phone, and/or address as needed",
      "Save the updates to the client master data"
    ],
    "outcome": "The client record is updated with the new details and an updated timestamp, ready for use on projects and outbound communications"
  },
  "accessPattern": {
    "kind": "commandInput",
    "description": "Form to edit an existing client master-data record identified by clientId",
    "entity": "Client",
    "keyField": "Client.clientId",
    "pagination": "none",
    "selection": "single",
    "output": [
      "Client.clientId",
      "Client.name",
      "Client.company",
      "Client.email",
      "Client.phone",
      "Client.address",
      "Client.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "clientId",
        "type": "string",
        "required": true,
        "fieldRef": "Client.clientId"
      },
      {
        "name": "name",
        "type": "string",
        "required": true,
        "fieldRef": "Client.name"
      },
      {
        "name": "company",
        "type": "string",
        "required": false,
        "fieldRef": "Client.company"
      },
      {
        "name": "email",
        "type": "string",
        "required": true,
        "fieldRef": "Client.email"
      },
      {
        "name": "phone",
        "type": "string",
        "required": false,
        "fieldRef": "Client.phone"
      },
      {
        "name": "address",
        "type": "string",
        "required": false,
        "fieldRef": "Client.address"
      },
      {
        "name": "createdAt",
        "type": "string",
        "required": true,
        "fieldRef": "Client.createdAt"
      },
      {
        "name": "updatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "Client.updatedAt"
      }
    ]
  },
  "inputs": [
    {
      "inputId": "clientId",
      "fieldRef": "Client.clientId",
      "required": true,
      "source": "routeParam",
      "description": "Identifier of the client record to update"
    },
    {
      "inputId": "name",
      "fieldRef": "Client.name",
      "required": true,
      "source": "userInput",
      "description": "Updated display name of the client"
    },
    {
      "inputId": "company",
      "fieldRef": "Client.company",
      "required": false,
      "source": "userInput",
      "description": "Updated legal or trading name of the client organization"
    },
    {
      "inputId": "email",
      "fieldRef": "Client.email",
      "required": true,
      "source": "userInput",
      "description": "Updated email for status reports, billing summaries, and invoices"
    },
    {
      "inputId": "phone",
      "fieldRef": "Client.phone",
      "required": false,
      "source": "userInput",
      "description": "Updated contact phone number"
    },
    {
      "inputId": "address",
      "fieldRef": "Client.address",
      "required": false,
      "source": "userInput",
      "description": "Updated postal or billing address"
    },
    {
      "inputId": "updatedAt",
      "fieldRef": "Client.updatedAt",
      "required": true,
      "source": "systemDefault",
      "description": "Timestamp set automatically when the client record is saved"
    }
  ],
  "contextResolution": [
    {
      "inputId": "clientId",
      "targetRef": "Client.clientId",
      "source": "routeParam",
      "originRef": "routeParam.clientId",
      "description": "Resolved from the clientId route parameter identifying the client being edited"
    },
    {
      "inputId": "updatedAt",
      "targetRef": "Client.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Server sets updatedAt to the current timestamp when the update is persisted"
    }
  ],
  "acceptanceAssertions": [
    "After confirmation the client record identified by clientId still exists with the submitted name and email values",
    "Optional fields company, phone, and address are stored exactly as submitted when provided",
    "Client.updatedAt is refreshed to the time of the update while Client.createdAt remains unchanged",
    "The updated client name and contact details are available for selection when entering project basics"
  ],
  "pageId": "updateClient",
  "commandName": "updateClient",
  "bffName": "buildFlowFsm.updateClient.updateClient",
  "capability": {
    "capabilityId": "updateClient",
    "title": "Update client",
    "actor": "projectManager",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationUpdateClient;
