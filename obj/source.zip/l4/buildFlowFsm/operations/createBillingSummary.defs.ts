/// <mls fileReference="_102045_/l4/buildFlowFsm/operations/createBillingSummary.defs.ts" enhancement="_blank"/>

export const operationCreateBillingSummary = {
  "operationId": "createBillingSummary",
  "title": "Create billing summary",
  "actors": [
    "billingStaff"
  ],
  "entity": "BillingSummary",
  "kind": "create",
  "reads": [
    "Project",
    "TimeLog",
    "MaterialUsage",
    "ChangeOrder",
    "WorkTask"
  ],
  "writes": [
    "BillingSummary"
  ],
  "rulesApplied": [
    "onlyApprovedChangeOrdersAffectCosting",
    "billingSummaryClientFacing"
  ],
  "story": {
    "actor": "Billing staff",
    "goal": "Compile a client-facing billing summary of labor, material, and approved change order costs for a project billing period",
    "steps": [
      "Open the project billing context",
      "Choose the billing period start and end dates",
      "Review accumulated labor, material, and approved change order costs for that period",
      "Confirm creation of the billing summary in draft status"
    ],
    "outcome": "A draft billing summary exists with labor, material, approved change order, and total costs compiled for the selected period, ready to share with the client"
  },
  "accessPattern": {
    "kind": "commandInput",
    "description": "Form input to create a draft billing summary for a project over a chosen billing period, with costs derived from job data",
    "entity": "BillingSummary",
    "keyField": "BillingSummary.billingSummaryId",
    "pagination": "none",
    "selection": "none",
    "output": [
      "BillingSummary.billingSummaryId",
      "BillingSummary.projectId",
      "BillingSummary.status",
      "BillingSummary.periodStart",
      "BillingSummary.periodEnd",
      "BillingSummary.laborCost",
      "BillingSummary.materialCost",
      "BillingSummary.changeOrderCost",
      "BillingSummary.totalCost",
      "BillingSummary.createdAt",
      "BillingSummary.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "billingSummaryId",
        "type": "string",
        "required": true,
        "fieldRef": "BillingSummary.billingSummaryId"
      },
      {
        "name": "projectId",
        "type": "string",
        "required": true,
        "fieldRef": "BillingSummary.projectId"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "BillingSummary.status"
      },
      {
        "name": "periodStart",
        "type": "string",
        "required": true,
        "fieldRef": "BillingSummary.periodStart"
      },
      {
        "name": "periodEnd",
        "type": "string",
        "required": true,
        "fieldRef": "BillingSummary.periodEnd"
      },
      {
        "name": "laborCost",
        "type": "number",
        "required": true,
        "fieldRef": "BillingSummary.laborCost"
      },
      {
        "name": "materialCost",
        "type": "number",
        "required": true,
        "fieldRef": "BillingSummary.materialCost"
      },
      {
        "name": "changeOrderCost",
        "type": "number",
        "required": true,
        "fieldRef": "BillingSummary.changeOrderCost"
      },
      {
        "name": "totalCost",
        "type": "number",
        "required": true,
        "fieldRef": "BillingSummary.totalCost"
      },
      {
        "name": "createdAt",
        "type": "string",
        "required": true,
        "fieldRef": "BillingSummary.createdAt"
      },
      {
        "name": "updatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "BillingSummary.updatedAt"
      }
    ]
  },
  "inputs": [
    {
      "inputId": "projectId",
      "fieldRef": "BillingSummary.projectId",
      "required": true,
      "source": "routeParam",
      "description": "Project for which the billing summary is compiled"
    },
    {
      "inputId": "periodStart",
      "fieldRef": "BillingSummary.periodStart",
      "required": true,
      "source": "userInput",
      "description": "Start date of the billing period to include in the summary"
    },
    {
      "inputId": "periodEnd",
      "fieldRef": "BillingSummary.periodEnd",
      "required": true,
      "source": "userInput",
      "description": "End date of the billing period to include in the summary"
    },
    {
      "inputId": "billingSummaryId",
      "fieldRef": "BillingSummary.billingSummaryId",
      "required": true,
      "source": "systemDefault",
      "description": "Server-generated primary key for the new billing summary"
    },
    {
      "inputId": "createdAt",
      "fieldRef": "BillingSummary.createdAt",
      "required": true,
      "source": "systemDefault",
      "description": "Server timestamp when the billing summary is created"
    },
    {
      "inputId": "updatedAt",
      "fieldRef": "BillingSummary.updatedAt",
      "required": true,
      "source": "systemDefault",
      "description": "Server timestamp of the initial billing summary write"
    }
  ],
  "contextResolution": [
    {
      "inputId": "projectId",
      "targetRef": "BillingSummary.projectId",
      "source": "routeParam",
      "originRef": "routeParam.projectId",
      "description": "Resolve the project from the projectId route parameter on the billing screen"
    },
    {
      "inputId": "billingSummaryId",
      "targetRef": "BillingSummary.billingSummaryId",
      "source": "systemDefault",
      "originRef": "systemDefault.uuid",
      "description": "Generate a new UUID for the billing summary primary key"
    },
    {
      "inputId": "createdAt",
      "targetRef": "BillingSummary.createdAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Set createdAt to the current server time at insert"
    },
    {
      "inputId": "updatedAt",
      "targetRef": "BillingSummary.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Set updatedAt to the current server time at insert"
    }
  ],
  "acceptanceAssertions": [
    "After confirmation a BillingSummary record exists for the given projectId with status draft",
    "periodStart and periodEnd on the created summary match the dates provided by billing staff",
    "laborCost equals the sum of laborCost from non-voided TimeLogs linked to the project's work tasks within the billing period",
    "materialCost equals the sum of quantity times unitCost from non-voided MaterialUsage records for the project within the billing period",
    "changeOrderCost includes only ChangeOrders for the project with status approved; pending and rejected change orders are excluded",
    "totalCost equals laborCost plus materialCost plus changeOrderCost",
    "The created billing summary does not expose internal material cost-code detail to the client-facing payload",
    "sharedAt is not set on creation while the summary remains in draft status"
  ],
  "pageId": "billingSummaryLifecycle",
  "commandName": "createBillingSummary",
  "bffName": "buildFlowFsm.billingSummaryLifecycle.createBillingSummary",
  "capability": {
    "capabilityId": "billingSummaryLifecycle",
    "title": "Billing summary lifecycle",
    "actor": "billingStaff",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationCreateBillingSummary;
