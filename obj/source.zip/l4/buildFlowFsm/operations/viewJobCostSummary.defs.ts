/// <mls fileReference="_102045_/l4/buildFlowFsm/operations/viewJobCostSummary.defs.ts" enhancement="_blank"/>

export const operationViewJobCostSummary = {
  "operationId": "viewJobCostSummary",
  "title": "View job cost summary",
  "actors": [
    "billingStaff"
  ],
  "entity": "Project",
  "kind": "query",
  "reads": [
    "Project",
    "Client",
    "WorkTask",
    "TimeLog",
    "MaterialUsage",
    "ChangeOrder"
  ],
  "writes": [],
  "rulesApplied": [
    "jobCostingRequiresBudgetAndSchedule"
  ],
  "story": {
    "actor": "Billing staff",
    "goal": "Review accumulated labor, material, and approved change-order costs for a project against its budget before preparing billing",
    "steps": [
      "Open the job cost summary for a selected project",
      "See project identity, budget, and lifecycle status",
      "Review aggregated labor cost from non-voided time logs",
      "Review aggregated material cost from non-voided material usage",
      "Review aggregated cost from approved change orders",
      "Compare total actual cost to the project budget"
    ],
    "outcome": "Billing staff has an accurate cost basis showing labor, material, change-order, and total costs versus budget for the project"
  },
  "accessPattern": {
    "kind": "getById",
    "description": "Load one project by id and return its job cost summary with aggregated labor, material, and approved change-order costs",
    "entity": "Project",
    "keyField": "Project.projectId",
    "pagination": "none",
    "selection": "none",
    "output": [
      "Project.projectId",
      "Project.name",
      "Project.clientId",
      "Project.budget",
      "Project.status",
      "Project.startDate",
      "Project.endDate"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "projectId",
        "type": "string",
        "required": true,
        "fieldRef": "Project.projectId"
      },
      {
        "name": "name",
        "type": "string",
        "required": true,
        "fieldRef": "Project.name"
      },
      {
        "name": "clientId",
        "type": "string",
        "required": true,
        "fieldRef": "Project.clientId"
      },
      {
        "name": "clientName",
        "type": "string",
        "required": true,
        "fieldRef": "Client.name"
      },
      {
        "name": "budget",
        "type": "number",
        "required": true,
        "fieldRef": "Project.budget"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "Project.status"
      },
      {
        "name": "startDate",
        "type": "string",
        "required": true,
        "fieldRef": "Project.startDate"
      },
      {
        "name": "endDate",
        "type": "string",
        "required": true,
        "fieldRef": "Project.endDate"
      },
      {
        "name": "laborCost",
        "type": "number",
        "required": true
      },
      {
        "name": "materialCost",
        "type": "number",
        "required": true
      },
      {
        "name": "changeOrderCost",
        "type": "number",
        "required": true
      },
      {
        "name": "totalCost",
        "type": "number",
        "required": true
      },
      {
        "name": "budgetVariance",
        "type": "number",
        "required": true
      }
    ]
  },
  "inputs": [
    {
      "inputId": "projectId",
      "fieldRef": "Project.projectId",
      "required": true,
      "source": "routeParam",
      "description": "Identifier of the project whose job cost summary is displayed"
    }
  ],
  "contextResolution": [
    {
      "inputId": "projectId",
      "targetRef": "Project.projectId",
      "source": "routeParam",
      "originRef": "routeParam.projectId",
      "description": "Resolves the project from the projectId route parameter when the job cost summary screen is opened"
    }
  ],
  "acceptanceAssertions": [
    "After opening the summary, the response includes the project id, name, budget, and status for the requested project",
    "Labor cost equals the sum of laborCost from non-voided time logs linked to the project's work tasks",
    "Material cost equals the sum of quantity times unitCost from non-voided material usage records for the project",
    "Change order cost equals the sum of costAdjustment from change orders on the project that are in approved status",
    "Total cost equals labor cost plus material cost plus change order cost",
    "Budget variance equals project budget minus total cost",
    "Job cost aggregation is only returned when the project has budget and schedule dates set"
  ],
  "pageId": "viewJobCostSummary",
  "commandName": "viewJobCostSummary",
  "bffName": "buildFlowFsm.viewJobCostSummary.viewJobCostSummary",
  "capability": {
    "capabilityId": "viewJobCostSummary",
    "title": "View job cost summary",
    "actor": "billingStaff",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationViewJobCostSummary;
