/// <mls fileReference="_102045_/l4/buildFlowFsm/workspaces/jobCostWorkspace.defs.ts" enhancement="_blank"/>

export const jobCostWorkspaceWorkspace = {
  "workspaceId": "jobCostWorkspace",
  "title": "Job Cost Summary",
  "actors": [
    "billingStaff"
  ],
  "kind": "operation",
  "entity": "Project",
  "bffCalls": [
    {
      "bffId": "viewJobCostSummary",
      "kind": "query",
      "uses": [
        {
          "operationId": "viewJobCostSummary"
        }
      ],
      "input": [
        {
          "name": "projectId",
          "from": "viewJobCostSummary.projectId",
          "type": "string",
          "required": true
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "projectId",
            "from": "viewJobCostSummary.projectId",
            "type": "string",
            "required": true
          },
          {
            "name": "name",
            "from": "viewJobCostSummary.name",
            "type": "string",
            "required": true
          },
          {
            "name": "clientId",
            "from": "viewJobCostSummary.clientId",
            "type": "string",
            "required": true
          },
          {
            "name": "clientName",
            "from": "viewJobCostSummary.clientName",
            "type": "string",
            "required": true
          },
          {
            "name": "budget",
            "from": "viewJobCostSummary.budget",
            "type": "number",
            "required": true
          },
          {
            "name": "status",
            "from": "viewJobCostSummary.status",
            "type": "string",
            "required": true
          },
          {
            "name": "startDate",
            "from": "viewJobCostSummary.startDate",
            "type": "string",
            "required": true
          },
          {
            "name": "endDate",
            "from": "viewJobCostSummary.endDate",
            "type": "string",
            "required": true
          },
          {
            "name": "laborCost",
            "from": "viewJobCostSummary.laborCost",
            "type": "number",
            "required": true
          },
          {
            "name": "materialCost",
            "from": "viewJobCostSummary.materialCost",
            "type": "number",
            "required": true
          },
          {
            "name": "changeOrderCost",
            "from": "viewJobCostSummary.changeOrderCost",
            "type": "number",
            "required": true
          },
          {
            "name": "totalCost",
            "from": "viewJobCostSummary.totalCost",
            "type": "number",
            "required": true
          },
          {
            "name": "budgetVariance",
            "from": "viewJobCostSummary.budgetVariance",
            "type": "number",
            "required": true
          }
        ]
      },
      "route": "buildFlowFsm.jobCostWorkspace.viewJobCostSummary"
    }
  ],
  "sections": [
    {
      "sectionId": "costSummary",
      "intent": "Billing staff reviews the project's identity, budget, aggregated labor/material/change-order costs and budget variance before preparing billing documents.",
      "organisms": [
        {
          "role": "primarySurface",
          "dataSource": "viewJobCostSummary"
        }
      ]
    }
  ],
  "operationIds": [
    "viewJobCostSummary"
  ],
  "purpose": "Billing staff reviews accumulated job costs per project before preparing billing documents.",
  "presentation": {
    "categoryRef": "readOnlyDetailPortal",
    "confidence": 9,
    "classificationNote": "Single-record read-only view with aggregated cost fields (labor, material, change orders, total, variance) and no write operations. The actor reviews the summary before acting in a separate billing workspace. Fits readOnlyDetailPortal: summary-first, no writes, stakeholder consultation.",
    "alternates": [
      {
        "categoryRef": "dashboardCommandCenter",
        "confidence": 4,
        "reason": "Has aggregated cost metrics but no alerts, trends or recommended actions — it is a single-record detail, not a monitoring dashboard."
      }
    ]
  },
  "sliceHash": "djb2:8c7b5537"
} as const;

export default jobCostWorkspaceWorkspace;
