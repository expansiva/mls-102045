/// <mls fileReference="_102045_/l4/buildFlowFsm/workspaces/clientManagementWorkspace.defs.ts" enhancement="_blank"/>

export const clientManagementWorkspaceWorkspace = {
  "workspaceId": "clientManagementWorkspace",
  "title": "Client Directory",
  "actors": [
    "projectManager"
  ],
  "kind": "entityManagement",
  "entity": "Client",
  "bffCalls": [
    {
      "bffId": "listClients",
      "kind": "query",
      "uses": [
        {
          "operationId": "queryClients"
        }
      ],
      "input": [
        {
          "name": "name",
          "from": "queryClients.name",
          "type": "string"
        },
        {
          "name": "company",
          "from": "queryClients.company",
          "type": "string"
        },
        {
          "name": "email",
          "from": "queryClients.email",
          "type": "string"
        },
        {
          "name": "page",
          "from": "queryClients.page",
          "type": "number"
        },
        {
          "name": "pageSize",
          "from": "queryClients.pageSize",
          "type": "number"
        }
      ],
      "output": {
        "kind": "paginated",
        "fields": [
          {
            "name": "clients",
            "from": "queryClients.clients",
            "type": "array",
            "item": {
              "fields": [
                {
                  "name": "clientId",
                  "from": "queryClients.clients.$items.clientId",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "name",
                  "from": "queryClients.clients.$items.name",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "company",
                  "from": "queryClients.clients.$items.company",
                  "type": "string"
                },
                {
                  "name": "email",
                  "from": "queryClients.clients.$items.email",
                  "type": "string"
                },
                {
                  "name": "phone",
                  "from": "queryClients.clients.$items.phone",
                  "type": "string"
                },
                {
                  "name": "address",
                  "from": "queryClients.clients.$items.address",
                  "type": "string"
                },
                {
                  "name": "createdAt",
                  "from": "queryClients.clients.$items.createdAt",
                  "type": "string"
                },
                {
                  "name": "updatedAt",
                  "from": "queryClients.clients.$items.updatedAt",
                  "type": "string"
                }
              ]
            }
          },
          {
            "name": "total",
            "from": "queryClients.total",
            "type": "number",
            "required": true
          }
        ]
      },
      "route": "buildFlowFsm.clientManagementWorkspace.listClients"
    },
    {
      "bffId": "createClientCmd",
      "kind": "command",
      "uses": [
        {
          "operationId": "createClient"
        }
      ],
      "input": [
        {
          "name": "name",
          "from": "createClient.name",
          "type": "string",
          "required": true,
          "source": "userDecision"
        },
        {
          "name": "email",
          "from": "createClient.email",
          "type": "string",
          "required": true,
          "source": "userDecision"
        },
        {
          "name": "company",
          "from": "createClient.company",
          "type": "string",
          "source": "userDecision"
        },
        {
          "name": "phone",
          "from": "createClient.phone",
          "type": "string",
          "source": "userDecision"
        },
        {
          "name": "address",
          "from": "createClient.address",
          "type": "string",
          "source": "userDecision"
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "clientId",
            "from": "createClient.clientId",
            "type": "string",
            "required": true
          },
          {
            "name": "name",
            "from": "createClient.name",
            "type": "string"
          },
          {
            "name": "company",
            "from": "createClient.company",
            "type": "string"
          },
          {
            "name": "email",
            "from": "createClient.email",
            "type": "string"
          },
          {
            "name": "phone",
            "from": "createClient.phone",
            "type": "string"
          },
          {
            "name": "address",
            "from": "createClient.address",
            "type": "string"
          },
          {
            "name": "createdAt",
            "from": "createClient.createdAt",
            "type": "string"
          },
          {
            "name": "updatedAt",
            "from": "createClient.updatedAt",
            "type": "string"
          }
        ]
      },
      "route": "buildFlowFsm.clientManagementWorkspace.createClientCmd"
    },
    {
      "bffId": "updateClientCmd",
      "kind": "command",
      "uses": [
        {
          "operationId": "updateClient"
        }
      ],
      "input": [
        {
          "name": "clientId",
          "from": "updateClient.clientId",
          "type": "string",
          "required": true,
          "source": "selection",
          "sourceRef": "listClients"
        },
        {
          "name": "name",
          "from": "updateClient.name",
          "type": "string",
          "source": "userDecision"
        },
        {
          "name": "company",
          "from": "updateClient.company",
          "type": "string",
          "source": "userDecision"
        },
        {
          "name": "email",
          "from": "updateClient.email",
          "type": "string",
          "source": "userDecision"
        },
        {
          "name": "phone",
          "from": "updateClient.phone",
          "type": "string",
          "source": "userDecision"
        },
        {
          "name": "address",
          "from": "updateClient.address",
          "type": "string",
          "source": "userDecision"
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "clientId",
            "from": "updateClient.clientId",
            "type": "string",
            "required": true
          },
          {
            "name": "name",
            "from": "updateClient.name",
            "type": "string"
          },
          {
            "name": "company",
            "from": "updateClient.company",
            "type": "string"
          },
          {
            "name": "email",
            "from": "updateClient.email",
            "type": "string"
          },
          {
            "name": "phone",
            "from": "updateClient.phone",
            "type": "string"
          },
          {
            "name": "address",
            "from": "updateClient.address",
            "type": "string"
          },
          {
            "name": "updatedAt",
            "from": "updateClient.updatedAt",
            "type": "string"
          }
        ]
      },
      "route": "buildFlowFsm.clientManagementWorkspace.updateClientCmd"
    },
    {
      "bffId": "deleteClientCmd",
      "kind": "command",
      "uses": [
        {
          "operationId": "deleteClient"
        }
      ],
      "input": [
        {
          "name": "clientId",
          "from": "deleteClient.clientId",
          "type": "string",
          "required": true,
          "source": "selection",
          "sourceRef": "listClients"
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "clientId",
            "from": "deleteClient.clientId",
            "type": "string",
            "required": true
          },
          {
            "name": "name",
            "from": "deleteClient.name",
            "type": "string"
          }
        ]
      },
      "route": "buildFlowFsm.clientManagementWorkspace.deleteClientCmd"
    }
  ],
  "sections": [
    {
      "sectionId": "clientListSection",
      "intent": "Browse, search and manage all clients in the directory",
      "organisms": [
        {
          "role": "filterControl",
          "attachTo": "listClients"
        },
        {
          "role": "primarySurface",
          "dataSource": "listClients"
        },
        {
          "role": "contextualAction",
          "action": "createClientCmd"
        },
        {
          "role": "contextualAction",
          "action": "updateClientCmd"
        },
        {
          "role": "contextualAction",
          "action": "deleteClientCmd"
        }
      ]
    }
  ],
  "operationIds": [
    "queryClients",
    "createClient",
    "updateClient",
    "deleteClient"
  ],
  "purpose": "Project manager maintains the client directory used across projects.",
  "presentation": {
    "categoryRef": "customerManagement",
    "confidence": 9,
    "classificationNote": "Entity is Client (equivalent to Customer in project management context): list, search, create, edit, delete — a textbook customer/contact directory management pattern.",
    "alternates": [
      {
        "categoryRef": "masterDataManagement",
        "confidence": 5,
        "reason": "Clients serve as master data referenced across projects, but the interaction pattern (search, create, edit, delete a contact record) fits customerManagement more precisely."
      }
    ]
  },
  "sliceHash": "djb2:27aea603"
} as const;

export default clientManagementWorkspaceWorkspace;
