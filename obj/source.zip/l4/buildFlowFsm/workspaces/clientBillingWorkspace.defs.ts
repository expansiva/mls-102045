/// <mls fileReference="_102045_/l4/buildFlowFsm/workspaces/clientBillingWorkspace.defs.ts" enhancement="_blank"/>

export const clientBillingWorkspaceWorkspace = {
  "workspaceId": "clientBillingWorkspace",
  "title": "My Billing",
  "actors": [
    "client"
  ],
  "kind": "operation",
  "entity": "BillingSummary",
  "bffCalls": [
    {
      "bffId": "getBillingSummary",
      "kind": "query",
      "uses": [
        {
          "operationId": "viewBillingSummary"
        }
      ],
      "input": [
        {
          "name": "billingSummaryId",
          "from": "viewBillingSummary.billingSummaryId",
          "required": true,
          "source": "pageInput"
        },
        {
          "name": "clientId",
          "from": "viewBillingSummary.clientId",
          "required": true,
          "source": "actorSession"
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "billingSummaryId",
            "from": "viewBillingSummary.billingSummaryId",
            "type": "string",
            "required": true
          },
          {
            "name": "projectId",
            "from": "viewBillingSummary.projectId",
            "type": "string"
          },
          {
            "name": "projectName",
            "from": "viewBillingSummary.projectName",
            "type": "string"
          },
          {
            "name": "status",
            "from": "viewBillingSummary.status",
            "type": "string"
          },
          {
            "name": "periodStart",
            "from": "viewBillingSummary.periodStart",
            "type": "string"
          },
          {
            "name": "periodEnd",
            "from": "viewBillingSummary.periodEnd",
            "type": "string"
          },
          {
            "name": "laborCost",
            "from": "viewBillingSummary.laborCost",
            "type": "number"
          },
          {
            "name": "materialCost",
            "from": "viewBillingSummary.materialCost",
            "type": "number"
          },
          {
            "name": "changeOrderCost",
            "from": "viewBillingSummary.changeOrderCost",
            "type": "number"
          },
          {
            "name": "totalCost",
            "from": "viewBillingSummary.totalCost",
            "type": "number"
          },
          {
            "name": "sharedAt",
            "from": "viewBillingSummary.sharedAt",
            "type": "string"
          }
        ]
      },
      "route": "buildFlowFsm.clientBillingWorkspace.getBillingSummary"
    },
    {
      "bffId": "getInvoice",
      "kind": "query",
      "uses": [
        {
          "operationId": "viewInvoice"
        }
      ],
      "input": [
        {
          "name": "invoiceId",
          "from": "viewInvoice.invoiceId",
          "required": true,
          "source": "pageInput"
        },
        {
          "name": "clientId",
          "from": "viewInvoice.clientId",
          "required": true,
          "source": "actorSession"
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "invoiceId",
            "from": "viewInvoice.invoiceId",
            "type": "string",
            "required": true
          },
          {
            "name": "projectId",
            "from": "viewInvoice.projectId",
            "type": "string"
          },
          {
            "name": "clientId",
            "from": "viewInvoice.clientId",
            "type": "string"
          },
          {
            "name": "invoiceNumber",
            "from": "viewInvoice.invoiceNumber",
            "type": "string"
          },
          {
            "name": "status",
            "from": "viewInvoice.status",
            "type": "string"
          },
          {
            "name": "totalAmount",
            "from": "viewInvoice.totalAmount",
            "type": "number"
          },
          {
            "name": "sentAt",
            "from": "viewInvoice.sentAt",
            "type": "string"
          },
          {
            "name": "createdAt",
            "from": "viewInvoice.createdAt",
            "type": "string"
          }
        ]
      },
      "route": "buildFlowFsm.clientBillingWorkspace.getInvoice"
    }
  ],
  "sections": [
    {
      "sectionId": "billingSummarySection",
      "intent": "Client reviews the billing summary for the project, including period, cost breakdown, and overall total.",
      "organisms": [
        {
          "role": "primarySurface",
          "dataSource": "getBillingSummary"
        }
      ]
    },
    {
      "sectionId": "invoiceSection",
      "intent": "Client views the invoice details shared by billing staff, including invoice number, status, and total amount.",
      "organisms": [
        {
          "role": "detailPanel",
          "dataSource": "getInvoice"
        },
        {
          "role": "primarySurface",
          "dataSource": "getBillingSummary"
        }
      ]
    }
  ],
  "operationIds": [
    "viewBillingSummary",
    "viewInvoice"
  ],
  "purpose": "Client reviews billing summaries and invoices shared by billing staff.",
  "presentation": {
    "categoryRef": "readOnlyDetailPortal",
    "confidence": 10,
    "classificationNote": "Both operations are read-only views (no write operations at all). The workspace presents a single billing summary record and its associated invoice to an external stakeholder (client) — a textbook read-only detail portal.",
    "alternates": [
      {
        "categoryRef": "financialTransactions",
        "confidence": 4,
        "reason": "The entities (BillingSummary, Invoice) are financial in nature, but there is no list, filter, or any write operation — the interaction pattern is purely a read-only detail view, not a financial transaction list."
      }
    ]
  },
  "sliceHash": "djb2:c9587237"
} as const;

export default clientBillingWorkspaceWorkspace;
