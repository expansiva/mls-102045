/// <mls fileReference="_102045_/l4/buildFlowFsm/workspaces/fieldLoggingWorkspace.defs.ts" enhancement="_blank"/>

export const fieldLoggingWorkspaceWorkspace = {
  "workspaceId": "fieldLoggingWorkspace",
  "title": "Log Time & Materials",
  "actors": [
    "fieldWorker"
  ],
  "kind": "operation",
  "entity": "TimeLog",
  "bffCalls": [
    {
      "bffId": "submitTimeLog",
      "kind": "command",
      "uses": [
        {
          "operationId": "createTimeLog"
        }
      ],
      "input": [
        {
          "name": "workTaskId",
          "from": "createTimeLog.workTaskId",
          "required": true,
          "source": "selection",
          "sourceRef": "listActiveTasksForTime"
        },
        {
          "name": "logDate",
          "from": "createTimeLog.logDate",
          "required": true,
          "source": "userDecision"
        },
        {
          "name": "hoursWorked",
          "from": "createTimeLog.hoursWorked",
          "required": true,
          "source": "userDecision"
        },
        {
          "name": "workerName",
          "from": "createTimeLog.workerName",
          "required": true,
          "source": "actorSession"
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "timeLogId",
            "from": "createTimeLog.timeLogId",
            "type": "string"
          },
          {
            "name": "workTaskId",
            "from": "createTimeLog.workTaskId",
            "type": "string"
          },
          {
            "name": "workerName",
            "from": "createTimeLog.workerName",
            "type": "string"
          },
          {
            "name": "logDate",
            "from": "createTimeLog.logDate",
            "type": "string"
          },
          {
            "name": "hoursWorked",
            "from": "createTimeLog.hoursWorked",
            "type": "number"
          },
          {
            "name": "laborCost",
            "from": "createTimeLog.laborCost",
            "type": "number"
          },
          {
            "name": "status",
            "from": "createTimeLog.status",
            "type": "string"
          },
          {
            "name": "createdAt",
            "from": "createTimeLog.createdAt",
            "type": "string"
          }
        ]
      },
      "route": "buildFlowFsm.fieldLoggingWorkspace.submitTimeLog"
    },
    {
      "bffId": "submitVoidTimeLog",
      "kind": "command",
      "uses": [
        {
          "operationId": "voidTimeLog"
        }
      ],
      "input": [
        {
          "name": "timeLogId",
          "from": "voidTimeLog.timeLogId",
          "required": true,
          "source": "pageInput"
        },
        {
          "name": "voidReason",
          "from": "voidTimeLog.voidReason",
          "required": true,
          "source": "userDecision"
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "timeLogId",
            "from": "voidTimeLog.timeLogId",
            "type": "string"
          },
          {
            "name": "workTaskId",
            "from": "voidTimeLog.workTaskId",
            "type": "string"
          },
          {
            "name": "workerName",
            "from": "voidTimeLog.workerName",
            "type": "string"
          },
          {
            "name": "logDate",
            "from": "voidTimeLog.logDate",
            "type": "string"
          },
          {
            "name": "hoursWorked",
            "from": "voidTimeLog.hoursWorked",
            "type": "number"
          },
          {
            "name": "laborCost",
            "from": "voidTimeLog.laborCost",
            "type": "number"
          },
          {
            "name": "status",
            "from": "voidTimeLog.status",
            "type": "string"
          },
          {
            "name": "voidedAt",
            "from": "voidTimeLog.voidedAt",
            "type": "string"
          },
          {
            "name": "voidReason",
            "from": "voidTimeLog.voidReason",
            "type": "string"
          }
        ]
      },
      "route": "buildFlowFsm.fieldLoggingWorkspace.submitVoidTimeLog"
    },
    {
      "bffId": "submitMaterialUsage",
      "kind": "command",
      "uses": [
        {
          "operationId": "createMaterialUsage"
        }
      ],
      "input": [
        {
          "name": "projectId",
          "from": "createMaterialUsage.projectId",
          "required": true,
          "source": "pageInput"
        },
        {
          "name": "materialName",
          "from": "createMaterialUsage.materialName",
          "required": true,
          "source": "userDecision"
        },
        {
          "name": "quantity",
          "from": "createMaterialUsage.quantity",
          "required": true,
          "source": "userDecision"
        },
        {
          "name": "unit",
          "from": "createMaterialUsage.unit",
          "required": true,
          "source": "userDecision"
        },
        {
          "name": "unitCost",
          "from": "createMaterialUsage.unitCost",
          "required": true,
          "source": "userDecision"
        },
        {
          "name": "costCode",
          "from": "createMaterialUsage.costCode",
          "source": "userDecision"
        },
        {
          "name": "usageDate",
          "from": "createMaterialUsage.usageDate",
          "required": true,
          "source": "userDecision"
        },
        {
          "name": "recordedBy",
          "from": "createMaterialUsage.recordedBy",
          "required": true,
          "source": "actorSession"
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "materialUsageId",
            "from": "createMaterialUsage.materialUsageId",
            "type": "string"
          },
          {
            "name": "projectId",
            "from": "createMaterialUsage.projectId",
            "type": "string"
          },
          {
            "name": "status",
            "from": "createMaterialUsage.status",
            "type": "string"
          },
          {
            "name": "materialName",
            "from": "createMaterialUsage.materialName",
            "type": "string"
          },
          {
            "name": "quantity",
            "from": "createMaterialUsage.quantity",
            "type": "number"
          },
          {
            "name": "unit",
            "from": "createMaterialUsage.unit",
            "type": "string"
          },
          {
            "name": "unitCost",
            "from": "createMaterialUsage.unitCost",
            "type": "number"
          },
          {
            "name": "costCode",
            "from": "createMaterialUsage.costCode",
            "type": "string"
          },
          {
            "name": "usageDate",
            "from": "createMaterialUsage.usageDate",
            "type": "string"
          },
          {
            "name": "recordedBy",
            "from": "createMaterialUsage.recordedBy",
            "type": "string"
          },
          {
            "name": "createdAt",
            "from": "createMaterialUsage.createdAt",
            "type": "string"
          }
        ]
      },
      "route": "buildFlowFsm.fieldLoggingWorkspace.submitMaterialUsage"
    },
    {
      "bffId": "submitVoidMaterialUsage",
      "kind": "command",
      "uses": [
        {
          "operationId": "voidMaterialUsage"
        }
      ],
      "input": [
        {
          "name": "materialUsageId",
          "from": "voidMaterialUsage.materialUsageId",
          "required": true,
          "source": "pageInput"
        },
        {
          "name": "voidedReason",
          "from": "voidMaterialUsage.voidedReason",
          "required": true,
          "source": "userDecision"
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "materialUsageId",
            "from": "voidMaterialUsage.materialUsageId",
            "type": "string"
          },
          {
            "name": "projectId",
            "from": "voidMaterialUsage.projectId",
            "type": "string"
          },
          {
            "name": "status",
            "from": "voidMaterialUsage.status",
            "type": "string"
          },
          {
            "name": "materialName",
            "from": "voidMaterialUsage.materialName",
            "type": "string"
          },
          {
            "name": "quantity",
            "from": "voidMaterialUsage.quantity",
            "type": "number"
          },
          {
            "name": "unit",
            "from": "voidMaterialUsage.unit",
            "type": "string"
          },
          {
            "name": "unitCost",
            "from": "voidMaterialUsage.unitCost",
            "type": "number"
          },
          {
            "name": "voidedAt",
            "from": "voidMaterialUsage.voidedAt",
            "type": "string"
          },
          {
            "name": "voidedReason",
            "from": "voidMaterialUsage.voidedReason",
            "type": "string"
          }
        ]
      },
      "route": "buildFlowFsm.fieldLoggingWorkspace.submitVoidMaterialUsage"
    }
  ],
  "sections": [
    {
      "sectionId": "timeLoggingSection",
      "intent": "Field worker selects a work task, enters the date and hours worked, and submits the time log entry.",
      "organisms": [
        {
          "role": "primarySurface",
          "action": "submitTimeLog"
        },
        {
          "role": "contextualAction",
          "action": "submitVoidTimeLog",
          "attachTo": "submitTimeLog"
        }
      ]
    },
    {
      "sectionId": "materialLoggingSection",
      "intent": "Field worker enters material name, quantity, unit, cost, and usage date to post a material usage record against the active project.",
      "organisms": [
        {
          "role": "primarySurface",
          "action": "submitMaterialUsage"
        },
        {
          "role": "contextualAction",
          "action": "submitVoidMaterialUsage",
          "attachTo": "submitMaterialUsage"
        }
      ]
    }
  ],
  "operationIds": [
    "createTimeLog",
    "voidTimeLog",
    "createMaterialUsage",
    "voidMaterialUsage"
  ],
  "purpose": "Field worker logs hours worked and materials used against active tasks, keeping job costing accurate.",
  "presentation": {
    "categoryRef": "fieldDataCapture",
    "confidence": 10,
    "classificationNote": "All four operations are short-form field captures (create/void time logs and material usage) with no query surface — a textbook fieldDataCapture pattern: selectTarget, enterValues, submit, confirmAndReset.",
    "alternates": [
      {
        "categoryRef": "processWizard",
        "confidence": 4,
        "reason": "Each entry follows a short guided sequence (select task → enter values → confirm), but the forms are too lightweight and independent to warrant a full wizard shell."
      },
      {
        "categoryRef": "entityRecordManagement",
        "confidence": 3,
        "reason": "Void actions resemble lifecycle transitions, but the dominant pattern is rapid field capture rather than single-record lifecycle management."
      }
    ]
  },
  "sliceHash": "djb2:6f6a1a42"
} as const;

export default fieldLoggingWorkspaceWorkspace;
