/// <mls fileReference="_102045_/l4/buildFlowFsm/ontology/ChangeOrder.defs.ts" enhancement="_blank"/>

export const buildFlowFsmEntityChangeOrder = {
  "entityId": "ChangeOrder",
  "title": "Change Order",
  "description": "A formal document capturing a scope, cost, or schedule adjustment on an active project, with an approval lifecycle before it affects job costing and billing.",
  "kind": "core",
  "ownership": "moduleOwned",
  "fields": [
    {
      "fieldId": "changeOrderId",
      "type": "uuid",
      "required": true,
      "description": "Unique identifier for the change order."
    },
    {
      "fieldId": "projectId",
      "type": "uuid",
      "required": true,
      "description": "Reference to the active project this change order applies to."
    },
    {
      "fieldId": "title",
      "type": "string",
      "required": true,
      "description": "Short summary title of the change order."
    },
    {
      "fieldId": "description",
      "type": "text",
      "required": true,
      "description": "Detailed description of the scope, cost, or schedule impact being requested."
    },
    {
      "fieldId": "impactType",
      "type": "string",
      "required": true,
      "description": "Primary category of the impact this change order introduces.",
      "enum": [
        "scope",
        "cost",
        "schedule"
      ]
    },
    {
      "fieldId": "costAdjustment",
      "type": "money",
      "required": true,
      "description": "Monetary amount of the cost adjustment; positive for additions, negative for deductions."
    },
    {
      "fieldId": "scheduleAdjustmentDays",
      "type": "number",
      "required": false,
      "description": "Number of days added to or removed from the project schedule; positive for extensions, negative for reductions."
    },
    {
      "fieldId": "status",
      "type": "string",
      "required": true,
      "description": "Approval lifecycle state of the change order; only approved change orders affect job costing and billing.",
      "enum": [
        "draft",
        "pendingReview",
        "approved",
        "rejected"
      ]
    },
    {
      "fieldId": "rejectionReason",
      "type": "text",
      "required": false,
      "description": "Reason recorded when a change order is rejected during review."
    },
    {
      "fieldId": "approvedAt",
      "type": "datetime",
      "required": false,
      "description": "Timestamp when the change order was approved and became eligible for job costing and billing."
    },
    {
      "fieldId": "rejectedAt",
      "type": "datetime",
      "required": false,
      "description": "Timestamp when the change order was rejected during review."
    },
    {
      "fieldId": "createdAt",
      "type": "datetime",
      "required": true,
      "description": "Timestamp when the change order was created."
    },
    {
      "fieldId": "updatedAt",
      "type": "datetime",
      "required": true,
      "description": "Timestamp of the last modification to the change order."
    }
  ],
  "statusEnum": [
    "draft",
    "pendingReview",
    "approved",
    "rejected"
  ],
  "lifecycleStates": [
    "draft",
    "pendingReview",
    "approved",
    "rejected"
  ]
} as const;

export default buildFlowFsmEntityChangeOrder;
