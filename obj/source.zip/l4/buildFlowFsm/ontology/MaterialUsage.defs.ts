/// <mls fileReference="_102045_/l4/buildFlowFsm/ontology/MaterialUsage.defs.ts" enhancement="_blank"/>

export const buildFlowFsmEntityMaterialUsage = {
  "entityId": "MaterialUsage",
  "title": "Material Usage",
  "description": "An append-only record of materials consumed against a project for job costing, not full warehouse stock management.",
  "kind": "event",
  "ownership": "moduleOwned",
  "fields": [
    {
      "fieldId": "materialUsageId",
      "type": "uuid",
      "required": true,
      "description": "Primary identifier for the material usage record."
    },
    {
      "fieldId": "projectId",
      "type": "uuid",
      "required": true,
      "description": "Reference to the project this material usage was recorded against."
    },
    {
      "fieldId": "status",
      "type": "string",
      "required": true,
      "description": "Lifecycle status of the material usage record.",
      "enum": [
        "posted",
        "voided"
      ]
    },
    {
      "fieldId": "materialName",
      "type": "string",
      "required": true,
      "description": "Name or description of the material consumed."
    },
    {
      "fieldId": "quantity",
      "type": "number",
      "required": true,
      "description": "Quantity of the material consumed."
    },
    {
      "fieldId": "unit",
      "type": "string",
      "required": true,
      "description": "Unit of measure for the material quantity.",
      "enum": [
        "kg",
        "liter",
        "meter",
        "unit",
        "bag",
        "box"
      ]
    },
    {
      "fieldId": "unitCost",
      "type": "money",
      "required": true,
      "description": "Cost per unit of the material at the time of usage."
    },
    {
      "fieldId": "costCode",
      "type": "string",
      "required": false,
      "description": "Internal cost classification code used for job costing detail."
    },
    {
      "fieldId": "usageDate",
      "type": "date",
      "required": true,
      "description": "Date the material was consumed on the project site."
    },
    {
      "fieldId": "recordedBy",
      "type": "string",
      "required": false,
      "description": "Name or identifier of the person who recorded the material usage."
    },
    {
      "fieldId": "voidedAt",
      "type": "datetime",
      "required": false,
      "description": "Timestamp when the material usage record was voided."
    },
    {
      "fieldId": "voidedReason",
      "type": "text",
      "required": false,
      "description": "Reason provided when voiding the material usage record."
    },
    {
      "fieldId": "createdAt",
      "type": "datetime",
      "required": true,
      "description": "Timestamp when the material usage record was created."
    }
  ],
  "statusEnum": [
    "posted",
    "voided"
  ],
  "eventPolicy": {
    "purpose": "audit",
    "retentionDays": 2555
  }
} as const;

export default buildFlowFsmEntityMaterialUsage;
