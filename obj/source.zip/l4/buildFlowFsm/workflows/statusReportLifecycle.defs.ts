/// <mls fileReference="_102045_/l4/buildFlowFsm/workflows/statusReportLifecycle.defs.ts" enhancement="_blank"/>

export const workflowStatusReportLifecycle = {
  "workflowId": "statusReportLifecycle",
  "title": "Status report lifecycle",
  "executionMode": "sequential",
  "trigger": "Project manager generates an AI-assisted status report from live project data.",
  "actors": [
    "projectManager",
    "client"
  ],
  "states": [
    "draft",
    "reviewed",
    "shared"
  ],
  "transitions": [
    {
      "from": "draft",
      "to": "reviewed",
      "on": "updateStatusReportStatus",
      "by": "projectManager",
      "guard": "PM has reviewed and may edit the report before marking it reviewed."
    },
    {
      "from": "reviewed",
      "to": "shared",
      "on": "updateStatusReportStatus",
      "by": "projectManager",
      "guard": "Only the project manager may share the report with the client."
    }
  ],
  "operationIds": [
    "generateStatusReport",
    "updateStatusReportStatus"
  ],
  "entities": [
    "StatusReport",
    "Project",
    "DelayRiskSuggestion"
  ],
  "rulesApplied": [
    "statusReportGenerationSource",
    "pmControlsStatusReportLifecycle"
  ],
  "story": {
    "actor": "Project manager",
    "goal": "Produce a professional project status summary from live data, review it, and share it with the client.",
    "steps": [
      "The project manager opens the project detail and triggers AI generation of a status report from live tasks, time logs, and materials.",
      "The system creates the report in draft and surfaces delay-risk suggestions for review.",
      "The project manager reviews and edits the draft, then marks the report as reviewed.",
      "The project manager shares the reviewed report with the client.",
      "The client receives and reads the progress summary without internal editing access."
    ],
    "outcome": "A reviewed status report is shared with the client, keeping them informed of progress while the PM retains control of generation and sharing."
  },
  "pageId": "statusReportLifecycle",
  "capabilities": [
    {
      "capabilityId": "statusReportLifecycle",
      "title": "Status report lifecycle",
      "actor": "projectManager",
      "priority": "now"
    }
  ],
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default workflowStatusReportLifecycle;
