/// <mls fileReference="_102045_/l1/propertyFlowCrm/layer_1_external/corretorStatusMetrics.defs.ts" enhancement="_blank"/>

export const corretorStatusMetricsDefs = {
  "schemaVersion": "2026-06-06",
  "artifactType": "metricTable",
  "artifactId": "corretorStatusMetrics",
  "moduleName": "propertyFlowCrm",
  "status": "draft",
  "source": {
    "agentName": "agentPlanMetricTableDefinition",
    "stepId": 49,
    "planId": ""
  },
  "data": {
    "metricTableDefinition": {
      "metricTableId": "corretorStatusMetrics",
      "tableName": "corretor_status_metrics",
      "moduleId": "propertyFlowCrm",
      "title": "Métricas de Status de Corretores",
      "purpose": "Série temporal de mudanças de status e ativação de corretores na imobiliária",
      "tableKind": "metricTimeseries",
      "storageEngine": "postgresTimescaleDB",
      "layer": "layer_1_external",
      "timeColumn": "event_timestamp",
      "columns": [
        {
          "name": "event_timestamp",
          "type": "timestamptz",
          "nullable": false,
          "description": "Data/hora do evento de status do corretor"
        },
        {
          "name": "corretor_id",
          "type": "uuid",
          "nullable": false,
          "description": "Identificador do corretor"
        },
        {
          "name": "status",
          "type": "text",
          "nullable": false,
          "description": "Status do corretor no evento"
        },
        {
          "name": "status_change_count",
          "type": "integer",
          "nullable": false,
          "default": 0,
          "description": "Contagem de alterações de status registradas no evento"
        },
        {
          "name": "active_broker_count",
          "type": "integer",
          "nullable": false,
          "default": 0,
          "description": "Contagem de corretores ativos no evento"
        }
      ],
      "dimensions": [
        {
          "dimensionId": "corretorId",
          "column": "corretor_id",
          "type": "string",
          "description": "Identificador do corretor"
        },
        {
          "dimensionId": "status",
          "column": "status",
          "type": "string",
          "description": "Status do corretor"
        }
      ],
      "measures": [
        {
          "measureId": "statusChangeCount",
          "column": "status_change_count",
          "aggregation": "sum",
          "unit": "eventos",
          "description": "Contagem de alterações de status"
        },
        {
          "measureId": "activeBrokerCount",
          "column": "active_broker_count",
          "aggregation": "sum",
          "unit": "corretores",
          "description": "Contagem de corretores ativos"
        }
      ],
      "sourceWriteEvents": [
        "corretor_created",
        "corretor_updated",
        "corretor_status_changed"
      ],
      "hypertable": {
        "timeColumn": "event_timestamp",
        "chunkTimeInterval": "7 days",
        "retentionPolicy": "2 years",
        "indexes": [
          {
            "indexName": "corretor_status_metrics_event_timestamp_idx",
            "columns": [
              "event_timestamp"
            ],
            "purpose": "Suporte a filtros e ordenação temporal"
          },
          {
            "indexName": "corretor_status_metrics_corretor_time_idx",
            "columns": [
              "corretor_id",
              "event_timestamp"
            ],
            "purpose": "Consulta por corretor em janelas de tempo"
          },
          {
            "indexName": "corretor_status_metrics_status_time_idx",
            "columns": [
              "status",
              "event_timestamp"
            ],
            "purpose": "Agregações por status com recorte temporal"
          }
        ]
      },
      "updatePolicy": {
        "updatedByLayer": "layer_3_usecases",
        "pagesMayUpdate": false,
        "controllersMayUpdate": false,
        "usecaseRefs": [
          "crudCorretorUsecase"
        ]
      },
      "accessPolicy": {
        "directAccessAllowedFor": [
          "layer_3_usecases"
        ],
        "forbiddenFor": [
          "pages",
          "layer_2_controllers",
          "agents"
        ]
      },
      "rulesApplied": []
    },
    "defsPlan": {
      "fileName": "tables/corretorStatusMetrics.defs.ts",
      "exportName": "corretorStatusMetricsDefs",
      "saveAsDefs": true
    }
  }
} as const;

export default corretorStatusMetricsDefs;
