/// <mls fileReference="_102045_/l1/propertyFlowCrm/layer_1_external/propertyStatusMetrics.defs.ts" enhancement="_blank"/>

export const propertyStatusMetricsTableDefinition = {
  "schemaVersion": "2026-06-06",
  "artifactType": "metricTable",
  "artifactId": "propertyStatusMetrics",
  "moduleName": "propertyFlowCrm",
  "status": "draft",
  "source": {
    "agentName": "agentPlanMetricTableDefinition",
    "stepId": 51,
    "planId": ""
  },
  "data": {
    "metricTableDefinition": {
      "metricTableId": "propertyStatusMetrics",
      "tableName": "property_status_metrics",
      "moduleId": "propertyFlowCrm",
      "title": "Métricas de Status dos Imóveis",
      "purpose": "Acompanhar a evolução do estoque de imóveis por status, ciclo de vida e corretor ao longo do tempo.",
      "tableKind": "metricTimeseries",
      "storageEngine": "postgresTimescaleDB",
      "layer": "layer_1_external",
      "timeColumn": "event_time",
      "columns": [
        {
          "name": "event_time",
          "type": "timestamptz",
          "nullable": false,
          "description": "Timestamp do evento de status do imóvel."
        },
        {
          "name": "property_id",
          "type": "uuid",
          "nullable": false,
          "description": "ID do imóvel."
        },
        {
          "name": "broker_id",
          "type": "uuid",
          "nullable": false,
          "description": "ID do corretor responsável."
        },
        {
          "name": "status",
          "type": "varchar",
          "nullable": false,
          "description": "Status atual do imóvel."
        },
        {
          "name": "lifecycle_state",
          "type": "varchar",
          "nullable": false,
          "description": "Estado do ciclo de vida do imóvel."
        },
        {
          "name": "property_count",
          "type": "bigint",
          "nullable": false,
          "default": 0,
          "description": "Contagem de imóveis."
        },
        {
          "name": "total_value",
          "type": "numeric",
          "nullable": false,
          "default": 0,
          "description": "Valor total dos imóveis (BRL)."
        }
      ],
      "dimensions": [
        {
          "dimensionId": "propertyId",
          "column": "property_id",
          "type": "string",
          "description": "ID do imóvel"
        },
        {
          "dimensionId": "brokerId",
          "column": "broker_id",
          "type": "string",
          "description": "ID do corretor responsável"
        },
        {
          "dimensionId": "status",
          "column": "status",
          "type": "string",
          "description": "Status atual do imóvel"
        },
        {
          "dimensionId": "lifecycleState",
          "column": "lifecycle_state",
          "type": "string",
          "description": "Estado do ciclo de vida do imóvel"
        }
      ],
      "measures": [
        {
          "measureId": "propertyCount",
          "column": "property_count",
          "aggregation": "sum",
          "unit": "unidades",
          "description": "Contagem de imóveis"
        },
        {
          "measureId": "totalValue",
          "column": "total_value",
          "aggregation": "sum",
          "unit": "BRL",
          "description": "Valor total dos imóveis"
        }
      ],
      "sourceWriteEvents": [
        "propertyCreated",
        "propertyUpdated",
        "propertyStatusChanged",
        "propertyLifecycleChanged"
      ],
      "hypertable": {
        "timeColumn": "event_time",
        "chunkTimeInterval": "7 days",
        "retentionPolicy": "1 year",
        "compressionPolicy": "30 days",
        "indexes": [
          {
            "indexName": "idx_property_status_metrics_event_time",
            "columns": [
              "event_time"
            ],
            "purpose": "Ordenação e filtros por janela temporal."
          },
          {
            "indexName": "idx_property_status_metrics_property_time",
            "columns": [
              "property_id",
              "event_time"
            ],
            "purpose": "Histórico temporal por imóvel."
          },
          {
            "indexName": "idx_property_status_metrics_broker_time",
            "columns": [
              "broker_id",
              "event_time"
            ],
            "purpose": "Análises por corretor ao longo do tempo."
          },
          {
            "indexName": "idx_property_status_metrics_status_time",
            "columns": [
              "status",
              "event_time"
            ],
            "purpose": "Distribuição de imóveis por status e período."
          },
          {
            "indexName": "idx_property_status_metrics_lifecycle_time",
            "columns": [
              "lifecycle_state",
              "event_time"
            ],
            "purpose": "Distribuição por ciclo de vida e período."
          }
        ]
      },
      "updatePolicy": {
        "updatedByLayer": "layer_3_usecases",
        "pagesMayUpdate": false,
        "controllersMayUpdate": false
      },
      "accessPolicy": {
        "directAccessAllowedFor": [
          "layer_3_usecases"
        ],
        "forbiddenFor": [
          "pages",
          "layer_2_controllers",
          "agents"
        ]
      },
      "rulesApplied": [
        "rulePropertyStatusLifecycle"
      ]
    },
    "defsPlan": {
      "fileName": "tables/propertyStatusMetrics.defs.ts",
      "exportName": "propertyStatusMetricsTableDefinition",
      "saveAsDefs": true
    }
  }
} as const;

export default propertyStatusMetricsTableDefinition;

export const pipeline = [
  {
    "id": "propertyStatusMetrics__layer_1_external",
    "type": "layer_1_external",
    "outputPath": "_102045_/l1/propertyFlowCrm/layer_1_external/propertyStatusMetrics.ts",
    "defPath": "_102045_/l1/propertyFlowCrm/layer_1_external/propertyStatusMetrics.defs.ts",
    "dependsFiles": [],
    "dependsOn": [],
    "skills": [
      "_102021_/l2/skills/layer_1.md",
      "_102034_.d.ts"
    ],
    "afterSaveBackEnd": "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1",
    "agent": "agentMaterializeGen"
  }
] as const;
