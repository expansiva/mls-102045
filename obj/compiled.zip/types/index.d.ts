declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Corretor.defs" {
    export const CorretorMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Corretor";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Corretor";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "broker";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Corretor";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly [];
            readonly title: "Corretor";
            readonly description: "Cadastro de corretores que atuam no CRM.";
            readonly fields: readonly [{
                readonly fieldId: "corretorId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do corretor.";
            }, {
                readonly fieldId: "nome";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do corretor.";
            }, {
                readonly fieldId: "email";
                readonly type: "string";
                readonly required: true;
                readonly description: "E-mail corporativo do corretor.";
            }, {
                readonly fieldId: "telefone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do corretor.";
            }, {
                readonly fieldId: "creci";
                readonly type: "string";
                readonly required: false;
                readonly description: "Registro profissional do corretor.";
            }, {
                readonly fieldId: "ativo";
                readonly type: "boolean";
                readonly required: true;
                readonly description: "Indica se o corretor está ativo.";
            }, {
                readonly fieldId: "criadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data de criação do corretor.";
            }, {
                readonly fieldId: "atualizadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data da última atualização do corretor.";
            }];
        };
    };
    export default CorretorMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Imovel.defs" {
    export const ImovelMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Imovel";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Imovel";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "property";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Imóvel";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["imovelActiveStatus", "dashboardMetricsRefresh"];
            readonly title: "Imóvel";
            readonly description: "Cadastro de imóvel com endereço, tipo, preço, status e características.";
            readonly fields: readonly [{
                readonly fieldId: "imovelId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do imóvel.";
            }, {
                readonly fieldId: "titulo";
                readonly type: "string";
                readonly required: true;
                readonly description: "Título curto do anúncio do imóvel.";
            }, {
                readonly fieldId: "endereco";
                readonly type: "string";
                readonly required: true;
                readonly description: "Endereço completo do imóvel.";
            }, {
                readonly fieldId: "tipo";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo de imóvel (ex.: apartamento, casa).";
            }, {
                readonly fieldId: "preco";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço de venda ou locação.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status do imóvel: ativo, reservado, inativo.";
            }, {
                readonly fieldId: "caracteristicas";
                readonly type: "string[]";
                readonly required: false;
                readonly description: "Lista de características e diferenciais.";
            }, {
                readonly fieldId: "fotosMock";
                readonly type: "string[]";
                readonly required: false;
                readonly description: "Referências das fotos mock do imóvel.";
            }, {
                readonly fieldId: "descricaoGeradaIa";
                readonly type: "string";
                readonly required: false;
                readonly description: "Descrição gerada por IA para o imóvel.";
            }, {
                readonly fieldId: "corretorResponsavelId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Corretor responsável pelo imóvel.";
            }, {
                readonly fieldId: "criadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data de criação do imóvel.";
            }, {
                readonly fieldId: "atualizadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data da última atualização do imóvel.";
            }];
        };
    };
    export default ImovelMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Lead.defs" {
    export const LeadMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Lead";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Lead";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "leadCustomer";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Lead/Cliente";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["leadPipelineStages", "kanbanMoveUpdatesStatus", "dashboardMetricsRefresh"];
            readonly title: "Lead/Cliente";
            readonly description: "Lead ou cliente potencial no pipeline comercial.";
            readonly fields: readonly [{
                readonly fieldId: "leadId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do lead.";
            }, {
                readonly fieldId: "nome";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do lead/cliente.";
            }, {
                readonly fieldId: "email";
                readonly type: "string";
                readonly required: false;
                readonly description: "E-mail principal do lead.";
            }, {
                readonly fieldId: "telefone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone principal do lead.";
            }, {
                readonly fieldId: "origem";
                readonly type: "string";
                readonly required: false;
                readonly description: "Origem do lead (ex.: site, indicação).";
            }, {
                readonly fieldId: "statusFunil";
                readonly type: "string";
                readonly required: true;
                readonly description: "Etapa do funil: Novo, Contato, Visita agendada, Proposta enviada, Fechado.";
            }, {
                readonly fieldId: "qualificacao";
                readonly type: "string";
                readonly required: false;
                readonly description: "Qualificação do lead: quente, morno, frio.";
            }, {
                readonly fieldId: "anotacoes";
                readonly type: "string";
                readonly required: false;
                readonly description: "Anotações do corretor sobre o lead.";
            }, {
                readonly fieldId: "sugestaoFollowUp";
                readonly type: "string";
                readonly required: false;
                readonly description: "Sugestão de mensagem de follow-up gerada por IA.";
            }, {
                readonly fieldId: "corretorResponsavelId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Corretor responsável pelo lead.";
            }, {
                readonly fieldId: "criadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data de criação do lead.";
            }, {
                readonly fieldId: "atualizadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data da última atualização do lead.";
            }];
        };
    };
    export default LeadMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Negocio.defs" {
    export const NegocioMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Negocio";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Negocio";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "dealProposal";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Negócio/Proposta";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["negocioRequiresLinks", "dashboardMetricsRefresh"];
            readonly title: "Negócio/Proposta";
            readonly description: "Proposta comercial vinculada a imóvel e lead.";
            readonly fields: readonly [{
                readonly fieldId: "negocioId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do negócio/proposta.";
            }, {
                readonly fieldId: "imovelId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Imóvel associado à proposta.";
            }, {
                readonly fieldId: "leadId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Lead associado à proposta.";
            }, {
                readonly fieldId: "valor";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor da proposta.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status da proposta: em negociacao, proposta enviada, fechado, perdido.";
            }, {
                readonly fieldId: "corretorId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Corretor responsável pela proposta.";
            }, {
                readonly fieldId: "dataProposta";
                readonly type: "date";
                readonly required: true;
                readonly description: "Data de emissão da proposta.";
            }, {
                readonly fieldId: "observacoes";
                readonly type: "string";
                readonly required: false;
                readonly description: "Observações da negociação.";
            }, {
                readonly fieldId: "criadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data de criação da proposta.";
            }, {
                readonly fieldId: "atualizadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data da última atualização da proposta.";
            }];
        };
    };
    export default NegocioMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/Visita.defs" {
    export const VisitaMdm: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmEntity";
        readonly artifactId: "Visita";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdmEntity";
            readonly entity: "Visita";
            readonly ownership: "mdmOwned";
            readonly generateTable: false;
            readonly moduleId: "propertyFlowCrm";
            readonly domainId: "visitAppointment";
            readonly infrastructureModuleRef: "102034";
            readonly domainTitle: "Visita/Agendamento";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["visitaRequiresLinks", "imovelActiveStatus"];
            readonly title: "Visita/Agendamento";
            readonly description: "Agendamento de visita vinculado a imóvel e lead.";
            readonly fields: readonly [{
                readonly fieldId: "visitaId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único da visita.";
            }, {
                readonly fieldId: "imovelId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Imóvel associado à visita.";
            }, {
                readonly fieldId: "leadId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Lead associado à visita.";
            }, {
                readonly fieldId: "corretorId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Corretor responsável pela visita.";
            }, {
                readonly fieldId: "dataHora";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora agendada para a visita.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status da visita: agendada, concluida, cancelada.";
            }, {
                readonly fieldId: "observacoes";
                readonly type: "string";
                readonly required: false;
                readonly description: "Observações adicionais da visita.";
            }, {
                readonly fieldId: "criadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data de criação do agendamento.";
            }, {
                readonly fieldId: "atualizadoEm";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data da última atualização do agendamento.";
            }];
        };
    };
    export default VisitaMdm;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/corretorStatusMetrics.defs" {
    export const corretorStatusMetricsDefs: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "corretorStatusMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "corretorStatusMetrics";
                readonly tableName: "corretor_status_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Status de Corretores";
                readonly purpose: "Série temporal de mudanças de status e ativação de corretores na imobiliária";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora do evento de status do corretor";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do corretor";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do corretor no evento";
                }, {
                    readonly name: "status_change_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de alterações de status registradas no evento";
                }, {
                    readonly name: "active_broker_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de corretores ativos no evento";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "string";
                    readonly description: "Identificador do corretor";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status do corretor";
                }];
                readonly measures: readonly [{
                    readonly measureId: "statusChangeCount";
                    readonly column: "status_change_count";
                    readonly aggregation: "sum";
                    readonly unit: "eventos";
                    readonly description: "Contagem de alterações de status";
                }, {
                    readonly measureId: "activeBrokerCount";
                    readonly column: "active_broker_count";
                    readonly aggregation: "sum";
                    readonly unit: "corretores";
                    readonly description: "Contagem de corretores ativos";
                }];
                readonly sourceWriteEvents: readonly ["corretor_created", "corretor_updated", "corretor_status_changed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly indexes: readonly [{
                        readonly indexName: "corretor_status_metrics_event_timestamp_idx";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Suporte a filtros e ordenação temporal";
                    }, {
                        readonly indexName: "corretor_status_metrics_corretor_time_idx";
                        readonly columns: readonly ["corretor_id", "event_timestamp"];
                        readonly purpose: "Consulta por corretor em janelas de tempo";
                    }, {
                        readonly indexName: "corretor_status_metrics_status_time_idx";
                        readonly columns: readonly ["status", "event_timestamp"];
                        readonly purpose: "Agregações por status com recorte temporal";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["crudCorretorUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/corretorStatusMetrics.defs.ts";
                readonly exportName: "corretorStatusMetricsDefs";
                readonly saveAsDefs: true;
            };
        };
    };
    export default corretorStatusMetricsDefs;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/imovelInventoryMetrics.defs" {
    export const imovelInventoryMetricsTable: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "imovelInventoryMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "imovelInventoryMetrics";
                readonly tableName: "imovel_inventory_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Inventário de Imóveis";
                readonly purpose: "Série temporal do inventário de imóveis, capturando ativações, arquivamentos e atualizações";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de inventário do imóvel";
                }, {
                    readonly name: "imovel_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do imóvel";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do imóvel";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Corretor responsável";
                }, {
                    readonly name: "property_type";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Tipo do imóvel";
                }, {
                    readonly name: "property_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Contagem de imóveis no evento";
                }, {
                    readonly name: "listed_value";
                    readonly type: "numeric(14,2)";
                    readonly nullable: true;
                    readonly description: "Valor de listagem";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "imovelId";
                    readonly column: "imovel_id";
                    readonly type: "string";
                    readonly description: "Identificador do imóvel";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status do imóvel";
                }, {
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "string";
                    readonly description: "Corretor responsável";
                }, {
                    readonly dimensionId: "propertyType";
                    readonly column: "property_type";
                    readonly type: "string";
                    readonly description: "Tipo do imóvel";
                }];
                readonly measures: readonly [{
                    readonly measureId: "propertyCount";
                    readonly column: "property_count";
                    readonly aggregation: "sum";
                    readonly unit: "imóveis";
                    readonly description: "Contagem de imóveis";
                }, {
                    readonly measureId: "listedValue";
                    readonly column: "listed_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor de listagem";
                }];
                readonly sourceWriteEvents: readonly ["imovel_created", "imovel_updated", "imovel_archived"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "90 days";
                    readonly indexes: readonly [{
                        readonly indexName: "imovel_inventory_metrics_time_idx";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Acelerar consultas por janela temporal";
                    }, {
                        readonly indexName: "imovel_inventory_metrics_time_status_idx";
                        readonly columns: readonly ["event_timestamp", "status"];
                        readonly purpose: "Filtros por tempo e status";
                    }, {
                        readonly indexName: "imovel_inventory_metrics_imovel_idx";
                        readonly columns: readonly ["imovel_id"];
                        readonly purpose: "Filtrar por imóvel";
                    }, {
                        readonly indexName: "imovel_inventory_metrics_corretor_idx";
                        readonly columns: readonly ["corretor_id"];
                        readonly purpose: "Filtrar por corretor";
                    }, {
                        readonly indexName: "imovel_inventory_metrics_property_type_idx";
                        readonly columns: readonly ["property_type"];
                        readonly purpose: "Filtrar por tipo de imóvel";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["crudImovelUsecase", "arquivarImovelUsecase", "atualizarImovelUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["imovelActiveStatus"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/imovelInventoryMetrics.defs.ts";
                readonly exportName: "imovelInventoryMetricsTable";
                readonly saveAsDefs: true;
            };
        };
    };
    export default imovelInventoryMetricsTable;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/leadPipelineMetrics.defs" {
    export const leadPipelineMetricsDefs: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "leadPipelineMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 45;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "leadPipelineMetrics";
                readonly tableName: "lead_pipeline_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas do Pipeline de Leads";
                readonly purpose: "Série temporal de eventos do pipeline de leads para análise de volume, etapas e conversões";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Momento do evento do pipeline";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do lead";
                }, {
                    readonly name: "stage";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Etapa atual do pipeline";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Corretor responsável";
                }, {
                    readonly name: "origin";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Origem do lead";
                }, {
                    readonly name: "lead_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Quantidade de leads no evento";
                }, {
                    readonly name: "stage_transition_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de transições de etapa";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "Identificador do lead";
                }, {
                    readonly dimensionId: "stage";
                    readonly column: "stage";
                    readonly type: "string";
                    readonly description: "Etapa atual do pipeline";
                }, {
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "string";
                    readonly description: "Corretor responsável";
                }, {
                    readonly dimensionId: "origin";
                    readonly column: "origin";
                    readonly type: "string";
                    readonly description: "Origem do lead";
                }];
                readonly measures: readonly [{
                    readonly measureId: "leadCount";
                    readonly column: "lead_count";
                    readonly aggregation: "sum";
                    readonly unit: "leads";
                    readonly description: "Quantidade de leads no evento";
                }, {
                    readonly measureId: "stageTransitionCount";
                    readonly column: "stage_transition_count";
                    readonly aggregation: "sum";
                    readonly unit: "transições";
                    readonly description: "Quantidade de transições de etapa";
                }];
                readonly sourceWriteEvents: readonly ["lead_created", "lead_updated", "lead_stage_changed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "90 days";
                    readonly indexes: readonly [{
                        readonly indexName: "lead_pipeline_metrics_time_idx";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Ordenação temporal e queries por período";
                    }, {
                        readonly indexName: "lead_pipeline_metrics_lead_time_idx";
                        readonly columns: readonly ["lead_id", "event_timestamp"];
                        readonly purpose: "Filtrar séries por lead";
                    }, {
                        readonly indexName: "lead_pipeline_metrics_stage_time_idx";
                        readonly columns: readonly ["stage", "event_timestamp"];
                        readonly purpose: "Filtrar séries por etapa";
                    }, {
                        readonly indexName: "lead_pipeline_metrics_corretor_time_idx";
                        readonly columns: readonly ["corretor_id", "event_timestamp"];
                        readonly purpose: "Filtrar séries por corretor";
                    }, {
                        readonly indexName: "lead_pipeline_metrics_origin_time_idx";
                        readonly columns: readonly ["origin", "event_timestamp"];
                        readonly purpose: "Filtrar séries por origem";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["kanbanLeadUsecase", "classificarLeadUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["leadPipelineStages", "kanbanMoveUpdatesStatus"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/leadPipelineMetrics.defs.ts";
                readonly exportName: "leadPipelineMetricsDefs";
                readonly saveAsDefs: true;
            };
        };
    };
    export default leadPipelineMetricsDefs;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/negocioMetrics.defs" {
    export const negocioMetricsTableDefs: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "negocioMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "negocioMetrics";
                readonly tableName: "negocio_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Negócios";
                readonly purpose: "Série temporal de criação, evolução e fechamento de propostas e negócios";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Momento do evento de negócio";
                }, {
                    readonly name: "negocio_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do negócio";
                }, {
                    readonly name: "imovel_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel negociado";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Lead/cliente associado";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do negócio";
                }, {
                    readonly name: "deal_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Contagem de negócios";
                }, {
                    readonly name: "proposal_value";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor da proposta";
                }, {
                    readonly name: "closed_value";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor fechado";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "negocioId";
                    readonly column: "negocio_id";
                    readonly type: "string";
                    readonly description: "Identificador do negócio";
                }, {
                    readonly dimensionId: "imovelId";
                    readonly column: "imovel_id";
                    readonly type: "string";
                    readonly description: "Imóvel negociado";
                }, {
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "Lead/cliente associado";
                }, {
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "string";
                    readonly description: "Corretor responsável";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status do negócio";
                }];
                readonly measures: readonly [{
                    readonly measureId: "dealCount";
                    readonly column: "deal_count";
                    readonly aggregation: "sum";
                    readonly unit: "negócios";
                    readonly description: "Contagem de negócios";
                }, {
                    readonly measureId: "proposalValue";
                    readonly column: "proposal_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor da proposta";
                }, {
                    readonly measureId: "closedValue";
                    readonly column: "closed_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor fechado";
                }];
                readonly sourceWriteEvents: readonly ["negocio_created", "negocio_updated", "negocio_status_changed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "negocio_metrics_event_timestamp_idx";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Ordenação temporal para consultas de séries";
                        readonly unique: false;
                    }, {
                        readonly indexName: "negocio_metrics_negocio_time_idx";
                        readonly columns: readonly ["negocio_id", "event_timestamp"];
                        readonly purpose: "Busca por negócio com recorte temporal";
                        readonly unique: false;
                    }, {
                        readonly indexName: "negocio_metrics_imovel_time_idx";
                        readonly columns: readonly ["imovel_id", "event_timestamp"];
                        readonly purpose: "Busca por imóvel e período";
                        readonly unique: false;
                    }, {
                        readonly indexName: "negocio_metrics_lead_time_idx";
                        readonly columns: readonly ["lead_id", "event_timestamp"];
                        readonly purpose: "Busca por lead e período";
                        readonly unique: false;
                    }, {
                        readonly indexName: "negocio_metrics_corretor_time_idx";
                        readonly columns: readonly ["corretor_id", "event_timestamp"];
                        readonly purpose: "Busca por corretor e período";
                        readonly unique: false;
                    }, {
                        readonly indexName: "negocio_metrics_status_time_idx";
                        readonly columns: readonly ["status", "event_timestamp"];
                        readonly purpose: "Filtros por status do negócio e período";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["rastrearNegocioUsecase", "atualizarStatusPropostaUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["negocioRequiresLinks"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/negocioMetrics.defs.ts";
                readonly exportName: "negocioMetricsTableDefs";
                readonly saveAsDefs: true;
            };
        };
    };
    export default negocioMetricsTableDefs;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/visitaMetrics.defs" {
    export const visitaMetricsTableDefs: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "visitaMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 46;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "visitaMetrics";
                readonly tableName: "visita_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Visitas";
                readonly purpose: "Série temporal de agendamentos, reagendamentos, cancelamentos e conclusões de visitas";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de visita";
                }, {
                    readonly name: "visita_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador da visita";
                }, {
                    readonly name: "imovel_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel visitado";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Lead/cliente associado";
                }, {
                    readonly name: "corretor_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Corretor responsável";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status da visita";
                }, {
                    readonly name: "visit_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de visitas";
                }, {
                    readonly name: "cancellation_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de cancelamentos";
                }, {
                    readonly name: "reschedule_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de reagendamentos";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "visitaId";
                    readonly column: "visita_id";
                    readonly type: "string";
                    readonly description: "Identificador da visita";
                }, {
                    readonly dimensionId: "imovelId";
                    readonly column: "imovel_id";
                    readonly type: "string";
                    readonly description: "Imóvel visitado";
                }, {
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "Lead/cliente associado";
                }, {
                    readonly dimensionId: "corretorId";
                    readonly column: "corretor_id";
                    readonly type: "string";
                    readonly description: "Corretor responsável";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status da visita";
                }];
                readonly measures: readonly [{
                    readonly measureId: "visitCount";
                    readonly column: "visit_count";
                    readonly aggregation: "sum";
                    readonly unit: "visitas";
                    readonly description: "Contagem de visitas";
                }, {
                    readonly measureId: "cancellationCount";
                    readonly column: "cancellation_count";
                    readonly aggregation: "sum";
                    readonly unit: "cancelamentos";
                    readonly description: "Contagem de cancelamentos";
                }, {
                    readonly measureId: "rescheduleCount";
                    readonly column: "reschedule_count";
                    readonly aggregation: "sum";
                    readonly unit: "reagendamentos";
                    readonly description: "Contagem de reagendamentos";
                }];
                readonly sourceWriteEvents: readonly ["visita_created", "visita_updated", "visita_cancelled", "visita_rescheduled", "visita_completed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "visita_metrics_time_idx";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Acelerar queries por janela de tempo";
                    }, {
                        readonly indexName: "visita_metrics_imovel_time_idx";
                        readonly columns: readonly ["imovel_id", "event_timestamp"];
                        readonly purpose: "Filtros por imóvel e tempo";
                    }, {
                        readonly indexName: "visita_metrics_lead_time_idx";
                        readonly columns: readonly ["lead_id", "event_timestamp"];
                        readonly purpose: "Filtros por lead e tempo";
                    }, {
                        readonly indexName: "visita_metrics_corretor_time_idx";
                        readonly columns: readonly ["corretor_id", "event_timestamp"];
                        readonly purpose: "Filtros por corretor e tempo";
                    }, {
                        readonly indexName: "visita_metrics_status_time_idx";
                        readonly columns: readonly ["status", "event_timestamp"];
                        readonly purpose: "Filtros por status e tempo";
                    }, {
                        readonly indexName: "visita_metrics_visita_time_idx";
                        readonly columns: readonly ["visita_id", "event_timestamp"];
                        readonly purpose: "Rastreamento por visita e tempo";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["agendarVisitaUsecase", "reagendarVisitaUsecase", "cancelarVisitaUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["visitaRequiresLinks", "imovelActiveStatus"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/visitaMetrics.defs.ts";
                readonly exportName: "visitaMetricsTableDefs";
                readonly saveAsDefs: true;
            };
        };
    };
    export default visitaMetricsTableDefs;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/agendarVisita-commands.defs" {
    export const agendarVisitaCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "agendarVisita";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "agendarVisita";
                readonly commands: readonly [{
                    readonly commandId: "agendarVisita";
                    readonly input: readonly [{
                        readonly name: "imovelId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "leadId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "dataHora";
                        readonly type: "date";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "visitaId";
                        readonly type: "string";
                    }, {
                        readonly name: "dataHora";
                        readonly type: "date";
                    }];
                }];
            };
        };
    };
    export default agendarVisitaCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/agendarVisita.defs" {
    export const useCase: {
        readonly usecaseId: "agendarVisita";
        readonly title: "Agendar visita";
        readonly purpose: "Agendar uma visita vinculada a um imóvel e lead.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitaEntity"];
        readonly outputEntities: readonly ["visitaEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visita";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "visita";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visita_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["visitaRequiresLinks", "imovelActiveStatus"];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "imovelEntity", "visitaEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/alterarStatusCorretor-commands.defs" {
    export const alterarStatusCorretorCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "alterarStatusCorretor";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "alterarStatusCorretor";
                readonly commands: readonly [{
                    readonly commandId: "alterarStatusCorretor";
                    readonly input: readonly [{
                        readonly name: "corretorId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "ativo";
                        readonly type: "boolean";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "corretor";
                        readonly type: "corretorEntity";
                    }];
                }];
            };
        };
    };
    export default alterarStatusCorretorCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/alterarStatusCorretor.defs" {
    export const useCase: {
        readonly usecaseId: "alterarStatusCorretor";
        readonly title: "Ativar/desativar corretor";
        readonly purpose: "Alterar o status ativo/inativo de um corretor.";
        readonly actor: "adminImobiliaria";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["corretorEntity"];
        readonly outputEntities: readonly ["corretorEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "corretor_status_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["corretorEntity", "dashboardMetricsEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/arquivarImovel-commands.defs" {
    export const arquivarImovelCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "arquivarImovel";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "arquivarImovel";
                readonly commands: readonly [{
                    readonly commandId: "arquivarImovel";
                    readonly input: readonly [{
                        readonly name: "imovelId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "imovel";
                        readonly type: "imovelEntity";
                    }];
                }];
            };
        };
    };
    export default arquivarImovelCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/arquivarImovel.defs" {
    export const useCase: {
        readonly usecaseId: "arquivarImovel";
        readonly title: "Arquivar imóvel";
        readonly purpose: "Arquivar um imóvel, removendo-o do inventário ativo.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["imovelEntity"];
        readonly outputEntities: readonly ["imovelEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "imovel_inventory_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "imovelEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/atualizarStatusProposta.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarStatusProposta";
        readonly title: "Atualizar status da proposta";
        readonly purpose: "Atualizar o status de uma proposta em andamento.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["negocioEntity"];
        readonly outputEntities: readonly ["negocioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "negocio";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "negocio";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "negocio_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "negocioEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/buscarCorretor-commands.defs" {
    export const buscarCorretorCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "buscarCorretor";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "buscarCorretor";
                readonly commands: readonly [{
                    readonly commandId: "listarCorretores";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "corretores";
                        readonly type: "corretorEntity[]";
                    }];
                }];
            };
        };
    };
    export default buscarCorretorCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/buscarCorretor.defs" {
    export const useCase: {
        readonly usecaseId: "buscarCorretor";
        readonly title: "Buscar corretor";
        readonly purpose: "Consultar e listar corretores cadastrados.";
        readonly actor: "adminImobiliaria";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["corretorEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["corretorEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/buscarImovel-commands.defs" {
    export const buscarImovelCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "buscarImovel";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "buscarImovel";
                readonly commands: readonly [{
                    readonly commandId: "buscarImovel";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "imoveis";
                        readonly type: "imovelEntity[]";
                    }];
                }];
            };
        };
    };
    export default buscarImovelCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/buscarImovel.defs" {
    export const useCase: {
        readonly usecaseId: "buscarImovel";
        readonly title: "Buscar imóvel";
        readonly purpose: "Consultar e listar imóveis com filtros.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["imovelEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["imovelEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/cancelarVisita-commands.defs" {
    export const cancelarVisitaCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "cancelarVisita";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 52;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "cancelarVisita";
                readonly commands: readonly [{
                    readonly commandId: "cancelarVisita";
                    readonly input: readonly [{
                        readonly name: "visitaId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "visitaId";
                        readonly type: "string";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                    }];
                }];
            };
        };
    };
    export default cancelarVisitaCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/cancelarVisita.defs" {
    export const useCase: {
        readonly usecaseId: "cancelarVisita";
        readonly title: "Cancelar visita";
        readonly purpose: "Cancelar uma visita previamente agendada.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitaEntity"];
        readonly outputEntities: readonly ["visitaEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visita";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "visita";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visita_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "visitaEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/classificarLeadIa-commands.defs" {
    export const classificarLeadIaCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "classificarLeadIa";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "classificarLeadIa";
                readonly commands: readonly [{
                    readonly commandId: "classificarLeadIa";
                    readonly input: readonly [{
                        readonly name: "leadId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "lead";
                        readonly type: "leadEntity";
                    }];
                }];
            };
        };
    };
    export default classificarLeadIaCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/classificarLeadIa.defs" {
    export const useCase: {
        readonly usecaseId: "classificarLeadIa";
        readonly title: "Classificar lead com IA";
        readonly purpose: "Qualificar e classificar um lead automaticamente via IA.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadEntity"];
        readonly outputEntities: readonly ["leadEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["leadEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarCorretor-commands.defs" {
    export const criarCorretorCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "criarCorretor";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "criarCorretor";
                readonly commands: readonly [{
                    readonly commandId: "criarCorretor";
                    readonly input: readonly [{
                        readonly name: "corretor";
                        readonly type: "corretorEntity";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "corretor";
                        readonly type: "corretorEntity";
                    }];
                }];
            };
        };
    };
    export default criarCorretorCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarCorretor.defs" {
    export const useCase: {
        readonly usecaseId: "criarCorretor";
        readonly title: "Criar corretor";
        readonly purpose: "Cadastrar um novo corretor na imobiliária.";
        readonly actor: "adminImobiliaria";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["corretorEntity"];
        readonly outputEntities: readonly ["corretorEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "corretor_status_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["corretorEntity", "dashboardMetricsEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarImovel-commands.defs" {
    export const criarImovelCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "criarImovel";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "criarImovel";
                readonly commands: readonly [{
                    readonly commandId: "criarImovel";
                    readonly input: readonly [{
                        readonly name: "imovel";
                        readonly type: "imovelEntity";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "imovel";
                        readonly type: "imovelEntity";
                    }];
                }];
            };
        };
    };
    export default criarImovelCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarImovel.defs" {
    export const useCase: {
        readonly usecaseId: "criarImovel";
        readonly title: "Criar imóvel";
        readonly purpose: "Cadastrar um novo imóvel no sistema e atualizar métricas de inventário.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["imovelEntity"];
        readonly outputEntities: readonly ["imovelEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "imovel_inventory_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "imovelEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarLead.defs" {
    export const useCase: {
        readonly usecaseId: "criarLead";
        readonly title: "Criar lead";
        readonly purpose: "Cadastrar um novo lead no pipeline.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadEntity"];
        readonly outputEntities: readonly ["leadEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["leadPipelineStages"];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "leadEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarProposta-commands.defs" {
    export const criarPropostaCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "criarProposta";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "criarProposta";
                readonly commands: readonly [{
                    readonly commandId: "criarProposta";
                    readonly input: readonly [{
                        readonly name: "negocio";
                        readonly type: "negocioEntity";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "negocio";
                        readonly type: "negocioEntity";
                    }];
                }];
            };
        };
    };
    export default criarPropostaCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarProposta.defs" {
    export const useCase: {
        readonly usecaseId: "criarProposta";
        readonly title: "Criar proposta";
        readonly purpose: "Criar uma nova proposta/negócio vinculada a lead e imóvel.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["negocioEntity"];
        readonly outputEntities: readonly ["negocioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "negocio";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "negocio";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "negocio_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["negocioRequiresLinks"];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "negocioEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/editarCorretor-commands.defs" {
    export const editarCorretorCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "editarCorretor";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 52;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "editarCorretor";
                readonly commands: readonly [{
                    readonly commandId: "editarCorretor";
                    readonly input: readonly [{
                        readonly name: "corretor";
                        readonly type: "corretorEntity";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "corretor";
                        readonly type: "corretorEntity";
                    }];
                }];
            };
        };
    };
    export default editarCorretorCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/editarCorretor.defs" {
    export const useCase: {
        readonly usecaseId: "editarCorretor";
        readonly title: "Editar corretor";
        readonly purpose: "Atualizar dados cadastrais de um corretor.";
        readonly actor: "adminImobiliaria";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["corretorEntity"];
        readonly outputEntities: readonly ["corretorEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "corretor_status_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["corretorEntity", "dashboardMetricsEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/editarImovel-commands.defs" {
    export const editarImovelCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "editarImovel";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "editarImovel";
                readonly commands: readonly [{
                    readonly commandId: "editarImovel";
                    readonly input: readonly [{
                        readonly name: "imovel";
                        readonly type: "imovelEntity";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "imovel";
                        readonly type: "imovelEntity";
                    }];
                }];
            };
        };
    };
    export default editarImovelCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/editarImovel.defs" {
    export const useCase: {
        readonly usecaseId: "editarImovel";
        readonly title: "Editar imóvel";
        readonly purpose: "Atualizar dados de um imóvel existente.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["imovelEntity"];
        readonly outputEntities: readonly ["imovelEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "imovel_inventory_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "imovelEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/gerarDescricaoImovelIa.defs" {
    export const useCase: {
        readonly usecaseId: "gerarDescricaoImovelIa";
        readonly title: "Gerar descrição de imóvel com IA";
        readonly purpose: "Gerar e persistir descrição automatizada de imóvel via LLM.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["imovelEntity"];
        readonly outputEntities: readonly ["imovelEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["imovelEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/moverLeadKanban-commands.defs" {
    export const moverLeadKanbanCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "moverLeadKanban";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "moverLeadKanban";
                readonly commands: readonly [{
                    readonly commandId: "moverLeadKanban";
                    readonly input: readonly [{
                        readonly name: "leadId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "pipelineStageId";
                        readonly type: "string";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "lead";
                        readonly type: "leadEntity";
                    }];
                }];
            };
        };
    };
    export default moverLeadKanbanCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/moverLeadKanban.defs" {
    export const useCase: {
        readonly usecaseId: "moverLeadKanban";
        readonly title: "Mover lead no Kanban";
        readonly purpose: "Alterar a etapa do lead no pipeline e atualizar métricas.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadEntity"];
        readonly outputEntities: readonly ["leadEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["leadPipelineStages", "kanbanMoveUpdatesStatus"];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "leadEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/reagendarVisita-commands.defs" {
    export const reagendarVisitaCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "reagendarVisita";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "reagendarVisita";
                readonly commands: readonly [{
                    readonly commandId: "reagendarVisita";
                    readonly input: readonly [{
                        readonly name: "visitaId";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "novaDataHora";
                        readonly type: "date";
                        readonly required: true;
                    }];
                    readonly output: readonly [{
                        readonly name: "visitaId";
                        readonly type: "string";
                    }, {
                        readonly name: "dataHora";
                        readonly type: "date";
                    }];
                }];
            };
        };
    };
    export default reagendarVisitaCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/reagendarVisita.defs" {
    export const useCase: {
        readonly usecaseId: "reagendarVisita";
        readonly title: "Reagendar visita";
        readonly purpose: "Alterar a data ou horário de uma visita existente.";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitaEntity"];
        readonly outputEntities: readonly ["visitaEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visita";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "visita";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visita_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["dashboardMetricsEntity", "visitaEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/visualizarDashboard-commands.defs" {
    export const visualizarDashboardCommands: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecaseCommands";
        readonly artifactId: "visualizarDashboard";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseDefinition: {
                readonly usecaseId: "visualizarDashboard";
                readonly commands: readonly [{
                    readonly commandId: "getDashboardMetrics";
                    readonly input: readonly [];
                    readonly output: readonly [{
                        readonly name: "dashboardMetrics";
                        readonly type: "dashboardMetricsEntity";
                    }];
                }];
            };
        };
    };
    export default visualizarDashboardCommands;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/visualizarDashboard.defs" {
    export const useCase: {
        readonly usecaseId: "visualizarDashboard";
        readonly title: "Visualizar dashboard";
        readonly purpose: "Consultar métricas consolidadas para o dashboard administrativo.";
        readonly actor: "adminImobiliaria";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["dashboardMetricsEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visita_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "negocio_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "imovel_inventory_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "corretor_status_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["dashboardMetricsRefresh"];
        readonly entityRefs: readonly ["corretorEntity", "dashboardMetricsEntity", "imovelEntity", "leadEntity", "negocioEntity", "visitaEntity"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/corretorEntity.defs" {
    export const entity: {
        readonly entityId: "corretorEntity";
        readonly title: "Corretor";
        readonly purpose: "Gestão de corretores da imobiliária, incluindo cadastro, edição e controle de status.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "corretor";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "corretor_status_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Corretor";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/Corretor.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "corretorStatusMetrics";
            readonly tableName: "corretor_status_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/corretorStatusMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["visualizarDashboard", "criarCorretor", "editarCorretor", "alterarStatusCorretor", "buscarCorretor"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/CorretorEntity.ts";
            readonly className: "CorretorEntity";
            readonly contractName: "ICorretorEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/dashboardMetricsEntity.defs" {
    export const entity: {
        readonly entityId: "dashboardMetricsEntity";
        readonly title: "Métricas do Dashboard";
        readonly purpose: "Consolidação de métricas para visualização no dashboard administrativo.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "visita_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "negocio_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "imovel_inventory_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "corretor_status_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "metricTable";
            readonly metricTableId: "leadPipelineMetrics";
            readonly tableName: "lead_pipeline_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/leadPipelineMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "visitaMetrics";
            readonly tableName: "visita_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/visitaMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "negocioMetrics";
            readonly tableName: "negocio_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/negocioMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "imovelInventoryMetrics";
            readonly tableName: "imovel_inventory_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/imovelInventoryMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "corretorStatusMetrics";
            readonly tableName: "corretor_status_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/corretorStatusMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["read"];
        readonly rulesApplied: readonly ["dashboardMetricsRefresh"];
        readonly usecaseRefs: readonly ["criarImovel", "editarImovel", "arquivarImovel", "criarLead", "moverLeadKanban", "agendarVisita", "reagendarVisita", "cancelarVisita", "criarProposta", "atualizarStatusProposta", "visualizarDashboard", "criarCorretor", "editarCorretor", "alterarStatusCorretor"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/DashboardMetricsEntity.ts";
            readonly className: "DashboardMetricsEntity";
            readonly contractName: "IDashboardMetricsEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/imovelEntity.defs" {
    export const entity: {
        readonly entityId: "imovelEntity";
        readonly title: "Imóvel";
        readonly purpose: "Gestão completa de imóveis, incluindo criação, edição, arquivamento, busca e geração de descrição por IA.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "imovel";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "imovel_inventory_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Imovel";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/Imovel.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "imovelInventoryMetrics";
            readonly tableName: "imovel_inventory_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/imovelInventoryMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["criarImovel", "editarImovel", "arquivarImovel", "buscarImovel", "agendarVisita", "gerarDescricaoImovelIa", "visualizarDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/ImovelEntity.ts";
            readonly className: "ImovelEntity";
            readonly contractName: "IImovelEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/leadEntity.defs" {
    export const entity: {
        readonly entityId: "leadEntity";
        readonly title: "Lead";
        readonly purpose: "Gestão de leads no pipeline, criação, movimentação no Kanban e qualificação por IA.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Lead";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/Lead.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "leadPipelineMetrics";
            readonly tableName: "lead_pipeline_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/leadPipelineMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update"];
        readonly rulesApplied: readonly ["leadPipelineStages", "kanbanMoveUpdatesStatus"];
        readonly usecaseRefs: readonly ["criarLead", "moverLeadKanban", "classificarLeadIa", "visualizarDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/LeadEntity.ts";
            readonly className: "LeadEntity";
            readonly contractName: "ILeadEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/negocioEntity.defs" {
    export const entity: {
        readonly entityId: "negocioEntity";
        readonly title: "Negócio";
        readonly purpose: "Criação e acompanhamento de propostas e negócios.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "negocio";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "negocio_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Negocio";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/Negocio.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "negocioMetrics";
            readonly tableName: "negocio_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/negocioMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update"];
        readonly rulesApplied: readonly ["negocioRequiresLinks"];
        readonly usecaseRefs: readonly ["criarProposta", "atualizarStatusProposta", "visualizarDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/NegocioEntity.ts";
            readonly className: "NegocioEntity";
            readonly contractName: "INegocioEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/visitaEntity.defs" {
    export const entity: {
        readonly entityId: "visitaEntity";
        readonly title: "Visita";
        readonly purpose: "Agendamento, reagendamento e cancelamento de visitas a imóveis.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "visita";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visita_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Visita";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/Visita.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "visitaMetrics";
            readonly tableName: "visita_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/visitaMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update"];
        readonly rulesApplied: readonly ["visitaRequiresLinks", "imovelActiveStatus"];
        readonly usecaseRefs: readonly ["agendarVisita", "reagendarVisita", "cancelarVisita", "visualizarDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/VisitaEntity.ts";
            readonly className: "VisitaEntity";
            readonly contractName: "IVisitaEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l2/plugins/llmProvider/plugin.defs" {
    export const llmProviderPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "llmProvider";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llmProvider";
                readonly provider: "Llm Provider";
                readonly priority: "soon";
                readonly reason: "Integração de IA para geração de descrição de imóvel e qualificação de leads foi aceita como melhoria pós‑MVP.";
                readonly events: readonly ["gerarDescricaoImovel", "classificarLead"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["caracteristicasImovel", "anotacoesLead"];
                readonly outputData: readonly ["descricaoImovel", "classificacaoLead", "sugestaoFollowUp"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Escolha do provedor de IA pode impactar custo e qualidade das respostas.", "Dependência de dados sensíveis para qualificação de leads requer cuidados de privacidade."];
                readonly questions: readonly ["Qual provedor de LLM será usado (ex.: OpenAI, Anthropic, Azure)?", "Há requisitos de compliance/privacidade para os dados enviados ao LLM?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/llmProvider/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/llmProvider.defs.ts";
            };
        };
    };
    export default llmProviderPluginPlan;
}
declare module "_102045_/l2/propertyFlowCrm/dashboardAdministrativo.defs" {
    export const dashboardAdministrativoPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dashboardAdministrativo";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 55;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dashboardAdministrativo";
                readonly pageName: "Dashboard administrativo";
                readonly actor: "adminImobiliaria";
                readonly purpose: "Visualizar métricas do pipeline, visitas, negócios, inventário e corretores.";
                readonly capabilities: readonly ["dashboardBasico"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["dashboardMetricsWorkflow"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "periodo";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["query", "session"];
                    readonly description: "Janela temporal para agregação das métricas.";
                }, {
                    readonly name: "filtroCorretor";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["query", "session"];
                    readonly description: "Filtro opcional por corretor responsável.";
                    readonly entityRef: "corretorEntity";
                    readonly fieldRef: "corretorId";
                }];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e período";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "filtroDashboard";
                        readonly purpose: "Selecionar período e filtros para atualização das métricas.";
                        readonly userActions: readonly ["definirPeriodo", "filtrarPorCorretor", "atualizarDashboard"];
                        readonly requiredEntities: readonly ["dashboardMetricsEntity"];
                        readonly readsFields: readonly ["periodo", "filtroCorretor"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["dashboardMetricsRefresh"];
                    }];
                }, {
                    readonly sectionName: "Resumo do pipeline de leads";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "leadPipelineMetricsCards";
                        readonly purpose: "Exibir volume e transições do pipeline de leads.";
                        readonly userActions: readonly ["visualizarMetricasLeads"];
                        readonly requiredEntities: readonly ["dashboardMetricsEntity"];
                        readonly readsFields: readonly ["leadCount", "stageTransitionCount", "stage", "corretorId", "origin"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["dashboardMetricsRefresh"];
                    }];
                }, {
                    readonly sectionName: "Métricas de visitas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "visitaMetricsCards";
                        readonly purpose: "Exibir contagem de visitas, cancelamentos e reagendamentos.";
                        readonly userActions: readonly ["visualizarMetricasVisitas"];
                        readonly requiredEntities: readonly ["dashboardMetricsEntity"];
                        readonly readsFields: readonly ["visitCount", "cancellationCount", "rescheduleCount", "status", "corretorId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["dashboardMetricsRefresh"];
                    }];
                }, {
                    readonly sectionName: "Métricas de negócios";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "negocioMetricsCards";
                        readonly purpose: "Exibir volume de negócios e valores agregados.";
                        readonly userActions: readonly ["visualizarMetricasNegocios"];
                        readonly requiredEntities: readonly ["dashboardMetricsEntity"];
                        readonly readsFields: readonly ["dealCount", "proposalValue", "closedValue", "status", "corretorId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["dashboardMetricsRefresh"];
                    }];
                }, {
                    readonly sectionName: "Inventário de imóveis";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "imovelInventoryMetricsCards";
                        readonly purpose: "Exibir volume e valor do inventário de imóveis.";
                        readonly userActions: readonly ["visualizarMetricasImoveis"];
                        readonly requiredEntities: readonly ["dashboardMetricsEntity"];
                        readonly readsFields: readonly ["propertyCount", "listedValue", "status", "propertyType", "corretorId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["dashboardMetricsRefresh"];
                    }];
                }, {
                    readonly sectionName: "Status de corretores";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "corretorStatusMetricsCards";
                        readonly purpose: "Exibir status e total de corretores ativos.";
                        readonly userActions: readonly ["visualizarMetricasCorretores"];
                        readonly requiredEntities: readonly ["dashboardMetricsEntity"];
                        readonly readsFields: readonly ["statusChangeCount", "activeBrokerCount", "status", "corretorId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["dashboardMetricsRefresh"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "visualizarDashboard";
                readonly purpose: "Carregar métricas agregadas para o dashboard.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodo";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "filtroCorretor";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadPipelineMetrics";
                    readonly type: "dashboardMetricsEntity";
                }, {
                    readonly name: "visitaMetrics";
                    readonly type: "dashboardMetricsEntity";
                }, {
                    readonly name: "negocioMetrics";
                    readonly type: "dashboardMetricsEntity";
                }, {
                    readonly name: "imovelInventoryMetrics";
                    readonly type: "dashboardMetricsEntity";
                }, {
                    readonly name: "corretorStatusMetrics";
                    readonly type: "dashboardMetricsEntity";
                }];
                readonly readsEntities: readonly ["dashboardMetricsEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["lead_pipeline_metrics", "visita_metrics", "negocio_metrics", "imovel_inventory_metrics", "corretor_status_metrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["visualizarDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["dashboardMetricsRefresh"];
            }];
        };
    };
    export default dashboardAdministrativoPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/imoveisLista.defs" {
    export const imoveisListaPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "imoveisLista";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 55;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "imoveisLista";
                readonly pageName: "Imóveis";
                readonly actor: "corretor";
                readonly purpose: "Listar, buscar e acessar imóveis para criar, editar ou arquivar.";
                readonly capabilities: readonly ["gerirImoveis"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyLifecycleWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [{
                    readonly name: "filtrosBusca";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryString", "uiState"];
                    readonly description: "Filtros de busca aplicados à lista de imóveis.";
                }, {
                    readonly name: "ordenacao";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryString", "uiState"];
                    readonly description: "Ordenação da lista de imóveis.";
                }, {
                    readonly name: "statusImovel";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryString", "uiState"];
                    readonly description: "Status do imóvel para filtrar a lista.";
                }, {
                    readonly name: "pagina";
                    readonly type: "number";
                    readonly required: false;
                    readonly sources: readonly ["queryString", "uiState"];
                    readonly description: "Página atual da listagem.";
                }, {
                    readonly name: "tamanhoPagina";
                    readonly type: "number";
                    readonly required: false;
                    readonly sources: readonly ["queryString", "uiState"];
                    readonly description: "Tamanho da página da listagem.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "imovelEditor";
                    readonly trigger: "Criar ou editar imóvel";
                    readonly description: "Abrir cadastro para criação ou edição.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e ações";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "barraDeBuscaImoveis";
                        readonly purpose: "Permitir busca e filtros de imóveis.";
                        readonly userActions: readonly ["buscarImovel", "limparFiltros"];
                        readonly requiredEntities: readonly ["imovelEntity"];
                        readonly readsFields: readonly ["imovelId", "titulo", "status", "preco", "endereco"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["imovelActiveStatus"];
                    }, {
                        readonly organismName: "acoesRapidasImoveis";
                        readonly purpose: "Atalhos para criação de imóvel.";
                        readonly userActions: readonly ["criarImovel"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de imóveis";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "tabelaImoveis";
                        readonly purpose: "Exibir lista de imóveis com ações de edição e arquivamento.";
                        readonly userActions: readonly ["editarImovel", "arquivarImovel", "abrirDetalheImovel"];
                        readonly requiredEntities: readonly ["imovelEntity"];
                        readonly readsFields: readonly ["imovelId", "titulo", "status", "preco", "endereco"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["imovelActiveStatus"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "buscarImovel";
                readonly purpose: "Buscar lista de imóveis conforme filtros.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "filtrosBusca";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "statusImovel";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "ordenacao";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "pagina";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "tamanhoPagina";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "preco";
                    readonly type: "number";
                }, {
                    readonly name: "endereco";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["imovelEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["buscarImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["imovelActiveStatus"];
            }, {
                readonly commandName: "arquivarImovel";
                readonly purpose: "Arquivar um imóvel selecionado na lista.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["imovelEntity"];
                readonly writesEntities: readonly ["imovelEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["imovel_inventory_metrics"];
                readonly usecaseRefs: readonly ["arquivarImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default imoveisListaPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/imovelEditor.defs" {
    export const imovelEditorPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "imovelEditor";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 56;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "imovelEditor";
                readonly pageName: "Cadastro de imóvel";
                readonly actor: "corretor";
                readonly purpose: "Criar ou editar imóvel e controlar status.";
                readonly capabilities: readonly ["gerirImoveis"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["propertyLifecycleWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do imóvel a editar ou arquivar.";
                    readonly entityRef: "Imovel";
                    readonly fieldRef: "imovel.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "imoveisLista";
                    readonly trigger: "Selecionar imóvel ou criar novo";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "imoveisLista";
                    readonly trigger: "Salvar ou arquivar imóvel";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "dadosDoImovel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "formularioImovel";
                        readonly purpose: "Cadastrar ou atualizar os dados do imóvel.";
                        readonly userActions: readonly ["preencherDados", "salvarImovel"];
                        readonly requiredEntities: readonly ["Imovel"];
                        readonly readsFields: readonly ["imovel.id", "imovel.titulo", "imovel.endereco", "imovel.tipo", "imovel.preco", "imovel.descricao", "imovel.status"];
                        readonly writesFields: readonly ["imovel.titulo", "imovel.endereco", "imovel.tipo", "imovel.preco", "imovel.descricao", "imovel.status"];
                        readonly rulesApplied: readonly ["imovelActiveStatus"];
                    }];
                }, {
                    readonly sectionName: "statusEArquivamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "acoesDeStatus";
                        readonly purpose: "Controlar status e arquivar imóvel quando necessário.";
                        readonly userActions: readonly ["arquivarImovel"];
                        readonly requiredEntities: readonly ["Imovel"];
                        readonly readsFields: readonly ["imovel.id", "imovel.status"];
                        readonly writesFields: readonly ["imovel.status", "imovel.motivoArquivamento"];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "criarImovel";
                readonly purpose: "Registrar um novo imóvel.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "endereco";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "tipo";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "preco";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "statusInicial";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["imovelEntity"];
                readonly writesEntities: readonly ["imovelEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["imovel_inventory_metrics"];
                readonly usecaseRefs: readonly ["criarImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["imovelActiveStatus"];
            }, {
                readonly commandName: "editarImovel";
                readonly purpose: "Atualizar dados do imóvel existente.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "endereco";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "tipo";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "preco";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["imovelEntity"];
                readonly writesEntities: readonly ["imovelEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["imovel_inventory_metrics"];
                readonly usecaseRefs: readonly ["editarImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "arquivarImovel";
                readonly purpose: "Arquivar imóvel.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "motivo";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["imovelEntity"];
                readonly writesEntities: readonly ["imovelEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["imovel_inventory_metrics"];
                readonly usecaseRefs: readonly ["arquivarImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default imovelEditorPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/module.defs" {
    export const initial: {
        readonly moduleName: "propertyFlowCrm";
        readonly requestKind: "solution";
        readonly userLanguage: "pt-BR";
        readonly userPrompt: "um app profissional chamado PropertyFlowCRM para imobiliárias e corretores.\nEntidades principais: Imóvel (endereço, tipo, preço, status, características, fotos mock), Lead/Cliente, Visita/Agendamento, Negócio/Proposta (status, valor, imóvel), Corretor.\nTelas chave: Dashboard (imóveis ativos, leads do mês, pipeline de fechamentos), CRUD de imóveis com busca, Pipeline de leads (kanban ou lista), Agendador de visitas, Rastreador de negócios por etapas.\nFuncionalidade LLM: IA que gera descrição do imóvel a partir de bullets ou classifica lead como \"quente/morno/frio\" a partir de anotações e sugere próxima mensagem de follow-up.\nFoco: Gestão de imóveis + leads + coordenação de visitas — específico para corretagem imobiliária.\nlinguagens: 'en' e 'pt-br'";
        readonly createdAt: "2026-06-11T13:23:00.759Z";
    };
}
declare module "_102045_/l2/propertyFlowCrm/visitasAgenda.defs" {
    export const visitasAgendaPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitasAgenda";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitasAgenda";
                readonly pageName: "Agenda de visitas";
                readonly actor: "corretor";
                readonly purpose: "Agendar, reagendar e cancelar visitas vinculadas a imóveis e leads.";
                readonly capabilities: readonly ["agendarVisitas"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitSchedulingWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["visitAppointment", "property", "leadCustomer"];
                readonly pageInputs: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do imóvel quando a visita é iniciada a partir de um imóvel.";
                    readonly entityRef: "Imovel";
                    readonly fieldRef: "imovelId";
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do lead quando a visita é iniciada a partir de um lead.";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "leadId";
                }, {
                    readonly name: "dataHoraPreferida";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "previousStepResult"];
                    readonly description: "Data e hora sugeridas para o agendamento.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "imoveisLista";
                    readonly trigger: "Agendar visita para imóvel";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "leadsKanban";
                    readonly trigger: "Agendar visita para lead";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Agendar visita";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "FormAgendarVisita";
                        readonly purpose: "Registrar um novo agendamento de visita vinculado a imóvel e lead.";
                        readonly userActions: readonly ["agendarVisita"];
                        readonly requiredEntities: readonly ["Visita", "Imovel", "Lead"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Visita.imovelId", "Visita.leadId", "Visita.dataHora", "Visita.observacoes"];
                        readonly rulesApplied: readonly ["visitaRequiresLinks", "imovelActiveStatus"];
                    }];
                }, {
                    readonly sectionName: "Reagendar visita";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "FormReagendarVisita";
                        readonly purpose: "Atualizar data e hora de uma visita existente.";
                        readonly userActions: readonly ["reagendarVisita"];
                        readonly requiredEntities: readonly ["Visita"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Visita.dataHora", "Visita.observacoes"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Cancelar visita";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "FormCancelarVisita";
                        readonly purpose: "Cancelar uma visita existente e registrar o motivo.";
                        readonly userActions: readonly ["cancelarVisita"];
                        readonly requiredEntities: readonly ["Visita"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Visita.status", "Visita.observacoes"];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "agendarVisita";
                readonly purpose: "Criar agendamento de visita.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "imovelId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "dataHora";
                    readonly type: "date";
                    readonly required: true;
                }, {
                    readonly name: "observacoes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitaId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Imovel", "Lead", "Visita"];
                readonly writesEntities: readonly ["Visita"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visita_metrics"];
                readonly usecaseRefs: readonly ["agendarVisita"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["visitaRequiresLinks", "imovelActiveStatus"];
            }, {
                readonly commandName: "reagendarVisita";
                readonly purpose: "Atualizar data e hora da visita.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "visitaId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "novaDataHora";
                    readonly type: "date";
                    readonly required: true;
                }, {
                    readonly name: "observacoes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitaId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Visita"];
                readonly writesEntities: readonly ["Visita"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visita_metrics"];
                readonly usecaseRefs: readonly ["reagendarVisita"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "cancelarVisita";
                readonly purpose: "Cancelar visita existente.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "visitaId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "motivo";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "visitaId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Visita"];
                readonly writesEntities: readonly ["Visita"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visita_metrics"];
                readonly usecaseRefs: readonly ["cancelarVisita"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default visitasAgendaPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/plugins/llmProvider.defs" {
    export const llmProviderPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "llmProvider";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 14;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llmProvider";
                readonly provider: "Llm Provider";
                readonly priority: "soon";
                readonly reason: "Integração de IA para geração de descrição de imóvel e qualificação de leads foi aceita como melhoria pós‑MVP.";
                readonly events: readonly ["gerarDescricaoImovel", "classificarLead"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["caracteristicasImovel", "anotacoesLead"];
                readonly outputData: readonly ["descricaoImovel", "classificacaoLead", "sugestaoFollowUp"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Escolha do provedor de IA pode impactar custo e qualidade das respostas.", "Dependência de dados sensíveis para qualificação de leads requer cuidados de privacidade."];
                readonly questions: readonly ["Qual provedor de LLM será usado (ex.: OpenAI, Anthropic, Azure)?", "Há requisitos de compliance/privacidade para os dados enviados ao LLM?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102045_/l2/plugins/llmProvider/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102045_/l2/propertyFlowCrm/plugins/llmProvider.defs.ts";
            };
        };
    };
    export default llmProviderPluginConnectionPlan;
}
