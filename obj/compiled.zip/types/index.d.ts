declare module "_102045_/l1/propertyFlowCrm/layer_1_external/brokerActivityMetrics.defs" {
    export const brokerActivityMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "brokerActivityMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 54;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "brokerActivityMetrics";
                readonly tableName: "broker_activity_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Atividade dos Corretores";
                readonly purpose: "Consolidar a atividade operacional dos corretores em um índice temporal unificado.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora do evento de atividade consolidado.";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do corretor responsável pela atividade.";
                }, {
                    readonly name: "activity_type";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly description: "Tipo de atividade registrada.";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Imóvel associado à atividade, quando aplicável.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Lead associado à atividade, quando aplicável.";
                }, {
                    readonly name: "activity_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Contagem unitária da atividade registrada.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "string";
                    readonly description: "ID do corretor";
                }, {
                    readonly dimensionId: "activityType";
                    readonly column: "activity_type";
                    readonly type: "string";
                    readonly description: "Tipo de atividade registrada";
                }, {
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "string";
                    readonly description: "FK dimension derived from ontology relationship visitLinksProperty (Visit -> Property)";
                }, {
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "FK dimension derived from ontology relationship visitLinksLead (Visit -> Lead)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "activityCount";
                    readonly column: "activity_count";
                    readonly aggregation: "sum";
                    readonly unit: "atividades";
                    readonly description: "Contagem de atividades";
                }];
                readonly sourceWriteEvents: readonly ["propertyCreated", "leadCreated", "visitCreated", "dealCreated", "leadStageChanged", "dealStageChanged", "propertyDescriptionRequested", "leadQualificationRequested"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "90 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_broker_activity_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Acelerar filtros temporais e políticas de chunk.";
                    }, {
                        readonly indexName: "idx_broker_activity_metrics_broker_time";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Consulta de atividade por corretor ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_broker_activity_metrics_activity_time";
                        readonly columns: readonly ["activity_type", "event_time"];
                        readonly purpose: "Filtro por tipo de atividade com recorte temporal.";
                    }, {
                        readonly indexName: "idx_broker_activity_metrics_property_time";
                        readonly columns: readonly ["property_id", "event_time"];
                        readonly purpose: "Análises de atividade por imóvel quando aplicável.";
                    }, {
                        readonly indexName: "idx_broker_activity_metrics_lead_time";
                        readonly columns: readonly ["lead_id", "event_time"];
                        readonly purpose: "Análises de atividade por lead quando aplicável.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["dashboardMetricsRefreshWorkflow"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMetricRefresh"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/brokerActivityMetrics.defs.ts";
                readonly exportName: "brokerActivityMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default brokerActivityMetricsTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/dashboardMetricUpdate.defs" {
    export const dashboardMetricUpdateTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "dashboardMetricUpdate";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "dashboardMetricUpdate";
                readonly tableName: "dashboard_metric_update";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Atualização de métricas do dashboard";
                readonly purpose: "Registrar execuções de atualização de métricas administrativas.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "DashboardMetricUpdate";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "dashboard_metric_update_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da atualização de métricas do dashboard.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly default: "completed";
                    readonly description: "Status de execução da atualização de métricas.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do evento de atualização.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["dashboard_metric_update_id"];
                readonly indexes: readonly [{
                    readonly indexName: "idx_dashboard_metric_update_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly reason: "Suporte a filtros por período no dashboard.";
                }, {
                    readonly indexName: "idx_dashboard_metric_update_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtrar execuções por status.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "DashboardMetricUpdateDetails";
                    readonly reason: "Armazenar listas agregadas de imóveis, leads e negócios sem uso frequente em filtros.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["adminDashboardMetrics"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMetricRefresh"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dashboardMetricUpdate.defs.ts";
                readonly exportName: "dashboardMetricUpdateTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dashboardMetricUpdateTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/dealPipelineMetrics.defs" {
    export const dealPipelineMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "dealPipelineMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 53;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "dealPipelineMetrics";
                readonly tableName: "deal_pipeline_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Pipeline de Negócios";
                readonly purpose: "Rastrear o volume e valor dos negócios por etapa, corretor, lead e imóvel relacionado.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora do evento de negócio usado para agregação temporal.";
                }, {
                    readonly name: "deal_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do negócio relacionado ao evento.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do lead relacionado ao negócio.";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do imóvel relacionado ao negócio.";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do corretor responsável pelo negócio.";
                }, {
                    readonly name: "stage";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly description: "Etapa atual do negócio.";
                }, {
                    readonly name: "deal_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de negócios.";
                }, {
                    readonly name: "deal_value";
                    readonly type: "numeric(14,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total dos negócios.";
                }, {
                    readonly name: "avg_deal_value";
                    readonly type: "numeric(14,2)";
                    readonly nullable: true;
                    readonly description: "Valor médio dos negócios.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "dealId";
                    readonly column: "deal_id";
                    readonly type: "string";
                    readonly description: "ID do negócio";
                }, {
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "ID do lead relacionado";
                }, {
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "string";
                    readonly description: "ID do imóvel relacionado";
                }, {
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "string";
                    readonly description: "ID do corretor responsável";
                }, {
                    readonly dimensionId: "stage";
                    readonly column: "stage";
                    readonly type: "string";
                    readonly description: "Etapa atual do negócio";
                }];
                readonly measures: readonly [{
                    readonly measureId: "dealCount";
                    readonly column: "deal_count";
                    readonly aggregation: "sum";
                    readonly unit: "negócios";
                    readonly description: "Contagem de negócios.";
                }, {
                    readonly measureId: "dealValue";
                    readonly column: "deal_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total dos negócios.";
                }, {
                    readonly measureId: "avgDealValue";
                    readonly column: "avg_deal_value";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Valor médio dos negócios.";
                }];
                readonly sourceWriteEvents: readonly ["dealCreated", "dealUpdated", "dealStageChanged"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_deal_pipeline_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Ordenação e filtros temporais para consultas de métricas.";
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_stage_time";
                        readonly columns: readonly ["stage", "event_time"];
                        readonly purpose: "Consultas por etapa ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_broker_time";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Consultas por corretor e período.";
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_lead_time";
                        readonly columns: readonly ["lead_id", "event_time"];
                        readonly purpose: "Consultas por lead e período.";
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_property_time";
                        readonly columns: readonly ["property_id", "event_time"];
                        readonly purpose: "Consultas por imóvel e período.";
                    }, {
                        readonly indexName: "idx_deal_pipeline_metrics_deal_time";
                        readonly columns: readonly ["deal_id", "event_time"];
                        readonly purpose: "Consultas por negócio e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleDealStages"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dealPipelineMetrics.defs.ts";
                readonly exportName: "dealPipelineMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dealPipelineMetricsMetricTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/dealStageChange.defs" {
    export const dealStageChangeTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "dealStageChange";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "dealStageChange";
                readonly tableName: "deal_stage_change";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Mudança de etapa do negócio";
                readonly purpose: "Registrar avanços e mudanças de etapa do negócio/proposta.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "DealStageChange";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "deal_stage_change_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da mudança de etapa do negócio.";
                }, {
                    readonly name: "deal_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Negócio alvo cuja etapa será alterada.";
                }, {
                    readonly name: "from_stage";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly description: "Etapa anterior do negócio antes da mudança.";
                }, {
                    readonly name: "to_stage";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly description: "Nova etapa do negócio após a mudança.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status do registro de mudança de etapa.";
                }, {
                    readonly name: "changed_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora em que a mudança de etapa ocorreu.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro de mudança.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro de mudança.";
                }];
                readonly primaryKey: readonly ["deal_stage_change_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "deal_id";
                    readonly targetEntity: "Deal";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Mudança de etapa referencia o negócio alvo.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_deal_stage_change_deal_id";
                    readonly columns: readonly ["deal_id"];
                    readonly reason: "Busca por mudanças por negócio.";
                }, {
                    readonly indexName: "idx_deal_stage_change_changed_at";
                    readonly columns: readonly ["changed_at"];
                    readonly reason: "Ordenação e filtros por data da mudança.";
                }, {
                    readonly indexName: "idx_deal_stage_change_deal_id_changed_at";
                    readonly columns: readonly ["deal_id", "changed_at"];
                    readonly reason: "Timeline de mudanças por negócio.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar dados internos adicionais do evento sem impacto em filtros principais.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly metricRefs: readonly [];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleDealStages"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dealStageChange.defs.ts";
                readonly exportName: "dealStageChangeTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dealStageChangeTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/leadPipelineMetrics.defs" {
    export const leadPipelineMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "leadPipelineMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 52;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "leadPipelineMetrics";
                readonly tableName: "lead_pipeline_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Pipeline de Leads";
                readonly purpose: "Monitorar o volume, qualificação e conversão de leads por etapa do pipeline e corretor.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Momento do evento agregado para o pipeline de leads.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do lead.";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do corretor responsável.";
                }, {
                    readonly name: "stage";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly description: "Etapa atual do pipeline do lead.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly description: "Status do lead.";
                }, {
                    readonly name: "lead_count";
                    readonly type: "bigint";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de leads.";
                }, {
                    readonly name: "qualified_count";
                    readonly type: "bigint";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de leads qualificados.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "leadId";
                    readonly column: "lead_id";
                    readonly type: "string";
                    readonly description: "ID do lead";
                }, {
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "string";
                    readonly description: "ID do corretor responsável";
                }, {
                    readonly dimensionId: "stage";
                    readonly column: "stage";
                    readonly type: "string";
                    readonly description: "Etapa atual do pipeline do lead";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status do lead";
                }];
                readonly measures: readonly [{
                    readonly measureId: "leadCount";
                    readonly column: "lead_count";
                    readonly aggregation: "sum";
                    readonly unit: "leads";
                    readonly description: "Contagem de leads";
                }, {
                    readonly measureId: "qualifiedCount";
                    readonly column: "qualified_count";
                    readonly aggregation: "sum";
                    readonly unit: "leads";
                    readonly description: "Contagem de leads qualificados";
                }];
                readonly sourceWriteEvents: readonly ["leadCreated", "leadUpdated", "leadStageChanged"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_lead_pipeline_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Consulta temporal principal da série.";
                    }, {
                        readonly indexName: "idx_lead_pipeline_metrics_lead_time";
                        readonly columns: readonly ["lead_id", "event_time"];
                        readonly purpose: "Filtros por lead com ordenação temporal.";
                    }, {
                        readonly indexName: "idx_lead_pipeline_metrics_broker_time";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Filtros por corretor com ordenação temporal.";
                    }, {
                        readonly indexName: "idx_lead_pipeline_metrics_stage_time";
                        readonly columns: readonly ["stage", "event_time"];
                        readonly purpose: "Análises por etapa do pipeline.";
                    }, {
                        readonly indexName: "idx_lead_pipeline_metrics_status_time";
                        readonly columns: readonly ["status", "event_time"];
                        readonly purpose: "Análises por status do lead.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/leadPipelineMetrics.defs.ts";
                readonly exportName: "leadPipelineMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default leadPipelineMetricsTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/leadQualificationRequest.defs" {
    export const leadQualificationRequestTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "leadQualificationRequest";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "leadQualificationRequest";
                readonly tableName: "lead_qualification_request";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Solicitação de qualificação do lead";
                readonly purpose: "Registrar solicitações de qualificação de leads via IA e resultados.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "LeadQualificationRequest";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "lead_qualification_request_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da solicitação de qualificação do lead.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao lead alvo da qualificação.";
                }, {
                    readonly name: "lead_temperature";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Temperatura/classificação do lead sugerida (frio/morno/quente).";
                }, {
                    readonly name: "follow_up_suggestion";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Sugestão de ação de follow-up para o lead.";
                }, {
                    readonly name: "ai_generated";
                    readonly type: "boolean";
                    readonly nullable: false;
                    readonly description: "Indica se a qualificação e sugestão foram geradas por IA.";
                }, {
                    readonly name: "review_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status de revisão humana da qualificação gerada por IA (pendente/aprovado/rejeitado).";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status da solicitação (pendente/emRevisao/concluida/cancelada).";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data/hora de criação da solicitação.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data/hora da última atualização da solicitação.";
                }];
                readonly primaryKey: readonly ["lead_qualification_request_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "lead_id";
                    readonly targetEntity: "Lead";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Relacionar solicitação ao lead qualificado.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_lead_qualification_request_lead_id";
                    readonly columns: readonly ["lead_id"];
                    readonly unique: false;
                    readonly reason: "Busca de solicitações por lead.";
                }, {
                    readonly indexName: "idx_lead_qualification_request_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtrar por status da solicitação.";
                }, {
                    readonly indexName: "idx_lead_qualification_request_review_status";
                    readonly columns: readonly ["review_status"];
                    readonly unique: false;
                    readonly reason: "Filtrar por status de revisão.";
                }, {
                    readonly indexName: "idx_lead_qualification_request_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por data de criação.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "LeadQualificationRequestDetails";
                    readonly reason: "Armazenar dados adicionais da classificação e auditoria sem uso frequente em filtros.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleAiHumanReview"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/leadQualificationRequest.defs.ts";
                readonly exportName: "leadQualificationRequestTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default leadQualificationRequestTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/leadStageChange.defs" {
    export const leadStageChangeTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "leadStageChange";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "leadStageChange";
                readonly tableName: "lead_stage_change";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Mudança de etapa do lead";
                readonly purpose: "Registrar movimentos do lead no pipeline.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "LeadStageChange";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "lead_stage_change_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da mudança de etapa do lead.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Lead alvo da mudança de etapa.";
                }, {
                    readonly name: "from_stage";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Etapa anterior do lead no pipeline.";
                }, {
                    readonly name: "to_stage";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Nova etapa do lead no pipeline.";
                }, {
                    readonly name: "changed_by_broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Responsável pela mudança de etapa.";
                }, {
                    readonly name: "changed_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da mudança de etapa.";
                }, {
                    readonly name: "note";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações ou motivo da mudança de etapa.";
                }, {
                    readonly name: "record_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status do registro para controle de ciclo de vida.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data de criação do registro de mudança.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data da última atualização do registro de mudança.";
                }];
                readonly primaryKey: readonly ["lead_stage_change_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "lead_id";
                    readonly targetEntity: "Lead";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Mudança vinculada ao lead alvo.";
                }, {
                    readonly fieldName: "changed_by_broker_id";
                    readonly targetEntity: "Broker";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Responsável pela mudança de etapa.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_lead_stage_change_lead";
                    readonly columns: readonly ["lead_id", "changed_at"];
                    readonly unique: false;
                    readonly reason: "Consulta do histórico de mudanças do lead em ordem temporal.";
                }, {
                    readonly indexName: "idx_lead_stage_change_broker";
                    readonly columns: readonly ["changed_by_broker_id", "changed_at"];
                    readonly unique: false;
                    readonly reason: "Auditoria de mudanças por corretor.";
                }, {
                    readonly indexName: "idx_lead_stage_change_stage";
                    readonly columns: readonly ["to_stage", "changed_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por etapa atual no pipeline.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "LeadStageChangeDetails";
                    readonly reason: "Armazenar metadados adicionais da mudança sem impactar filtros principais.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/leadStageChange.defs.ts";
                readonly exportName: "leadStageChangeTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default leadStageChangeTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/propertyDescriptionRequest.defs" {
    export const propertyDescriptionRequestTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "propertyDescriptionRequest";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "propertyDescriptionRequest";
                readonly tableName: "property_description_request";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Solicitação de descrição do imóvel";
                readonly purpose: "Registrar pedidos de geração de descrição via IA e seu histórico.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "PropertyDescriptionRequest";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da solicitação de descrição.";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel alvo para o qual a descrição será gerada.";
                }, {
                    readonly name: "bullets";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Lista de pontos/bullets informados para compor a descrição.";
                }, {
                    readonly name: "ai_description";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Descrição gerada por IA a partir dos bullets.";
                }, {
                    readonly name: "human_review_notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações e ajustes realizados na revisão humana.";
                }, {
                    readonly name: "review_status";
                    readonly type: "varchar(20)";
                    readonly nullable: false;
                    readonly description: "Estado da revisão humana da descrição gerada.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação da solicitação.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização da solicitação.";
                }];
                readonly primaryKey: readonly ["id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "property_id";
                    readonly targetEntity: "Property";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Solicitação vinculada ao imóvel alvo.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_property_description_request_property_id";
                    readonly columns: readonly ["property_id"];
                    readonly unique: false;
                    readonly reason: "Busca por solicitações do imóvel.";
                }, {
                    readonly indexName: "idx_property_description_request_review_status";
                    readonly columns: readonly ["review_status"];
                    readonly unique: false;
                    readonly reason: "Filtrar por estado de revisão.";
                }, {
                    readonly indexName: "idx_property_description_request_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por data de criação.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar dados auxiliares e históricos eventuais sem impacto em filtros principais.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleAiHumanReview"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/propertyDescriptionRequest.defs.ts";
                readonly exportName: "propertyDescriptionRequestTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default propertyDescriptionRequestTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/propertyStatusMetrics.defs" {
    export const propertyStatusMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "propertyStatusMetrics";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "propertyStatusMetrics";
                readonly tableName: "property_status_metrics";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Métricas de Status dos Imóveis";
                readonly purpose: "Acompanhar a evolução do estoque de imóveis por status, ciclo de vida e corretor ao longo do tempo.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_time";
                readonly columns: readonly [{
                    readonly name: "event_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de status do imóvel.";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do imóvel.";
                }, {
                    readonly name: "broker_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "ID do corretor responsável.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly description: "Status atual do imóvel.";
                }, {
                    readonly name: "lifecycle_state";
                    readonly type: "varchar";
                    readonly nullable: false;
                    readonly description: "Estado do ciclo de vida do imóvel.";
                }, {
                    readonly name: "property_count";
                    readonly type: "bigint";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de imóveis.";
                }, {
                    readonly name: "total_value";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total dos imóveis (BRL).";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "propertyId";
                    readonly column: "property_id";
                    readonly type: "string";
                    readonly description: "ID do imóvel";
                }, {
                    readonly dimensionId: "brokerId";
                    readonly column: "broker_id";
                    readonly type: "string";
                    readonly description: "ID do corretor responsável";
                }, {
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status atual do imóvel";
                }, {
                    readonly dimensionId: "lifecycleState";
                    readonly column: "lifecycle_state";
                    readonly type: "string";
                    readonly description: "Estado do ciclo de vida do imóvel";
                }];
                readonly measures: readonly [{
                    readonly measureId: "propertyCount";
                    readonly column: "property_count";
                    readonly aggregation: "sum";
                    readonly unit: "unidades";
                    readonly description: "Contagem de imóveis";
                }, {
                    readonly measureId: "totalValue";
                    readonly column: "total_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total dos imóveis";
                }];
                readonly sourceWriteEvents: readonly ["propertyCreated", "propertyUpdated", "propertyStatusChanged", "propertyLifecycleChanged"];
                readonly hypertable: {
                    readonly timeColumn: "event_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_property_status_metrics_event_time";
                        readonly columns: readonly ["event_time"];
                        readonly purpose: "Ordenação e filtros por janela temporal.";
                    }, {
                        readonly indexName: "idx_property_status_metrics_property_time";
                        readonly columns: readonly ["property_id", "event_time"];
                        readonly purpose: "Histórico temporal por imóvel.";
                    }, {
                        readonly indexName: "idx_property_status_metrics_broker_time";
                        readonly columns: readonly ["broker_id", "event_time"];
                        readonly purpose: "Análises por corretor ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_property_status_metrics_status_time";
                        readonly columns: readonly ["status", "event_time"];
                        readonly purpose: "Distribuição de imóveis por status e período.";
                    }, {
                        readonly indexName: "idx_property_status_metrics_lifecycle_time";
                        readonly columns: readonly ["lifecycle_state", "event_time"];
                        readonly purpose: "Distribuição por ciclo de vida e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/propertyStatusMetrics.defs.ts";
                readonly exportName: "propertyStatusMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default propertyStatusMetricsTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_1_external/visitScheduleRequest.defs" {
    export const visitScheduleRequestTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "visitScheduleRequest";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "visitScheduleRequest";
                readonly tableName: "visit_schedule_request";
                readonly moduleId: "propertyFlowCrm";
                readonly title: "Solicitação de agendamento de visita";
                readonly purpose: "Registrar pedidos de agendamento e alterações de visita.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "VisitScheduleRequest";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "visit_schedule_request_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da solicitação de agendamento de visita.";
                }, {
                    readonly name: "visit_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência à visita criada ou alterada pela solicitação.";
                }, {
                    readonly name: "property_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Imóvel alvo da solicitação de agendamento.";
                }, {
                    readonly name: "lead_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Lead alvo da solicitação de agendamento.";
                }, {
                    readonly name: "requested_start_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora solicitadas para início da visita.";
                }, {
                    readonly name: "requested_end_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly description: "Data e hora solicitadas para término da visita.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status atual da solicitação de agendamento.";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações adicionais para o agendamento.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação da solicitação.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização da solicitação.";
                }];
                readonly primaryKey: readonly ["visit_schedule_request_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "visit_id";
                    readonly targetEntity: "Visit";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular solicitação à visita criada ou alterada.";
                }, {
                    readonly fieldName: "property_id";
                    readonly targetEntity: "Property";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vínculo obrigatório ao imóvel da solicitação.";
                }, {
                    readonly fieldName: "lead_id";
                    readonly targetEntity: "Lead";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vínculo obrigatório ao lead da solicitação.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_visit_schedule_request_property";
                    readonly columns: readonly ["property_id", "requested_start_at"];
                    readonly unique: false;
                    readonly reason: "Filtrar solicitações por imóvel e janela de datas.";
                }, {
                    readonly indexName: "idx_visit_schedule_request_lead";
                    readonly columns: readonly ["lead_id", "requested_start_at"];
                    readonly unique: false;
                    readonly reason: "Filtrar solicitações por lead e janela de datas.";
                }, {
                    readonly indexName: "idx_visit_schedule_request_status";
                    readonly columns: readonly ["status", "requested_start_at"];
                    readonly unique: false;
                    readonly reason: "Listagens por status e data solicitada.";
                }, {
                    readonly indexName: "idx_visit_schedule_request_visit";
                    readonly columns: readonly ["visit_id"];
                    readonly unique: false;
                    readonly reason: "Localizar solicitação vinculada a uma visita.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "VisitScheduleRequestDetails";
                    readonly reason: "Armazenar dados adicionais da solicitação que não exigem filtro/consulta frequente.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["visitScheduling"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleVisitStatus"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/visitScheduleRequest.defs.ts";
                readonly exportName: "visitScheduleRequestTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default visitScheduleRequestTableDefinition;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/agendarVisita.defs" {
    export const useCase: {
        readonly usecaseId: "agendarVisita";
        readonly title: "Agendar visita";
        readonly purpose: "Criar agendamento de visita e registrar solicitação";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["visitEntity", "visitScheduleRequestEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visit_schedule_request";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleVisitStatus", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "visitEntity", "visitScheduleRequestEntity"];
        readonly commands: readonly [{
            readonly commandId: "agendarVisita";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "visitId";
            }, {
                readonly name: "visitScheduleRequestId";
                readonly type: "visitScheduleRequestId";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais campos de entrada são obrigatórios para agendar uma visita (ex.: corretorId, imóvelId, dataHora, clienteId)?"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/atualizarImovel.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarImovel";
        readonly title: "Atualizar imóvel";
        readonly purpose: "Atualizar dados e status de um imóvel";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyEntity"];
        readonly outputEntities: readonly ["propertyEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property_status_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["rulePropertyStatusLifecycle", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "propertyEntity"];
        readonly commands: readonly [{
            readonly commandId: "atualizarImovel";
            readonly input: readonly [{
                readonly name: "propertyEntity";
                readonly type: "propertyEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "propertyEntity";
                readonly type: "propertyEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/atualizarLead.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarLead";
        readonly title: "Atualizar lead";
        readonly purpose: "Atualizar dados de um lead";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadEntity"];
        readonly outputEntities: readonly ["leadEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleLeadPipelineStages", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "leadEntity"];
        readonly commands: readonly [{
            readonly commandId: "atualizarLead";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "lead";
                readonly type: "leadEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "lead";
                readonly type: "leadEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/atualizarMetricasDashboard.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarMetricasDashboard";
        readonly title: "Atualizar métricas do dashboard";
        readonly purpose: "Recalcular e persistir todas as métricas do dashboard";
        readonly actor: "admin";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["dashboardMetricEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property_description_request";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead_qualification_request";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead_stage_change";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_stage_change";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "property_status_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dashboard_metric_update";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "dealEntity", "dealStageChangeEntity", "leadEntity", "leadQualificationRequestEntity", "leadStageChangeEntity", "propertyDescriptionRequestEntity", "propertyEntity", "visitEntity"];
        readonly commands: readonly [{
            readonly commandId: "atualizarMetricasDashboard";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "dashboardMetricEntity";
                readonly type: "dashboardMetricEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/atualizarStatusVisita.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarStatusVisita";
        readonly title: "Atualizar status da visita";
        readonly purpose: "Alterar status de uma visita existente";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitEntity"];
        readonly outputEntities: readonly ["visitEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleVisitStatus", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "visitEntity"];
        readonly commands: readonly [{
            readonly commandId: "atualizarStatusVisita";
            readonly input: readonly [{
                readonly name: "visitId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "visitId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/avancarEtapaNegocio.defs" {
    export const useCase: {
        readonly usecaseId: "avancarEtapaNegocio";
        readonly title: "Avançar etapa do negócio";
        readonly purpose: "Mover negócio para próxima etapa e registrar mudança";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealEntity"];
        readonly outputEntities: readonly ["dealEntity", "dealStageChangeEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "deal_stage_change";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleDealStages", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "dealEntity", "dealStageChangeEntity"];
        readonly commands: readonly [{
            readonly commandId: "avancarEtapaNegocio";
            readonly input: readonly [{
                readonly name: "dealId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "currentStageId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "nextStageId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "deal";
                readonly type: "dealEntity";
            }, {
                readonly name: "dealStageChange";
                readonly type: "dealStageChangeEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarImovel.defs" {
    export const useCase: {
        readonly usecaseId: "criarImovel";
        readonly title: "Cadastrar imóvel";
        readonly purpose: "Criar novo imóvel no sistema";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["propertyEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "property_status_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["rulePropertyStatusLifecycle", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "propertyEntity"];
        readonly commands: readonly [{
            readonly commandId: "criarImovel";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "property";
                readonly type: "propertyEntity";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais campos de entrada são necessários para cadastrar o imóvel (ex.: endereço, tipo, preço, área, etc.)?", "O comando deve retornar apenas o identificador do imóvel ou o objeto completo de propertyEntity? Se apenas ID, qual o nome do campo?"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarLead.defs" {
    export const useCase: {
        readonly usecaseId: "criarLead";
        readonly title: "Cadastrar lead";
        readonly purpose: "Criar novo lead no sistema";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["leadEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleLeadPipelineStages", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "leadEntity"];
        readonly commands: readonly [{
            readonly commandId: "createLead";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "lead";
                readonly type: "leadEntity";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais campos de entrada são obrigatórios para cadastrar um lead (ex.: nome, contato, origem, corretorId)?", "O comando deve retornar somente o lead criado ou também métricas atualizadas (lead_pipeline_metrics, broker_activity_metrics)? Se retornar, quais campos?"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/criarNegocio.defs" {
    export const useCase: {
        readonly usecaseId: "criarNegocio";
        readonly title: "Criar negócio/proposta";
        readonly purpose: "Criar novo negócio no sistema";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["dealEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleDealStages", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "dealEntity"];
        readonly commands: readonly [{
            readonly commandId: "criarNegocio";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "dealEntity";
                readonly type: "dealEntity";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais são os campos obrigatórios para criar um negócio (ex.: brokerId, clienteId, produtoId, valor, estágio inicial, origem)?", "Há algum identificador externo ou referência que deve ser informada na criação?", "O retorno deve incluir apenas o dealEntity completo ou algum campo específico (ex.: dealId)?"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarAtualizacoesMetricas.defs" {
    export const useCase: {
        readonly usecaseId: "listarAtualizacoesMetricas";
        readonly title: "Listar atualizações de métricas";
        readonly purpose: "Listar histórico de execuções de atualização de métricas";
        readonly actor: "admin";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["dashboardMetricEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "dashboard_metric_update";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarAtualizacoesMetricas";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "atualizacoes";
                readonly type: "dashboardMetricEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarImoveis.defs" {
    export const useCase: {
        readonly usecaseId: "listarImoveis";
        readonly title: "Listar imóveis";
        readonly purpose: "Listagem e busca de imóveis";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["propertyEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
        readonly entityRefs: readonly ["propertyEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarImoveis";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "properties";
                readonly type: "propertyEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarLeads.defs" {
    export const useCase: {
        readonly usecaseId: "listarLeads";
        readonly title: "Listar leads";
        readonly purpose: "Listagem de leads e clientes";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["leadEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
        readonly entityRefs: readonly ["leadEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarLeads";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "leads";
                readonly type: "leadEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarMudancasEtapaLead.defs" {
    export const useCase: {
        readonly usecaseId: "listarMudancasEtapaLead";
        readonly title: "Listar mudanças de etapa do lead";
        readonly purpose: "Listar histórico de mudanças no pipeline de leads";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["leadStageChangeEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead_stage_change";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
        readonly entityRefs: readonly ["leadStageChangeEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarMudancasEtapaLead";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "leadStageChanges";
                readonly type: "leadStageChangeEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarMudancasEtapaNegocio.defs" {
    export const useCase: {
        readonly usecaseId: "listarMudancasEtapaNegocio";
        readonly title: "Listar mudanças de etapa do negócio";
        readonly purpose: "Listar histórico de mudanças nos negócios";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["dealStageChangeEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal_stage_change";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleDealStages"];
        readonly entityRefs: readonly ["dealStageChangeEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarMudancasEtapaNegocio";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "mudancasEtapaNegocio";
                readonly type: "dealStageChangeEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarNegocios.defs" {
    export const useCase: {
        readonly usecaseId: "listarNegocios";
        readonly title: "Listar negócios";
        readonly purpose: "Listagem de negócios e propostas";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["dealEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleDealStages"];
        readonly entityRefs: readonly ["dealEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarNegocios";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "negocios";
                readonly type: "dealEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarSolicitacoesAgendamentoVisita.defs" {
    export const useCase: {
        readonly usecaseId: "listarSolicitacoesAgendamentoVisita";
        readonly title: "Listar solicitações de agendamento de visita";
        readonly purpose: "Listar histórico de solicitações de agendamento";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["visitScheduleRequestEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit_schedule_request";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleVisitStatus"];
        readonly entityRefs: readonly ["visitScheduleRequestEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarSolicitacoesAgendamentoVisita";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "solicitacoesAgendamentoVisita";
                readonly type: "visitScheduleRequestEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarSolicitacoesDescricaoImovel.defs" {
    export const useCase: {
        readonly usecaseId: "listarSolicitacoesDescricaoImovel";
        readonly title: "Listar solicitações de descrição de imóvel";
        readonly purpose: "Listar histórico de solicitações de IA para descrição";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["propertyDescriptionRequestEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property_description_request";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleAiHumanReview"];
        readonly entityRefs: readonly ["propertyDescriptionRequestEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarSolicitacoesDescricaoImovel";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "solicitacoes";
                readonly type: "propertyDescriptionRequestEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarSolicitacoesQualificacaoLead.defs" {
    export const useCase: {
        readonly usecaseId: "listarSolicitacoesQualificacaoLead";
        readonly title: "Listar solicitações de qualificação de lead";
        readonly purpose: "Listar histórico de solicitações de IA para qualificação";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["leadQualificationRequestEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead_qualification_request";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleAiHumanReview"];
        readonly entityRefs: readonly ["leadQualificationRequestEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarSolicitacoesQualificacaoLead";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "solicitacoes";
                readonly type: "leadQualificationRequestEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/listarVisitas.defs" {
    export const useCase: {
        readonly usecaseId: "listarVisitas";
        readonly title: "Listar visitas";
        readonly purpose: "Listagem de visitas agendadas";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["visitEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleVisitStatus"];
        readonly entityRefs: readonly ["visitEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarVisitas";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "visitas";
                readonly type: "visitEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/moverEtapaLead.defs" {
    export const useCase: {
        readonly usecaseId: "moverEtapaLead";
        readonly title: "Mover lead no pipeline";
        readonly purpose: "Alterar etapa de um lead e registrar transição";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadEntity"];
        readonly outputEntities: readonly ["leadEntity", "leadStageChangeEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "lead_stage_change";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleLeadPipelineStages", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "leadEntity", "leadStageChangeEntity"];
        readonly commands: readonly [{
            readonly commandId: "moveLeadStage";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "toStageId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "lead";
                readonly type: "leadEntity";
            }, {
                readonly name: "leadStageChange";
                readonly type: "leadStageChangeEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/obterImovel.defs" {
    export const useCase: {
        readonly usecaseId: "obterImovel";
        readonly title: "Obter imóvel";
        readonly purpose: "Recuperar detalhes de um imóvel";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyEntity"];
        readonly outputEntities: readonly ["propertyEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
        readonly entityRefs: readonly ["propertyEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterImovel";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "property";
                readonly type: "propertyEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/obterLead.defs" {
    export const useCase: {
        readonly usecaseId: "obterLead";
        readonly title: "Obter lead";
        readonly purpose: "Recuperar detalhes de um lead";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadEntity"];
        readonly outputEntities: readonly ["leadEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
        readonly entityRefs: readonly ["leadEntity"];
        readonly commands: readonly [{
            readonly commandId: "getLead";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "lead";
                readonly type: "leadEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/obterMudancaEtapaLead.defs" {
    export const useCase: {
        readonly usecaseId: "obterMudancaEtapaLead";
        readonly title: "Obter mudança de etapa do lead";
        readonly purpose: "Recuperar detalhes de uma mudança de etapa";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadStageChangeEntity"];
        readonly outputEntities: readonly ["leadStageChangeEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead_stage_change";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
        readonly entityRefs: readonly ["leadStageChangeEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterMudancaEtapaLead";
            readonly input: readonly [{
                readonly name: "leadStageChangeId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "leadStageChange";
                readonly type: "leadStageChangeEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/obterMudancaEtapaNegocio.defs" {
    export const useCase: {
        readonly usecaseId: "obterMudancaEtapaNegocio";
        readonly title: "Obter mudança de etapa do negócio";
        readonly purpose: "Recuperar detalhes de uma mudança de etapa";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealStageChangeEntity"];
        readonly outputEntities: readonly ["dealStageChangeEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal_stage_change";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleDealStages"];
        readonly entityRefs: readonly ["dealStageChangeEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterMudancaEtapaNegocio";
            readonly input: readonly [{
                readonly name: "dealStageChangeId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "dealStageChange";
                readonly type: "dealStageChangeEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/obterNegocio.defs" {
    export const useCase: {
        readonly usecaseId: "obterNegocio";
        readonly title: "Obter negócio";
        readonly purpose: "Recuperar detalhes de um negócio";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dealEntity"];
        readonly outputEntities: readonly ["dealEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleDealStages"];
        readonly entityRefs: readonly ["dealEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterNegocio";
            readonly input: readonly [{
                readonly name: "dealId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "deal";
                readonly type: "dealEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/obterSolicitacaoAgendamentoVisita.defs" {
    export const useCase: {
        readonly usecaseId: "obterSolicitacaoAgendamentoVisita";
        readonly title: "Obter solicitação de agendamento de visita";
        readonly purpose: "Recuperar detalhes de uma solicitação de agendamento";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitScheduleRequestEntity"];
        readonly outputEntities: readonly ["visitScheduleRequestEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit_schedule_request";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleVisitStatus"];
        readonly entityRefs: readonly ["visitScheduleRequestEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterSolicitacaoAgendamentoVisita";
            readonly input: readonly [{
                readonly name: "visitScheduleRequestId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "visitScheduleRequest";
                readonly type: "visitScheduleRequestEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/obterSolicitacaoDescricaoImovel.defs" {
    export const useCase: {
        readonly usecaseId: "obterSolicitacaoDescricaoImovel";
        readonly title: "Obter solicitação de descrição de imóvel";
        readonly purpose: "Recuperar detalhes de uma solicitação de descrição";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyDescriptionRequestEntity"];
        readonly outputEntities: readonly ["propertyDescriptionRequestEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property_description_request";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleAiHumanReview"];
        readonly entityRefs: readonly ["propertyDescriptionRequestEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterSolicitacaoDescricaoImovel";
            readonly input: readonly [{
                readonly name: "propertyDescriptionRequestId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "propertyDescriptionRequest";
                readonly type: "propertyDescriptionRequestEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/obterSolicitacaoQualificacaoLead.defs" {
    export const useCase: {
        readonly usecaseId: "obterSolicitacaoQualificacaoLead";
        readonly title: "Obter solicitação de qualificação de lead";
        readonly purpose: "Recuperar detalhes de uma solicitação de qualificação";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadQualificationRequestEntity"];
        readonly outputEntities: readonly ["leadQualificationRequestEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead_qualification_request";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleAiHumanReview"];
        readonly entityRefs: readonly ["leadQualificationRequestEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterSolicitacaoQualificacaoLead";
            readonly input: readonly [{
                readonly name: "leadQualificationRequestId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "leadQualificationRequest";
                readonly type: "leadQualificationRequestEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/obterVisita.defs" {
    export const useCase: {
        readonly usecaseId: "obterVisita";
        readonly title: "Obter visita";
        readonly purpose: "Recuperar detalhes de uma visita";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["visitEntity"];
        readonly outputEntities: readonly ["visitEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleVisitStatus"];
        readonly entityRefs: readonly ["visitEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterVisita";
            readonly input: readonly [{
                readonly name: "visitId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "visit";
                readonly type: "visitEntity";
            }];
        }];
        readonly pendingQuestions: readonly ["Qual é o identificador de entrada esperado para recuperar a visita (ex.: visitId)?", "Quais campos compõem o visitEntity retornado?"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/solicitarDescricaoImovel.defs" {
    export const useCase: {
        readonly usecaseId: "solicitarDescricaoImovel";
        readonly title: "Solicitar descrição do imóvel via IA";
        readonly purpose: "Criar solicitação de geração de descrição para um imóvel";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["propertyEntity"];
        readonly outputEntities: readonly ["propertyDescriptionRequestEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "property_description_request";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleAiHumanReview", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "propertyDescriptionRequestEntity", "propertyEntity"];
        readonly commands: readonly [{
            readonly commandId: "solicitarDescricaoImovel";
            readonly input: readonly [{
                readonly name: "propertyId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "brokerId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "propertyDescriptionRequestId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais são os campos mínimos de entrada para identificar o imóvel e o corretor? Confirma propertyId e brokerId ou há outros obrigatórios?"];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/solicitarQualificacaoLead.defs" {
    export const useCase: {
        readonly usecaseId: "solicitarQualificacaoLead";
        readonly title: "Solicitar qualificação do lead via IA";
        readonly purpose: "Criar solicitação de qualificação de temperatura para um lead";
        readonly actor: "corretor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["leadEntity"];
        readonly outputEntities: readonly ["leadQualificationRequestEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "lead_qualification_request";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["ruleAiHumanReview", "ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity", "leadEntity", "leadQualificationRequestEntity"];
        readonly commands: readonly [{
            readonly commandId: "solicitarQualificacaoLead";
            readonly input: readonly [{
                readonly name: "leadId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "leadQualificationRequestId";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/visualizarAdminDashboard.defs" {
    export const useCase: {
        readonly usecaseId: "visualizarAdminDashboard";
        readonly title: "Visualizar dashboard administrativo";
        readonly purpose: "Apresentar métricas e histórico de atualizações para admin";
        readonly actor: "admin";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["dashboardMetricEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property_status_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dashboard_metric_update";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity"];
        readonly commands: readonly [{
            readonly commandId: "visualizarAdminDashboard";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "dashboardMetrics";
                readonly type: "dashboardMetricEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_3_usecases/visualizarDashboard.defs" {
    export const useCase: {
        readonly usecaseId: "visualizarDashboard";
        readonly title: "Visualizar dashboard de métricas";
        readonly purpose: "Apresentar métricas consolidadas para gestores";
        readonly actor: "gestor";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly ["dashboardMetricEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "property_status_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly ["ruleMetricRefresh"];
        readonly entityRefs: readonly ["dashboardMetricEntity"];
        readonly commands: readonly [{
            readonly commandId: "getDashboardMetrics";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "metrics";
                readonly type: "dashboardMetricEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/broker.defs" {
    export const entity: {
        readonly entityId: "broker";
        readonly title: "Corretor";
        readonly purpose: "MDM-backed entity for Broker (data lives in the shared MDM infrastructure, project 102034)";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "brokerId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do corretor.";
        }, {
            readonly fieldId: "fullName";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome completo do corretor.";
        }, {
            readonly fieldId: "email";
            readonly type: "string";
            readonly required: false;
            readonly description: "E-mail de contato do corretor.";
        }, {
            readonly fieldId: "phone";
            readonly type: "string";
            readonly required: false;
            readonly description: "Telefone de contato do corretor.";
        }, {
            readonly fieldId: "licenseNumber";
            readonly type: "string";
            readonly required: false;
            readonly description: "Número de registro/CRECI do corretor.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Situação do corretor no sistema.";
            readonly enum: readonly ["ativo", "inativo"];
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["ativo", "inativo"];
        readonly lifecycleStates: readonly ["ativo", "inativo"];
        readonly sourceTables: readonly [{
            readonly tableName: "Broker";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Broker";
            readonly domainId: "broker";
            readonly sourceOfTruth: "102034";
        }];
        readonly allowedOperations: readonly ["read", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly [];
        readonly materialization: {
            readonly fileName: "layer_4_entities/BrokerEntity.ts";
            readonly className: "BrokerEntity";
            readonly contractName: "IBrokerEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/dashboardMetricEntity.defs" {
    export const entity: {
        readonly entityId: "dashboardMetricEntity";
        readonly title: "Métricas do Dashboard";
        readonly purpose: "Consolidação de tabelas de métricas e controle de atualizações";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "dashboardMetricUpdateId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da atualização de métricas do dashboard.";
        }, {
            readonly fieldId: "propertyIds";
            readonly type: "Property";
            readonly required: false;
            readonly description: "Imóveis agregados para cálculo das métricas nesta atualização.";
        }, {
            readonly fieldId: "leadIds";
            readonly type: "Lead";
            readonly required: false;
            readonly description: "Leads agregados para cálculo das métricas nesta atualização.";
        }, {
            readonly fieldId: "dealIds";
            readonly type: "Deal";
            readonly required: false;
            readonly description: "Negócios agregados para cálculo das métricas nesta atualização.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do evento de atualização.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "dashboard_metric_update";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "property_status_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "lead_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "deal_pipeline_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "broker_activity_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "dashboardMetricUpdate";
            readonly tableName: "dashboard_metric_update";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/dashboardMetricUpdate.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "propertyStatusMetrics";
            readonly tableName: "property_status_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/propertyStatusMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "leadPipelineMetrics";
            readonly tableName: "lead_pipeline_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/leadPipelineMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "dealPipelineMetrics";
            readonly tableName: "deal_pipeline_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/dealPipelineMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "brokerActivityMetrics";
            readonly tableName: "broker_activity_metrics";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/brokerActivityMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["criarImovel", "atualizarImovel", "criarLead", "atualizarLead", "agendarVisita", "atualizarStatusVisita", "criarNegocio", "avancarEtapaNegocio", "solicitarDescricaoImovel", "solicitarQualificacaoLead", "moverEtapaLead", "visualizarDashboard", "visualizarAdminDashboard", "listarAtualizacoesMetricas", "atualizarMetricasDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/DashboardMetricEntity.ts";
            readonly className: "DashboardMetricEntity";
            readonly contractName: "IDashboardMetricEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/dealEntity.defs" {
    export const entity: {
        readonly entityId: "dealEntity";
        readonly title: "Negócio/Proposta";
        readonly purpose: "Gestão de negócios e propostas";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "dealId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do negócio.";
        }, {
            readonly fieldId: "propertyId";
            readonly type: "Property";
            readonly required: true;
            readonly description: "Imóvel associado ao negócio.";
        }, {
            readonly fieldId: "leadId";
            readonly type: "Lead";
            readonly required: true;
            readonly description: "Lead associado ao negócio.";
        }, {
            readonly fieldId: "brokerId";
            readonly type: "Broker";
            readonly required: true;
            readonly description: "Corretor responsável pelo negócio.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Etapa atual do negócio.";
            readonly enum: readonly ["rascunho", "enviada", "emNegociacao", "aceita", "recusada", "fechada"];
        }, {
            readonly fieldId: "amount";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor proposto para o negócio.";
        }, {
            readonly fieldId: "notes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações adicionais sobre o negócio.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["rascunho", "enviada", "emNegociacao", "aceita", "recusada", "fechada"];
        readonly lifecycleStates: readonly ["rascunho", "enviada", "emNegociacao", "aceita", "recusada", "fechada"];
        readonly sourceTables: readonly [{
            readonly tableName: "deal";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Deal";
            readonly domainId: "deal";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["ruleDealStages"];
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["listarNegocios", "obterNegocio", "criarNegocio", "avancarEtapaNegocio", "atualizarMetricasDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/DealEntity.ts";
            readonly className: "DealEntity";
            readonly contractName: "IDealEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/dealStageChangeEntity.defs" {
    export const entity: {
        readonly entityId: "dealStageChangeEntity";
        readonly title: "Mudança de Etapa do Negócio";
        readonly purpose: "Histórico de mudanças de etapa nos negócios";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "dealStageChangeId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da mudança de etapa do negócio.";
        }, {
            readonly fieldId: "dealId";
            readonly type: "Deal";
            readonly required: true;
            readonly description: "Negócio alvo cuja etapa será alterada.";
        }, {
            readonly fieldId: "fromStage";
            readonly type: "string";
            readonly required: true;
            readonly description: "Etapa anterior do negócio antes da mudança.";
        }, {
            readonly fieldId: "toStage";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nova etapa do negócio após a mudança.";
        }, {
            readonly fieldId: "changedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que a mudança de etapa ocorreu.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro de mudança.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro de mudança.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "deal_stage_change";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "dealStageChange";
            readonly tableName: "deal_stage_change";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/dealStageChange.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["avancarEtapaNegocio", "listarMudancasEtapaNegocio", "obterMudancaEtapaNegocio", "atualizarMetricasDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/DealStageChangeEntity.ts";
            readonly className: "DealStageChangeEntity";
            readonly contractName: "IDealStageChangeEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/leadEntity.defs" {
    export const entity: {
        readonly entityId: "leadEntity";
        readonly title: "Lead/Cliente";
        readonly purpose: "Gestão de leads e clientes";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "leadId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do lead.";
        }, {
            readonly fieldId: "brokerId";
            readonly type: "Broker";
            readonly required: true;
            readonly description: "Corretor responsável pelo lead.";
        }, {
            readonly fieldId: "fullName";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome completo do lead.";
        }, {
            readonly fieldId: "email";
            readonly type: "string";
            readonly required: false;
            readonly description: "E-mail principal do lead.";
        }, {
            readonly fieldId: "phone";
            readonly type: "string";
            readonly required: false;
            readonly description: "Telefone de contato do lead.";
        }, {
            readonly fieldId: "notes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Anotações sobre o lead.";
        }, {
            readonly fieldId: "leadTemperature";
            readonly type: "string";
            readonly required: false;
            readonly description: "Temperatura do lead (ex.: frio, morno, quente).";
        }, {
            readonly fieldId: "source";
            readonly type: "string";
            readonly required: false;
            readonly description: "Origem do lead (ex.: indicação, portal, anúncio).";
        }, {
            readonly fieldId: "leadStatus";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual do lead no pipeline.";
            readonly enum: readonly ["novo", "emContato", "qualificado", "proposta", "fechado", "perdido"];
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["novo", "emContato", "qualificado", "proposta", "fechado", "perdido"];
        readonly lifecycleStates: readonly ["captado", "qualificado", "negociacao", "fechado", "perdido"];
        readonly sourceTables: readonly [{
            readonly tableName: "lead";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Lead";
            readonly domainId: "lead";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["ruleLeadPipelineStages"];
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["listarLeads", "obterLead", "criarLead", "atualizarLead", "solicitarQualificacaoLead", "moverEtapaLead", "atualizarMetricasDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/LeadEntity.ts";
            readonly className: "LeadEntity";
            readonly contractName: "ILeadEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/leadQualificationRequestEntity.defs" {
    export const entity: {
        readonly entityId: "leadQualificationRequestEntity";
        readonly title: "Solicitação de Qualificação do Lead";
        readonly purpose: "Solicitações de qualificação de lead via IA";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "leadQualificationRequestId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da solicitação de qualificação do lead.";
        }, {
            readonly fieldId: "leadId";
            readonly type: "Lead";
            readonly required: true;
            readonly description: "Referência ao lead alvo da qualificação.";
        }, {
            readonly fieldId: "leadTemperature";
            readonly type: "string";
            readonly required: true;
            readonly description: "Temperatura/classificação do lead sugerida.";
            readonly enum: readonly ["frio", "morno", "quente"];
        }, {
            readonly fieldId: "followUpSuggestion";
            readonly type: "text";
            readonly required: false;
            readonly description: "Sugestão de ação de follow-up para o lead.";
        }, {
            readonly fieldId: "aiGenerated";
            readonly type: "boolean";
            readonly required: true;
            readonly description: "Indica se a qualificação e sugestão foram geradas por IA.";
        }, {
            readonly fieldId: "reviewStatus";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status de revisão humana da qualificação gerada por IA.";
            readonly enum: readonly ["pendente", "aprovado", "rejeitado"];
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data/hora de criação da solicitação.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data/hora da última atualização da solicitação.";
        }];
        readonly statusEnum: readonly ["pendente", "emRevisao", "concluida", "cancelada"];
        readonly lifecycleStates: readonly ["criada", "qualificada", "revisada", "finalizada"];
        readonly sourceTables: readonly [{
            readonly tableName: "lead_qualification_request";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "leadQualificationRequest";
            readonly tableName: "lead_qualification_request";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/leadQualificationRequest.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["listarSolicitacoesQualificacaoLead", "obterSolicitacaoQualificacaoLead", "solicitarQualificacaoLead", "atualizarMetricasDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/LeadQualificationRequestEntity.ts";
            readonly className: "LeadQualificationRequestEntity";
            readonly contractName: "ILeadQualificationRequestEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/leadStageChangeEntity.defs" {
    export const entity: {
        readonly entityId: "leadStageChangeEntity";
        readonly title: "Mudança de Etapa do Lead";
        readonly purpose: "Histórico de mudanças de etapa no pipeline de leads";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "leadStageChangeId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da mudança de etapa do lead.";
        }, {
            readonly fieldId: "leadId";
            readonly type: "Lead";
            readonly required: true;
            readonly description: "Lead alvo da mudança de etapa.";
        }, {
            readonly fieldId: "fromStage";
            readonly type: "string";
            readonly required: true;
            readonly description: "Etapa anterior do lead no pipeline.";
        }, {
            readonly fieldId: "toStage";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nova etapa do lead no pipeline.";
        }, {
            readonly fieldId: "changedByBrokerId";
            readonly type: "Broker";
            readonly required: true;
            readonly description: "Responsável pela mudança de etapa.";
        }, {
            readonly fieldId: "changedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da mudança de etapa.";
        }, {
            readonly fieldId: "note";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações ou motivo da mudança de etapa.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data de criação do registro de mudança.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data da última atualização do registro de mudança.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "lead_stage_change";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "leadStageChange";
            readonly tableName: "lead_stage_change";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/leadStageChange.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["listarMudancasEtapaLead", "obterMudancaEtapaLead", "moverEtapaLead", "atualizarMetricasDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/LeadStageChangeEntity.ts";
            readonly className: "LeadStageChangeEntity";
            readonly contractName: "ILeadStageChangeEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/propertyDescriptionRequestEntity.defs" {
    export const entity: {
        readonly entityId: "propertyDescriptionRequestEntity";
        readonly title: "Solicitação de Descrição do Imóvel";
        readonly purpose: "Solicitações de geração de descrição via IA";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "id";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da solicitação de descrição.";
        }, {
            readonly fieldId: "propertyId";
            readonly type: "Property";
            readonly required: true;
            readonly description: "Imóvel alvo para o qual a descrição será gerada.";
        }, {
            readonly fieldId: "bullets";
            readonly type: "text";
            readonly required: true;
            readonly description: "Lista de pontos/bullets informados para compor a descrição.";
        }, {
            readonly fieldId: "aiDescription";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição gerada por IA a partir dos bullets.";
        }, {
            readonly fieldId: "humanReviewNotes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações e ajustes realizados na revisão humana.";
        }, {
            readonly fieldId: "reviewStatus";
            readonly type: "string";
            readonly required: true;
            readonly description: "Estado da revisão humana da descrição gerada.";
            readonly enum: readonly ["pendente", "aprovada", "rejeitada"];
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação da solicitação.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização da solicitação.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "property_description_request";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "propertyDescriptionRequest";
            readonly tableName: "property_description_request";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/propertyDescriptionRequest.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["listarSolicitacoesDescricaoImovel", "obterSolicitacaoDescricaoImovel", "solicitarDescricaoImovel", "atualizarMetricasDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/PropertyDescriptionRequestEntity.ts";
            readonly className: "PropertyDescriptionRequestEntity";
            readonly contractName: "IPropertyDescriptionRequestEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/propertyEntity.defs" {
    export const entity: {
        readonly entityId: "propertyEntity";
        readonly title: "Imóvel";
        readonly purpose: "Gestão completa de imóveis do CRM";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "propertyId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do imóvel.";
        }, {
            readonly fieldId: "brokerId";
            readonly type: "Broker";
            readonly required: true;
            readonly description: "Corretor responsável pelo imóvel.";
        }, {
            readonly fieldId: "address";
            readonly type: "text";
            readonly required: true;
            readonly description: "Endereço completo do imóvel.";
        }, {
            readonly fieldId: "propertyType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo do imóvel (ex.: apartamento, casa, sala comercial).";
        }, {
            readonly fieldId: "price";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço anunciado do imóvel.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual do imóvel.";
            readonly enum: readonly ["ativo", "inativo", "vendido", "reservado"];
        }, {
            readonly fieldId: "lifecycleState";
            readonly type: "string";
            readonly required: true;
            readonly description: "Estado do ciclo de vida do imóvel.";
            readonly enum: readonly ["captado", "publicado", "emNegociacao", "vendido", "arquivado"];
        }, {
            readonly fieldId: "features";
            readonly type: "text";
            readonly required: false;
            readonly description: "Características e detalhes do imóvel.";
        }, {
            readonly fieldId: "photosMock";
            readonly type: "text";
            readonly required: false;
            readonly description: "Referências ou descrições de fotos mock do imóvel.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["ativo", "inativo", "vendido", "reservado"];
        readonly lifecycleStates: readonly ["captado", "publicado", "emNegociacao", "vendido", "arquivado"];
        readonly sourceTables: readonly [{
            readonly tableName: "property";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Property";
            readonly domainId: "property";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["rulePropertyStatusLifecycle"];
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list", "search"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["listarImoveis", "obterImovel", "criarImovel", "atualizarImovel", "solicitarDescricaoImovel", "atualizarMetricasDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/PropertyEntity.ts";
            readonly className: "PropertyEntity";
            readonly contractName: "IPropertyEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/visitEntity.defs" {
    export const entity: {
        readonly entityId: "visitEntity";
        readonly title: "Visita/Agendamento";
        readonly purpose: "Gestão de visitas e agendamentos";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "visitId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da visita.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual da visita.";
            readonly enum: readonly ["agendada", "confirmada", "reagendada", "realizada", "cancelada"];
        }, {
            readonly fieldId: "propertyId";
            readonly type: "Property";
            readonly required: true;
            readonly description: "Imóvel vinculado à visita.";
        }, {
            readonly fieldId: "leadId";
            readonly type: "Lead";
            readonly required: true;
            readonly description: "Lead vinculado à visita.";
        }, {
            readonly fieldId: "brokerId";
            readonly type: "Broker";
            readonly required: false;
            readonly description: "Corretor responsável pela visita.";
        }, {
            readonly fieldId: "scheduledAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora agendadas para a visita.";
        }, {
            readonly fieldId: "notes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações ou instruções para a visita.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["agendada", "confirmada", "reagendada", "realizada", "cancelada"];
        readonly sourceTables: readonly [{
            readonly tableName: "visit";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Visit";
            readonly domainId: "visit";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["ruleVisitStatus"];
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["listarVisitas", "obterVisita", "agendarVisita", "atualizarStatusVisita", "atualizarMetricasDashboard"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/VisitEntity.ts";
            readonly className: "VisitEntity";
            readonly contractName: "IVisitEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l1/propertyFlowCrm/layer_4_entities/visitScheduleRequestEntity.defs" {
    export const entity: {
        readonly entityId: "visitScheduleRequestEntity";
        readonly title: "Solicitação de Agendamento de Visita";
        readonly purpose: "Registro de solicitações de agendamento de visita";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "visitScheduleRequestId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da solicitação de agendamento de visita.";
        }, {
            readonly fieldId: "visitId";
            readonly type: "Visit";
            readonly required: false;
            readonly description: "Referência à visita criada ou alterada pela solicitação.";
        }, {
            readonly fieldId: "propertyId";
            readonly type: "Property";
            readonly required: true;
            readonly description: "Imóvel alvo da solicitação de agendamento.";
        }, {
            readonly fieldId: "leadId";
            readonly type: "Lead";
            readonly required: true;
            readonly description: "Lead alvo da solicitação de agendamento.";
        }, {
            readonly fieldId: "requestedStartAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora solicitadas para início da visita.";
        }, {
            readonly fieldId: "requestedEndAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora solicitadas para término da visita.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual da solicitação de agendamento.";
        }, {
            readonly fieldId: "notes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações adicionais para o agendamento.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação da solicitação.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização da solicitação.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "visit_schedule_request";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "visitScheduleRequest";
            readonly tableName: "visit_schedule_request";
            readonly fileRef: "_102045_/l1/propertyFlowCrm/layer_1_external/visitScheduleRequest.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["agendarVisita", "listarSolicitacoesAgendamentoVisita", "obterSolicitacaoAgendamentoVisita"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/VisitScheduleRequestEntity.ts";
            readonly className: "VisitScheduleRequestEntity";
            readonly contractName: "IVisitScheduleRequestEntity";
        };
    };
    export default entity;
}
declare module "_102045_/l2/propertyFlowCrm/adminDashboard.defs" {
    export const adminDashboardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "adminDashboard";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "adminDashboard";
                readonly pageName: "Dashboard administrativo";
                readonly actor: "admin";
                readonly purpose: "Monitorar métricas administrativas e forçar atualização.";
                readonly capabilities: readonly ["adminDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["dashboardMetricsUpdateFlow"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["query"];
                    readonly description: "Data inicial do período de análise no dashboard administrativo.";
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["query"];
                    readonly description: "Data final do período de análise no dashboard administrativo.";
                }];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros de período";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Seletor de período";
                        readonly purpose: "Definir o recorte temporal das métricas exibidas.";
                        readonly userActions: readonly ["definirPeriodo", "limparPeriodo"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleMetricRefresh"];
                    }];
                }, {
                    readonly sectionName: "Indicadores administrativos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Painel de métricas administrativas";
                        readonly purpose: "Exibir métricas agregadas de imóveis, leads, negócios e atividade dos corretores.";
                        readonly userActions: readonly ["visualizarIndicadores"];
                        readonly requiredEntities: readonly ["dashboardMetricEntity"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleMetricRefresh"];
                    }];
                }, {
                    readonly sectionName: "Histórico de atualizações";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de atualizações de métricas";
                        readonly purpose: "Mostrar o histórico recente de atualizações das métricas do dashboard.";
                        readonly userActions: readonly ["visualizarHistoricoAtualizacoes"];
                        readonly requiredEntities: readonly ["DashboardMetricUpdate"];
                        readonly readsFields: readonly ["dashboardMetricUpdateId", "createdAt", "updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleMetricRefresh"];
                    }];
                }, {
                    readonly sectionName: "Ações administrativas";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "Botão de atualização de métricas";
                        readonly purpose: "Permitir que o admin force a atualização das métricas do dashboard.";
                        readonly userActions: readonly ["refreshMetrics"];
                        readonly requiredEntities: readonly ["dashboardMetricEntity", "DashboardMetricUpdate"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["updatedAt"];
                        readonly rulesApplied: readonly ["ruleMetricRefresh"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "visualizarAdminDashboard";
                readonly purpose: "Carregar indicadores administrativos.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dashboardMetrics";
                    readonly type: "dashboardMetricEntity";
                }, {
                    readonly name: "lastUpdateAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["dashboardMetricEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["property_status_metrics", "lead_pipeline_metrics", "deal_pipeline_metrics", "broker_activity_metrics", "dashboard_metric_update"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["visualizarAdminDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleMetricRefresh"];
            }, {
                readonly commandName: "listarAtualizacoesMetricas";
                readonly purpose: "Exibir histórico de atualizações de métricas.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dashboardMetricUpdates";
                    readonly type: "DashboardMetricUpdate[]";
                }];
                readonly readsEntities: readonly ["DashboardMetricUpdate"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["dashboard_metric_update"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarAtualizacoesMetricas"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleMetricRefresh"];
            }, {
                readonly commandName: "atualizarMetricasDashboard";
                readonly purpose: "Forçar atualização das métricas.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "refreshStatus";
                    readonly type: "string";
                }, {
                    readonly name: "requestedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["dashboardMetricEntity"];
                readonly writesEntities: readonly ["dashboardMetricEntity", "DashboardMetricUpdate"];
                readonly readsTables: readonly ["property_description_request", "lead_qualification_request", "lead_stage_change", "deal_stage_change"];
                readonly writesTables: readonly ["property_status_metrics", "lead_pipeline_metrics", "deal_pipeline_metrics", "broker_activity_metrics", "dashboard_metric_update"];
                readonly usecaseRefs: readonly ["atualizarMetricasDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleMetricRefresh"];
            }];
        };
    };
    export default adminDashboardPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/dashboard.defs" {
    export const dashboardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dashboard";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dashboard";
                readonly pageName: "Dashboard de métricas";
                readonly actor: "gestor";
                readonly purpose: "Acompanhar KPIs e métricas de leads, imóveis e negócios.";
                readonly capabilities: readonly ["viewDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["dashboardMetricsUpdateFlow"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "startDate";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data inicial do período para filtros de métricas.";
                }, {
                    readonly name: "endDate";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data final do período para filtros de métricas.";
                }];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros do dashboard";
                    readonly mode: "filter";
                    readonly organisms: readonly [{
                        readonly organismName: "filtroPeriodoDashboard";
                        readonly purpose: "Selecionar período de análise das métricas.";
                        readonly userActions: readonly ["aplicarFiltroPeriodo"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "KPIs principais";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "cardsKpiDashboard";
                        readonly purpose: "Exibir indicadores consolidados de imóveis, leads, negócios e atividade.";
                        readonly userActions: readonly ["visualizarIndicadores"];
                        readonly requiredEntities: readonly ["dashboardMetricEntity"];
                        readonly readsFields: readonly ["dashboardMetricEntity.propertyStatusMetrics", "dashboardMetricEntity.leadPipelineMetrics", "dashboardMetricEntity.dealPipelineMetrics", "dashboardMetricEntity.brokerActivityMetrics", "dashboardMetricEntity.dashboardMetricUpdate"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleMetricRefresh"];
                    }];
                }, {
                    readonly sectionName: "Séries e distribuição";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "graficosMetricasDashboard";
                        readonly purpose: "Visualizar séries temporais e distribuição por status, etapas e corretores.";
                        readonly userActions: readonly ["visualizarSeries"];
                        readonly requiredEntities: readonly ["dashboardMetricEntity"];
                        readonly readsFields: readonly ["dashboardMetricEntity.propertyStatusMetrics", "dashboardMetricEntity.leadPipelineMetrics", "dashboardMetricEntity.dealPipelineMetrics", "dashboardMetricEntity.brokerActivityMetrics"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleMetricRefresh"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "visualizarDashboard";
                readonly purpose: "Carregar métricas para o dashboard do gestor.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "startDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "endDate";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "totalProperties";
                    readonly type: "number";
                }, {
                    readonly name: "activeProperties";
                    readonly type: "number";
                }, {
                    readonly name: "leadsThisMonth";
                    readonly type: "number";
                }, {
                    readonly name: "qualifiedLeads";
                    readonly type: "number";
                }, {
                    readonly name: "dealCount";
                    readonly type: "number";
                }, {
                    readonly name: "dealValue";
                    readonly type: "number";
                }, {
                    readonly name: "avgDealValue";
                    readonly type: "number";
                }, {
                    readonly name: "activityCount";
                    readonly type: "number";
                }, {
                    readonly name: "propertyStatusSeries";
                    readonly type: "MetricSeries";
                }, {
                    readonly name: "leadStageSeries";
                    readonly type: "MetricSeries";
                }, {
                    readonly name: "dealStageSeries";
                    readonly type: "MetricSeries";
                }, {
                    readonly name: "brokerActivitySeries";
                    readonly type: "MetricSeries";
                }, {
                    readonly name: "lastUpdatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["dashboardMetricEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["dashboard_metric_update", "property_status_metrics", "lead_pipeline_metrics", "deal_pipeline_metrics", "broker_activity_metrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["visualizarDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleMetricRefresh"];
            }];
        };
    };
    export default dashboardPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/dealsTracker.defs" {
    export const dealsTrackerPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dealsTracker";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dealsTracker";
                readonly pageName: "Rastreador de negócios";
                readonly actor: "corretor";
                readonly purpose: "Criar propostas e avançar etapas do negócio.";
                readonly capabilities: readonly ["trackDeals"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dealStageProgressFlow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["deal", "lead", "property"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Pipeline de negócios";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "FiltroETabelaDeNegocios";
                        readonly purpose: "Listar negócios por etapa e pesquisa para acompanhar o pipeline.";
                        readonly userActions: readonly ["filtrarPorEtapa", "buscarNegocio", "selecionarNegocio"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["dealId", "status", "leadId", "propertyId", "valorProposta", "updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleDealStages"];
                    }, {
                        readonly organismName: "CriarPropostaRapida";
                        readonly purpose: "Criar novo negócio/proposta a partir de lead e imóvel selecionados.";
                        readonly userActions: readonly ["criarNegocio"];
                        readonly requiredEntities: readonly ["Deal", "Lead", "Property"];
                        readonly readsFields: readonly ["leadId", "propertyId"];
                        readonly writesFields: readonly ["dealId", "status", "leadId", "propertyId", "valorProposta", "createdAt"];
                        readonly rulesApplied: readonly ["ruleDealStages"];
                    }];
                }, {
                    readonly sectionName: "Detalhes do negócio";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ResumoDoNegocio";
                        readonly purpose: "Exibir detalhes do negócio selecionado e sua etapa atual.";
                        readonly userActions: readonly ["visualizarNegocio"];
                        readonly requiredEntities: readonly ["Deal"];
                        readonly readsFields: readonly ["dealId", "status", "leadId", "propertyId", "valorProposta", "descricao", "updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleDealStages"];
                    }, {
                        readonly organismName: "AvancarEtapaDoNegocio";
                        readonly purpose: "Mover o negócio para a próxima etapa conforme o fluxo.";
                        readonly userActions: readonly ["avancarEtapaNegocio"];
                        readonly requiredEntities: readonly ["Deal", "DealStageChange"];
                        readonly readsFields: readonly ["dealId", "status", "valorProposta"];
                        readonly writesFields: readonly ["status", "dealStageChangeId", "fromStage", "toStage", "changedAt"];
                        readonly rulesApplied: readonly ["ruleDealStages"];
                    }, {
                        readonly organismName: "HistoricoDeEtapas";
                        readonly purpose: "Exibir histórico de mudanças de etapa do negócio.";
                        readonly userActions: readonly ["visualizarHistoricoEtapas"];
                        readonly requiredEntities: readonly ["DealStageChange"];
                        readonly readsFields: readonly ["dealStageChangeId", "dealId", "fromStage", "toStage", "changedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleDealStages"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarNegocios";
                readonly purpose: "Carregar negócios por etapa.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "etapa";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "termoPesquisa";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "Deal";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "leadId";
                    readonly type: "Lead";
                }, {
                    readonly name: "propertyId";
                    readonly type: "Property";
                }, {
                    readonly name: "valorProposta";
                    readonly type: "number";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Deal"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarNegocios"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealStages"];
            }, {
                readonly commandName: "obterNegocio";
                readonly purpose: "Carregar detalhes do negócio selecionado.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "Deal";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "Deal";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "leadId";
                    readonly type: "Lead";
                }, {
                    readonly name: "propertyId";
                    readonly type: "Property";
                }, {
                    readonly name: "valorProposta";
                    readonly type: "number";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Deal"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["obterNegocio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealStages"];
            }, {
                readonly commandName: "criarNegocio";
                readonly purpose: "Criar nova proposta vinculada.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "Lead";
                    readonly required: true;
                }, {
                    readonly name: "propertyId";
                    readonly type: "Property";
                    readonly required: true;
                }, {
                    readonly name: "valorProposta";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "termosIniciais";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "Deal";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Lead", "Property"];
                readonly writesEntities: readonly ["Deal"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["deal_pipeline_metrics", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["criarNegocio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealStages"];
            }, {
                readonly commandName: "avancarEtapaNegocio";
                readonly purpose: "Atualizar etapa do negócio.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "Deal";
                    readonly required: true;
                }, {
                    readonly name: "toStage";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "termosAtualizados";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dealId";
                    readonly type: "Deal";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "dealStageChangeId";
                    readonly type: "DealStageChange";
                }];
                readonly readsEntities: readonly ["Deal"];
                readonly writesEntities: readonly ["Deal", "DealStageChange"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["deal_stage_change", "deal_pipeline_metrics", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["avancarEtapaNegocio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealStages"];
            }, {
                readonly commandName: "listarMudancasEtapaNegocio";
                readonly purpose: "Listar histórico de mudanças nos negócios.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "dealId";
                    readonly type: "Deal";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dealStageChangeId";
                    readonly type: "DealStageChange";
                }, {
                    readonly name: "dealId";
                    readonly type: "Deal";
                }, {
                    readonly name: "fromStage";
                    readonly type: "string";
                }, {
                    readonly name: "toStage";
                    readonly type: "string";
                }, {
                    readonly name: "changedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["DealStageChange"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["deal_stage_change"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarMudancasEtapaNegocio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleDealStages"];
            }];
        };
    };
    export default dealsTrackerPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/leadDetails.defs" {
    export const leadDetailsPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadDetails";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadDetails";
                readonly pageName: "Detalhes do lead";
                readonly actor: "corretor";
                readonly purpose: "Atualizar informações e histórico do lead.";
                readonly capabilities: readonly ["manageLeads"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["lead"];
                readonly pageInputs: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam"];
                    readonly description: "Identificador do lead";
                    readonly entityRef: "Lead";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "leadsPipeline";
                    readonly trigger: "abrir detalhes do lead";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Dados do lead";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadInfoForm";
                        readonly purpose: "Exibir e editar dados de contato e preferências do lead.";
                        readonly userActions: readonly ["editar dados", "salvar alterações"];
                        readonly requiredEntities: readonly ["leadEntity"];
                        readonly readsFields: readonly ["lead.id", "lead.name", "lead.email", "lead.phone", "lead.preferences", "lead.stage"];
                        readonly writesFields: readonly ["lead.name", "lead.email", "lead.phone", "lead.preferences", "lead.stage"];
                        readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
                    }];
                }, {
                    readonly sectionName: "Histórico do lead";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "LeadHistoryTimeline";
                        readonly purpose: "Visualizar histórico e mudanças de etapa do lead.";
                        readonly userActions: readonly ["visualizar histórico"];
                        readonly requiredEntities: readonly ["leadEntity", "leadStageChangeEntity"];
                        readonly readsFields: readonly ["lead.id", "lead.stage", "lead.history"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "obterLead";
                readonly purpose: "Carregar dados completos do lead.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                }, {
                    readonly name: "preferences";
                    readonly type: "string";
                }, {
                    readonly name: "stage";
                    readonly type: "string";
                }, {
                    readonly name: "history";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["leadEntity", "leadStageChangeEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["obterLead"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
            }, {
                readonly commandName: "atualizarLead";
                readonly purpose: "Salvar alterações do lead.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "preferences";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "stage";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "string";
                }, {
                    readonly name: "stage";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["leadEntity"];
                readonly writesEntities: readonly ["leadEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_pipeline_metrics", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["atualizarLead"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
            }];
        };
    };
    export default leadDetailsPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/leadsPipeline.defs" {
    export const leadsPipelinePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "leadsPipeline";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "leadsPipeline";
                readonly pageName: "Pipeline de leads";
                readonly actor: "corretor";
                readonly purpose: "Visualizar e mover leads entre etapas e cadastrar novos leads.";
                readonly capabilities: readonly ["manageLeads", "leadPipeline"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["leadPipelineStageFlow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["leadQualificationRequestFlow"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["lead", "broker"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "leadDetails";
                    readonly trigger: "abrir detalhes do lead";
                    readonly description: "Abrir o lead selecionado para edição completa.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Kanban do pipeline";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "leadPipelineBoard";
                        readonly purpose: "Exibir leads por etapa e permitir arrastar para mudar de estágio.";
                        readonly userActions: readonly ["selecionarLead", "moverLeadEntreEtapas", "abrirDetalhesDoLead"];
                        readonly requiredEntities: readonly ["leadEntity"];
                        readonly readsFields: readonly ["leadId", "leadName", "leadStage", "leadTemperature", "leadUpdatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
                    }, {
                        readonly organismName: "leadQuickCreate";
                        readonly purpose: "Cadastrar novo lead a partir do pipeline.";
                        readonly userActions: readonly ["informarContato", "informarInteresse", "criarLead"];
                        readonly requiredEntities: readonly ["leadEntity"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["leadName", "leadEmail", "leadPhone", "leadSource", "leadInterest", "leadStage"];
                        readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
                    }];
                }, {
                    readonly sectionName: "Ações rápidas e histórico";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "leadCardActions";
                        readonly purpose: "Executar ações rápidas no lead selecionado.";
                        readonly userActions: readonly ["classificarTemperatura", "solicitarQualificacaoIa", "abrirDetalhesDoLead"];
                        readonly requiredEntities: readonly ["leadEntity", "leadQualificationRequestEntity"];
                        readonly readsFields: readonly ["leadId", "leadTemperature", "leadStage", "leadUpdatedAt"];
                        readonly writesFields: readonly ["leadTemperature"];
                        readonly rulesApplied: readonly ["ruleAiHumanReview"];
                    }, {
                        readonly organismName: "leadStageChangeHistory";
                        readonly purpose: "Consultar histórico de mudanças de etapa do lead selecionado.";
                        readonly userActions: readonly ["verHistoricoMudancasEtapa"];
                        readonly requiredEntities: readonly ["leadStageChangeEntity"];
                        readonly readsFields: readonly ["leadStageChangeId", "fromStage", "toStage", "changedAt", "changedByBrokerId", "note"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarLeads";
                readonly purpose: "Carregar leads por etapa do pipeline.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "stageFilter";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "searchText";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "Lead";
                }, {
                    readonly name: "leadName";
                    readonly type: "string";
                }, {
                    readonly name: "leadStage";
                    readonly type: "string";
                }, {
                    readonly name: "leadTemperature";
                    readonly type: "string";
                }, {
                    readonly name: "leadUpdatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["leadEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarLeads"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
            }, {
                readonly commandName: "moverEtapaLead";
                readonly purpose: "Atualizar etapa do lead ao mover card.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "Lead";
                    readonly required: true;
                }, {
                    readonly name: "fromStage";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "toStage";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "note";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "Lead";
                }, {
                    readonly name: "leadStageChangeId";
                    readonly type: "LeadStageChange";
                }];
                readonly readsEntities: readonly ["leadEntity"];
                readonly writesEntities: readonly ["leadEntity", "leadStageChangeEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_stage_change", "lead_pipeline_metrics", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["moverEtapaLead"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
            }, {
                readonly commandName: "criarLead";
                readonly purpose: "Cadastrar novo lead no pipeline.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "leadEmail";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "leadPhone";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "leadSource";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "leadInterest";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "initialStage";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadId";
                    readonly type: "Lead";
                }, {
                    readonly name: "leadStage";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["leadEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_pipeline_metrics", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["criarLead"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
            }, {
                readonly commandName: "solicitarQualificacaoLead";
                readonly purpose: "Solicitar qualificação via IA para o lead selecionado.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "Lead";
                    readonly required: true;
                }, {
                    readonly name: "leadContext";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "leadQualificationRequestId";
                    readonly type: "LeadQualificationRequest";
                }, {
                    readonly name: "reviewStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["leadEntity"];
                readonly writesEntities: readonly ["leadQualificationRequestEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["lead_qualification_request", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["solicitarQualificacaoLead"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleAiHumanReview"];
            }, {
                readonly commandName: "listarMudancasEtapaLead";
                readonly purpose: "Listar histórico de mudanças de etapa do lead.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "leadId";
                    readonly type: "Lead";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "leadStageChangeId";
                    readonly type: "LeadStageChange";
                }, {
                    readonly name: "fromStage";
                    readonly type: "string";
                }, {
                    readonly name: "toStage";
                    readonly type: "string";
                }, {
                    readonly name: "changedAt";
                    readonly type: "date";
                }, {
                    readonly name: "changedByBrokerId";
                    readonly type: "Broker";
                }, {
                    readonly name: "note";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["leadStageChangeEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["lead_stage_change"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarMudancasEtapaLead"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleLeadPipelineStages"];
            }];
        };
    };
    export default leadsPipelinePagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/propertiesList.defs" {
    export const propertiesListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertiesList";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertiesList";
                readonly pageName: "Lista de imóveis";
                readonly actor: "corretor";
                readonly purpose: "Pesquisar e cadastrar imóveis no estoque.";
                readonly capabilities: readonly ["manageProperties"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property", "broker"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "propertyDetails";
                    readonly trigger: "selecionar imóvel";
                    readonly description: "Abrir detalhes do imóvel selecionado na lista.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Busca e filtros de imóveis";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "propertyFilters";
                        readonly purpose: "Filtrar imóveis por status e localização.";
                        readonly userActions: readonly ["aplicar filtros", "limpar filtros"];
                        readonly requiredEntities: readonly ["propertyEntity"];
                        readonly readsFields: readonly ["propertyId", "status", "city", "neighborhood"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
                    }];
                }, {
                    readonly sectionName: "Lista de imóveis";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "propertyList";
                        readonly purpose: "Exibir imóveis com dados principais e permitir seleção.";
                        readonly userActions: readonly ["selecionar imóvel", "paginar lista"];
                        readonly requiredEntities: readonly ["propertyEntity"];
                        readonly readsFields: readonly ["propertyId", "title", "status", "price", "city", "neighborhood"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
                    }];
                }, {
                    readonly sectionName: "Cadastro rápido de imóvel";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "propertyCreateForm";
                        readonly purpose: "Cadastrar novo imóvel a partir do formulário.";
                        readonly userActions: readonly ["preencher dados", "salvar imóvel"];
                        readonly requiredEntities: readonly ["propertyEntity"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["title", "propertyType", "price", "city", "neighborhood", "status", "brokerId"];
                        readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarImoveis";
                readonly purpose: "Carregar lista e filtros de imóveis.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "neighborhood";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }, {
                    readonly name: "city";
                    readonly type: "string";
                }, {
                    readonly name: "neighborhood";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["propertyEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarImoveis"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
            }, {
                readonly commandName: "criarImovel";
                readonly purpose: "Cadastrar novo imóvel a partir do formulário.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "propertyType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "city";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "neighborhood";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "brokerId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["propertyEntity", "dashboardMetricEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["property_status_metrics", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["criarImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePropertyStatusLifecycle", "ruleMetricRefresh"];
            }];
        };
    };
    export default propertiesListPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/propertyDetails.defs" {
    export const propertyDetailsPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "propertyDetails";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "propertyDetails";
                readonly pageName: "Detalhes do imóvel";
                readonly actor: "corretor";
                readonly purpose: "Editar dados, preço e status do imóvel.";
                readonly capabilities: readonly ["manageProperties"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["propertyDescriptionRequestFlow"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["property"];
                readonly pageInputs: readonly [{
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                    readonly required: true;
                    readonly sources: readonly ["routeParam"];
                    readonly description: "Identificador do imóvel selecionado.";
                    readonly entityRef: "Property";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "propertiesList";
                    readonly trigger: "abrir detalhes do imóvel";
                    readonly description: "Acesso ao detalhe a partir da lista de imóveis.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Dados do imóvel";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "FormularioDadosImovel";
                        readonly purpose: "Exibir e editar informações principais do imóvel.";
                        readonly userActions: readonly ["editarCampos", "salvarImovel"];
                        readonly requiredEntities: readonly ["Property"];
                        readonly readsFields: readonly ["Property.id", "Property.title", "Property.address", "Property.price", "Property.status", "Property.description", "Property.features", "Property.bedrooms", "Property.bathrooms", "Property.area"];
                        readonly writesFields: readonly ["Property.title", "Property.address", "Property.price", "Property.status", "Property.description", "Property.features", "Property.bedrooms", "Property.bathrooms", "Property.area"];
                        readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
                    }];
                }, {
                    readonly sectionName: "Descrição do imóvel por IA";
                    readonly mode: "assist";
                    readonly organisms: readonly [{
                        readonly organismName: "SolicitarDescricaoImovel";
                        readonly purpose: "Solicitar geração de descrição via IA com bullets informados.";
                        readonly userActions: readonly ["informarBullets", "solicitarDescricaoImovel"];
                        readonly requiredEntities: readonly ["PropertyDescriptionRequest"];
                        readonly readsFields: readonly ["Property.id", "Property.title", "Property.features"];
                        readonly writesFields: readonly ["PropertyDescriptionRequest.bullets", "PropertyDescriptionRequest.propertyId"];
                        readonly rulesApplied: readonly ["ruleAiHumanReview"];
                    }, {
                        readonly organismName: "HistoricoSolicitacoesDescricao";
                        readonly purpose: "Listar solicitações e status da revisão humana.";
                        readonly userActions: readonly ["verSolicitacoes", "verDescricaoGerada"];
                        readonly requiredEntities: readonly ["PropertyDescriptionRequest"];
                        readonly readsFields: readonly ["PropertyDescriptionRequest.id", "PropertyDescriptionRequest.reviewStatus", "PropertyDescriptionRequest.aiDescription", "PropertyDescriptionRequest.humanReviewNotes", "PropertyDescriptionRequest.createdAt", "PropertyDescriptionRequest.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleAiHumanReview"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "obterImovel";
                readonly purpose: "Carregar detalhes completos do imóvel.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                }, {
                    readonly name: "address";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                }, {
                    readonly name: "features";
                    readonly type: "string";
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                }, {
                    readonly name: "area";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["obterImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
            }, {
                readonly commandName: "atualizarImovel";
                readonly purpose: "Salvar atualizações do imóvel.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "address";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "features";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "bedrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "bathrooms";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "area";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly ["Property"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["property_status_metrics", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["atualizarImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rulePropertyStatusLifecycle"];
            }, {
                readonly commandName: "solicitarDescricaoImovel";
                readonly purpose: "Solicitar geração de descrição via IA.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                    readonly required: true;
                }, {
                    readonly name: "bullets";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "requestId";
                    readonly type: "PropertyDescriptionRequestId";
                }, {
                    readonly name: "reviewStatus";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Property"];
                readonly writesEntities: readonly ["PropertyDescriptionRequest"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["property_description_request", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["solicitarDescricaoImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleAiHumanReview"];
            }, {
                readonly commandName: "listarSolicitacoesDescricaoImovel";
                readonly purpose: "Listar histórico de solicitações de descrição do imóvel.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "requests";
                    readonly type: "PropertyDescriptionRequest[]";
                }];
                readonly readsEntities: readonly ["PropertyDescriptionRequest"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["property_description_request"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarSolicitacoesDescricaoImovel"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleAiHumanReview"];
            }];
        };
    };
    export default propertyDetailsPagePlan;
}
declare module "_102045_/l2/propertyFlowCrm/visitsAgenda.defs" {
    export const visitsAgendaPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "visitsAgenda";
        readonly moduleName: "propertyFlowCrm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "visitsAgenda";
                readonly pageName: "Agenda de visitas";
                readonly actor: "corretor";
                readonly purpose: "Agendar, confirmar, reagendar e cancelar visitas.";
                readonly capabilities: readonly ["scheduleVisits"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["visitSchedulingFlow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["visit", "property", "lead"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e agenda";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "visitFilters";
                        readonly purpose: "Filtrar visitas por período, imóvel e lead.";
                        readonly userActions: readonly ["filtrarVisitas", "limparFiltros"];
                        readonly requiredEntities: readonly ["Visit", "Property", "Lead"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.status", "Visit.scheduledAt", "Visit.propertyId", "Visit.leadId", "Property.propertyId", "Property.title", "Lead.leadId", "Lead.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVisitStatus"];
                    }, {
                        readonly organismName: "visitCalendarList";
                        readonly purpose: "Exibir visitas agendadas em lista/calendário.";
                        readonly userActions: readonly ["selecionarVisita", "abrirDetalhesVisita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.status", "Visit.scheduledAt", "Visit.propertyId", "Visit.leadId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVisitStatus"];
                    }];
                }, {
                    readonly sectionName: "Novo agendamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "visitScheduleForm";
                        readonly purpose: "Criar novo agendamento de visita.";
                        readonly userActions: readonly ["selecionarImovel", "selecionarLead", "definirDataHora", "agendarVisita"];
                        readonly requiredEntities: readonly ["Property", "Lead", "VisitScheduleRequest"];
                        readonly readsFields: readonly ["Property.propertyId", "Property.title", "Lead.leadId", "Lead.name"];
                        readonly writesFields: readonly ["VisitScheduleRequest.propertyId", "VisitScheduleRequest.leadId", "VisitScheduleRequest.requestedStartAt", "VisitScheduleRequest.requestedEndAt", "VisitScheduleRequest.notes"];
                        readonly rulesApplied: readonly ["ruleVisitStatus"];
                    }];
                }, {
                    readonly sectionName: "Detalhes e ações da visita";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "visitDetailsPanel";
                        readonly purpose: "Visualizar detalhes da visita selecionada.";
                        readonly userActions: readonly ["carregarDetalhesVisita"];
                        readonly requiredEntities: readonly ["Visit"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.status", "Visit.scheduledAt", "Visit.propertyId", "Visit.leadId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVisitStatus"];
                    }, {
                        readonly organismName: "visitStatusActions";
                        readonly purpose: "Confirmar, reagendar, finalizar ou cancelar visita.";
                        readonly userActions: readonly ["confirmarVisita", "reagendarVisita", "finalizarVisita", "cancelarVisita"];
                        readonly requiredEntities: readonly ["VisitScheduleRequest", "Visit"];
                        readonly readsFields: readonly ["Visit.visitId", "Visit.status", "Visit.scheduledAt"];
                        readonly writesFields: readonly ["VisitScheduleRequest.status", "VisitScheduleRequest.requestedStartAt", "VisitScheduleRequest.requestedEndAt"];
                        readonly rulesApplied: readonly ["ruleVisitStatus"];
                    }];
                }, {
                    readonly sectionName: "Solicitações de agendamento";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "visitScheduleRequestsList";
                        readonly purpose: "Exibir histórico de solicitações de agendamento.";
                        readonly userActions: readonly ["listarSolicitacoesAgendamento", "selecionarSolicitacao"];
                        readonly requiredEntities: readonly ["VisitScheduleRequest"];
                        readonly readsFields: readonly ["VisitScheduleRequest.visitScheduleRequestId", "VisitScheduleRequest.status", "VisitScheduleRequest.requestedStartAt", "VisitScheduleRequest.propertyId", "VisitScheduleRequest.leadId", "VisitScheduleRequest.visitId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVisitStatus"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarVisitas";
                readonly purpose: "Carregar agenda e filtros de visitas.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "dataInicio";
                    readonly type: "datetime";
                    readonly required: true;
                }, {
                    readonly name: "dataFim";
                    readonly type: "datetime";
                    readonly required: true;
                }, {
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                    readonly required: false;
                }, {
                    readonly name: "leadId";
                    readonly type: "LeadId";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "VisitId";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                }, {
                    readonly name: "leadId";
                    readonly type: "LeadId";
                }];
                readonly readsEntities: readonly ["Visit"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarVisitas"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatus"];
            }, {
                readonly commandName: "agendarVisita";
                readonly purpose: "Criar novo agendamento.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                    readonly required: true;
                }, {
                    readonly name: "leadId";
                    readonly type: "LeadId";
                    readonly required: true;
                }, {
                    readonly name: "requestedStartAt";
                    readonly type: "datetime";
                    readonly required: true;
                }, {
                    readonly name: "requestedEndAt";
                    readonly type: "datetime";
                    readonly required: false;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "VisitId";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Property", "Lead"];
                readonly writesEntities: readonly ["Visit", "VisitScheduleRequest"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["visit_schedule_request", "broker_activity_metrics"];
                readonly usecaseRefs: readonly ["agendarVisita"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatus"];
            }, {
                readonly commandName: "obterVisita";
                readonly purpose: "Carregar detalhes de uma visita selecionada.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "VisitId";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "VisitId";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                }, {
                    readonly name: "leadId";
                    readonly type: "LeadId";
                }];
                readonly readsEntities: readonly ["Visit"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["obterVisita"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatus"];
            }, {
                readonly commandName: "atualizarStatusVisita";
                readonly purpose: "Atualizar status ou reagendar visita.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "visitId";
                    readonly type: "VisitId";
                    readonly required: true;
                }, {
                    readonly name: "novoStatus";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "requestedStartAt";
                    readonly type: "datetime";
                    readonly required: false;
                }, {
                    readonly name: "requestedEndAt";
                    readonly type: "datetime";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitId";
                    readonly type: "VisitId";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "scheduledAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Visit"];
                readonly writesEntities: readonly ["Visit", "VisitScheduleRequest"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["broker_activity_metrics"];
                readonly usecaseRefs: readonly ["atualizarStatusVisita"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatus"];
            }, {
                readonly commandName: "listarSolicitacoesAgendamentoVisita";
                readonly purpose: "Listar histórico de solicitações de agendamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "dataInicio";
                    readonly type: "datetime";
                    readonly required: false;
                }, {
                    readonly name: "dataFim";
                    readonly type: "datetime";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                    readonly required: false;
                }, {
                    readonly name: "leadId";
                    readonly type: "LeadId";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "visitScheduleRequestId";
                    readonly type: "VisitScheduleRequestId";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "requestedStartAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "propertyId";
                    readonly type: "PropertyId";
                }, {
                    readonly name: "leadId";
                    readonly type: "LeadId";
                }, {
                    readonly name: "visitId";
                    readonly type: "VisitId";
                }];
                readonly readsEntities: readonly ["VisitScheduleRequest"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["visit_schedule_request"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarSolicitacoesAgendamentoVisita"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVisitStatus"];
            }];
        };
    };
    export default visitsAgendaPagePlan;
}
