declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems.defs" {
    export const browseMenuItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "menuItemLifecycle";
            readonly controllerName: "BrowseMenuItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowBrowseMenuItemsHandler";
                readonly command: "browseMenuItems";
                readonly usecaseRef: "browseMenuItems";
                readonly inputTypeName: "BrowseMenuItemsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "MenuItem.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por status do item (draft, active, inactive) informado pelo gerente";
                }, {
                    readonly inputId: "menuCategoryIdFilter";
                    readonly fieldRef: "MenuItem.menuCategoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por categoria do item informado pelo gerente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "MenuItem.menuCategoryId";
                    readonly source: "businessContext";
                    readonly originRef: "businessContext.activeCompanyId";
                    readonly description: "O backend resolve o escopo da consulta limitando os itens do cardápio à empresa ativa da sessão do gerente";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "MenuItem";
                    readonly keyField: "MenuItem.menuItemId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.menuCategoryId", "MenuItem.price", "MenuItem.itemType", "MenuItem.status", "MenuItem.activatedAt", "MenuItem.createdAt", "MenuItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.menuItemLifecycle.browseMenuItems";
                readonly handlerName: "cafeFlowBrowseMenuItemsHandler";
            }];
        };
    };
    export default browseMenuItemsController;
    export const pipeline: readonly [{
        readonly id: "browseMenuItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseMenuItemsInput {
        statusFilter?: string;
        menuCategoryIdFilter?: string;
    }
    export interface MenuItemProjection {
        menuItemId: string;
        name: string;
        description: string | null;
        menuCategoryId: string | null;
        price: number;
        itemType: string;
        status: string;
        activatedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseMenuItemsOutput {
        items: MenuItemProjection[];
        total: number;
    }
    /**
     * BrowseMenuItems — lists all menu items from the MDM store as individual entries.
     *
     * MODELING GAP: MenuItem does not declare a `companyId` field in its entity model,
     * so the activeCompanyId business-context filter is intentionally skipped to avoid
     * matching against a non-existent column.
     *
     * Rule `simpleItemsOnly`: every item (simple or variant) appears as a separate
     * entry — no grouping or expansion of variants is performed.
     */
    export function browseMenuItems(ctx: RequestContext, input: BrowseMenuItemsInput): Promise<BrowseMenuItemsOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowBrowseMenuItemsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems.defs" {
    export const browseStockItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseStockItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseStockItems";
            readonly controllerName: "BrowseStockItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowBrowseStockItemsHandler";
                readonly command: "browseStockItems";
                readonly usecaseRef: "browseStockItems";
                readonly inputTypeName: "BrowseStockItemsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "searchTerm";
                    readonly fieldRef: "StockItem.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de busca opcional para filtrar itens de estoque pelo nome.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "StockItem.stockItemId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que está consultando o estoque.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StockItem.stockItemId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend extrai o actorId da sessão autenticada do gerente para autorizar o acesso à lista de itens de estoque.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "StockItem";
                    readonly keyField: "StockItem.stockItemId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unit", "StockItem.minimumLevel", "StockItem.createdAt", "StockItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.browseStockItems.browseStockItems";
                readonly handlerName: "cafeFlowBrowseStockItemsHandler";
            }];
        };
    };
    export default browseStockItemsController;
    export const pipeline: readonly [{
        readonly id: "browseStockItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel" {
    export type StockLevelUnit = 'kg' | 'liter' | 'portion' | 'unit';
    export interface StockLevel {
        stockLevelId: string;
        stockItemId: string;
        currentQuantity: number;
        minimumLevel: number;
        unit: StockLevelUnit;
        lastDecrementAt: string | null;
        lastAdjustmentAt: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export function isLowStock(stockLevel: Pick<StockLevel, 'currentQuantity' | 'minimumLevel'>): boolean;
    export function validateStockLevelQuantities(currentQuantity: number, minimumLevel: number): void;
    export function canChangeUnit(existing: Pick<StockLevel, 'unit'>, newUnit: StockLevelUnit): boolean;
    export function applyDecrement(stockLevel: StockLevel, amount: number, nowIso: string): StockLevel;
    export function applyAdjustment(stockLevel: StockLevel, newQuantity: number, nowIso: string): StockLevel;
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository" {
    import type { StockLevel, StockLevelUnit } from "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export type StockLevelId = string;
    export type ProductId = string;
    export interface StockLevelFilter {
        stockLevelId?: StockLevelId;
        stockItemId?: string;
        unit?: StockLevelUnit;
    }
    export interface IStockLevelRepository {
        getById(id: StockLevelId): Promise<StockLevel>;
        findById(id: StockLevelId): Promise<StockLevel | null>;
        findByProductId(productId: ProductId): Promise<StockLevel | null>;
        list(filter?: StockLevelFilter): Promise<StockLevel[]>;
        listLowStock(): Promise<StockLevel[]>;
        save(stockLevel: StockLevel): Promise<void>;
    }
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/browseStockItems" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type StockLevelUnit } from "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export interface BrowseStockItemsInput {
        searchTerm?: string;
    }
    export interface StockItemSummary {
        stockItemId: string;
        name: string;
        unit: StockLevelUnit;
        minimumLevel: number;
        createdAt: string;
        updatedAt: string;
        currentQuantity: number;
        lowStockAlert: boolean;
    }
    export interface BrowseStockItemsOutput {
        items: StockItemSummary[];
        total: number;
    }
    export function browseStockItems(ctx: RequestContext, input: BrowseStockItemsInput): Promise<BrowseStockItemsOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowBrowseStockItemsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.defs" {
    export const closeShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "closeShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "CloseShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCloseShiftHandler";
                readonly command: "closeShift";
                readonly usecaseRef: "closeShift";
                readonly inputTypeName: "CloseShiftInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "totalApurado";
                    readonly fieldRef: "Shift.totalApurado";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Valor total apurado no fechamento do turno, informado pelo gerente para conferência.";
                }, {
                    readonly inputId: "notes";
                    readonly fieldRef: "Shift.notes";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Observações gerais sobre o turno, opcionais.";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Identificador do turno atualmente aberto que será fechado.";
                }, {
                    readonly inputId: "closedBy";
                    readonly fieldRef: "Shift.closedBy";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente que está fechando o turno.";
                }, {
                    readonly inputId: "closedAt";
                    readonly fieldRef: "Shift.closedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora do fechamento do turno, definida automaticamente pelo sistema.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Shift.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend localiza o único Shift com status 'open' (turno ativo) e utiliza seu shiftId como alvo do fechamento.";
                }, {
                    readonly targetRef: "Shift.closedBy";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do gerente autenticado a partir da sessão ativa.";
                }, {
                    readonly targetRef: "Shift.closedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define a data e hora de fechamento como o timestamp atual no momento da confirmação.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Shift.status", "Shift.closedAt", "Shift.closedBy", "Shift.totalApurado", "Shift.notes"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.closeShift";
                readonly handlerName: "cafeFlowCloseShiftHandler";
            }];
        };
    };
    export default closeShiftController;
    export const pipeline: readonly [{
        readonly id: "closeShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/closeShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/shift" {
    export type ShiftStatus = 'open' | 'closed';
    export interface Shift {
        shiftId: string;
        status: ShiftStatus;
        openedAt: string;
        closedAt: string | null;
        openedBy: string;
        closedBy: string | null;
        totalApurado: number | null;
        notes: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const SHIFT_STATUS_TRANSITIONS: Record<ShiftStatus, ShiftStatus[]>;
    export function canTransitionShift(from: ShiftStatus, to: ShiftStatus): boolean;
    export function shiftRequiresClosedFieldsWhenClosed(shift: Pick<Shift, 'status' | 'closedAt' | 'closedBy' | 'totalApurado'>): boolean;
    export function shiftClosedAtMustBeAfterOpenedAt(shift: Pick<Shift, 'openedAt' | 'closedAt'>): boolean;
    export function shiftCannotBeReopened(from: ShiftStatus, to: ShiftStatus): boolean;
    export function onlyOneShiftOpen(shifts: Pick<Shift, 'status'>[]): boolean;
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository" {
    import type { Shift, ShiftStatus } from "_102045_/l1/cafeFlow/layer_3_domain/entities/shift";
    export type ShiftId = string;
    export type LocalDate = string;
    export interface ShiftFilter {
        status?: ShiftStatus;
        openedBy?: string;
    }
    export interface IShiftRepository {
        getById(id: ShiftId): Promise<Shift>;
        list(filter?: ShiftFilter): Promise<Shift[]>;
        save(shift: Shift): Promise<void>;
        findOpenShift(): Promise<Shift | null>;
        listByDate(date: LocalDate): Promise<Shift[]>;
    }
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/order" {
    export type OrderStatus = 'registered' | 'received' | 'inPreparation' | 'ready' | 'delivered';
    export type OrderType = 'table' | 'takeout';
    export interface OrderItem {
        orderItemId: string;
        orderId: string;
        menuItemId: string;
        quantity: number;
        unitPrice: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface Order {
        orderId: string;
        shiftId: string;
        status: OrderStatus;
        orderType: OrderType;
        tableNumber: string | null;
        priority: boolean | null;
        priorityReason: string | null;
        receivedAt: string | null;
        inPreparationAt: string | null;
        readyAt: string | null;
        deliveredAt: string | null;
        createdAt: string;
        updatedAt: string;
        items: OrderItem[];
    }
    export const ORDER_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]>;
    export function canTransitionOrder(from: OrderStatus, to: OrderStatus): boolean;
    export function orderRequiresItem(order: Pick<Order, 'items'>): boolean;
    export function validateTableNumber(order: Pick<Order, 'orderType' | 'tableNumber'>): boolean;
    export function validatePriorityReason(order: Pick<Order, 'priority' | 'priorityReason'>): boolean;
    export function validateStatusTimestamp(status: OrderStatus, timestamps: Pick<Order, 'receivedAt' | 'inPreparationAt' | 'readyAt' | 'deliveredAt'>): boolean;
    export function validateChronologicalTimestamps(timestamps: Pick<Order, 'receivedAt' | 'inPreparationAt' | 'readyAt' | 'deliveredAt'>): boolean;
    export function recomputeOrderTotal(items: OrderItem[]): number;
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository" {
    import type { Order, OrderStatus, OrderType } from "_102045_/l1/cafeFlow/layer_3_domain/entities/order";
    export type OrderId = string;
    export type OrderNumber = string;
    export type ShiftId = string;
    export interface OrderFilter {
        shiftId?: ShiftId;
        status?: OrderStatus;
        orderType?: OrderType;
        tableNumber?: string;
    }
    export interface IOrderRepository {
        getById(id: OrderId): Promise<Order>;
        findById(id: OrderId): Promise<Order | null>;
        findByOrderNumber(orderNumber: OrderNumber): Promise<Order | null>;
        list(filter?: OrderFilter): Promise<Order[]>;
        listByShiftId(shiftId: ShiftId): Promise<Order[]>;
        save(order: Order): Promise<void>;
    }
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport" {
    export interface ShiftClosingReport {
        shiftClosingReportId: string;
        shiftId: string;
        totalApurado: number;
        paidOrderCount: number;
        createdAt: string;
        updatedAt: string;
    }
    export function shiftClosingReportRequiresClosedShift(shiftStatus: string): boolean;
    export function shiftClosingReportTotalApuradoIsValid(totalApurado: number): boolean;
    export function shiftClosingReportPaidOrderCountIsValid(paidOrderCount: number): boolean;
    export function isUniqueShiftClosingReportForShift(existingReports: ShiftClosingReport[], shiftId: string): boolean;
    export function validateShiftClosingReport(report: Pick<ShiftClosingReport, 'totalApurado' | 'paidOrderCount'>, shiftStatus: string, existingReports: ShiftClosingReport[], shiftId: string): void;
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository" {
    import type { ShiftClosingReport } from "_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport";
    export type ShiftClosingReportId = string;
    export type ShiftId = string;
    export interface ShiftClosingReportFilter {
        shiftId?: ShiftId;
    }
    export interface IShiftClosingReportRepository {
        getById(id: ShiftClosingReportId): Promise<ShiftClosingReport>;
        list(filter?: ShiftClosingReportFilter): Promise<ShiftClosingReport[]>;
        save(report: ShiftClosingReport): Promise<void>;
        findByShiftId(shiftId: ShiftId): Promise<ShiftClosingReport | null>;
    }
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/closeShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CloseShiftInput {
        totalApurado: number;
        notes?: string;
    }
    export interface CloseShiftOutput {
        shiftId: string;
        status: string;
        closedAt: string;
        closedBy: string;
        totalApurado: number;
        notes?: string;
    }
    export function closeShift(ctx: RequestContext, input: CloseShiftInput): Promise<CloseShiftOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCloseShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs" {
    export const createOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "CreateOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateOrderHandler";
                readonly command: "createOrder";
                readonly usecaseRef: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "orderType";
                    readonly fieldRef: "Order.orderType";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Tipo do pedido selecionado pelo atendente: 'table' (consumo na mesa) ou 'takeout' (para viagem)";
                }, {
                    readonly inputId: "tableNumber";
                    readonly fieldRef: "Order.tableNumber";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Número da mesa informado pelo atendente, obrigatório quando orderType = 'table'";
                }, {
                    readonly inputId: "orderItems";
                    readonly fieldRef: "OrderItem.menuItemId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Lista de itens do cardápio selecionados pelo cliente, cada um com menuItemId e quantidade";
                }, {
                    readonly inputId: "priority";
                    readonly fieldRef: "Order.priority";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Indica se o atendente marcou o pedido como prioritário no preparo";
                }, {
                    readonly inputId: "priorityReason";
                    readonly fieldRef: "Order.priorityReason";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Justificativa da priorização, obrigatória quando priority = true";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno aberto no momento do lançamento do pedido";
                }, {
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único gerado para o novo pedido";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Order.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento de criação do registro do pedido";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento da última atualização do registro do pedido";
                }];
                readonly contextResolution: readonly [{
                    readonly inputId: "shiftId";
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolves the single Shift with status open — the active shift at the moment of order creation";
                }, {
                    readonly inputId: "orderId";
                    readonly targetRef: "Order.orderId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Generates a new UUID to identify the order being created";
                }, {
                    readonly inputId: "createdAt";
                    readonly targetRef: "Order.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Sets the creation timestamp to the current server time at the moment of order launch";
                }, {
                    readonly inputId: "updatedAt";
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Sets the last-update timestamp to the current server time at the moment of order launch";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.createOrder";
                readonly handlerName: "cafeFlowCreateOrderHandler";
            }];
        };
    };
    export default createOrderController;
    export const pipeline: readonly [{
        readonly id: "createOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/createOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption" {
    export type StockConsumptionStatus = 'posted' | 'voided';
    export interface StockConsumption {
        stockConsumptionId: string;
        stockItemId: string;
        orderId: string;
        quantity: number;
        status: StockConsumptionStatus;
        createdAt: string;
        voidedAt: string | null;
        voidReason: string | null;
    }
    export const STOCK_CONSUMPTION_STATUS_TRANSITIONS: Record<StockConsumptionStatus, StockConsumptionStatus[]>;
    export function canTransitionStockConsumption(from: StockConsumptionStatus, to: StockConsumptionStatus): boolean;
    export function isStockConsumptionActive(consumption: Pick<StockConsumption, 'status'>): boolean;
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository" {
    import type { StockConsumption } from "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption";
    export type OrderId = string;
    export type ProductId = string;
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface IStockConsumptionRepository {
        append(consumption: StockConsumption): Promise<void>;
        listByOwnerId(orderId: OrderId): Promise<StockConsumption[]>;
        listByPeriod(period: DateRange): Promise<StockConsumption[]>;
        listByProductId(productId: ProductId): Promise<StockConsumption[]>;
    }
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/createOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateOrderItemInput {
        menuItemId: string;
        quantity: number;
    }
    export interface CreateOrderInput {
        orderType: string;
        tableNumber?: string;
        orderItems: CreateOrderItemInput[];
        priority?: boolean;
        priorityReason?: string;
    }
    export interface CreateOrderOutput {
        orderId: string;
        status: string;
        orderType: string;
        tableNumber: string | null;
        createdAt: string;
    }
    export function createOrder(ctx: RequestContext, input: CreateOrderInput): Promise<CreateOrderOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder.defs" {
    export const deliverOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deliverOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "DeliverOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeliverOrderHandler";
                readonly command: "deliverOrder";
                readonly usecaseRef: "deliverOrder";
                readonly inputTypeName: "DeliverOrderInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Pedido selecionado pelo atendente no painel para entrega";
                }, {
                    readonly inputId: "deliveredAt";
                    readonly fieldRef: "Order.deliveredAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento em que o pedido foi entregue ao cliente, gerado automaticamente";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento da última atualização do registro do pedido, gerado automaticamente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.orderId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Order.orderId";
                    readonly description: "O backend resolve o orderId a partir do pedido atualmente selecionado pelo atendente no painel de pedidos.";
                }, {
                    readonly targetRef: "Order.deliveredAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define deliveredAt com o timestamp atual no momento da confirmação da entrega.";
                }, {
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define updatedAt com o timestamp atual no momento da atualização do registro.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.deliveredAt", "Order.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.deliverOrder";
                readonly handlerName: "cafeFlowDeliverOrderHandler";
            }];
        };
    };
    export default deliverOrderController;
    export const pipeline: readonly [{
        readonly id: "deliverOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/deliverOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeliverOrderInput {
        orderId: string;
    }
    export interface DeliverOrderOutput {
        orderId: string;
        status: string;
        deliveredAt: string;
        updatedAt: string;
    }
    export function deliverOrder(ctx: RequestContext, input: DeliverOrderInput): Promise<DeliverOrderOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeliverOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem.defs" {
    export const manageMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "menuItemLifecycle";
            readonly controllerName: "ManageMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageMenuItemHandler";
                readonly command: "manageMenuItem";
                readonly usecaseRef: "manageMenuItem";
                readonly inputTypeName: "ManageMenuItemInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "menuItemId";
                    readonly fieldRef: "MenuItem.menuItemId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do item do cardápio selecionado para edição";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "MenuItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do item do cardápio exibido no POS";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "MenuItem.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada do item do cardápio";
                }, {
                    readonly inputId: "menuCategoryId";
                    readonly fieldRef: "MenuItem.menuCategoryId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Categoria de classificação à qual o item pertence";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "MenuItem.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço de venda do item do cardápio";
                }, {
                    readonly inputId: "itemType";
                    readonly fieldRef: "MenuItem.itemType";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Tipo do item: deve ser 'simple' nesta fase";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "MenuItem.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Status do item: rascunho, ativo ou inativo";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "MenuItem.menuItemId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que realiza a alteração";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "MenuItem.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "MenuItem.menuItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "MenuItem.menuItemId";
                    readonly description: "O backend resolve o menuItemId a partir do item atualmente selecionado na tela de gestão de cardápio";
                }, {
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do gerente a partir da sessão autenticada do usuário";
                }, {
                    readonly targetRef: "MenuItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend atribui o timestamp atual do sistema ao campo updatedAt no momento da persistência";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "MenuItem";
                    readonly keyField: "MenuItem.menuItemId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.menuCategoryId", "MenuItem.price", "MenuItem.itemType", "MenuItem.status", "MenuItem.activatedAt", "MenuItem.inactivatedAt", "MenuItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.menuItemLifecycle.manageMenuItem";
                readonly handlerName: "cafeFlowManageMenuItemHandler";
            }];
        };
    };
    export default manageMenuItemController;
    export const pipeline: readonly [{
        readonly id: "manageMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ManageMenuItemInput {
        menuItemId: string;
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: string;
        status: string;
    }
    export interface ManageMenuItemOutput {
        menuItemId: string;
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: string;
        status: string;
        activatedAt?: string;
        inactivatedAt?: string;
        updatedAt: string;
    }
    export function manageMenuItem(ctx: RequestContext, input: ManageMenuItemInput): Promise<ManageMenuItemOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowManageMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem.defs" {
    export const manageStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageStockItem";
            readonly controllerName: "ManageStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageStockItemHandler";
                readonly command: "manageStockItem";
                readonly usecaseRef: "manageStockItem";
                readonly inputTypeName: "ManageStockItemInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "stockItemId";
                    readonly fieldRef: "StockItem.stockItemId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do item de estoque a ser atualizado, obtido da rota de edição.";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "StockItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do ingrediente editado pelo gerente.";
                }, {
                    readonly inputId: "unit";
                    readonly fieldRef: "StockItem.unit";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Unidade de medida do ingrediente (kg, liter, portion ou unit).";
                }, {
                    readonly inputId: "minimumLevel";
                    readonly fieldRef: "StockItem.minimumLevel";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "StockItem.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do item de estoque.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StockItem.stockItemId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.stockItemId";
                    readonly description: "O backend extrai o identificador do item de estoque do parâmetro de rota da tela de edição.";
                }, {
                    readonly targetRef: "StockItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend atribui automaticamente o timestamp atual no momento da persistência da atualização.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "StockItem";
                    readonly keyField: "StockItem.stockItemId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unit", "StockItem.minimumLevel", "StockItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageStockItem.manageStockItem";
                readonly handlerName: "cafeFlowManageStockItemHandler";
            }];
        };
    };
    export default manageStockItemController;
    export const pipeline: readonly [{
        readonly id: "manageStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/manageStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ManageStockItemInput {
        stockItemId: string;
        name: string;
        unit: string;
        minimumLevel: number;
    }
    export interface ManageStockItemOutput {
        stockItemId: string;
        name: string;
        unit: string;
        minimumLevel: number;
        updatedAt: string;
    }
    export function manageStockItem(ctx: RequestContext, input: ManageStockItemInput): Promise<ManageStockItemOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowManageStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.defs" {
    export const openShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "openShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "OpenShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowOpenShiftHandler";
                readonly command: "openShift";
                readonly usecaseRef: "openShift";
                readonly inputTypeName: "OpenShiftInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "notes";
                    readonly fieldRef: "Shift.notes";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Observações gerais opcionais sobre o turno, informadas pelo gerente ao abrir.";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único do turno, gerado automaticamente pelo sistema.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Shift.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Situação inicial do turno, definida como 'open' no momento da criação.";
                }, {
                    readonly inputId: "openedAt";
                    readonly fieldRef: "Shift.openedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de abertura do turno, definida automaticamente como o momento atual.";
                }, {
                    readonly inputId: "openedBy";
                    readonly fieldRef: "Shift.openedBy";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente que abriu o turno, obtido da sessão ativa.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Shift.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de criação do registro, definida automaticamente como o momento atual.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Shift.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do registro, definida automaticamente como o momento atual.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Shift.shiftId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID para o novo turno no momento da criação.";
                }, {
                    readonly targetRef: "Shift.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define o status como 'open' fixamente na criação do turno.";
                }, {
                    readonly targetRef: "Shift.openedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data e hora de abertura do turno.";
                }, {
                    readonly targetRef: "Shift.openedBy";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do gerente autenticado a partir da sessão ativa.";
                }, {
                    readonly targetRef: "Shift.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data de criação do registro.";
                }, {
                    readonly targetRef: "Shift.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data da última atualização do registro.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Shift.shiftId", "Shift.status", "Shift.openedAt", "Shift.openedBy"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.openShift";
                readonly handlerName: "cafeFlowOpenShiftHandler";
            }];
        };
    };
    export default openShiftController;
    export const pipeline: readonly [{
        readonly id: "openShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/openShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/openShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface OpenShiftInput {
        notes?: string;
    }
    export interface OpenShiftOutput {
        shiftId: string;
        status: string;
        openedAt: string;
        openedBy: string;
    }
    export function openShift(ctx: RequestContext, input: OpenShiftInput): Promise<OpenShiftOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowOpenShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions.defs" {
    export const requestAiPromoSuggestionsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "requestAiPromoSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "requestAiPromoSuggestions";
            readonly controllerName: "RequestAiPromoSuggestionsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRequestAiPromoSuggestionsHandler";
                readonly command: "requestAiPromoSuggestions";
                readonly usecaseRef: "requestAiPromoSuggestions";
                readonly inputTypeName: "RequestAiPromoSuggestionsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "actorId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identidade do gerente que solicita as sugestões, para auditoria e contexto de permissão";
                }, {
                    readonly inputId: "windowStart";
                    readonly fieldRef: "Order.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data de início da janela de análise (7 dias antes do momento atual)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend resolve o identificador do gerente a partir da sessão ativa para validar permissão e registrar auditoria da solicitação";
                }, {
                    readonly targetRef: "Order.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend calcula o início da janela de 7 dias subtraindo 7 dias do timestamp atual (systemDefault.now) para filtrar apenas pedidos dentro do período relevante";
                }];
                readonly accessPattern: {
                    readonly kind: "lookup";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.orderType", "Order.status", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions";
                readonly handlerName: "cafeFlowRequestAiPromoSuggestionsHandler";
            }];
        };
    };
    export default requestAiPromoSuggestionsController;
    export const pipeline: readonly [{
        readonly id: "requestAiPromoSuggestions__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface RequestAiPromoSuggestionsInput {
    }
    export interface AiPromoSuggestion {
        menuItemId: string;
        totalQuantitySold: number;
        currentStockQuantity: number;
        stockUnit: string;
        suggestionReason: string;
        suggestedDiscountPercent?: number;
    }
    /**
     * Rule aiPromoBasedOnLast7Days: the analysis window is always the last 7 days
     * computed from ctx.clock.now() — no user input is required.
     *
     * Rule aiConsumesDomainData: only domain data from Order, OrderItem and
     * StockLevel is consumed. No external data sources are used.
     */
    export function requestAiPromoSuggestions(ctx: RequestContext, _input: RequestAiPromoSuggestionsInput): Promise<AiPromoSuggestion[]>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowRequestAiPromoSuggestionsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary.defs" {
    export const requestAiSalesSummaryController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "requestAiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "requestAiSalesSummary";
            readonly controllerName: "RequestAiSalesSummaryController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRequestAiSalesSummaryHandler";
                readonly command: "requestAiSalesSummary";
                readonly usecaseRef: "requestAiSalesSummary";
                readonly inputTypeName: "AiSalesSummaryInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno atualmente aberto para filtrar apenas os pedidos do dia corrente";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que solicita o resumo";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolvido a partir do único Shift com status open, filtrando apenas pedidos do turno/dia corrente";
                }, {
                    readonly targetRef: "Order.shiftId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "Resolvido a partir da sessão autenticada do gerente para autorizar o acesso ao resumo de vendas";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.createdAt", "Order.deliveredAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.requestAiSalesSummary.requestAiSalesSummary";
                readonly handlerName: "cafeFlowRequestAiSalesSummaryHandler";
            }];
        };
    };
    export default requestAiSalesSummaryController;
    export const pipeline: readonly [{
        readonly id: "requestAiSalesSummary__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AiSalesSummaryInput {
    }
    export interface AiSalesSummaryOrderProjection {
        orderId: string;
        status: string;
        orderType: string;
        createdAt: string;
        deliveredAt: string | null;
    }
    export interface AiSalesSummaryTopSeller {
        menuItemId: string;
        totalQuantity: number;
        totalRevenue: number;
    }
    export interface AiSalesSummaryStockLevelProjection {
        stockItemId: string;
        currentQuantity: number;
        minimumLevel: number;
        unit: string;
    }
    export interface AiSalesSummaryOutput {
        shiftId: string | null;
        shiftOpenedAt: string | null;
        totalOrders: number;
        totalRevenue: number;
        orders: AiSalesSummaryOrderProjection[];
        topSellers: AiSalesSummaryTopSeller[];
        stockLevels: AiSalesSummaryStockLevelProjection[];
    }
    export function requestAiSalesSummary(ctx: RequestContext, _input: AiSalesSummaryInput): Promise<AiSalesSummaryOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowRequestAiSalesSummaryHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs" {
    export const updateOrderStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "UpdateOrderStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
                readonly command: "updateOrderStatus";
                readonly usecaseRef: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Pedido selecionado pelo cozinheiro na fila da cozinha";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Order.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Novo status que o cozinheiro deseja atribuir ao pedido (inPreparation ou ready)";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno aberto no momento da atualização, para validar que o pedido pertence ao turno atual";
                }, {
                    readonly inputId: "inPreparationAt";
                    readonly fieldRef: "Order.inPreparationAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp definido quando o status passa a inPreparation";
                }, {
                    readonly inputId: "readyAt";
                    readonly fieldRef: "Order.readyAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp definido quando o status passa a ready";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp da última atualização do registro";
                }];
                readonly contextResolution: readonly [{
                    readonly inputId: "shiftId";
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolve o turno atualmente aberto (single Shift with status open) para validar que o pedido pertence ao turno ativo";
                }, {
                    readonly inputId: "inPreparationAt";
                    readonly targetRef: "Order.inPreparationAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Define o timestamp atual quando o status transita para inPreparation";
                }, {
                    readonly inputId: "readyAt";
                    readonly targetRef: "Order.readyAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Define o timestamp atual quando o status transita para ready";
                }, {
                    readonly inputId: "updatedAt";
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Define o timestamp atual em toda atualização do registro";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "single";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.updateOrderStatus";
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
            }];
        };
    };
    export default updateOrderStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateOrderStatusInput {
        orderId: string;
        status: string;
    }
    export interface UpdateOrderStatusOutput {
        orderId: string;
        status: string;
        updatedAt: string;
    }
    export function updateOrderStatus(ctx: RequestContext, input: UpdateOrderStatusInput): Promise<UpdateOrderStatusOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateOrderStatusHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.defs" {
    export const viewDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewDashboard";
            readonly controllerName: "ViewDashboardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewDashboardHandler";
                readonly command: "viewDashboard";
                readonly usecaseRef: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno atualmente aberto, usado para filtrar todos os dados do dashboard";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que solicita o dashboard";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend localiza o único Shift com status aberto no momento e usa seu shiftId para filtrar todos os pedidos e dados agregados do dashboard";
                }, {
                    readonly targetRef: "Order.shiftId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend extrai o actorId da sessão autenticada do gerente para autorizar o acesso ao dashboard";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "Lista agregada de pedidos do turno atual para composição do dashboard com total de vendas, itens mais vendidos e alertas de estoque baixo";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.status", "Order.orderType", "Order.createdAt", "Order.shiftId", "Order.deliveredAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.viewDashboard.viewDashboard";
                readonly handlerName: "cafeFlowViewDashboardHandler";
            }];
        };
    };
    export default viewDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/viewDashboard" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { OrderStatus, OrderType } from "_102045_/l1/cafeFlow/layer_3_domain/entities/order";
    import type { StockLevelUnit } from "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export interface ViewDashboardInput {
    }
    export interface OrderSummary {
        orderId: string;
        status: OrderStatus;
        orderType: OrderType;
        createdAt: string;
        shiftId: string;
        deliveredAt: string | null;
    }
    export interface TopSeller {
        menuItemId: string;
        totalQuantity: number;
        totalRevenue: number;
    }
    export interface LowStockAlert {
        stockItemId: string;
        currentQuantity: number;
        minimumLevel: number;
        unit: StockLevelUnit;
    }
    export interface ViewDashboardOutput {
        shiftId: string | null;
        totalSales: number;
        orderCount: number;
        orders: OrderSummary[];
        topSellers: TopSeller[];
        lowStockAlerts: LowStockAlert[];
    }
    export function viewDashboard(ctx: RequestContext, _input: ViewDashboardInput): Promise<ViewDashboardOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewDashboardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard.defs" {
    export const viewKitchenBoardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewKitchenBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "ViewKitchenBoardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewKitchenBoardHandler";
                readonly command: "viewKitchenBoard";
                readonly usecaseRef: "viewKitchenBoard";
                readonly inputTypeName: "ViewKitchenBoardInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno aberto no momento, usado para filtrar apenas pedidos do turno atual";
                }, {
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "Order.status";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Filtro padrão de status: exibe pedidos com status 'received' ou 'inPreparation'";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolvido buscando o único Shift com status 'open' no momento da consulta, garantindo que apenas pedidos do turno atual sejam exibidos";
                }, {
                    readonly targetRef: "Order.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O filtro de status é aplicado automaticamente pelo backend, restringindo a lista aos status 'received' e 'inPreparation' sem exigir entrada do usuário";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly filters: readonly ["Order.status", "Order.shiftId"];
                    readonly sort: readonly ["Order.priority", "Order.receivedAt"];
                    readonly pagination: "optional";
                    readonly selection: "single";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.priority", "Order.priorityReason", "Order.receivedAt", "Order.inPreparationAt", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.viewKitchenBoard";
                readonly handlerName: "cafeFlowViewKitchenBoardHandler";
            }];
        };
    };
    export default viewKitchenBoardController;
    export const pipeline: readonly [{
        readonly id: "viewKitchenBoard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewKitchenBoardInput {
    }
    export interface KitchenBoardOrderItem {
        orderItemId: string;
        menuItemId: string;
        quantity: number;
        unitPrice: number;
    }
    export interface KitchenBoardEntry {
        orderId: string;
        status: string;
        orderType: string;
        tableNumber?: string;
        priority?: boolean;
        priorityReason?: string;
        receivedAt?: string;
        inPreparationAt?: string;
        createdAt: string;
        orderItems: KitchenBoardOrderItem[];
    }
    export interface ViewKitchenBoardOutput {
        orders: KitchenBoardEntry[];
    }
    /**
     * Use-case: viewKitchenBoard
     *
     * Lists all orders of the current open shift whose status is 'received' or
     * 'inPreparation', sorted by priority (priority=true first) and then by
     * receivedAt ascending (FIFO).
     *
     * Rules applied:
     *  - dashboardCurrentShiftOnly: only orders belonging to the active open shift
     *  - fifoKitchenQueue: priority orders first, then FIFO by receivedAt
     */
    export function viewKitchenBoard(ctx: RequestContext, _input: ViewKitchenBoardInput): Promise<ViewKitchenBoardOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewKitchenBoardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard.defs" {
    export const viewOrderBoardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewOrderBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "ViewOrderBoardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewOrderBoardHandler";
                readonly command: "viewOrderBoard";
                readonly usecaseRef: "viewOrderBoard";
                readonly inputTypeName: "ViewOrderBoardInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno atualmente aberto para filtrar apenas pedidos do turno corrente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend resolve o turno atualmente aberto consultando a única Shift com status open e utiliza seu shiftId para filtrar os pedidos exibidos no painel";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.priority", "Order.priorityReason", "Order.receivedAt", "Order.inPreparationAt", "Order.readyAt", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.viewOrderBoard";
                readonly handlerName: "cafeFlowViewOrderBoardHandler";
            }];
        };
    };
    export default viewOrderBoardController;
    export const pipeline: readonly [{
        readonly id: "viewOrderBoard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { Order } from "_102045_/l1/cafeFlow/layer_3_domain/entities/order";
    export interface ViewOrderBoardInput {
    }
    export interface ViewOrderBoardOutput {
        orders: Order[];
        currentShiftId?: string;
    }
    export function viewOrderBoard(ctx: RequestContext, _input: ViewOrderBoardInput): Promise<ViewOrderBoardOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewOrderBoardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport.defs" {
    export const viewShiftClosingReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "ViewShiftClosingReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewShiftClosingReportHandler";
                readonly command: "viewShiftClosingReport";
                readonly usecaseRef: "viewShiftClosingReport";
                readonly inputTypeName: "ViewShiftClosingReportInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "ShiftClosingReport.shiftId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do turno fechado cujo relatório de fechamento será exibido.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ShiftClosingReport.shiftId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.shiftId";
                    readonly description: "O shiftId é extraído do parâmetro de rota para localizar o único relatório de fechamento correspondente ao turno fechado.";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "ShiftClosingReport";
                    readonly keyField: "ShiftClosingReport.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ShiftClosingReport.shiftClosingReportId", "ShiftClosingReport.shiftId", "ShiftClosingReport.totalApurado", "ShiftClosingReport.paidOrderCount", "ShiftClosingReport.createdAt", "ShiftClosingReport.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.viewShiftClosingReport";
                readonly handlerName: "cafeFlowViewShiftClosingReportHandler";
            }];
        };
    };
    export default viewShiftClosingReportController;
    export const pipeline: readonly [{
        readonly id: "viewShiftClosingReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewShiftClosingReportInput {
        shiftId: string;
    }
    export interface ViewShiftClosingReportOutput {
        shiftClosingReportId: string;
        shiftId: string;
        totalApurado: number;
        paidOrderCount: number;
        createdAt: string;
        updatedAt: string;
    }
    export function viewShiftClosingReport(ctx: RequestContext, input: ViewShiftClosingReportInput): Promise<ViewShiftClosingReportOutput>;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewShiftClosingReportHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.defs" {
    export const menuItemIngredientTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "MenuItemIngredient";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "MenuItemIngredient";
            readonly tableName: "menu_item_ingredient";
            readonly columns: readonly [{
                readonly name: "menu_item_ingredient_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "menu_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "stock_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "unit";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "quantity, updatedAt";
            }];
            readonly primaryKey: readonly ["menu_item_ingredient_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_menu_item_ingredient_menu_item_id";
                readonly columns: readonly ["menu_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_ingredient_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_ingredient_unit";
                readonly columns: readonly ["unit"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_ingredient_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default menuItemIngredientTableDefinition;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredient__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const menuItemIngredientTableDef: TableDefinition;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter.defs" {
    export const menuItemIngredientRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MenuItemIngredientRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "MenuItemIngredientRepositoryAdapter";
            readonly entityId: "MenuItemIngredient";
            readonly portRef: "IMenuItemIngredientRepository";
            readonly tableRef: "menu_item_ingredients";
            readonly mdmReads: readonly ["ctx.mdm.collection.getMany/hydrateMany({ type: 'MenuItem', ids: [...menuItemIds] })", "ctx.mdm.collection.getMany/hydrateMany({ type: 'StockItem', ids: [...stockItemIds] })"];
            readonly notes: readonly ["columns: menu_item_ingredient_id, menu_item_id, stock_item_id, unit, created_at", "details JSONB: quantity, updatedAt", "menu_item_id -> MenuItem and stock_item_id -> StockItem resolved via bulk ctx.mdm.collection.getMany/hydrateMany"];
        };
    };
    export default menuItemIngredientRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredientRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.d.ts", "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient" {
    export type MenuItemIngredientUnit = 'kg' | 'gram' | 'liter' | 'milliliter' | 'portion' | 'unit';
    export interface MenuItemIngredient {
        menuItemIngredientId: string;
        menuItemId: string;
        stockItemId: string;
        quantity: number;
        unit: MenuItemIngredientUnit;
        createdAt: string;
        updatedAt: string;
    }
    /**
     * Unit compatibility groups — ingredients whose stock item uses a unit from the
     * same group are considered compatible.
     */
    export const UNIT_COMPATIBILITY_GROUPS: Record<MenuItemIngredientUnit, MenuItemIngredientUnit[]>;
    /**
     * Invariant: quantity must be greater than zero.
     */
    export function menuItemIngredientQuantityIsValid(ingredient: Pick<MenuItemIngredient, 'quantity'>): boolean;
    /**
     * Invariant: the unit of the link must be compatible with the unit of the
     * referenced stock item.
     */
    export function menuItemIngredientUnitIsCompatible(ingredientUnit: MenuItemIngredientUnit, stockItemUnit: MenuItemIngredientUnit): boolean;
    /**
     * Invariant: cannot have more than one link between the same menuItemId and stockItemId.
     * Returns true when the given list has no duplicate (menuItemId, stockItemId) pairs.
     */
    export function menuItemIngredientNoDuplicateLinks(ingredients: Array<Pick<MenuItemIngredient, 'menuItemId' | 'stockItemId'>>): boolean;
    /**
     * Returns the duplicate key if one exists, or null otherwise.
     */
    export function findDuplicateMenuItemIngredientLink(ingredients: Array<Pick<MenuItemIngredient, 'menuItemId' | 'stockItemId'>>): {
        menuItemId: string;
        stockItemId: string;
    } | null;
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository" {
    import type { MenuItemIngredient } from "_102045_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient";
    export interface MenuItemIngredientFilter {
        menuItemId?: string;
        stockItemId?: string;
        unit?: MenuItemIngredient['unit'];
    }
    export interface IMenuItemIngredientRepository {
        /** Retrieve a menu item ingredient by its unique identifier. Throws NOT_FOUND when absent. */
        getById(id: string): Promise<MenuItemIngredient>;
        /** List menu item ingredients matching the given filter. */
        list(filter?: MenuItemIngredientFilter): Promise<MenuItemIngredient[]>;
        /** Persist the menu item ingredient aggregate (upsert). */
        save(menuItemIngredient: MenuItemIngredient): Promise<void>;
        /** Find ingredient mappings for a specific menu item. */
        findByMenuItemId(menuItemId: string): Promise<MenuItemIngredient[]>;
        /** Find menu item mappings for a specific ingredient (stock item). */
        findByIngredientId(ingredientId: string): Promise<MenuItemIngredient[]>;
    }
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IMenuItemIngredientRepository } from "_102045_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository";
    export function createMenuItemIngredientRepositoryAdapter(ctx: RequestContext): IMenuItemIngredientRepository;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique order identifier";
            }, {
                readonly name: "shift_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to shift";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "order lifecycle status";
            }, {
                readonly name: "order_type";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "order type discriminator";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "tableNumber, priority, priorityReason, receivedAt, inPreparationAt, readyAt, deliveredAt, updatedAt + child collection OrderItem";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_shift_id";
                readonly columns: readonly ["shift_id"];
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_order_order_type";
                readonly columns: readonly ["order_type"];
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly ["OrderItem"];
            };
            readonly purpose: "operational";
            readonly appendOnly: false;
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/order" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderTableDef: TableDefinition;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepositoryAdapter";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain aggregate Order <-> orders table row", "Real columns: order_id, shift_id, status, order_type, created_at", "details JSONB contains: tableNumber, priority, priorityReason, receivedAt, inPreparationAt, readyAt, deliveredAt, updatedAt, items (embedded OrderItem[])", "Uses ctx.data.moduleData.orders"];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderRepository } from "_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository";
    export function createOrderRepositoryAdapter(ctx: RequestContext): IOrderRepository;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/seeds" {
    import type { TableSeedRows } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const menuItemIngredientSeeds: TableSeedRows;
    export const orderSeeds: TableSeedRows;
    export const shiftSeeds: TableSeedRows;
    export const shiftClosingReportSeeds: TableSeedRows;
    export const stockAdjustmentSeeds: TableSeedRows;
    export const stockConsumptionSeeds: TableSeedRows;
    export const stockLevelSeeds: TableSeedRows;
    export const mdmEntityIndexSeeds: TableSeedRows;
    export const mdmDocumentSeeds: TableSeedRows;
    export const mdmRelationshipSeeds: TableSeedRows;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.defs" {
    export const shiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Shift";
            readonly tableName: "shift";
            readonly columns: readonly [{
                readonly name: "shift_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique shift identifier";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "shift lifecycle status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "openedAt, closedAt, openedBy, closedBy, totalApurado, notes, updatedAt";
            }];
            readonly primaryKey: readonly ["shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_shift_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "operational";
            readonly appendOnly: false;
        };
    };
    export default shiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shift" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftTableDef: TableDefinition;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.defs" {
    export const shiftClosingReportTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "ShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "ShiftClosingReport";
            readonly tableName: "shift_closing_report";
            readonly columns: readonly [{
                readonly name: "shift_closing_report_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique report identifier";
            }, {
                readonly name: "shift_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to shift";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "totalApurado, paidOrderCount, updatedAt";
            }];
            readonly primaryKey: readonly ["shift_closing_report_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_closing_report_shift_id";
                readonly columns: readonly ["shift_id"];
            }, {
                readonly indexName: "idx_shift_closing_report_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "operational";
            readonly appendOnly: false;
        };
    };
    export default shiftClosingReportTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReport__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftClosingReportTableDef: TableDefinition;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter.defs" {
    export const shiftClosingReportRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftClosingReportRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftClosingReportRepositoryAdapter";
            readonly entityId: "ShiftClosingReport";
            readonly portRef: "IShiftClosingReportRepository";
            readonly tableRef: "shift_closing_reports";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain aggregate ShiftClosingReport <-> shift_closing_reports table row", "Real columns: shift_closing_report_id, shift_id, created_at", "details JSONB contains: totalApurado, paidOrderCount, updatedAt", "Uses ctx.data.moduleData.shift_closing_reports"];
        };
    };
    export default shiftClosingReportRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReportRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.d.ts", "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftClosingReportRepository } from "_102045_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository";
    export function createShiftClosingReportRepositoryAdapter(ctx: RequestContext): IShiftClosingReportRepository;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.defs" {
    export const shiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftRepositoryAdapter";
            readonly entityId: "Shift";
            readonly portRef: "IShiftRepository";
            readonly tableRef: "shifts";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain aggregate Shift <-> shifts table row", "Real columns: shift_id, status, created_at", "details JSONB contains: openedAt, closedAt, openedBy, closedBy, totalApurado, notes, updatedAt", "Uses ctx.data.moduleData.shifts"];
        };
    };
    export default shiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftRepository } from "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository";
    export function createShiftRepositoryAdapter(ctx: RequestContext): IShiftRepository;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.defs" {
    export const stockAdjustmentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockAdjustment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockAdjustment";
            readonly tableName: "stock_adjustment";
            readonly columns: readonly [{
                readonly name: "stock_adjustment_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique adjustment identifier";
            }, {
                readonly name: "stock_item_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to stock item (owner)";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "adjustment status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "quantity, reason, voidedAt, voidedReason";
            }];
            readonly primaryKey: readonly ["stock_adjustment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_adjustment_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
            }, {
                readonly indexName: "idx_stock_adjustment_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_stock_adjustment_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "controle";
            readonly appendOnly: true;
            readonly retentionDays: 365;
        };
    };
    export default stockAdjustmentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockAdjustment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockAdjustmentTableDef: TableDefinition;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter.defs" {
    export const stockAdjustmentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockAdjustmentRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockAdjustmentRepositoryAdapter";
            readonly entityId: "StockAdjustment";
            readonly portRef: "IStockAdjustmentRepository";
            readonly tableRef: "stock_adjustments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Event StockAdjustment <-> stock_adjustments table row", "Real columns: stock_adjustment_id, stock_item_id, status, created_at", "details JSONB contains: quantity, reason, voidedAt, voidedReason", "Append-only: insert row only, no update/delete; provides read finders", "Uses ctx.data.moduleData.stock_adjustments"];
        };
    };
    export default stockAdjustmentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockAdjustmentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.d.ts", "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment" {
    export type StockAdjustmentStatus = 'posted' | 'voided';
    export interface StockAdjustment {
        stockAdjustmentId: string;
        stockItemId: string;
        status: StockAdjustmentStatus;
        quantity: number;
        reason: string;
        voidedAt: string | null;
        voidedReason: string | null;
        createdAt: string;
    }
    export const STOCK_ADJUSTMENT_STATUS_TRANSITIONS: Record<StockAdjustmentStatus, StockAdjustmentStatus[]>;
    export function canTransitionStockAdjustment(from: StockAdjustmentStatus, to: StockAdjustmentStatus): boolean;
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository" {
    import type { StockAdjustment } from "_102045_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment";
    export type ProductId = string;
    export type AdjustmentReason = string;
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface IStockAdjustmentRepository {
        append(adjustment: StockAdjustment): Promise<void>;
        listByPeriod(period: DateRange): Promise<StockAdjustment[]>;
        listByProductId(productId: ProductId): Promise<StockAdjustment[]>;
        listByReason(reason: AdjustmentReason): Promise<StockAdjustment[]>;
    }
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockAdjustmentRepository } from "_102045_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository";
    export function createStockAdjustmentRepositoryAdapter(ctx: RequestContext): IStockAdjustmentRepository;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.defs" {
    export const stockConsumptionTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockConsumption";
            readonly tableName: "stock_consumption";
            readonly columns: readonly [{
                readonly name: "stock_consumption_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique consumption identifier";
            }, {
                readonly name: "stock_item_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to stock item (owner)";
            }, {
                readonly name: "order_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to order";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "consumption status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "quantity, voidedAt, voidReason";
            }];
            readonly primaryKey: readonly ["stock_consumption_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_consumption_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
            }, {
                readonly indexName: "idx_stock_consumption_order_id";
                readonly columns: readonly ["order_id"];
            }, {
                readonly indexName: "idx_stock_consumption_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_stock_consumption_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "controle";
            readonly appendOnly: true;
            readonly retentionDays: 365;
        };
    };
    export default stockConsumptionTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockConsumption__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockConsumptionTableDef: TableDefinition;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter.defs" {
    export const stockConsumptionRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockConsumptionRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockConsumptionRepositoryAdapter";
            readonly entityId: "StockConsumption";
            readonly portRef: "IStockConsumptionRepository";
            readonly tableRef: "stock_consumptions";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Event StockConsumption <-> stock_consumptions table row", "Real columns: stock_consumption_id, stock_item_id, order_id, status, created_at", "details JSONB contains: quantity, voidedAt, voidReason", "Append-only: insert row only, no update/delete; provides read finders", "Uses ctx.data.moduleData.stock_consumptions"];
        };
    };
    export default stockConsumptionRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockConsumptionRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockConsumptionRepository } from "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository";
    export function createStockConsumptionRepositoryAdapter(ctx: RequestContext): IStockConsumptionRepository;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs" {
    export const stockLevelTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockLevel";
            readonly tableName: "stock_level";
            readonly columns: readonly [{
                readonly name: "stock_level_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique stock level identifier";
            }, {
                readonly name: "stock_item_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to stock item";
            }, {
                readonly name: "unit";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "unit of measure discriminator";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "currentQuantity, minimumLevel, lastDecrementAt, lastAdjustmentAt, updatedAt";
            }];
            readonly primaryKey: readonly ["stock_level_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_level_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
            }, {
                readonly indexName: "idx_stock_level_unit";
                readonly columns: readonly ["unit"];
            }, {
                readonly indexName: "idx_stock_level_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "operational";
            readonly appendOnly: false;
        };
    };
    export default stockLevelTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockLevel__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockLevelTableDef: TableDefinition;
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs" {
    export const stockLevelRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockLevelRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockLevelRepositoryAdapter";
            readonly entityId: "StockLevel";
            readonly portRef: "IStockLevelRepository";
            readonly tableRef: "stock_levels";
            readonly mdmReads: readonly ["StockItem"];
            readonly notes: readonly ["Domain aggregate StockLevel <-> stock_levels table row", "Real columns: stock_level_id, stock_item_id, unit, created_at", "details JSONB contains: currentQuantity, minimumLevel, lastDecrementAt, lastAdjustmentAt, updatedAt", "MDM ref StockItem resolved via ctx.mdm.collection.getMany/hydrateMany using stock_item_id (bulk load, never in loop)", "Uses ctx.data.moduleData.stock_levels"];
        };
    };
    export default stockLevelRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockLevelRepository } from "_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository";
    export function createStockLevelRepositoryAdapter(ctx: RequestContext): IStockLevelRepository;
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.defs" {
    export const menuItemIngredientRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "MenuItemIngredientRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItemIngredient";
            readonly interfaceName: "IMenuItemIngredientRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: MenuItemIngredientId"];
                readonly returns: "MenuItemIngredient";
                readonly description: "Retrieve a menu item ingredient by its unique identifier";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: MenuItemIngredientFilter"];
                readonly returns: "MenuItemIngredient[]";
                readonly description: "List menu item ingredients matching the given filter";
            }, {
                readonly name: "save";
                readonly params: readonly ["menuItemIngredient: MenuItemIngredient"];
                readonly returns: "void";
                readonly description: "Persist the menu item ingredient aggregate";
            }, {
                readonly name: "findByMenuItemId";
                readonly params: readonly ["menuItemId: MenuItemId"];
                readonly returns: "MenuItemIngredient[]";
                readonly description: "Find ingredient mappings for a specific menu item";
            }, {
                readonly name: "findByIngredientId";
                readonly params: readonly ["ingredientId: IngredientId"];
                readonly returns: "MenuItemIngredient[]";
                readonly description: "Find menu item mappings for a specific ingredient";
            }];
        };
    };
    export default menuItemIngredientRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredientRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Order";
                readonly params: readonly ["id: OrderId"];
            }, {
                readonly name: "list";
                readonly returns: "Order[]";
                readonly params: readonly ["filter: OrderFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["order: Order"];
            }, {
                readonly name: "findByOrderNumber";
                readonly returns: "Order | null";
                readonly params: readonly ["orderNumber: OrderNumber"];
            }, {
                readonly name: "listByShiftId";
                readonly returns: "Order[]";
                readonly params: readonly ["shiftId: ShiftId"];
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.defs" {
    export const shiftClosingReportRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftClosingReportRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftClosingReport";
            readonly interfaceName: "IShiftClosingReportRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "ShiftClosingReport";
                readonly params: readonly ["id: ShiftClosingReportId"];
            }, {
                readonly name: "list";
                readonly returns: "ShiftClosingReport[]";
                readonly params: readonly ["filter: ShiftClosingReportFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["report: ShiftClosingReport"];
            }, {
                readonly name: "findByShiftId";
                readonly returns: "ShiftClosingReport | null";
                readonly params: readonly ["shiftId: ShiftId"];
            }];
        };
    };
    export default shiftClosingReportRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReportRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.defs" {
    export const shiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Shift";
            readonly interfaceName: "IShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Shift";
                readonly params: readonly ["id: ShiftId"];
            }, {
                readonly name: "list";
                readonly returns: "Shift[]";
                readonly params: readonly ["filter: ShiftFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["shift: Shift"];
            }, {
                readonly name: "findOpenShift";
                readonly returns: "Shift | null";
                readonly params: readonly [];
            }, {
                readonly name: "listByDate";
                readonly returns: "Shift[]";
                readonly params: readonly ["date: LocalDate"];
            }];
        };
    };
    export default shiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.defs" {
    export const stockAdjustmentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockAdjustmentRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockAdjustment";
            readonly interfaceName: "IStockAdjustmentRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["adjustment: StockAdjustment"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "StockAdjustment[]";
                readonly params: readonly ["period: DateRange"];
            }, {
                readonly name: "listByProductId";
                readonly returns: "StockAdjustment[]";
                readonly params: readonly ["productId: ProductId"];
            }, {
                readonly name: "listByReason";
                readonly returns: "StockAdjustment[]";
                readonly params: readonly ["reason: AdjustmentReason"];
            }];
        };
    };
    export default stockAdjustmentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockAdjustmentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.defs" {
    export const stockConsumptionRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockConsumptionRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockConsumption";
            readonly interfaceName: "IStockConsumptionRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["consumption: StockConsumption"];
            }, {
                readonly name: "listByOwnerId";
                readonly returns: "StockConsumption[]";
                readonly params: readonly ["orderId: OrderId"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "StockConsumption[]";
                readonly params: readonly ["period: DateRange"];
            }, {
                readonly name: "listByProductId";
                readonly returns: "StockConsumption[]";
                readonly params: readonly ["productId: ProductId"];
            }];
        };
    };
    export default stockConsumptionRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockConsumptionRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs" {
    export const stockLevelRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockLevelRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly interfaceName: "IStockLevelRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "StockLevel";
                readonly params: readonly ["id: StockLevelId"];
            }, {
                readonly name: "list";
                readonly returns: "StockLevel[]";
                readonly params: readonly ["filter: StockLevelFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["stockLevel: StockLevel"];
            }, {
                readonly name: "findByProductId";
                readonly returns: "StockLevel | null";
                readonly params: readonly ["productId: ProductId"];
            }, {
                readonly name: "listLowStock";
                readonly returns: "StockLevel[]";
                readonly params: readonly [];
            }];
        };
    };
    export default stockLevelRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.defs" {
    export const browseMenuItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseMenuItems";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "browseMenuItems";
                readonly inputTypeName: "BrowseMenuItemsInput";
                readonly outputTypeName: "BrowseMenuItemsOutput";
                readonly input: readonly [{
                    readonly name: "statusFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Filtro opcional por status do item (draft, active, inactive)";
                }, {
                    readonly name: "menuCategoryIdFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Filtro opcional por categoria do item (menuCategoryId)";
                }];
                readonly output: readonly [{
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Lista de itens do cardápio com campos projetados: menuItemId, name, description, menuCategoryId, price, itemType, status, activatedAt, createdAt, updatedAt";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total de itens retornados na lista";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["simpleItemsOnly"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver activeCompanyId a partir de ctx.sessionContext.businessContext.activeCompanyId para escopo da consulta", "2. MODELING GAP: MenuItem nao possui campo companyId em seu modelo de entidade; registrar a lacuna e NAO aplicar filtro por empresa ativa (evitar matching contra campo inexistente)", "3. Listar entidades MDM do tipo MenuItem via ctx.mdm.collection.listByType({ type: 'MenuItem' })", "4. Aplicar filtro opcional statusFilter: se informado, manter apenas itens cujo status corresponde ao valor", "5. Aplicar filtro opcional menuCategoryIdFilter: se informado, manter apenas itens cujo menuCategoryId corresponde ao valor", "6. Aplicar regra simpleItemsOnly: listar todos os itens (simple e variant) como entradas separadas, sem expansao ou agrupamento de variantes — cada item aparece individualmente na lista", "7. Projetar campos de saida (menuItemId, name, description, menuCategoryId, price, itemType, status, activatedAt, createdAt, updatedAt) para cada item", "8. Retornar { items, total } com a lista filtrada e projetada"];
            }];
            readonly mdmRefs: readonly ["MenuItem", "MenuCategory"];
        };
    };
    export default browseMenuItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseMenuItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.defs" {
    export const browseStockItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseStockItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseStockItems";
            readonly ports: readonly ["StockLevel"];
            readonly functions: readonly [{
                readonly functionName: "browseStockItems";
                readonly inputTypeName: "BrowseStockItemsInput";
                readonly outputTypeName: "BrowseStockItemsOutput";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Termo de busca opcional para filtrar itens de estoque pelo nome.";
                }];
                readonly output: readonly [{
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Lista de itens de estoque com nome, unidade, limite mínimo, quantidade atual e flag de alerta de estoque baixo.";
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Número total de itens retornados na lista.";
                }];
                readonly ports: readonly ["StockLevel"];
                readonly rulesApplied: readonly ["lowStockAlertCalculation"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver o actorId a partir de ctx.sessionContext para autorização do gerente autenticado.", "2. Listar todos os StockItems do MDM via ctx.mdm.collection.listByType({ type: 'StockItem' }).", "3. Se searchTerm foi informado, filtrar os itens cujo name contém o termo (case-insensitive).", "4. Ordenar os itens resultantes por name em ordem ascendente.", "5. Coletar todos os stockItemId dos itens filtrados e buscar os StockLevels correspondentes em lote através da porta StockLevel (list/find by stockItemId).", "6. Para cada StockItem, localizar seu StockLevel correspondente e aplicar a regra lowStockAlertCalculation: se currentQuantity <= minimumLevel, marcar lowStockAlert = true; caso contrário false.", "7. Montar a lista de saída com stockItemId, name, unit, minimumLevel, createdAt, updatedAt, currentQuantity e lowStockAlert para cada item.", "8. Retornar { items, total } onde total é o número de itens na lista."];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default browseStockItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseStockItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/closeShift.defs" {
    export const closeShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeShift";
            readonly ports: readonly ["Shift", "Order", "ShiftClosingReport", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "closeShift";
                readonly inputTypeName: "CloseShiftInput";
                readonly outputTypeName: "CloseShiftOutput";
                readonly input: readonly [{
                    readonly name: "totalApurado";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Valor total apurado no fechamento do turno, informado pelo gerente para conferência.";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Observações gerais sobre o turno, opcionais.";
                    readonly ofEntity: "Shift";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "closedBy";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "totalApurado";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Shift";
                }];
                readonly ports: readonly ["Shift", "Order", "ShiftClosingReport"];
                readonly rulesApplied: readonly ["singleOpenShift", "shiftClosingRecordsRevenue", "dashboardCurrentShiftOnly"];
                readonly transactional: true;
                readonly steps: readonly ["1. Query Shift port for all shifts with status='open' (resolve activeLifecycleInstance).", "2. Apply rule singleOpenShift: if zero or more than one open shift is found, throw validation error 'closeShift.singleOpenShift: exactly one open shift required'.", "3. Resolve closedBy from ctx.sessionContext.actorId (actorSession).", "4. Resolve closedAt from ctx.clock.now() (systemDefault).", "5. Load the open Shift aggregate via Shift port getById.", "6. Validate the Shift is in 'open' status (guard against race condition).", "7. Mutate the Shift: set status='closed', closedAt=resolved timestamp, closedBy=resolved actor id, totalApurado=input value, notes=input value (or null), updatedAt=ctx.clock.now().", "8. Save the Shift aggregate via Shift port save.", "9. Query Order port for all orders with shiftId=open shift id and status='delivered' to count paid orders (shiftClosingRecordsRevenue context).", "10. Generate shiftClosingReportId via ctx.idGenerator.", "11. Create ShiftClosingReport via ShiftClosingReport port: shiftId, totalApurado (from input), paidOrderCount (count of delivered orders), createdAt=ctx.clock.now(), updatedAt=ctx.clock.now().", "12. Apply rule dashboardCurrentShiftOnly: after closing, no shift remains 'open', so dashboard will show no active shift — this is the expected terminal state.", "13. Return shiftId, status='closed', closedAt, closedBy, totalApurado, notes."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default closeShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/closeShift.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/closeShift.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly ports: readonly ["Order", "StockLevel", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly outputTypeName: "CreateOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Tipo do pedido: 'table' (consumo na mesa) ou 'takeout' (para viagem)";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Número da mesa, obrigatório quando orderType = 'table'";
                }, {
                    readonly name: "orderItems";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Lista de itens do cardápio selecionados, cada um com menuItemId (string) e quantity (number > 0)";
                }, {
                    readonly name: "priority";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Indica se o pedido foi marcado como prioritário no preparo";
                }, {
                    readonly name: "priorityReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Justificativa da priorização, obrigatória quando priority = true";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identificador único gerado para o novo pedido";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Status inicial do pedido: 'registered'";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Tipo do pedido criado";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Número da mesa (nulo quando takeout)";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Momento de criação do pedido";
                }];
                readonly ports: readonly ["Order", "StockLevel", "Shift"];
                readonly rulesApplied: readonly ["stockDecrementOnOrderLaunch", "orderStatusFlow", "fifoKitchenQueue"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve the active (open) Shift by querying the Shift port for status='open'; if none found, throw validation error 'No open shift found — cannot launch order'", "2. Validate orderType is 'table' or 'takeout' (rule: orderStatusFlow — order must start at 'registered')", "3. If orderType='table', validate tableNumber is provided and non-empty; if orderType='takeout', set tableNumber to null", "4. If priority=true, validate priorityReason is provided and non-empty (rule: orderStatusFlow — priority requires justification)", "5. Validate orderItems array is not empty and each item has a non-null menuItemId and quantity > 0", "6. Collect all menuItemIds from orderItems; fetch MenuItems from MDM via ctx.mdm.collection.getMany({ mdmIds }); validate all exist and have status='active'", "7. Generate orderId via ctx.idGenerator; set createdAt and updatedAt to ctx.clock.now()", "8. Build Order aggregate root with status='registered', shiftId from resolved open Shift, orderType, tableNumber, priority (default false), priorityReason, createdAt, updatedAt", "9. For each orderItem entry, generate orderItemId via ctx.idGenerator, set unitPrice from the corresponding MenuItem.price, and create an OrderItem child linked to orderId with createdAt and updatedAt", "10. For all ordered MenuItems, resolve ingredient stock-item links via ctx.mdm.collection.relatedOfMany to get each ingredient's stockItemId and quantity-per-unit", "11. Aggregate total consumption per stockItemId across all order items: sum(ingredient.quantityPerUnit × orderItem.quantity) for each stock item", "12. For each stockItemId with consumption > 0, load StockLevel via StockLevel port (find by stockItemId); validate currentQuantity >= total consumption (rule: stockDecrementOnOrderLaunch — stock must be available at launch); decrement currentQuantity by total consumption; set lastDecrementAt to ctx.clock.now()", "13. For each consumption, create a StockConsumption child record with generated stockConsumptionId (ctx.idGenerator), stockItemId, orderId, quantity, status='posted', createdAt=ctx.clock.now()", "14. Append StockConsumption audit event records through the Order port (StockConsumption is owned by Order) inside the same transaction — event purpose 'audit', persisted=true", "15. The order's createdAt timestamp establishes its position in the kitchen queue, ensuring FIFO processing (rule: fifoKitchenQueue — orders are queued by creation time)", "16. Inside a single ctx.data transaction: save the Order aggregate (with embedded OrderItems and StockConsumption children) through the Order port; save each updated StockLevel through the StockLevel port", "17. Return { orderId, status: 'registered', orderType, tableNumber, createdAt }"];
            }];
            readonly mdmRefs: readonly ["MenuItem"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.defs" {
    export const deliverOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deliverOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deliverOrder";
            readonly ports: readonly ["Order", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "deliverOrder";
                readonly inputTypeName: "DeliverOrderInput";
                readonly outputTypeName: "DeliverOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Pedido selecionado pelo atendente no painel para entrega";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order", "StockConsumption"];
                readonly rulesApplied: readonly ["orderStatusFlow", "readyBeforeDelivered"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Order aggregate by orderId via OrderPort.getById(orderId); throw NotFoundError if absent.", "Apply rule readyBeforeDelivered: verify order.status === 'ready'; if not, throw ValidationError with detail { rule: 'readyBeforeDelivered', currentStatus: order.status, expectedStatus: 'ready' }.", "Apply rule orderStatusFlow: verify the transition 'ready' -> 'delivered' is permitted in the status flow enum [registered, received, inPreparation, ready, delivered]; if not allowed, throw ValidationError with detail { rule: 'orderStatusFlow', from: order.status, to: 'delivered' }.", "Mutate the Order in memory: set status = 'delivered', deliveredAt = ctx.clock.now(), updatedAt = ctx.clock.now().", "Persist the updated Order via OrderPort.save(order) inside the transaction.", "Append a StockConsumption audit event record (entityId: StockConsumption, owner: Order, purpose: audit) through the StockConsumption port inside the same transaction, capturing the orderId, previous status 'ready', new status 'delivered', and deliveredAt timestamp.", "Return { orderId, status: 'delivered', deliveredAt, updatedAt }."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default deliverOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "deliverOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.defs" {
    export const manageMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "manageMenuItem";
                readonly inputTypeName: "ManageMenuItemInput";
                readonly outputTypeName: "ManageMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador do item do cardápio selecionado para edição";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Nome do item do cardápio exibido no POS";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Descrição detalhada do item do cardápio";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Categoria de classificação à qual o item pertence";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Preço de venda do item do cardápio";
                }, {
                    readonly name: "itemType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Tipo do item: deve ser 'simple' nesta fase";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Status do item: draft, active ou inactive";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador do item atualizado";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "itemType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "activatedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "inactivatedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["simpleItemsOnly", "menuItemRequiresIngredient"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve actorId from ctx.sessionContext and now from ctx.clock (systemDefault for updatedAt).", "2. Load existing MenuItem via ctx.mdm.entity.get({ mdmId: menuItemId }). If not found, throw validation error 'MenuItem not found'.", "3. Validate menuCategoryId exists via ctx.mdm.entity.get({ mdmId: menuCategoryId }) (MenuCategory is an MDM ref). If not found, throw validation error 'MenuCategory not found'.", "4. Apply rule simpleItemsOnly: if itemType !== 'simple', throw validation error with ruleId 'simpleItemsOnly' — 'Only simple items are allowed in this phase'.", "5. Determine status transition from existing.status to input.status:", "   5a. If transitioning from 'draft' or 'inactive' to 'active': set activatedAt = now (ctx.clock).", "   5b. If transitioning from 'active' to 'inactive': set inactivatedAt = now (ctx.clock).", "   5c. If status remains unchanged, preserve existing activatedAt/inactivatedAt.", "6. Apply rule menuItemRequiresIngredient: if the resulting status is 'active', query MenuItemIngredient via ctx.mdm.collection.listByType({ type: 'MenuItemIngredient', filter: { menuItemId } }). If the returned collection is empty, throw validation error with ruleId 'menuItemRequiresIngredient' — 'Cannot activate a MenuItem without at least one ingredient'.", "7. Build the update payload: name, description, menuCategoryId, price, itemType, status, activatedAt (if set), inactivatedAt (if set), updatedAt = now.", "8. Persist via ctx.mdm.entity.update({ mdmId: menuItemId, details: updatePayload }) inside a single ctx.data transaction wrapper.", "9. Return the updated MenuItem projection: menuItemId, name, description, menuCategoryId, price, itemType, status, activatedAt, inactivatedAt, updatedAt."];
            }];
            readonly mdmRefs: readonly ["MenuItem", "MenuCategory"];
        };
    };
    export default manageMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.defs" {
    export const manageStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "manageStockItem";
                readonly inputTypeName: "ManageStockItemInput";
                readonly outputTypeName: "ManageStockItemOutput";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador do item de estoque a ser atualizado, obtido do parâmetro de rota.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Nome do ingrediente editado pelo gerente.";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unidade de medida do ingrediente (kg, liter, portion ou unit).";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo.";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador do item de estoque atualizado.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Nome atualizado do item de estoque.";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unidade de medida atualizada.";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Limite mínimo atualizado para alerta de estoque baixo.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Timestamp da última atualização atribuído pelo sistema.";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlertCalculation"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate that unit is one of the allowed enum values: kg, liter, portion, unit. If invalid, throw validation error referencing rule lowStockAlertCalculation context.", "2. Validate that minimumLevel is a non-negative number. If invalid, throw validation error.", "3. Load the existing StockItem from MDM via ctx.mdm.entity.get({ mdmId: stockItemId }). If not found, throw a not-found error.", "4. Build the updated StockItem payload: name, unit, minimumLevel from user input; updatedAt from ctx.clock.now(); preserve createdAt from the existing record.", "5. Persist the update via ctx.mdm.entity.update({ mdmId: stockItemId, details: { name, unit, minimumLevel, createdAt, updatedAt } }).", "6. Apply rule lowStockAlertCalculation: after the update, the low-stock alert threshold is the new minimumLevel. The alert is recalculated by comparing the current StockLevel quantity against the updated minimumLevel — if current quantity <= minimumLevel, the item is flagged as low-stock. This is an inline calculation using the updated minimumLevel value.", "7. Return the updated StockItem projection: stockItemId, name, unit, minimumLevel, updatedAt."];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default manageStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "manageStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/openShift.defs" {
    export const openShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "openShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "openShift";
            readonly ports: readonly ["Shift"];
            readonly functions: readonly [{
                readonly functionName: "openShift";
                readonly inputTypeName: "OpenShiftInput";
                readonly outputTypeName: "OpenShiftOutput";
                readonly input: readonly [{
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Shift";
                    readonly description: "Observações gerais opcionais sobre o turno, informadas pelo gerente ao abrir.";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador único do turno criado.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Situação do turno, sempre 'open' após a criação.";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Data e hora de abertura do turno.";
                }, {
                    readonly name: "openedBy";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador do gerente que abriu o turno.";
                }];
                readonly ports: readonly ["Shift"];
                readonly rulesApplied: readonly ["singleOpenShift"];
                readonly transactional: true;
                readonly steps: readonly ["1. Query the Shift port for any existing Shift with status 'open' (singleOpenShift rule). If one is found, reject the operation with a validation error referencing rule 'singleOpenShift'.", "2. Generate a new UUID for shiftId via ctx.idGenerator.", "3. Resolve openedBy from ctx.sessionContext.actorId (actorSession).", "4. Set status = 'open', openedAt = ctx.clock.now(), createdAt = ctx.clock.now(), updatedAt = ctx.clock.now().", "5. Build the Shift aggregate with the provided notes (optional) and all resolved fields; closedAt, closedBy and totalApurado remain null.", "6. Persist the Shift through its port inside a single transaction (ctx.data transaction wrapper).", "7. Return shiftId, status, openedAt, openedBy."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default openShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "openShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/openShift.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/openShift.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.defs" {
    export const requestAiPromoSuggestionsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "requestAiPromoSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "requestAiPromoSuggestions";
            readonly ports: readonly ["Order", "StockLevel", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "requestAiPromoSuggestions";
                readonly inputTypeName: "RequestAiPromoSuggestionsInput";
                readonly outputTypeName: "AiPromoSuggestion";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "ID do item de menu sugerido para promoção";
                }, {
                    readonly name: "totalQuantitySold";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade total vendida do item nos últimos 7 dias";
                }, {
                    readonly name: "currentStockQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade atual em estoque do item";
                }, {
                    readonly name: "stockUnit";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Unidade de medida do estoque (kg, liter, portion, unit)";
                }, {
                    readonly name: "suggestionReason";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Motivo da sugestão derivado do padrão de vendas e nível de estoque";
                }, {
                    readonly name: "suggestedDiscountPercent";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Percentual de desconto sugerido com base no volume de vendas e estoque";
                }];
                readonly ports: readonly ["Order", "StockLevel"];
                readonly rulesApplied: readonly ["aiPromoBasedOnLast7Days", "aiConsumesDomainData"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve windowStart = ctx.clock.now() minus 7 days (rule aiPromoBasedOnLast7Days) — this is the analysis window; no user input needed", "Resolve actorId from ctx.sessionContext for audit and permission context", "Query Order port for all orders with createdAt >= windowStart (last 7 days only)", "From each loaded Order aggregate, collect embedded OrderItems and aggregate total quantity by menuItemId across the entire window", "Query StockLevel port for all current stock levels to cross-reference with aggregated sales data (rule aiConsumesDomainData — only domain data from Order, OrderItem, StockLevel is consumed, no external sources)", "Cross-reference: items with high sales volume AND sufficient stock (currentQuantity > minimumLevel) are promo candidates; items with low stock (currentQuantity <= minimumLevel) are excluded to avoid supply constraints", "Compute suggestedDiscountPercent proportional to sales volume and stock surplus — higher volume + higher surplus yields larger suggested discount", "Build the promo suggestion list with menuItemId, totalQuantitySold, currentStockQuantity, stockUnit, suggestionReason, and suggestedDiscountPercent", "Append audit event to StockConsumption port recording the AI suggestion request (actorId, windowStart, suggestionCount) — note: StockConsumption port is referenced by eventWrites but not present in provided ports; this is a modeling gap that should be resolved by adding StockConsumption to ports", "Return the list of promo suggestions as the operation result — no Order, OrderItem, or StockLevel records are modified (strictly read-only)"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default requestAiPromoSuggestionsUsecase;
    export const pipeline: readonly [{
        readonly id: "requestAiPromoSuggestions__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.defs" {
    export const requestAiSalesSummaryUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "requestAiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "requestAiSalesSummary";
            readonly ports: readonly ["Order", "Shift", "StockLevel", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "requestAiSalesSummary";
                readonly inputTypeName: "AiSalesSummaryInput";
                readonly outputTypeName: "AiSalesSummaryOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "ID of the currently open shift used to scope the summary";
                }, {
                    readonly name: "shiftOpenedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Timestamp when the current shift was opened";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total count of orders placed during the current open shift";
                }, {
                    readonly name: "totalRevenue";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of revenue across all orders in the current shift";
                }, {
                    readonly name: "orders";
                    readonly type: "array";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Orders from the current shift projected as {orderId, status, orderType, createdAt, deliveredAt}";
                }, {
                    readonly name: "topSellers";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Top-selling items aggregated from day orders: {menuItemId, totalQuantity, totalRevenue} sorted by totalQuantity descending";
                }, {
                    readonly name: "stockLevels";
                    readonly type: "array";
                    readonly ofEntity: "StockLevel";
                    readonly required: true;
                    readonly description: "Current stock levels projected as {stockItemId, currentQuantity, minimumLevel, unit} for AI consumption";
                }];
                readonly ports: readonly ["Order", "Shift", "StockLevel"];
                readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "aiConsumesDomainData", "topSellersFromDayOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve the active lifecycle instance: query the Shift port for the single Shift with status='open' (rule: dashboardCurrentShiftOnly). If no open shift is found, return an empty summary with shiftId=null, zero counts, and empty arrays — never expose historical or multi-shift data.", "2. Extract the resolved shiftId and shiftOpenedAt from the open Shift record.", "3. Load all Orders for the resolved shiftId via the Order port (list filtered by shiftId). Each Order aggregate includes its embedded OrderItem collection.", "4. Project each Order to {orderId, status, orderType, createdAt, deliveredAt} for the orders output array.", "5. Aggregate OrderItems across all loaded Orders: group by menuItemId, sum quantity into totalQuantity and sum (quantity * unitPrice) into totalRevenue. Sort descending by totalQuantity to produce topSellers (rule: topSellersFromDayOrders).", "6. Compute totalOrders as the count of loaded Orders and totalRevenue as the sum of all OrderItem subtotals.", "7. Load all StockLevel records via the StockLevel port and project each to {stockItemId, currentQuantity, minimumLevel, unit} for the stockLevels output array.", "8. Assemble and return the AiSalesSummaryOutput containing only domain-sourced data — no external APIs, no historical periods, no multi-shift consolidation (rule: aiConsumesDomainData)."];
            }];
            readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "aiConsumesDomainData", "topSellersFromDayOrders"];
            readonly mdmRefs: readonly [];
        };
    };
    export default requestAiSalesSummaryUsecase;
    export const pipeline: readonly [{
        readonly id: "requestAiSalesSummary__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "aiConsumesDomainData", "topSellersFromDayOrders"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly ports: readonly ["Order", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly outputTypeName: "UpdateOrderStatusOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Pedido selecionado pelo cozinheiro na fila da cozinha";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Novo status que o cozinheiro deseja atribuir ao pedido (inPreparation ou ready)";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID do pedido atualizado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Status confirmado após a atualização";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp da última atualização do registro";
                }];
                readonly ports: readonly ["Order", "Shift", "StockConsumption"];
                readonly rulesApplied: readonly ["orderStatusFlow", "inProgressBeforeReady"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve o turno ativo consultando o port Shift por status='open'; se nenhum turno aberto existir, retorna erro de validação 'Nenhum turno aberto encontrado'", "2. Carrega o pedido pelo orderId através do port Order (getById)", "3. Valida que o pedido pertence ao turno ativo comparando order.shiftId com o shiftId resolvido no passo 1; se não pertencer, retorna erro 'Pedido não pertence ao turno ativo'", "4. Aplica a regra orderStatusFlow: o novo status deve seguir a sequência obrigatória received → inPreparation → ready. Se o status atual for 'received', só permite transição para 'inPreparation'. Se o status atual for 'inPreparation', só permite transição para 'ready'. Qualquer outro salto retorna erro com a regra orderStatusFlow", "5. Aplica a regra inProgressBeforeReady: o pedido só pode ser marcado como 'ready' se o status atual for 'inPreparation'; caso contrário retorna erro com a regra inProgressBeforeReady", "6. Define timestamps via ctx.clock.now(): se o novo status for 'inPreparation', preenche inPreparationAt; se for 'ready', preenche readyAt; sempre atualiza updatedAt", "7. Persiste o pedido atualizado através do port Order (update) dentro da mesma transação", "8. Emite evento StockConsumption (purpose=audit) através do port StockConsumption dentro da mesma transação, registrando a mudança de status do pedido", "9. Retorna orderId, status confirmado e updatedAt"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.defs" {
    export const viewDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewDashboard";
            readonly ports: readonly ["Order", "StockLevel", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly outputTypeName: "ViewDashboardOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "ID of the currently open shift used to scope all dashboard data";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of all order totals (unitPrice * quantity per OrderItem) for orders in the current shift";
                }, {
                    readonly name: "orderCount";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Number of orders registered in the current shift";
                }, {
                    readonly name: "orders";
                    readonly type: "OrderSummary[]";
                    readonly required: true;
                    readonly description: "List of order summaries for the current shift including status, orderType, createdAt, and deliveredAt";
                }, {
                    readonly name: "topSellers";
                    readonly type: "TopSeller[]";
                    readonly required: true;
                    readonly description: "Items ranked by total quantity sold, computed only from OrderItems of the current shift orders (rule topSellersFromDayOrders)";
                }, {
                    readonly name: "lowStockAlerts";
                    readonly type: "LowStockAlert[]";
                    readonly required: true;
                    readonly description: "Stock items whose currentQuantity is below minimumLevel, flagged as low-stock alerts";
                }];
                readonly ports: readonly ["Order", "StockLevel", "Shift"];
                readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "topSellersFromDayOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve the currently open Shift by querying the Shift port for status='open' (activeLifecycleInstance resolution). If no open shift exists, return an empty dashboard with shiftId=null, totalSales=0, orderCount=0, empty orders/topSellers/lowStockAlerts (rule dashboardCurrentShiftOnly).", "2. Extract actorId from ctx.sessionContext for authorization context (actorSession resolution). The actor must be an authenticated manager; if sessionContext is missing, throw an authorization error.", "3. Load all Orders for the resolved shiftId via the Order port (list by shiftId). Each Order aggregate includes its embedded OrderItem collection.", "4. Build the orders summary list projecting orderId, status, orderType, createdAt, shiftId, deliveredAt for each order.", "5. Compute totalSales by iterating all OrderItems across all loaded orders and summing (unitPrice * quantity).", "6. Compute topSellers by aggregating OrderItems grouped by menuItemId: sum quantity per menuItemId and sum (unitPrice * quantity) as totalRevenue. Sort descending by totalQuantity. This applies rule topSellersFromDayOrders — only OrderItems from the current shift orders are considered, never historical data.", "7. Query the StockLevel port for all stock level records. Filter those where currentQuantity < minimumLevel to build lowStockAlerts with stockItemId, currentQuantity, minimumLevel, and unit.", "8. Assemble and return the dashboard output: shiftId, totalSales, orderCount, orders, topSellers, lowStockAlerts. No historical periods or multi-shift consolidation is permitted (rule dashboardCurrentShiftOnly)."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.defs" {
    export const viewKitchenBoardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewKitchenBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewKitchenBoard";
            readonly ports: readonly ["Order", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "viewKitchenBoard";
                readonly inputTypeName: "ViewKitchenBoardInput";
                readonly outputTypeName: "ViewKitchenBoardOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Identificador único do pedido";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Status atual do pedido (received ou inPreparation)";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Tipo do pedido: table ou takeout";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Número da mesa quando orderType=table";
                }, {
                    readonly name: "priority";
                    readonly type: "boolean";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Indica se o pedido é prioritário";
                }, {
                    readonly name: "priorityReason";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Motivo da prioridade quando priority=true";
                }, {
                    readonly name: "receivedAt";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Data/hora em que o pedido foi recebido pela cozinha";
                }, {
                    readonly name: "inPreparationAt";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Data/hora em que o pedido entrou em preparação";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Data/hora de criação do pedido";
                }, {
                    readonly name: "orderItems";
                    readonly type: "OrderItem[]";
                    readonly ofEntity: "OrderItem";
                    readonly required: true;
                    readonly description: "Itens do pedido com orderItemId, menuItemId, quantity e unitPrice";
                }];
                readonly ports: readonly ["Order", "Shift"];
                readonly rulesApplied: readonly ["fifoKitchenQueue", "dashboardCurrentShiftOnly"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver o turno ativo: consultar o port Shift listando por status='open' para obter o shiftId do único turno aberto (activeLifecycleInstance). Se nenhum turno estiver aberto, retornar lista vazia.", "2. Aplicar regra dashboardCurrentShiftOnly: filtrar pedidos do port Order pelo shiftId resolvido no passo 1, garantindo que apenas pedidos do turno atual sejam exibidos.", "3. Aplicar filtro de status (systemDefault): restringir a lista aos pedidos cujo status seja 'received' ou 'inPreparation', excluindo pedidos 'registered', 'ready' ou 'delivered'.", "4. Aplicar regra fifoKitchenQueue: ordenar os pedidos colocando primeiro os com priority=true (destaque) e dentro de cada grupo ordenar por receivedAt em ordem crescente (FIFO).", "5. Projetar os campos de saída de cada Order (orderId, status, orderType, tableNumber, priority, priorityReason, receivedAt, inPreparationAt, createdAt) e incluir os OrderItems embarcados no agregado Order (orderItemId, menuItemId, quantity, unitPrice).", "6. Retornar a lista de pedidos projetada como coleção de ViewKitchenBoardOutput."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewKitchenBoardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewKitchenBoard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.defs" {
    export const viewOrderBoardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewOrderBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewOrderBoard";
            readonly ports: readonly ["Order", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "viewOrderBoard";
                readonly inputTypeName: "ViewOrderBoardInput";
                readonly outputTypeName: "ViewOrderBoardOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "orders";
                    readonly type: "Order[]";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Pedidos do turno atual aberto, ordenados por createdAt crescente (FIFO)";
                }, {
                    readonly name: "currentShiftId";
                    readonly type: "string";
                    readonly ofEntity: "Shift";
                    readonly required: false;
                    readonly description: "ID do turno aberto resolvido em runtime; ausente quando nenhum turno está aberto";
                }];
                readonly ports: readonly ["Order", "Shift"];
                readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "fifoKitchenQueue", "orderStatusFlow"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver o turno atualmente aberto consultando o port Shift por status='open' (regra dashboardCurrentShiftOnly)", "2. Se nenhum turno aberto for encontrado, retornar lista vazia sem erro (regra dashboardCurrentShiftOnly)", "3. Consultar o port Order filtrando por shiftId igual ao shiftId do turno aberto resolvido no passo 1", "4. Ordenar os resultados por Order.createdAt em ordem crescente (regra fifoKitchenQueue)", "5. Validar que cada Order.status pertence ao enum permitido [registered, received, inPreparation, ready, delivered] (regra orderStatusFlow); pedidos com status inválido são filtrados e não exibidos", "6. Projetar os campos orderId, status, orderType, tableNumber, priority, priorityReason, receivedAt, inPreparationAt, readyAt, createdAt para cada pedido", "7. Retornar a lista projetada junto com o currentShiftId resolvido"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewOrderBoardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewOrderBoard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.defs" {
    export const viewShiftClosingReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewShiftClosingReport";
            readonly ports: readonly ["ShiftClosingReport", "Shift"];
            readonly functions: readonly [{
                readonly functionName: "viewShiftClosingReport";
                readonly inputTypeName: "ViewShiftClosingReportInput";
                readonly outputTypeName: "ViewShiftClosingReportOutput";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Identificador do turno fechado cujo relatório de fechamento será exibido.";
                }];
                readonly output: readonly [{
                    readonly name: "shiftClosingReportId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Identificador único do relatório de fechamento.";
                }, {
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Identificador do turno ao qual o relatório pertence.";
                }, {
                    readonly name: "totalApurado";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Total apurado do turno — soma da receita registrada conforme a regra shiftClosingRecordsRevenue.";
                }, {
                    readonly name: "paidOrderCount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Quantidade de pedidos pagos consolidados no período do turno conforme a regra shiftClosingConsolidatesPaidOrders.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Data e hora de criação do relatório.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Data e hora da última atualização do relatório.";
                }];
                readonly ports: readonly ["ShiftClosingReport", "Shift"];
                readonly rulesApplied: readonly ["shiftClosingRecordsRevenue", "shiftClosingConsolidatesPaidOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load the Shift aggregate via Shift port using shiftId to verify the shift exists and its status is 'closed' — a closing report is only available for a closed shift.", "2. If the Shift is not found, return a validation error indicating the shift does not exist.", "3. If the Shift status is not 'closed', return a validation error indicating the closing report is only available for closed shifts (rule: shiftClosingRecordsRevenue requires a finalized shift).", "4. Load the ShiftClosingReport aggregate via ShiftClosingReport port using shiftId as the key field (getById pattern).", "5. If no ShiftClosingReport is found for the given shiftId, return an empty/not-found result.", "6. Verify the returned report's totalApurado reflects the revenue recorded for the shift (rule: shiftClosingRecordsRevenue) and paidOrderCount consolidates only paid orders (rule: shiftClosingConsolidatesPaidOrders) — these invariants were enforced at report creation; on read, validate that totalApurado >= 0 and paidOrderCount >= 0, returning a data-integrity error otherwise.", "7. Return the ShiftClosingReport fields: shiftClosingReportId, shiftId, totalApurado, paidOrderCount, createdAt, updatedAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewShiftClosingReportUsecase;
    export const pipeline: readonly [{
        readonly id: "viewShiftClosingReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.d.ts", "_102045_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts", "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.defs" {
    export const menuItemIngredientDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "MenuItemIngredient";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItemIngredient";
            readonly fields: readonly [{
                readonly fieldId: "menuItemIngredientId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do vínculo entre item de cardápio e ingrediente de estoque.";
            }, {
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de cardápio ao qual este ingrediente está vinculado.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de estoque master consumido quando o item de cardápio é pedido.";
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade do ingrediente consumida a cada pedido do item de cardápio.";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida da quantidade consumida do ingrediente.";
                readonly enum: readonly ["kg", "gram", "liter", "milliliter", "portion", "unit"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do vínculo de ingrediente.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do vínculo de ingrediente.";
            }];
            readonly statusEnum: readonly [];
            readonly valueObjects: readonly [];
            readonly invariants: readonly ["quantity deve ser maior que zero", "A unidade do vínculo deve ser compatível com a unidade do item de estoque referenciado", "Não pode haver mais de um vínculo entre o mesmo menuItemId e stockItemId"];
        };
    };
    export default menuItemIngredientDomainEntity;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredient__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Turno aberto no momento do lançamento do pedido";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido no fluxo de acompanhamento";
                readonly enum: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
            }, {
                readonly fieldId: "orderType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do pedido: consumo na mesa ou para viagem";
                readonly enum: readonly ["table", "takeout"];
            }, {
                readonly fieldId: "tableNumber";
                readonly type: "string";
                readonly required: false;
                readonly description: "Número da mesa quando o pedido é do tipo mesa";
            }, {
                readonly fieldId: "priority";
                readonly type: "boolean";
                readonly required: false;
                readonly description: "Indica se o pedido recebeu priorização no preparo fora da ordem de chegada";
            }, {
                readonly fieldId: "priorityReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Justificativa para a priorização do pedido fora da ordem de chegada";
            }, {
                readonly fieldId: "receivedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o pedido foi recebido pela cozinha";
            }, {
                readonly fieldId: "inPreparationAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o cozinheiro iniciou o preparo do pedido";
            }, {
                readonly fieldId: "readyAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o pedido foi marcado como pronto pela cozinha";
            }, {
                readonly fieldId: "deliveredAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o pedido foi entregue ao cliente";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Momento de criação do registro do pedido";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Momento da última atualização do registro do pedido";
            }];
            readonly statusEnum: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
            readonly invariants: readonly ["tableNumber is required when orderType is 'table'", "tableNumber must be null when orderType is 'takeout'", "priorityReason is required when priority is true", "Status transitions must follow the sequence: registered → received → inPreparation → ready → delivered", "receivedAt must be set when status transitions to 'received'", "inPreparationAt must be set when status transitions to 'inPreparation'", "readyAt must be set when status transitions to 'ready'", "deliveredAt must be set when status transitions to 'delivered'", "Order must belong to a shift whose status is 'open'", "Order must contain at least one OrderItem", "Timestamps must be chronologically ordered: receivedAt ≤ inPreparationAt ≤ readyAt ≤ deliveredAt"];
            readonly valueObjects: readonly [{
                readonly name: "OrderItem";
                readonly fields: readonly [{
                    readonly fieldId: "orderItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da linha do pedido.";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido ao qual esta linha pertence.";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio cadastrado que foi solicitado.";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade solicitada do item do cardápio nesta linha do pedido.";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do item no momento do lançamento do pedido, snapshot para fins de fechamento.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora em que a linha do pedido foi criada.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização da linha do pedido.";
                }];
                readonly collection: true;
            }];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.defs" {
    export const shiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Shift";
            readonly fields: readonly [{
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do turno";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de abertura do turno pelo gerente";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora de fechamento do turno";
            }, {
                readonly fieldId: "openedBy";
                readonly type: "string";
                readonly required: true;
                readonly description: "Identificador do gerente que abriu o turno";
            }, {
                readonly fieldId: "closedBy";
                readonly type: "string";
                readonly required: false;
                readonly description: "Identificador do gerente que fechou o turno";
            }, {
                readonly fieldId: "totalApurado";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor total apurado no fechamento do turno para conferência, sem conciliação bancária";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações gerais sobre o turno";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly invariants: readonly ["closedAt is required when status is 'closed'", "closedBy is required when status is 'closed'", "closedAt must be after openedAt", "A closed shift cannot be reopened", "totalApurado is required when status is 'closed'", "Only one shift may be open at a time"];
            readonly valueObjects: readonly [];
        };
    };
    export default shiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/shift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.defs" {
    export const shiftClosingReportDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "ShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftClosingReport";
            readonly fields: readonly [{
                readonly fieldId: "shiftClosingReportId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do relatório de fechamento de turno.";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao turno fechado ao qual este relatório corresponde.";
            }, {
                readonly fieldId: "totalApurado";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total apurado no fechamento do turno para conferência do gerente.";
            }, {
                readonly fieldId: "paidOrderCount";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade de pedidos pagos consolidados no período do turno.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que o relatório de fechamento foi gerado.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do relatório de fechamento.";
            }];
            readonly invariants: readonly ["Referenced shift must have status 'closed' before generating the report", "totalApurado must be >= 0", "paidOrderCount must be >= 0", "Only one ShiftClosingReport per shift"];
            readonly valueObjects: readonly [];
        };
    };
    export default shiftClosingReportDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReport__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.defs" {
    export const stockAdjustmentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockAdjustment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockAdjustment";
            readonly fields: readonly [{
                readonly fieldId: "stockAdjustmentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do ajuste de estoque.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Item de estoque ao qual o ajuste se aplica.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação do ajuste: lançado ou anulado.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade ajustada, positiva para reposição e negativa para correção ou baixa.";
            }, {
                readonly fieldId: "reason";
                readonly type: "text";
                readonly required: true;
                readonly description: "Motivo do ajuste informado pelo gerente ao registrar a reposição ou correção.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o ajuste foi anulado.";
            }, {
                readonly fieldId: "voidedReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo da anulação do ajuste de estoque.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro do ajuste.";
            }];
            readonly statusEnum: readonly ["posted", "voided"];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default stockAdjustmentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockAdjustment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.defs" {
    export const stockConsumptionDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockConsumption";
            readonly fields: readonly [{
                readonly fieldId: "stockConsumptionId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do consumo de estoque.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Item de estoque cuja quantidade foi decrementada por este consumo.";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Pedido que disparou este consumo de estoque no momento do lançamento.";
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade do item de estoque consumida e decrementada neste lançamento.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação do consumo: lançado ou estornado.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora do registro do consumo de estoque.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o consumo foi estornado, quando aplicável.";
            }, {
                readonly fieldId: "voidReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do estorno do consumo de estoque.";
            }];
            readonly statusEnum: readonly ["posted", "voided"];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default stockConsumptionDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockConsumption__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs" {
    export const stockLevelDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly fields: readonly [{
                readonly fieldId: "stockLevelId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do nível de estoque";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de estoque master ao qual este nível pertence";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual disponível em estoque, decrementada por consumos e ajustada por reposições";
            }, {
                readonly fieldId: "minimumLevel";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida do estoque do ingrediente";
                readonly enum: readonly ["kg", "liter", "portion", "unit"];
            }, {
                readonly fieldId: "lastDecrementAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do último decremento de estoque por lançamento de pedido";
            }, {
                readonly fieldId: "lastAdjustmentAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do último ajuste manual de reposição de estoque";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro de nível de estoque";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do nível de estoque";
            }];
            readonly invariants: readonly ["currentQuantity must be >= 0", "minimumLevel must be >= 0", "Low-stock alert is triggered when currentQuantity <= minimumLevel", "unit cannot be changed after creation"];
            readonly valueObjects: readonly [];
        };
    };
    export default stockLevelDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockLevel__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.ts";
        readonly defPath: "_102045_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102045_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102045_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.defs" {
    export const definition: ({
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: any[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    } | {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: any[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    })[];
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/contracts/kitchenQueue" {
    export interface CafeFlowViewKitchenBoardInput {
    }
    export interface CafeFlowViewKitchenBoardOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        priority: boolean;
        priorityReason: string;
        receivedAt: string;
        inPreparationAt: string;
        createdAt: string;
    }
    export interface CafeFlowViewKitchenBoardOutput {
        items: CafeFlowViewKitchenBoardOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowUpdateOrderStatusInput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
    }
    export interface CafeFlowUpdateOrderStatusOutput {
    }
}
declare module "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/contracts/managerDashboard.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: any[];
        output: ({
            name: string;
            type: string;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "managerDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102045_/l2/cafeFlow/web/contracts/managerDashboard.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/contracts/managerDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/contracts/managerDashboard" {
    export interface CafeFlowViewDashboardInput {
    }
    export interface CafeFlowViewDashboardOutputItem {
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        createdAt: string;
        shiftId: string;
        deliveredAt: string;
    }
    export type CafeFlowViewDashboardOutput = CafeFlowViewDashboardOutputItem[];
    export interface CafeFlowRequestAiSalesSummaryInput {
    }
    export interface CafeFlowRequestAiSalesSummaryOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        createdAt: string;
        deliveredAt: string;
    }
    export type CafeFlowRequestAiSalesSummaryOutput = CafeFlowRequestAiSalesSummaryOutputItem[];
    export interface CafeFlowRequestAiPromoSuggestionsInput {
    }
    export interface CafeFlowRequestAiPromoSuggestionsOutputItem {
        orderId: string;
        orderType: "table" | "takeout";
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        createdAt: string;
    }
    export type CafeFlowRequestAiPromoSuggestionsOutput = CafeFlowRequestAiPromoSuggestionsOutputItem[];
}
declare module "_102045_/l2/cafeFlow/web/contracts/managerDashboard.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/contracts/menuManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "menuManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102045_/l2/cafeFlow/web/contracts/menuManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/contracts/menuManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/contracts/menuManagement" {
    export interface CafeFlowBrowseMenuItemsInput {
        statusFilter?: "draft" | "active" | "inactive";
        menuCategoryIdFilter?: string;
    }
    export interface CafeFlowBrowseMenuItemsOutputItem {
        menuItemId: string;
        name: string;
        description: string;
        menuCategoryId: string;
        price: number;
        itemType: "simple" | "variant";
        status: "draft" | "active" | "inactive";
        activatedAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface CafeFlowBrowseMenuItemsOutput {
        items: CafeFlowBrowseMenuItemsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowManageMenuItemInput {
        menuItemId: string;
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: "simple" | "variant";
        status: "draft" | "active" | "inactive";
    }
    export interface CafeFlowManageMenuItemOutput {
        menuItemId: string;
        name: string;
        description: string;
        menuCategoryId: string;
        price: number;
        itemType: "simple" | "variant";
        status: "draft" | "active" | "inactive";
        activatedAt: string;
        inactivatedAt: string;
        updatedAt: string;
    }
}
declare module "_102045_/l2/cafeFlow/web/contracts/menuManagement.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/contracts/posWorkspace.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "posWorkspace__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102045_/l2/cafeFlow/web/contracts/posWorkspace.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/contracts/posWorkspace.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/contracts/posWorkspace" {
    export interface CafeFlowCreateOrderInput {
        orderType: "table" | "takeout";
        tableNumber?: string;
        orderItems: string;
        priority?: boolean;
        priorityReason?: string;
    }
    export interface CafeFlowCreateOrderOutput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        createdAt: string;
    }
    export interface CafeFlowViewOrderBoardInput {
    }
    export interface CafeFlowViewOrderBoardOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        priority: boolean;
        priorityReason: string;
        receivedAt: string;
        inPreparationAt: string;
        readyAt: string;
        createdAt: string;
    }
    export interface CafeFlowViewOrderBoardOutput {
        items: CafeFlowViewOrderBoardOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowDeliverOrderInput {
        orderId: string;
    }
    export interface CafeFlowDeliverOrderOutput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        deliveredAt: string;
        updatedAt: string;
    }
}
declare module "_102045_/l2/cafeFlow/web/contracts/posWorkspace.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/contracts/shiftManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102045_/l2/cafeFlow/web/contracts/shiftManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/contracts/shiftManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/contracts/shiftManagement" {
    export interface CafeFlowOpenShiftInput {
        notes?: string;
    }
    export interface CafeFlowOpenShiftOutput {
        shiftId: string;
        status: "open" | "closed";
        openedAt: string;
        openedBy: string;
    }
    export interface CafeFlowCloseShiftInput {
        totalApurado: number;
        notes?: string;
    }
    export interface CafeFlowCloseShiftOutput {
        status: "open" | "closed";
        closedAt: string;
        closedBy: string;
        totalApurado: number;
        notes: string;
    }
    export interface CafeFlowViewShiftClosingReportInput {
        shiftId: string;
    }
    export interface CafeFlowViewShiftClosingReportOutputItem {
        shiftClosingReportId: string;
        shiftId: string;
        totalApurado: number;
        paidOrderCount: number;
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowViewShiftClosingReportOutput = CafeFlowViewShiftClosingReportOutputItem;
}
declare module "_102045_/l2/cafeFlow/web/contracts/shiftManagement.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/contracts/stockManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "stockManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102045_/l2/cafeFlow/web/contracts/stockManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/contracts/stockManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/contracts/stockManagement" {
    export interface CafeFlowBrowseStockItemsInput {
        searchTerm?: string;
    }
    export interface CafeFlowBrowseStockItemsOutputItem {
        stockItemId: string;
        name: string;
        unit: "kg" | "liter" | "portion" | "unit";
        minimumLevel: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface CafeFlowBrowseStockItemsOutput {
        items: CafeFlowBrowseStockItemsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowManageStockItemInput {
        stockItemId: string;
        name: string;
        unit: "kg" | "liter" | "portion" | "unit";
        minimumLevel: number;
    }
    export interface CafeFlowManageStockItemOutput {
        stockItemId: string;
        name: string;
        unit: "kg" | "liter" | "portion" | "unit";
        minimumLevel: number;
        updatedAt: string;
    }
}
declare module "_102045_/l2/cafeFlow/web/contracts/stockManagement.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page11/kitchenQueue.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page11/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/kitchenQueue.defs.ts", "_102045_/l2/cafeFlow/web/shared/kitchenQueue.ts", "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.defs.ts", "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        private errorCounts;
        private errorEventsPushed;
        constructor();
        /**
         * Error-specific push: dedupes repeats (same message/source) bumping a
         * repeatCount instead of flooding, skips browser-extension noise, caps the
         * session volume, and never throws (an error handler must not error).
         */
        private pushError;
        private errorFlushTimer;
        /** Coalesce error bursts: wait 1s before the beacon so repeats dedupe into the queued event. */
        private scheduleErrorFlush;
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102045_/l2/cafeFlow/web/shared/kitchenQueue" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { CafeFlowViewKitchenBoardOutput, CafeFlowUpdateOrderStatusOutput } from "_102045_/l2/cafeFlow/web/contracts/kitchenQueue";
    const message_pt: {
        "page.title": string;
        "section.kitchenBoard.title": string;
        "section.orderTransition.title": string;
        "intention.boardList.title": string;
        "intention.transitionForm.title": string;
        "empty.kitchenBoard": string;
        "empty.transitionPanel": string;
        "field.orderId": string;
        "field.status": string;
        "field.orderType": string;
        "field.tableNumber": string;
        "field.priority": string;
        "field.priorityReason": string;
        "field.receivedAt": string;
        "field.inPreparationAt": string;
        "field.createdAt": string;
        "action.selectOrder": string;
        "action.updateOrderStatus.submit": string;
        "action.updateOrderStatus.success": string;
        "action.updateOrderStatus.error": string;
        "sec.kitchen.board.title": string;
        "org.kitchen.board.title": string;
        "sec.transition.title": string;
        "org.transition.panel.title": string;
        "section.discover.title": string;
        "section.discover.empty": string;
        "section.execute.title": string;
        "section.review.title": string;
        "field.orderId.label": string;
        "field.status.label": string;
        "field.orderType.label": string;
        "field.tableNumber.label": string;
        "field.priority.label": string;
        "field.priorityReason.label": string;
        "field.receivedAt.label": string;
        "field.inPreparationAt.label": string;
        "field.createdAt.label": string;
        "filter.status.label": string;
        "action.viewKitchenBoard.label": string;
        "action.updateOrderStatus.label": string;
        "action.selectOrder.label": string;
        "status.received.label": string;
        "status.inPreparation.label": string;
        "status.ready.label": string;
        "status.delivered.label": string;
        "status.registered.label": string;
        "sec.discover.title": string;
        "sec.execute.title": string;
        "org.update.status.title": string;
        "sec.review.title": string;
        "org.review.title": string;
        "section.queue.title": string;
        "section.queue.empty": string;
        "section.transition.title": string;
        "section.transition.empty": string;
        "column.orderId": string;
        "column.status": string;
        "column.orderType": string;
        "column.tableNumber": string;
        "column.priority": string;
        "column.priorityReason": string;
        "column.receivedAt": string;
        "column.inPreparationAt": string;
        "column.createdAt": string;
        "action.select": string;
        "action.refresh": string;
        "action.updateOrderStatus": string;
        "sec.kitchen.queue.title": string;
        "sec.order.transition.title": string;
        "org.status.transition.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowKitchenQueueBase extends CollabLitElement {
        status: string;
        viewKitchenBoardState: 'idle' | 'loading' | 'success' | 'error';
        viewKitchenBoardData: CafeFlowViewKitchenBoardOutput;
        updateOrderStatusState: 'idle' | 'loading' | 'success' | 'error';
        updateOrderStatusOrderId: string;
        updateOrderStatusStatus: string;
        updateOrderStatusOutput: CafeFlowUpdateOrderStatusOutput | null;
        updateOrderStatusError: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadViewKitchenBoard(): Promise<void>;
        handleViewKitchenBoardClick(_e: Event): void;
        updateOrderStatus(): Promise<void>;
        handleUpdateOrderStatusClick(_e: Event): void;
        setUpdateOrderStatusOrderId(value: string): void;
        handleUpdateOrderStatusOrderIdChange(e: Event): void;
        setUpdateOrderStatusStatus(value: string): void;
        handleUpdateOrderStatusStatusChange(e: Event): void;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/kitchenQueue" {
    import { CafeFlowKitchenQueueBase } from "_102045_/l2/cafeFlow/web/shared/kitchenQueue";
    export class CafeFlowDesktopPage11KitchenQueuePage extends CafeFlowKitchenQueueBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: any[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page11/managerDashboard.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page11/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/managerDashboard.defs.ts", "_102045_/l2/cafeFlow/web/shared/managerDashboard.ts", "_102045_/l2/cafeFlow/web/contracts/managerDashboard.defs.ts", "_102045_/l2/cafeFlow/web/contracts/managerDashboard.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/managerDashboard" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { CafeFlowViewDashboardOutput, CafeFlowRequestAiSalesSummaryOutput, CafeFlowRequestAiPromoSuggestionsOutput } from "_102045_/l2/cafeFlow/web/contracts/managerDashboard";
    const message_pt: {
        "page.title": string;
        "section.dashboard.title": string;
        "section.aiAssistant.title": string;
        "organism.dashboardMetrics.title": string;
        "organism.aiSalesSummary.title": string;
        "organism.aiPromoSuggestions.title": string;
        "column.status": string;
        "column.orderType": string;
        "column.createdAt": string;
        "column.shiftId": string;
        "column.deliveredAt": string;
        "column.orderId": string;
        "action.viewDashboard.label": string;
        "action.requestAiSalesSummary.label": string;
        "action.requestAiPromoSuggestions.label": string;
        "empty.viewDashboard": string;
        "empty.requestAiSalesSummary": string;
        "empty.requestAiPromoSuggestions": string;
        "sec.dashboard.title": string;
        "org.dashboard.metrics.title": string;
        "sec.ai.assistant.title": string;
        "org.ai.sales.summary.title": string;
        "org.ai.promo.suggestions.title": string;
        "section.dashboardList.title": string;
        "section.aiAssistant.empty": string;
        "organism.dashboardOrdersList.title": string;
        "organism.dashboardOrdersList.empty": string;
        "organism.aiSalesSummary.empty": string;
        "organism.aiPromoSuggestions.empty": string;
        "sec.dashboard.list.title": string;
        "org.dashboard.orders.title": string;
        "section.discover.title": string;
        "section.review.title": string;
        "organism.dashboard.title": string;
        "organism.dashboard.empty": string;
        "organism.aiSales.title": string;
        "organism.aiSales.empty": string;
        "organism.aiPromo.title": string;
        "organism.aiPromo.empty": string;
        "organism.review.title": string;
        "organism.review.empty": string;
        "field.status.label": string;
        "field.orderType.label": string;
        "field.createdAt.label": string;
        "field.shiftId.label": string;
        "field.deliveredAt.label": string;
        "field.orderId.label": string;
        "action.viewDashboard.success": string;
        "action.viewDashboard.error": string;
        "action.requestAiSalesSummary.success": string;
        "action.requestAiSalesSummary.error": string;
        "action.requestAiPromoSuggestions.success": string;
        "action.requestAiPromoSuggestions.error": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowManagerDashboardBase extends CollabLitElement {
        status: string;
        viewDashboardState: 'idle' | 'loading' | 'success' | 'error';
        viewDashboardData: CafeFlowViewDashboardOutput;
        requestAiSalesSummaryState: 'idle' | 'loading' | 'success' | 'error';
        requestAiSalesSummaryData: CafeFlowRequestAiSalesSummaryOutput;
        requestAiPromoSuggestionsState: 'idle' | 'loading' | 'success' | 'error';
        requestAiPromoSuggestionsData: CafeFlowRequestAiPromoSuggestionsOutput;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadViewDashboard(): Promise<void>;
        handleViewDashboardClick(_event: Event): void;
        loadRequestAiSalesSummary(): Promise<void>;
        handleRequestAiSalesSummaryClick(_event: Event): void;
        loadRequestAiPromoSuggestions(): Promise<void>;
        handleRequestAiPromoSuggestionsClick(_event: Event): void;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/managerDashboard" {
    import { CafeFlowManagerDashboardBase } from "_102045_/l2/cafeFlow/web/shared/managerDashboard";
    export class CafeFlowDesktopPage11ManagerDashboardPage extends CafeFlowManagerDashboardBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page11/menuManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page11/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/menuManagement.defs.ts", "_102045_/l2/cafeFlow/web/shared/menuManagement.ts", "_102045_/l2/cafeFlow/web/contracts/menuManagement.defs.ts", "_102045_/l2/cafeFlow/web/contracts/menuManagement.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/menuManagement" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { CafeFlowBrowseMenuItemsOutputItem, CafeFlowManageMenuItemOutput } from "_102045_/l2/cafeFlow/web/contracts/menuManagement";
    const message_pt: {
        "page.title": string;
        "section.queue.title": string;
        "section.queue.empty": string;
        "section.manage.title": string;
        "section.review.title": string;
        "section.review.empty": string;
        "filter.statusFilter.label": string;
        "filter.menuCategoryIdFilter.label": string;
        "column.menuItemId.label": string;
        "column.name.label": string;
        "column.description.label": string;
        "column.menuCategoryId.label": string;
        "column.price.label": string;
        "column.itemType.label": string;
        "column.status.label": string;
        "column.activatedAt.label": string;
        "column.inactivatedAt.label": string;
        "column.createdAt.label": string;
        "column.updatedAt.label": string;
        "field.menuItemId.label": string;
        "field.name.label": string;
        "field.description.label": string;
        "field.menuCategoryId.label": string;
        "field.price.label": string;
        "field.itemType.label": string;
        "field.status.label": string;
        "action.refresh.label": string;
        "action.selectItem.label": string;
        "action.manageMenuItem.label": string;
        "action.manageMenuItem.submit": string;
        "action.manageMenuItem.success": string;
        "action.manageMenuItem.error": string;
        "org.menu.item.queue.title": string;
        "org.manage.item.form.title": string;
        "org.review.summary.title": string;
        "page.menuManagement.title": string;
        "section.board.title": string;
        "section.detail.title": string;
        "organism.kanbanBoard.title": string;
        "organism.manageForm.title": string;
        "intention.browse.title": string;
        "intention.manage.title": string;
        "action.browseMenuItems.label": string;
        "action.selectCard.label": string;
        "empty.board": string;
        "empty.detail": string;
        "lane.draft.title": string;
        "lane.active.title": string;
        "lane.inactive.title": string;
        "sec.board.title": string;
        "org.kanban.board.title": string;
        "sec.detail.title": string;
        "org.manage.form.title": string;
        "section.discover.title": string;
        "section.execute.title": string;
        "organism.menuItemsList.title": string;
        "organism.manageItemForm.title": string;
        "organism.actionFeedback.title": string;
        "field.menuItemId": string;
        "field.name": string;
        "field.description": string;
        "field.menuCategoryId": string;
        "field.price": string;
        "field.itemType": string;
        "field.status": string;
        "field.activatedAt": string;
        "field.inactivatedAt": string;
        "field.updatedAt": string;
        "filter.statusFilter": string;
        "filter.menuCategoryIdFilter": string;
        "action.refresh": string;
        "action.newItem": string;
        "action.selectItem": string;
        "empty.menuItems": string;
        "status.draft": string;
        "status.active": string;
        "status.inactive": string;
        "sec.discover.title": string;
        "org.menuItemsCardList.title": string;
        "sec.execute.title": string;
        "org.manageItemForm.title": string;
        "sec.review.title": string;
        "org.actionFeedback.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowMenuManagementBase extends CollabLitElement {
        status: string;
        browseMenuItemsState: "idle" | "loading" | "success" | "error";
        browseMenuItemsStatusFilter: string;
        browseMenuItemsMenuCategoryIdFilter: string;
        browseMenuItemsData: {
            items: CafeFlowBrowseMenuItemsOutputItem[];
            total: number;
        };
        manageMenuItemState: "idle" | "loading" | "success" | "error";
        manageMenuItemMenuItemId: string;
        manageMenuItemName: string;
        manageMenuItemDescription: string;
        manageMenuItemMenuCategoryId: string;
        manageMenuItemPrice: string;
        manageMenuItemItemType: string;
        manageMenuItemStatus: string;
        manageMenuItemOutput: CafeFlowManageMenuItemOutput | null;
        manageMenuItemError: string;
        activeCompanyId: string;
        private subscribedKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        loadBrowseMenuItems(): Promise<void>;
        handleBrowseMenuItemsClick(_e: Event): void;
        manageMenuItem(): Promise<void>;
        handleManageMenuItemClick(_e: Event): void;
        setBrowseMenuItemsStatusFilter(value: string): void;
        handleBrowseMenuItemsStatusFilterChange(e: Event): void;
        setBrowseMenuItemsMenuCategoryIdFilter(value: string): void;
        handleBrowseMenuItemsMenuCategoryIdFilterChange(e: Event): void;
        setManageMenuItemMenuItemId(value: string): void;
        handleManageMenuItemMenuItemIdChange(e: Event): void;
        setManageMenuItemName(value: string): void;
        handleManageMenuItemNameChange(e: Event): void;
        setManageMenuItemDescription(value: string): void;
        handleManageMenuItemDescriptionChange(e: Event): void;
        setManageMenuItemMenuCategoryId(value: string): void;
        handleManageMenuItemMenuCategoryIdChange(e: Event): void;
        setManageMenuItemPrice(value: string): void;
        handleManageMenuItemPriceChange(e: Event): void;
        setManageMenuItemItemType(value: string): void;
        handleManageMenuItemItemTypeChange(e: Event): void;
        setManageMenuItemStatus(value: string): void;
        handleManageMenuItemStatusChange(e: Event): void;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/menuManagement" {
    import { CafeFlowMenuManagementBase } from "_102045_/l2/cafeFlow/web/shared/menuManagement";
    export class CafeFlowDesktopPage11MenuManagementPage extends CafeFlowMenuManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page11/posWorkspace.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page11/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/posWorkspace.defs.ts", "_102045_/l2/cafeFlow/web/shared/posWorkspace.ts", "_102045_/l2/cafeFlow/web/contracts/posWorkspace.defs.ts", "_102045_/l2/cafeFlow/web/contracts/posWorkspace.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/posWorkspace" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { CafeFlowCreateOrderOutput, CafeFlowViewOrderBoardOutput, CafeFlowDeliverOrderOutput } from "_102045_/l2/cafeFlow/web/contracts/posWorkspace";
    const message_pt: {
        "section.orderBoard.title": string;
        "section.createOrder.title": string;
        "section.deliverOrder.title": string;
        "organism.orderBoardCards.title": string;
        "organism.createOrderForm.title": string;
        "organism.deliverOrderSheet.title": string;
        "intention.orderBoard.list.title": string;
        "intention.createOrder.form.title": string;
        "intention.deliverOrder.form.title": string;
        "column.orderId": string;
        "column.status": string;
        "column.orderType": string;
        "column.tableNumber": string;
        "column.priority": string;
        "column.createdAt": string;
        "filter.status": string;
        "filter.orderType": string;
        "field.orderType": string;
        "field.tableNumber": string;
        "field.orderItems": string;
        "field.priority": string;
        "field.priorityReason": string;
        "field.orderId": string;
        "action.viewOrderBoard.label": string;
        "action.selectForDelivery": string;
        "action.createOrder.submit": string;
        "action.deliverOrder.submit": string;
        "action.createOrder.success": string;
        "action.createOrder.error": string;
        "action.deliverOrder.success": string;
        "action.deliverOrder.error": string;
        "empty.orderBoard": string;
        "empty.deliverOrder": string;
        "page.posWorkspace.title": string;
        "section.board.title": string;
        "section.review.title": string;
        "intention.board.title": string;
        "intention.createOrder.title": string;
        "intention.deliverOrder.title": string;
        "intention.review.title": string;
        "field.orderType.label": string;
        "field.tableNumber.label": string;
        "field.orderItems.label": string;
        "field.priority.label": string;
        "field.priorityReason.label": string;
        "field.orderId.label": string;
        "field.status.label": string;
        "field.receivedAt.label": string;
        "field.inPreparationAt.label": string;
        "field.readyAt.label": string;
        "field.createdAt.label": string;
        "action.createOrder.label": string;
        "action.deliverOrder.label": string;
        "action.selectOrder.label": string;
        "empty.board": string;
        "empty.createOrder": string;
        "empty.review": string;
        "lane.registered": string;
        "lane.received": string;
        "lane.inPreparation": string;
        "lane.ready": string;
        "lane.delivered": string;
        "sec.board.title": string;
        "org.orderKanbanBoard.title": string;
        "sec.createOrder.title": string;
        "org.createOrderForm.title": string;
        "sec.deliverOrder.title": string;
        "org.deliverOrderPanel.title": string;
        "sec.review.title": string;
        "org.reviewSummary.title": string;
        "section.queue.title": string;
        "section.queue.deliverTitle": string;
        "column.priorityReason": string;
        "column.receivedAt": string;
        "column.inPreparationAt": string;
        "column.readyAt": string;
        "column.deliveredAt": string;
        "column.updatedAt": string;
        "action.refresh.label": string;
        "action.confirmDeliver.label": string;
        "empty.queue": string;
        "queueSection.title": string;
        "orderBoard.title": string;
        "createOrderSection.title": string;
        "createOrderForm.title": string;
        "reviewSection.title": string;
        "actionSummary.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowPosWorkspaceBase extends CollabLitElement {
        status: string;
        createOrderState: 'idle' | 'loading' | 'success' | 'error';
        createOrderOrderType: string;
        createOrderTableNumber: string;
        createOrderOrderItems: string;
        createOrderPriority: string;
        createOrderPriorityReason: string;
        createOrderOutput: CafeFlowCreateOrderOutput | null;
        createOrderError: string;
        viewOrderBoardState: 'idle' | 'loading' | 'success' | 'error';
        viewOrderBoardData: CafeFlowViewOrderBoardOutput;
        deliverOrderState: 'idle' | 'loading' | 'success' | 'error';
        deliverOrderOrderId: string;
        deliverOrderOutput: CafeFlowDeliverOrderOutput | null;
        deliverOrderError: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadViewOrderBoard(): Promise<void>;
        handleViewOrderBoardClick(): void;
        createOrder(signal?: AbortSignal): Promise<void>;
        handleCreateOrderClick(): void;
        deliverOrder(signal?: AbortSignal): Promise<void>;
        handleDeliverOrderClick(): void;
        setCreateOrderOrderType(value: string): void;
        handleCreateOrderOrderTypeChange(e: Event): void;
        setCreateOrderTableNumber(value: string): void;
        handleCreateOrderTableNumberChange(e: Event): void;
        setCreateOrderOrderItems(value: string): void;
        handleCreateOrderOrderItemsChange(e: Event): void;
        setCreateOrderPriority(value: string): void;
        handleCreateOrderPriorityChange(e: Event): void;
        setCreateOrderPriorityReason(value: string): void;
        handleCreateOrderPriorityReasonChange(e: Event): void;
        setDeliverOrderOrderId(value: string): void;
        handleDeliverOrderOrderIdChange(e: Event): void;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/posWorkspace" {
    import { CafeFlowPosWorkspaceBase } from "_102045_/l2/cafeFlow/web/shared/posWorkspace";
    export class CafeFlowDesktopPage11PosWorkspacePage extends CafeFlowPosWorkspaceBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        }[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page11/shiftManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page11/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/shiftManagement.defs.ts", "_102045_/l2/cafeFlow/web/shared/shiftManagement.ts", "_102045_/l2/cafeFlow/web/contracts/shiftManagement.defs.ts", "_102045_/l2/cafeFlow/web/contracts/shiftManagement.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/shiftManagement" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { CafeFlowOpenShiftOutput, CafeFlowCloseShiftOutput, CafeFlowViewShiftClosingReportOutput } from "_102045_/l2/cafeFlow/web/contracts/shiftManagement";
    const message_pt: {
        "page.title": string;
        "section.discover.title": string;
        "section.openShift.title": string;
        "section.closeShift.title": string;
        "section.review.title": string;
        "field.notes.label": string;
        "field.totalApurado.label": string;
        "field.shiftId.label": string;
        "field.shiftClosingReportId.label": string;
        "field.paidOrderCount.label": string;
        "field.createdAt.label": string;
        "field.updatedAt.label": string;
        "field.status.label": string;
        "field.openedAt.label": string;
        "field.openedBy.label": string;
        "field.closedAt.label": string;
        "field.closedBy.label": string;
        "action.openShift.label": string;
        "action.closeShift.label": string;
        "action.openShift.success": string;
        "action.openShift.error": string;
        "action.closeShift.success": string;
        "action.closeShift.error": string;
        "empty.reports": string;
        "sec.discover.title": string;
        "org.report.cards.title": string;
        "sec.open.shift.title": string;
        "org.open.shift.title": string;
        "sec.close.shift.title": string;
        "org.close.shift.title": string;
        "sec.review.title": string;
        "org.shift.summary.title": string;
        "section.board.title": string;
        "lane.open.title": string;
        "lane.open.empty": string;
        "lane.closed.title": string;
        "lane.closed.empty": string;
        "intent.query.report.title": string;
        "intent.openShift.title": string;
        "intent.closeShift.title": string;
        "intent.report.summary.title": string;
        "empty.report": string;
        "action.viewShiftClosingReport.label": string;
        "org.shift.board.title": string;
        "org.open.shift.form.title": string;
        "org.close.shift.form.title": string;
        "org.report.summary.title": string;
        "page.shiftManagement.title": string;
        "section.execute.title": string;
        "organism.report.title": string;
        "organism.shiftLifecycle.title": string;
        "organism.openShift.title": string;
        "organism.closeShift.title": string;
        "organism.summary.title": string;
        "empty.openShift": string;
        "empty.closeShift": string;
        "empty.summary": string;
        "org.shift.report.title": string;
        "sec.execute.title": string;
        "org.shift.lifecycle.title": string;
        "org.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowShiftManagementBase extends CollabLitElement {
        status: string;
        openShiftState: 'idle' | 'loading' | 'success' | 'error';
        openShiftNotes: string;
        openShiftOutput: CafeFlowOpenShiftOutput | null;
        openShiftError: string;
        closeShiftState: 'idle' | 'loading' | 'success' | 'error';
        closeShiftTotalApurado: string;
        closeShiftNotes: string;
        closeShiftOutput: CafeFlowCloseShiftOutput | null;
        closeShiftError: string;
        viewShiftClosingReportState: 'idle' | 'loading' | 'success' | 'error';
        viewShiftClosingReportShiftId: string;
        viewShiftClosingReportData: CafeFlowViewShiftClosingReportOutput | null;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseRouteParams;
        setOpenShiftNotes(value: string): void;
        handleOpenShiftNotesChange(e: Event): void;
        setCloseShiftTotalApurado(value: string): void;
        handleCloseShiftTotalApuradoChange(e: Event): void;
        setCloseShiftNotes(value: string): void;
        handleCloseShiftNotesChange(e: Event): void;
        setViewShiftClosingReportShiftId(value: string): void;
        handleViewShiftClosingReportShiftIdChange(e: Event): void;
        loadViewShiftClosingReport(): Promise<void>;
        handleViewShiftClosingReportClick(e: Event): void;
        openShift(): Promise<void>;
        handleOpenShiftClick(e: Event): void;
        closeShift(): Promise<void>;
        handleCloseShiftClick(e: Event): void;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/shiftManagement" {
    import { CafeFlowShiftManagementBase } from "_102045_/l2/cafeFlow/web/shared/shiftManagement";
    export class CafeFlowDesktopPage11ShiftManagementPage extends CafeFlowShiftManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page11/stockManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page11/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/stockManagement.defs.ts", "_102045_/l2/cafeFlow/web/shared/stockManagement.ts", "_102045_/l2/cafeFlow/web/contracts/stockManagement.defs.ts", "_102045_/l2/cafeFlow/web/contracts/stockManagement.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/stockManagement" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { CafeFlowBrowseStockItemsOutput, CafeFlowManageStockItemOutput } from "_102045_/l2/cafeFlow/web/contracts/stockManagement";
    const message_pt: {
        "page.stockManagement.title": string;
        "section.stockItems.title": string;
        "section.stockItems.description": string;
        "section.manageStockItem.title": string;
        "section.manageStockItem.description": string;
        "column.stockItemId.label": string;
        "column.name.label": string;
        "column.unit.label": string;
        "column.minimumLevel.label": string;
        "column.createdAt.label": string;
        "column.updatedAt.label": string;
        "field.stockItemId.label": string;
        "field.name.label": string;
        "field.unit.label": string;
        "field.minimumLevel.label": string;
        "filter.searchTerm.label": string;
        "action.browseStockItems.label": string;
        "action.select.label": string;
        "action.manageStockItem.label": string;
        "action.manageStockItem.success": string;
        "action.manageStockItem.error": string;
        "empty.browseStockItems": string;
        "empty.manageStockItem": string;
        "sec.stock.items.title": string;
        "org.stock.items.table.title": string;
        "sec.manage.stock.item.title": string;
        "org.stock.item.form.title": string;
        "section.stockQueue.title": string;
        "section.review.title": string;
        "field.createdAt.label": string;
        "field.updatedAt.label": string;
        "field.searchTerm.label": string;
        "action.selectItem.label": string;
        "action.refresh.label": string;
        "empty.stockQueue": string;
        "org.stockQueueTable.title": string;
        "org.manageStockItemForm.title": string;
        "org.reviewSummary.title": string;
        "page.title": string;
        "section.stockItemsList.title": string;
        "section.stockItemDetailPanel.title": string;
        "section.reviewSummary.title": string;
        "organism.stockItemsBrowser.title": string;
        "organism.stockItemManager.title": string;
        "organism.actionSummary.title": string;
        "intention.queryStockItems.title": string;
        "intention.manageStockItem.title": string;
        "intention.summary.title": string;
        "toolbar.refresh.label": string;
        "rowAction.selectItem.label": string;
        "empty.stockItems": string;
        "empty.noItemSelected": string;
        "empty.noActionsYet": string;
        "org.stockItemsBrowser.title": string;
        "org.stockItemManager.title": string;
        "org.actionSummary.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowStockManagementBase extends CollabLitElement {
        status: string;
        browseStockItemsState: "idle" | "loading" | "success" | "error";
        browseStockItemsSearchTerm: string;
        browseStockItemsData: CafeFlowBrowseStockItemsOutput;
        manageStockItemState: "idle" | "loading" | "success" | "error";
        manageStockItemStockItemId: string;
        manageStockItemName: string;
        manageStockItemUnit: string;
        manageStockItemMinimumLevel: string;
        manageStockItemOutput: CafeFlowManageStockItemOutput | null;
        manageStockItemError: string;
        protected get msg(): MessageType;
        private parseRouteParams;
        loadBrowseStockItems(): Promise<void>;
        handleBrowseStockItemsClick(_event: Event): void;
        manageStockItem(): Promise<void>;
        handleManageStockItemClick(_event: Event): void;
        setBrowseStockItemsSearchTerm(value: string): void;
        handleBrowseStockItemsSearchTermChange(event: Event): void;
        setManageStockItemStockItemId(value: string): void;
        handleManageStockItemStockItemIdChange(event: Event): void;
        setManageStockItemName(value: string): void;
        handleManageStockItemNameChange(event: Event): void;
        setManageStockItemUnit(value: string): void;
        handleManageStockItemUnitChange(event: Event): void;
        setManageStockItemMinimumLevel(value: string): void;
        handleManageStockItemMinimumLevelChange(event: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page11/stockManagement" {
    import { CafeFlowStockManagementBase } from "_102045_/l2/cafeFlow/web/shared/stockManagement";
    export class CafeFlowDesktopPage11StockManagementPage extends CafeFlowStockManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page21/kitchenQueue.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page21/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/kitchenQueue.defs.ts", "_102045_/l2/cafeFlow/web/shared/kitchenQueue.ts", "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.defs.ts", "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/kitchenQueue" {
    import { CafeFlowKitchenQueueBase } from "_102045_/l2/cafeFlow/web/shared/kitchenQueue";
    export class CafeFlowDesktopPage21KitchenQueuePage extends CafeFlowKitchenQueueBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: any[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page21/managerDashboard.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page21/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/managerDashboard.defs.ts", "_102045_/l2/cafeFlow/web/shared/managerDashboard.ts", "_102045_/l2/cafeFlow/web/contracts/managerDashboard.defs.ts", "_102045_/l2/cafeFlow/web/contracts/managerDashboard.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/managerDashboard" {
    import { CafeFlowManagerDashboardBase } from "_102045_/l2/cafeFlow/web/shared/managerDashboard";
    export class CafeFlowDesktopPage21ManagerDashboardPage extends CafeFlowManagerDashboardBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page21/menuManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page21/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/menuManagement.defs.ts", "_102045_/l2/cafeFlow/web/shared/menuManagement.ts", "_102045_/l2/cafeFlow/web/contracts/menuManagement.defs.ts", "_102045_/l2/cafeFlow/web/contracts/menuManagement.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/menuManagement" {
    import { CafeFlowMenuManagementBase } from "_102045_/l2/cafeFlow/web/shared/menuManagement";
    export class CafeFlowDesktopPage21MenuManagementPage extends CafeFlowMenuManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page21/posWorkspace.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page21/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/posWorkspace.defs.ts", "_102045_/l2/cafeFlow/web/shared/posWorkspace.ts", "_102045_/l2/cafeFlow/web/contracts/posWorkspace.defs.ts", "_102045_/l2/cafeFlow/web/contracts/posWorkspace.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/posWorkspace" {
    import { CafeFlowPosWorkspaceBase } from "_102045_/l2/cafeFlow/web/shared/posWorkspace";
    export class CafeFlowDesktopPage21PosWorkspacePage extends CafeFlowPosWorkspaceBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        emptyKey?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page21/shiftManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page21/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/shiftManagement.defs.ts", "_102045_/l2/cafeFlow/web/shared/shiftManagement.ts", "_102045_/l2/cafeFlow/web/contracts/shiftManagement.defs.ts", "_102045_/l2/cafeFlow/web/contracts/shiftManagement.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/shiftManagement" {
    import { CafeFlowShiftManagementBase } from "_102045_/l2/cafeFlow/web/shared/shiftManagement";
    export class CafeFlowDesktopPage21ShiftManagementPage extends CafeFlowShiftManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page21/stockManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page21/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/stockManagement.defs.ts", "_102045_/l2/cafeFlow/web/shared/stockManagement.ts", "_102045_/l2/cafeFlow/web/contracts/stockManagement.defs.ts", "_102045_/l2/cafeFlow/web/contracts/stockManagement.ts", "_102045_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page21/stockManagement" {
    import { CafeFlowStockManagementBase } from "_102045_/l2/cafeFlow/web/shared/stockManagement";
    export class CafeFlowDesktopPage21StockManagementPage extends CafeFlowStockManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page31/kitchenQueue.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page31/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/kitchenQueue.defs.ts", "_102045_/l2/cafeFlow/web/shared/kitchenQueue.ts", "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.defs.ts", "_102045_/l2/cafeFlow/web/contracts/kitchenQueue.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/aura/agentImplementGenome/skills/genCfePageGenome2.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/kitchenQueue" {
    import { CafeFlowKitchenQueueBase } from "_102045_/l2/cafeFlow/web/shared/kitchenQueue";
    export class CafeFlowDesktopPage31KitchenQueuePage extends CafeFlowKitchenQueueBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: any[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: any[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page31/managerDashboard.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page31/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/managerDashboard.defs.ts", "_102045_/l2/cafeFlow/web/shared/managerDashboard.ts", "_102045_/l2/cafeFlow/web/contracts/managerDashboard.defs.ts", "_102045_/l2/cafeFlow/web/contracts/managerDashboard.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/aura/agentImplementGenome/skills/genCfePageGenome2.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/managerDashboard" {
    import { CafeFlowManagerDashboardBase } from "_102045_/l2/cafeFlow/web/shared/managerDashboard";
    export class CafeFlowDesktopPage31ManagerDashboardPage extends CafeFlowManagerDashboardBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page31/menuManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page31/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/menuManagement.defs.ts", "_102045_/l2/cafeFlow/web/shared/menuManagement.ts", "_102045_/l2/cafeFlow/web/contracts/menuManagement.defs.ts", "_102045_/l2/cafeFlow/web/contracts/menuManagement.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/aura/agentImplementGenome/skills/genCfePageGenome2.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/menuManagement" {
    import { CafeFlowMenuManagementBase } from "_102045_/l2/cafeFlow/web/shared/menuManagement";
    export class CafeFlowDesktopPage31MenuManagementPage extends CafeFlowMenuManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page31/posWorkspace.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page31/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/posWorkspace.defs.ts", "_102045_/l2/cafeFlow/web/shared/posWorkspace.ts", "_102045_/l2/cafeFlow/web/contracts/posWorkspace.defs.ts", "_102045_/l2/cafeFlow/web/contracts/posWorkspace.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_shared"];
        readonly skills: readonly ["_102020_/l2/aura/agentImplementGenome/skills/genCfePageGenome2.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/posWorkspace" {
    import { CafeFlowPosWorkspaceBase } from "_102045_/l2/cafeFlow/web/shared/posWorkspace";
    export class CafeFlowDesktopPage31PosWorkspacePage extends CafeFlowPosWorkspaceBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page31/shiftManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page31/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/shiftManagement.defs.ts", "_102045_/l2/cafeFlow/web/shared/shiftManagement.ts", "_102045_/l2/cafeFlow/web/contracts/shiftManagement.defs.ts", "_102045_/l2/cafeFlow/web/contracts/shiftManagement.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/aura/agentImplementGenome/skills/genCfePageGenome2.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/shiftManagement" {
    import { CafeFlowShiftManagementBase } from "_102045_/l2/cafeFlow/web/shared/shiftManagement";
    export class CafeFlowDesktopPage31ShiftManagementPage extends CafeFlowShiftManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: any[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102045_/l2/cafeFlow/web/desktop/page31/stockManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/desktop/page31/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/shared/stockManagement.defs.ts", "_102045_/l2/cafeFlow/web/shared/stockManagement.ts", "_102045_/l2/cafeFlow/web/contracts/stockManagement.defs.ts", "_102045_/l2/cafeFlow/web/contracts/stockManagement.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/aura/agentImplementGenome/skills/genCfePageGenome2.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/desktop/page31/stockManagement" {
    import { CafeFlowStockManagementBase } from "_102045_/l2/cafeFlow/web/shared/stockManagement";
    export class CafeFlowDesktopPage31StockManagementPage extends CafeFlowStockManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102045_/l2/cafeFlow/web/shared/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.kitchenQueue.title": string;
            "section.kitchenBoard.title": string;
            "section.kitchenBoard.empty": string;
            "section.transitionPanel.title": string;
            "section.transitionPanel.empty": string;
            "column.orderId.label": string;
            "column.status.label": string;
            "column.orderType.label": string;
            "column.tableNumber.label": string;
            "column.priority.label": string;
            "column.priorityReason.label": string;
            "column.receivedAt.label": string;
            "column.inPreparationAt.label": string;
            "column.createdAt.label": string;
            "field.orderId.label": string;
            "field.status.label": string;
            "action.viewKitchenBoard.label": string;
            "action.updateOrderStatus.label": string;
            "action.selectOrder.label": string;
            "action.set.updateOrderStatusOrderId.label": string;
            "action.set.updateOrderStatusStatus.label": string;
            "action.updateOrderStatus.success": string;
            "action.updateOrderStatus.error": string;
            "transition.startPreparation.label": string;
            "transition.markReady.label": string;
            "lane.received.title": string;
            "lane.inPreparation.title": string;
            "lane.ready.title": string;
            "lane.received.empty": string;
            "lane.inPreparation.empty": string;
            "lane.ready.empty": string;
            "org.kitchen.board.title": string;
            "org.transition.panel.title": string;
            "section.kitchenQueue.title": string;
            "organism.kitchenBoard.title": string;
            "intention.viewKitchenBoard.title": string;
            "rowAction.startPreparation.label": string;
            "rowAction.markReady.label": string;
            "toolbar.refresh.label": string;
            "empty.kitchenQueue": string;
            "kitchen.queue.section.title": string;
            "kitchen.board.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102045_/l2/cafeFlow/web/shared/kitchenQueue.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/shared/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/contracts/kitchenQueue.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/kitchenQueue.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/shared/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
        }[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.dashboardOverview.title": string;
            "section.dashboardOverview.empty": string;
            "section.aiSalesSummary.title": string;
            "section.aiSalesSummary.empty": string;
            "section.aiPromoSuggestions.title": string;
            "section.aiPromoSuggestions.empty": string;
            "column.status.label": string;
            "column.orderType.label": string;
            "column.createdAt.label": string;
            "column.shiftId.label": string;
            "column.deliveredAt.label": string;
            "column.orderId.label": string;
            "action.viewDashboard.label": string;
            "action.requestAiSalesSummary.label": string;
            "action.requestAiPromoSuggestions.label": string;
            "organism.dashboardMetrics.title": string;
            "organism.aiSalesSummary.title": string;
            "organism.aiPromoSuggestions.title": string;
            "sec.dashboard.overview.title": string;
            "org.dashboard.metrics.title": string;
            "sec.ai.sales.summary.title": string;
            "org.ai.sales.summary.title": string;
            "sec.ai.promo.suggestions.title": string;
            "org.ai.promo.suggestions.title": string;
            "page.title": string;
            "section.dashboard.title": string;
            "section.aiAssistant.title": string;
            "organism.dashboardSummary.title": string;
            "organism.dashboardSummary.empty": string;
            "organism.aiSalesSummary.empty": string;
            "organism.aiPromoSuggestions.empty": string;
            "column.status": string;
            "column.orderType": string;
            "column.createdAt": string;
            "column.shiftId": string;
            "column.deliveredAt": string;
            "column.orderId": string;
            "action.viewDashboard.success": string;
            "action.viewDashboard.error": string;
            "action.requestAiSalesSummary.success": string;
            "action.requestAiSalesSummary.error": string;
            "action.requestAiPromoSuggestions.success": string;
            "action.requestAiPromoSuggestions.error": string;
            "sec.dashboard.title": string;
            "org.dashboard.summary.title": string;
            "sec.ai.assistant.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102045_/l2/cafeFlow/web/shared/managerDashboard.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/shared/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/contracts/managerDashboard.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/managerDashboard.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/shared/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            targetRef: string;
            required: boolean;
            selector: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.discover.title": string;
            "section.execute.title": string;
            "section.review.title": string;
            "organism.queue.title": string;
            "organism.form.title": string;
            "organism.summary.title": string;
            "intention.queryList.title": string;
            "intention.commandForm.title": string;
            "intention.summary.title": string;
            "field.menuItemId.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.menuCategoryId.label": string;
            "field.price.label": string;
            "field.itemType.label": string;
            "field.status.label": string;
            "field.activatedAt.label": string;
            "field.createdAt.label": string;
            "field.updatedAt.label": string;
            "field.statusFilter.label": string;
            "field.menuCategoryIdFilter.label": string;
            "action.refresh.label": string;
            "action.select.label": string;
            "action.manageMenuItem.label": string;
            "action.manageMenuItem.success": string;
            "action.manageMenuItem.error": string;
            "empty.queue": string;
            "empty.form": string;
            "empty.summary": string;
            "sec.discover.title": string;
            "org.menuItemsQueue.title": string;
            "sec.execute.title": string;
            "org.manageMenuItemForm.title": string;
            "sec.review.title": string;
            "org.mutationFeedback.title": string;
            "section.menuItems.title": string;
            "section.menuItems.empty": string;
            "section.menuItemEditor.title": string;
            "section.menuItemEditor.empty": string;
            "filter.statusFilter.label": string;
            "filter.menuCategoryIdFilter.label": string;
            "column.name.label": string;
            "column.menuCategoryId.label": string;
            "column.price.label": string;
            "column.itemType.label": string;
            "column.status.label": string;
            "action.newItem.label": string;
            "action.save.label": string;
            "action.activate.label": string;
            "action.inactivate.label": string;
            "action.draft.label": string;
            "action.clear.label": string;
            "org.menuItemsBrowser.title": string;
            "org.menuItemEditor.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102045_/l2/cafeFlow/web/shared/menuManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/shared/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/contracts/menuManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/menuManagement.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/shared/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.posWorkspace.title": string;
            "section.orderBoard.title": string;
            "section.createOrder.title": string;
            "section.deliverOrder.title": string;
            "section.review.title": string;
            "organism.orderBoardCards.title": string;
            "organism.createOrderForm.title": string;
            "organism.deliverOrderForm.title": string;
            "organism.reviewCreate.title": string;
            "organism.reviewDeliver.title": string;
            "intention.orderBoardList.title": string;
            "intention.createOrderForm.title": string;
            "intention.deliverOrderForm.title": string;
            "intention.reviewCreate.title": string;
            "intention.reviewDeliver.title": string;
            "field.orderId": string;
            "field.status": string;
            "field.orderType": string;
            "field.tableNumber": string;
            "field.orderItems": string;
            "field.priority": string;
            "field.priorityReason": string;
            "field.receivedAt": string;
            "field.inPreparationAt": string;
            "field.readyAt": string;
            "field.createdAt": string;
            "field.deliveredAt": string;
            "field.updatedAt": string;
            "action.viewOrderBoard.label": string;
            "action.createOrder.label": string;
            "action.deliverOrder.label": string;
            "action.selectOrder.label": string;
            "empty.orderBoard": string;
            "action.createOrder.success": string;
            "action.createOrder.error": string;
            "action.deliverOrder.success": string;
            "action.deliverOrder.error": string;
            "section.board.title": string;
            "section.board.empty": string;
            "column.orderId": string;
            "column.status": string;
            "column.orderType": string;
            "column.tableNumber": string;
            "column.priority": string;
            "column.priorityReason": string;
            "column.receivedAt": string;
            "column.inPreparationAt": string;
            "column.readyAt": string;
            "column.createdAt": string;
            "field.orderType.label": string;
            "field.tableNumber.label": string;
            "field.orderItems.label": string;
            "field.priority.label": string;
            "field.priorityReason.label": string;
            "action.refresh.label": string;
            "org.orderBoard.title": string;
            "org.createOrderForm.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102045_/l2/cafeFlow/web/shared/posWorkspace.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/shared/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/contracts/posWorkspace.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/posWorkspace.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/shared/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.shiftManagement.title": string;
            "section.discover.title": string;
            "section.execute.openShift.title": string;
            "section.execute.closeShift.title": string;
            "section.review.title": string;
            "organism.shiftReport.title": string;
            "organism.openShiftForm.title": string;
            "organism.closeShiftForm.title": string;
            "organism.shiftSummary.title": string;
            "intention.viewReport.title": string;
            "intention.openShift.title": string;
            "intention.closeShift.title": string;
            "intention.summary.title": string;
            "field.notes.label": string;
            "field.totalApurado.label": string;
            "field.shiftClosingReportId.label": string;
            "field.shiftId.label": string;
            "field.paidOrderCount.label": string;
            "field.createdAt.label": string;
            "field.updatedAt.label": string;
            "field.status.label": string;
            "field.openedAt.label": string;
            "field.openedBy.label": string;
            "field.closedAt.label": string;
            "field.closedBy.label": string;
            "action.openShift.label": string;
            "action.closeShift.label": string;
            "action.viewShiftClosingReport.label": string;
            "action.openShift.success": string;
            "action.openShift.error": string;
            "action.closeShift.success": string;
            "action.closeShift.error": string;
            "empty.shiftReport": string;
            "empty.openShift": string;
            "empty.closeShift": string;
            "empty.summary": string;
            "sec.discover.title": string;
            "org.shift.report.title": string;
            "sec.execute.openShift.title": string;
            "org.open.shift.title": string;
            "sec.execute.closeShift.title": string;
            "org.close.shift.title": string;
            "sec.review.title": string;
            "org.shift.summary.title": string;
            "section.shiftLifecycle.title": string;
            "section.closingReport.title": string;
            "organism.shiftControl.title": string;
            "organism.closingReportDetail.title": string;
            "intention.shiftSummary.title": string;
            "intention.shiftSummary.empty": string;
            "intention.openShiftForm.title": string;
            "intention.closeShiftForm.title": string;
            "intention.reportDisplay.title": string;
            "intention.reportDisplay.empty": string;
            "org.shift.control.title": string;
            "org.closing.report.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102045_/l2/cafeFlow/web/shared/shiftManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/shared/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/contracts/shiftManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/shiftManagement.test" {
    export {};
}
declare module "_102045_/l2/cafeFlow/web/shared/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.browse.title": string;
            "section.browse.empty": string;
            "section.manage.title": string;
            "section.manage.empty": string;
            "field.stockItemId.label": string;
            "field.name.label": string;
            "field.unit.label": string;
            "field.minimumLevel.label": string;
            "field.updatedAt.label": string;
            "field.searchTerm.label": string;
            "action.refresh.label": string;
            "action.selectItem.label": string;
            "action.submit.label": string;
            "action.manageStockItem.success": string;
            "action.manageStockItem.error": string;
            "sec.browse.title": string;
            "org.stockItemsList.title": string;
            "sec.manage.title": string;
            "org.manageStockItemForm.title": string;
            "section.stockItems.title": string;
            "section.stockItems.empty": string;
            "section.editItem.title": string;
            "section.editItem.empty": string;
            "column.stockItemId.label": string;
            "column.name.label": string;
            "column.unit.label": string;
            "column.minimumLevel.label": string;
            "column.createdAt.label": string;
            "column.updatedAt.label": string;
            "filter.searchTerm.label": string;
            "action.browseStockItems.label": string;
            "action.manageStockItem.label": string;
            "action.browseStockItems.success": string;
            "action.browseStockItems.error": string;
            "stockItemsList.title": string;
            "stockItemEditor.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102045_/l2/cafeFlow/web/shared/stockManagement.ts";
        readonly defPath: "_102045_/l2/cafeFlow/web/shared/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102045_/l2/cafeFlow/web/contracts/stockManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102045_/l2/cafeFlow/web/shared/stockManagement.test" {
    export {};
}
declare module "_102045_/l4/actors/cafeFlowActors.defs" {
    export const cafeFlowActors: {
        readonly moduleName: "cafeFlow";
        readonly actors: readonly [{
            readonly actorId: "atendente";
            readonly title: "Atendente / Caixa";
            readonly description: "Lança pedidos rapidamente no POS, seleciona mesa ou takeout e acompanha status para entrega ao cliente.";
            readonly roleScope: "cafeFlow:atendente";
        }, {
            readonly actorId: "cozinheiro";
            readonly title: "Cozinheiro";
            readonly description: "Visualiza pedidos em preparo, atualiza status da cozinha e sinaliza quando o item está pronto.";
            readonly roleScope: "cafeFlow:cozinheiro";
        }, {
            readonly actorId: "gerente";
            readonly title: "Gerente / Proprietário";
            readonly description: "Cadastra itens do cardápio e estoque, abre e fecha turnos, consulta dashboard e utiliza o assistente IA para análise de vendas.";
            readonly roleScope: "cafeFlow:gerente";
        }];
    };
    export default cafeFlowActors;
}
declare module "_102045_/l4/cafeFlow/module.defs" {
    export const cafeFlowModule: {
        readonly module: {
            readonly moduleName: "cafeFlow";
            readonly title: "CafeFlow";
            readonly purpose: "O CafeFlow entrega um fluxo completo de atendimento para cafeterias e lanchonetes pequenas, desde o lançamento rápido de pedidos no POS até a coordenação da cozinha em tempo real. O módulo integra cardápio, controle simples de estoque e gestão de turnos com dashboard e assistente IA, permitindo ao gerente acompanhar o desempenho do dia e tomar decisões operacionais.";
            readonly businessDomain: "Food Service Operations";
            readonly languages: readonly ["en", "pt-BR"];
            readonly visualStyle: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly designContext: {
            readonly initialPrompt: "Gere um app profissional chamado CafeFlow para cafeterias e lanchonetes pequenas. Entidades principais: Item do Cardápio (categoria, preço, ingredientes em estoque), Pedido (mesa ou takeout, itens, status), Turno Diário, Item de Estoque. Telas chave: Dashboard (vendas de hoje, itens mais vendidos, estoque baixo), Interface rápida de POS (lançamento de pedido + status cozinha), Gerenciamento de cardápio e estoque, Relatório de fechamento de turno. Funcionalidade LLM: Assistente IA que gera \"resumo de vendas do dia\" ou sugere \"quais itens promover com base nos últimos 7 dias\". Foco: Atendimento rápido de pedidos, coordenação de cozinha e controle simples de estoque para food service. linguagem: en, pt-br";
            readonly userLanguage: "pt-BR";
            readonly openDetails: readonly [{
                readonly title: "O estoque é decrementado no lançamento do pedido ou na entrega?";
                readonly description: "Define o momento exato da baixa de estoque e o comportamento do alerta de insuficiente.";
            }, {
                readonly title: "O fechamento de turno zera o caixa ou apenas registra o valor apurado para conferência?";
                readonly description: "Influencia se o turno é um controle operacional simples ou se envolve conciliação financeira.";
            }, {
                readonly title: "Há necessidade de suportar variantes de item (ex: tamanho P, M, G) ou apenas itens simples?";
                readonly description: "Afeta a modelagem do cardápio e a interface de lançamento no POS.";
            }];
            readonly decisions: readonly [];
        };
        readonly ontology: {
            readonly entities: {
                readonly Order: {
                    readonly title: "Pedido";
                    readonly description: "Pedido registrado no POS pelo atendente, podendo ser de mesa ou takeout, com status acompanhado do lançamento à entrega.";
                    readonly kind: "core";
                    readonly ownership: "moduleOwned";
                    readonly statusEnum: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
                    readonly lifecycleStates: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
                };
                readonly OrderItem: {
                    readonly title: "Item do Pedido";
                    readonly description: "Linha de pedido que referencia um item do cardápio com quantidade, formando o detalhamento do pedido lançado no POS.";
                    readonly kind: "supporting";
                    readonly ownership: "moduleOwned";
                };
                readonly MenuItem: {
                    readonly title: "Item do Cardápio";
                    readonly description: "Item do cardápio cadastrado pelo gerente com nome, categoria, preço e vínculo a ingredientes de estoque, disponível para lançamento no POS quando ativado.";
                    readonly kind: "mdm";
                    readonly ownership: "moduleOwned";
                    readonly statusEnum: readonly ["draft", "active", "inactive"];
                    readonly lifecycleStates: readonly ["draft", "active", "inactive"];
                };
                readonly MenuCategory: {
                    readonly title: "Categoria do Cardápio";
                    readonly description: "Categoria de classificação dos itens do cardápio, utilizada para organização no POS e no cadastro.";
                    readonly kind: "mdm";
                    readonly ownership: "moduleOwned";
                };
                readonly MenuItemIngredient: {
                    readonly title: "Ingrediente do Item de Cardápio";
                    readonly description: "Vínculo entre um item do cardápio e um item de estoque, definindo a quantidade consumida do ingrediente a cada pedido do item.";
                    readonly kind: "supporting";
                    readonly ownership: "moduleOwned";
                };
                readonly StockItem: {
                    readonly title: "Item de Estoque";
                    readonly description: "Ingrediente cadastrado pelo gerente com unidade de medida e limite mínimo de alerta, representando a definição master do insumo.";
                    readonly kind: "mdm";
                    readonly ownership: "moduleOwned";
                };
                readonly StockLevel: {
                    readonly title: "Nível de Estoque";
                    readonly description: "Estado operacional do estoque de um ingrediente, mantendo a quantidade atual que é decrementada por consumos e ajustada por reposições.";
                    readonly kind: "core";
                    readonly ownership: "moduleOwned";
                };
                readonly StockConsumption: {
                    readonly title: "Consumo de Estoque";
                    readonly description: "Fato imutável registrado no lançamento de um pedido que decrementa o estoque de um ingrediente conforme os vínculos do item do cardápio.";
                    readonly kind: "event";
                    readonly ownership: "moduleOwned";
                    readonly statusEnum: readonly ["posted", "voided"];
                };
                readonly StockAdjustment: {
                    readonly title: "Ajuste de Estoque";
                    readonly description: "Fato imutável registrado pelo gerente para repor ou corrigir a quantidade de um item de estoque manualmente.";
                    readonly kind: "event";
                    readonly ownership: "moduleOwned";
                    readonly statusEnum: readonly ["posted", "voided"];
                };
                readonly Shift: {
                    readonly title: "Turno";
                    readonly description: "Turno diário aberto pelo gerente no início do expediente e fechado ao final, delimitando o período operacional dos pedidos.";
                    readonly kind: "core";
                    readonly ownership: "moduleOwned";
                    readonly statusEnum: readonly ["open", "closed"];
                    readonly lifecycleStates: readonly ["open", "closed"];
                };
                readonly ShiftClosingReport: {
                    readonly title: "Relatório de Fechamento de Turno";
                    readonly description: "Agregado persistido no fechamento do turno com o total apurado e os pedidos consolidados do período para conferência do gerente.";
                    readonly kind: "metric";
                    readonly ownership: "moduleOwned";
                };
            };
        };
        readonly journey: {
            readonly defPath: "l4/cafeFlow/journeys/cafeFlowJourneys.defs.ts";
        };
        readonly relationships: readonly [{
            readonly relationshipId: "orderHasOrderItems";
            readonly fromEntity: "Order";
            readonly toEntity: "OrderItem";
            readonly type: "oneToMany";
            readonly description: "Um pedido contém múltiplos itens de pedido que detalham o que foi solicitado.";
        }, {
            readonly relationshipId: "orderItemRefersToMenuItem";
            readonly fromEntity: "OrderItem";
            readonly toEntity: "MenuItem";
            readonly type: "manyToOne";
            readonly description: "Cada item do pedido referencia um item do cardápio cadastrado.";
        }, {
            readonly relationshipId: "menuItemBelongsToCategory";
            readonly fromEntity: "MenuItem";
            readonly toEntity: "MenuCategory";
            readonly type: "manyToOne";
            readonly description: "Cada item do cardápio pertence a uma categoria de classificação.";
        }, {
            readonly relationshipId: "menuItemHasIngredients";
            readonly fromEntity: "MenuItem";
            readonly toEntity: "MenuItemIngredient";
            readonly type: "oneToMany";
            readonly description: "Um item do cardápio possui múltiplos ingredientes de estoque vinculados.";
        }, {
            readonly relationshipId: "ingredientRefersToStockItem";
            readonly fromEntity: "MenuItemIngredient";
            readonly toEntity: "StockItem";
            readonly type: "manyToOne";
            readonly description: "Cada ingrediente vinculado referencia um item de estoque master.";
        }, {
            readonly relationshipId: "stockItemHasStockLevel";
            readonly fromEntity: "StockItem";
            readonly toEntity: "StockLevel";
            readonly type: "oneToOne";
            readonly description: "Cada item de estoque master possui um nível de estoque operacional com a quantidade atual.";
        }, {
            readonly relationshipId: "consumptionAffectsStockItem";
            readonly fromEntity: "StockConsumption";
            readonly toEntity: "StockItem";
            readonly type: "manyToOne";
            readonly description: "Cada consumo de estoque afeta um item de estoque específico.";
        }, {
            readonly relationshipId: "consumptionTriggeredByOrder";
            readonly fromEntity: "StockConsumption";
            readonly toEntity: "Order";
            readonly type: "manyToOne";
            readonly description: "Cada consumo de estoque é disparado pelo lançamento de um pedido.";
        }, {
            readonly relationshipId: "adjustmentAffectsStockItem";
            readonly fromEntity: "StockAdjustment";
            readonly toEntity: "StockItem";
            readonly type: "manyToOne";
            readonly description: "Cada ajuste de estoque afeta um item de estoque específico.";
        }, {
            readonly relationshipId: "orderBelongsToShift";
            readonly fromEntity: "Order";
            readonly toEntity: "Shift";
            readonly type: "manyToOne";
            readonly description: "Cada pedido pertence ao turno aberto no momento do seu lançamento.";
        }, {
            readonly relationshipId: "closingReportForShift";
            readonly fromEntity: "ShiftClosingReport";
            readonly toEntity: "Shift";
            readonly type: "oneToOne";
            readonly description: "Cada relatório de fechamento corresponde a um turno fechado.";
        }];
        readonly approvedArtifacts: {
            readonly mdm: readonly [{
                readonly title: "Catálogo de produtos (cardápio e estoque)";
                readonly reason: "Itens do cardápio e itens de estoque são dados de registro com identidade estável e raras alterações que poderiam ser sincronizados com o MDM da plataforma 102034 para padronização multi-unidade no futuro.";
            }];
            readonly horizontals: readonly [{
                readonly title: "Pagamentos";
                readonly reason: "O fechamento de turno registra valor apurado e consolida pedidos pagos, indicando que uma capacidade de pagamento cross-module é necessária para processar as transações que alimentam o relatório.";
            }];
            readonly plugins: readonly [{
                readonly title: "Documento fiscal (cupom fiscal / NF-e)";
                readonly reason: "Embora as regras de jornada não mencionem explicitamente emissão fiscal, um POS de cafeteria no Brasil tipicamente precisa emitir cupom fiscal ou NF-e, podendo ser integrado como plugin opcional no futuro.";
            }];
            readonly agents: readonly [{
                readonly title: "Assistente IA de vendas";
                readonly reason: "As jornadas useAiAssistant exigem um assistente IA que consome dados agregados de pedidos e estoque do domínio para gerar resumo de vendas do dia e sugestões de promoção baseadas nos últimos 7 dias, utilizando o proxy LLM da plataforma.";
            }];
        };
    };
    export default cafeFlowModule;
}
declare module "_102045_/l4/cafeFlow/journeys/cafeFlowJourneys.defs" {
    export const cafeFlowJourneys: {
        readonly moduleName: "cafeFlow";
        readonly note: "Consolidated navigation map derived from workflows/operations stories (view, not source).";
        readonly workspaces: readonly [{
            readonly workspaceId: "posWorkspace";
            readonly title: "POS — Lançamento e acompanhamento de pedidos";
            readonly actor: "atendente";
            readonly kind: "workflow";
            readonly entity: "Order";
            readonly operationIds: readonly ["createOrder", "viewOrderBoard", "deliverOrder"];
            readonly purpose: "O atendente lança pedidos no POS, acompanha o painel de status e entrega os pedidos prontos ao cliente.";
            readonly workflowId: "orderLifecycle";
        }, {
            readonly workspaceId: "kitchenQueue";
            readonly title: "Fila da cozinha — Preparo de pedidos";
            readonly actor: "cozinheiro";
            readonly kind: "workflow";
            readonly entity: "Order";
            readonly operationIds: readonly ["viewKitchenBoard", "updateOrderStatus"];
            readonly purpose: "O cozinheiro visualiza a fila de pedidos recebidos, inicia o preparo e sinaliza quando o pedido está pronto.";
            readonly workflowId: "orderLifecycle";
        }, {
            readonly workspaceId: "menuManagement";
            readonly title: "Gestão de cardápio";
            readonly actor: "gerente";
            readonly kind: "workflow";
            readonly entity: "MenuItem";
            readonly operationIds: readonly ["browseMenuItems", "manageMenuItem"];
            readonly purpose: "O gerente consulta, cria e edita itens do cardápio vinculando ingredientes de estoque e controlando a ativação.";
            readonly workflowId: "menuItemLifecycle";
        }, {
            readonly workspaceId: "stockManagement";
            readonly title: "Gestão de estoque e alertas";
            readonly actor: "gerente";
            readonly kind: "operation";
            readonly entity: "StockItem";
            readonly operationIds: readonly ["browseStockItems", "manageStockItem"];
            readonly purpose: "O gerente consulta itens de estoque, visualiza alertas de baixo estoque e atualiza cadastros de insumos.";
        }, {
            readonly workspaceId: "shiftManagement";
            readonly title: "Gestão de turno diário";
            readonly actor: "gerente";
            readonly kind: "workflow";
            readonly entity: "Shift";
            readonly operationIds: readonly ["openShift", "closeShift", "viewShiftClosingReport"];
            readonly purpose: "O gerente abre e fecha o turno diário e revisa o relatório de fechamento para conferência do expediente.";
            readonly workflowId: "shiftLifecycle";
        }, {
            readonly workspaceId: "managerDashboard";
            readonly title: "Dashboard e assistente IA";
            readonly actor: "gerente";
            readonly kind: "operation";
            readonly entity: "Order";
            readonly operationIds: readonly ["viewDashboard", "requestAiSalesSummary", "requestAiPromoSuggestions"];
            readonly purpose: "O gerente consulta o dashboard de vendas do dia e utiliza o assistente IA para obter resumos e sugestões de promoção.";
        }];
        readonly landings: readonly [{
            readonly actorId: "atendente";
            readonly workspaceId: "posWorkspace";
            readonly reason: "O atendente inicia o expediente lançando pedidos no POS e acompanhando o painel de status.";
        }, {
            readonly actorId: "cozinheiro";
            readonly workspaceId: "kitchenQueue";
            readonly reason: "O cozinheiro começa o turno visualizando a fila de pedidos recebidos para iniciar o preparo.";
        }, {
            readonly actorId: "gerente";
            readonly workspaceId: "shiftManagement";
            readonly reason: "O gerente abre o dia abrindo o turno antes de qualquer outra operação no módulo.";
        }];
        readonly navigationEdges: readonly [{
            readonly from: "shiftManagement";
            readonly to: "posWorkspace";
            readonly operationId: "openShift";
            readonly description: "Turno aberto habilita o lançamento de pedidos no POS pelo atendente.";
        }, {
            readonly from: "posWorkspace";
            readonly to: "kitchenQueue";
            readonly operationId: "createOrder";
            readonly description: "Pedido confirmado é enviado à cozinha e aparece na fila do cozinheiro.";
        }, {
            readonly from: "kitchenQueue";
            readonly to: "posWorkspace";
            readonly operationId: "updateOrderStatus";
            readonly description: "Cozinheiro marca pedido como pronto, sinalizando o atendente para entregar ao cliente.";
        }, {
            readonly from: "menuManagement";
            readonly to: "stockManagement";
            readonly description: "Gerente vincula ingredientes de estoque ao cadastrar item de cardápio, navegando para a gestão de estoque.";
        }, {
            readonly from: "managerDashboard";
            readonly to: "shiftManagement";
            readonly operationId: "closeShift";
            readonly description: "Gerente consulta o dashboard de vendas antes de fechar o turno e gerar o relatório de fechamento.";
        }, {
            readonly from: "shiftManagement";
            readonly to: "managerDashboard";
            readonly operationId: "viewShiftClosingReport";
            readonly description: "Após fechar o turno, o gerente pode consultar o dashboard e o assistente IA para análise do dia.";
        }];
    };
    export default cafeFlowJourneys;
}
declare module "_102045_/l4/cafeFlow/ontology/MenuCategory.defs" {
    export const cafeFlowEntityMenuCategory: {
        readonly entityId: "MenuCategory";
        readonly title: "Categoria do Cardápio";
        readonly description: "Categoria de classificação dos itens do cardápio, utilizada para organização no POS e no cadastro.";
        readonly kind: "mdm";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "menuCategoryId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da categoria do cardápio.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome da categoria exibido no POS e no cadastro.";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição complementar da categoria para uso interno.";
        }, {
            readonly fieldId: "displayOrder";
            readonly type: "number";
            readonly required: true;
            readonly description: "Ordem de exibição da categoria no POS e em listagens.";
        }, {
            readonly fieldId: "active";
            readonly type: "boolean";
            readonly required: true;
            readonly description: "Indica se a categoria está ativa e visível para seleção no POS.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro da categoria.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro da categoria.";
        }];
    };
    export default cafeFlowEntityMenuCategory;
}
declare module "_102045_/l4/cafeFlow/ontology/MenuItem.defs" {
    export const cafeFlowEntityMenuItem: {
        readonly entityId: "MenuItem";
        readonly title: "Item do Cardápio";
        readonly description: "Item do cardápio cadastrado pelo gerente com nome, categoria, preço e vínculo a ingredientes de estoque, disponível para lançamento no POS quando ativado.";
        readonly kind: "mdm";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "menuItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item do cardápio";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do item do cardápio exibido no POS";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição detalhada do item do cardápio";
        }, {
            readonly fieldId: "menuCategoryId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à categoria de classificação à qual o item pertence";
        }, {
            readonly fieldId: "price";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço de venda do item do cardápio";
        }, {
            readonly fieldId: "itemType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo do item: simples ou variante cadastrada como item separado";
            readonly enum: readonly ["simple", "variant"];
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status do item no ciclo de vida: rascunho, ativo ou inativo";
            readonly enum: readonly ["draft", "active", "inactive"];
        }, {
            readonly fieldId: "activatedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que o item foi ativado e disponibilizado no POS";
        }, {
            readonly fieldId: "inactivatedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que o item foi inativado e indisponibilizado no POS";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro do item";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro do item";
        }];
        readonly statusEnum: readonly ["draft", "active", "inactive"];
        readonly lifecycleStates: readonly ["draft", "active", "inactive"];
    };
    export default cafeFlowEntityMenuItem;
}
declare module "_102045_/l4/cafeFlow/ontology/MenuItemIngredient.defs" {
    export const cafeFlowEntityMenuItemIngredient: {
        readonly entityId: "MenuItemIngredient";
        readonly title: "Ingrediente do Item de Cardápio";
        readonly description: "Vínculo entre um item do cardápio e um item de estoque, definindo a quantidade consumida do ingrediente a cada pedido do item.";
        readonly kind: "supporting";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "menuItemIngredientId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do vínculo entre item de cardápio e ingrediente de estoque.";
        }, {
            readonly fieldId: "menuItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao item de cardápio ao qual este ingrediente está vinculado.";
        }, {
            readonly fieldId: "stockItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao item de estoque master consumido quando o item de cardápio é pedido.";
        }, {
            readonly fieldId: "quantity";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade do ingrediente consumida a cada pedido do item de cardápio.";
        }, {
            readonly fieldId: "unit";
            readonly type: "string";
            readonly required: true;
            readonly description: "Unidade de medida da quantidade consumida do ingrediente.";
            readonly enum: readonly ["kg", "gram", "liter", "milliliter", "portion", "unit"];
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do vínculo de ingrediente.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do vínculo de ingrediente.";
        }];
    };
    export default cafeFlowEntityMenuItemIngredient;
}
declare module "_102045_/l4/cafeFlow/ontology/Order.defs" {
    export const cafeFlowEntityOrder: {
        readonly entityId: "Order";
        readonly title: "Pedido";
        readonly description: "Pedido registrado no POS pelo atendente, podendo ser de mesa ou takeout, com status acompanhado do lançamento à entrega.";
        readonly kind: "core";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "orderId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do pedido";
        }, {
            readonly fieldId: "shiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Turno aberto no momento do lançamento do pedido";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual do pedido no fluxo de acompanhamento";
            readonly enum: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
        }, {
            readonly fieldId: "orderType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo do pedido: consumo na mesa ou para viagem";
            readonly enum: readonly ["table", "takeout"];
        }, {
            readonly fieldId: "tableNumber";
            readonly type: "string";
            readonly required: false;
            readonly description: "Número da mesa quando o pedido é do tipo mesa";
        }, {
            readonly fieldId: "priority";
            readonly type: "boolean";
            readonly required: false;
            readonly description: "Indica se o pedido recebeu priorização no preparo fora da ordem de chegada";
        }, {
            readonly fieldId: "priorityReason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Justificativa para a priorização do pedido fora da ordem de chegada";
        }, {
            readonly fieldId: "receivedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Momento em que o pedido foi recebido pela cozinha";
        }, {
            readonly fieldId: "inPreparationAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Momento em que o cozinheiro iniciou o preparo do pedido";
        }, {
            readonly fieldId: "readyAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Momento em que o pedido foi marcado como pronto pela cozinha";
        }, {
            readonly fieldId: "deliveredAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Momento em que o pedido foi entregue ao cliente";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Momento de criação do registro do pedido";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Momento da última atualização do registro do pedido";
        }];
        readonly statusEnum: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
        readonly lifecycleStates: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
    };
    export default cafeFlowEntityOrder;
}
declare module "_102045_/l4/cafeFlow/ontology/OrderItem.defs" {
    export const cafeFlowEntityOrderItem: {
        readonly entityId: "OrderItem";
        readonly title: "Item do Pedido";
        readonly description: "Linha de pedido que referencia um item do cardápio com quantidade, formando o detalhamento do pedido lançado no POS.";
        readonly kind: "supporting";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "orderItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da linha do pedido.";
        }, {
            readonly fieldId: "orderId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao pedido ao qual esta linha pertence.";
        }, {
            readonly fieldId: "menuItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao item do cardápio cadastrado que foi solicitado.";
        }, {
            readonly fieldId: "quantity";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade solicitada do item do cardápio nesta linha do pedido.";
        }, {
            readonly fieldId: "unitPrice";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço unitário do item no momento do lançamento do pedido, snapshot para fins de fechamento.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que a linha do pedido foi criada.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização da linha do pedido.";
        }];
    };
    export default cafeFlowEntityOrderItem;
}
declare module "_102045_/l4/cafeFlow/ontology/Shift.defs" {
    export const cafeFlowEntityShift: {
        readonly entityId: "Shift";
        readonly title: "Turno";
        readonly description: "Turno diário aberto pelo gerente no início do expediente e fechado ao final, delimitando o período operacional dos pedidos.";
        readonly kind: "core";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "shiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do turno";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Situação atual do turno";
            readonly enum: readonly ["open", "closed"];
        }, {
            readonly fieldId: "openedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de abertura do turno pelo gerente";
        }, {
            readonly fieldId: "closedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora de fechamento do turno";
        }, {
            readonly fieldId: "openedBy";
            readonly type: "string";
            readonly required: true;
            readonly description: "Identificador do gerente que abriu o turno";
        }, {
            readonly fieldId: "closedBy";
            readonly type: "string";
            readonly required: false;
            readonly description: "Identificador do gerente que fechou o turno";
        }, {
            readonly fieldId: "totalApurado";
            readonly type: "money";
            readonly required: false;
            readonly description: "Valor total apurado no fechamento do turno para conferência, sem conciliação bancária";
        }, {
            readonly fieldId: "notes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações gerais sobre o turno";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro";
        }];
        readonly statusEnum: readonly ["open", "closed"];
        readonly lifecycleStates: readonly ["open", "closed"];
    };
    export default cafeFlowEntityShift;
}
declare module "_102045_/l4/cafeFlow/ontology/ShiftClosingReport.defs" {
    export const cafeFlowEntityShiftClosingReport: {
        readonly entityId: "ShiftClosingReport";
        readonly title: "Relatório de Fechamento de Turno";
        readonly description: "Agregado persistido no fechamento do turno com o total apurado e os pedidos consolidados do período para conferência do gerente.";
        readonly kind: "metric";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "shiftClosingReportId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do relatório de fechamento de turno.";
        }, {
            readonly fieldId: "shiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao turno fechado ao qual este relatório corresponde.";
        }, {
            readonly fieldId: "totalApurado";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor total apurado no fechamento do turno para conferência do gerente.";
        }, {
            readonly fieldId: "paidOrderCount";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade de pedidos pagos consolidados no período do turno.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que o relatório de fechamento foi gerado.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do relatório de fechamento.";
        }];
    };
    export default cafeFlowEntityShiftClosingReport;
}
declare module "_102045_/l4/cafeFlow/ontology/StockAdjustment.defs" {
    export const cafeFlowEntityStockAdjustment: {
        readonly entityId: "StockAdjustment";
        readonly title: "Ajuste de Estoque";
        readonly description: "Fato imutável registrado pelo gerente para repor ou corrigir a quantidade de um item de estoque manualmente.";
        readonly kind: "event";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "stockAdjustmentId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do ajuste de estoque.";
        }, {
            readonly fieldId: "stockItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Item de estoque ao qual o ajuste se aplica.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Situação do ajuste: lançado ou anulado.";
            readonly enum: readonly ["posted", "voided"];
        }, {
            readonly fieldId: "quantity";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade ajustada, positiva para reposição e negativa para correção ou baixa.";
        }, {
            readonly fieldId: "reason";
            readonly type: "text";
            readonly required: true;
            readonly description: "Motivo do ajuste informado pelo gerente ao registrar a reposição ou correção.";
        }, {
            readonly fieldId: "voidedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que o ajuste foi anulado.";
        }, {
            readonly fieldId: "voidedReason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo da anulação do ajuste de estoque.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro do ajuste.";
        }];
        readonly statusEnum: readonly ["posted", "voided"];
        readonly eventPolicy: {
            readonly purpose: "audit";
            readonly retentionDays: 365;
        };
    };
    export default cafeFlowEntityStockAdjustment;
}
declare module "_102045_/l4/cafeFlow/ontology/StockConsumption.defs" {
    export const cafeFlowEntityStockConsumption: {
        readonly entityId: "StockConsumption";
        readonly title: "Consumo de Estoque";
        readonly description: "Fato imutável registrado no lançamento de um pedido que decrementa o estoque de um ingrediente conforme os vínculos do item do cardápio.";
        readonly kind: "event";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "stockConsumptionId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do consumo de estoque.";
        }, {
            readonly fieldId: "stockItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Item de estoque cuja quantidade foi decrementada por este consumo.";
        }, {
            readonly fieldId: "orderId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Pedido que disparou este consumo de estoque no momento do lançamento.";
        }, {
            readonly fieldId: "quantity";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade do item de estoque consumida e decrementada neste lançamento.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Situação do consumo: lançado ou estornado.";
            readonly enum: readonly ["posted", "voided"];
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora do registro do consumo de estoque.";
        }, {
            readonly fieldId: "voidedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que o consumo foi estornado, quando aplicável.";
        }, {
            readonly fieldId: "voidReason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo do estorno do consumo de estoque.";
        }];
        readonly statusEnum: readonly ["posted", "voided"];
        readonly eventPolicy: {
            readonly purpose: "audit";
            readonly retentionDays: 365;
        };
    };
    export default cafeFlowEntityStockConsumption;
}
declare module "_102045_/l4/cafeFlow/ontology/StockItem.defs" {
    export const cafeFlowEntityStockItem: {
        readonly entityId: "StockItem";
        readonly title: "Item de Estoque";
        readonly description: "Ingrediente cadastrado pelo gerente com unidade de medida e limite mínimo de alerta, representando a definição master do insumo.";
        readonly kind: "mdm";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "stockItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item de estoque master.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do ingrediente cadastrado pelo gerente.";
        }, {
            readonly fieldId: "unit";
            readonly type: "string";
            readonly required: true;
            readonly description: "Unidade de medida do ingrediente utilizada no controle de estoque.";
            readonly enum: readonly ["kg", "liter", "portion", "unit"];
        }, {
            readonly fieldId: "minimumLevel";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de cadastro do item de estoque.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do item de estoque.";
        }];
    };
    export default cafeFlowEntityStockItem;
}
declare module "_102045_/l4/cafeFlow/ontology/StockLevel.defs" {
    export const cafeFlowEntityStockLevel: {
        readonly entityId: "StockLevel";
        readonly title: "Nível de Estoque";
        readonly description: "Estado operacional do estoque de um ingrediente, mantendo a quantidade atual que é decrementada por consumos e ajustada por reposições.";
        readonly kind: "core";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "stockLevelId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do nível de estoque";
        }, {
            readonly fieldId: "stockItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao item de estoque master ao qual este nível pertence";
        }, {
            readonly fieldId: "currentQuantity";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade atual disponível em estoque, decrementada por consumos e ajustada por reposições";
        }, {
            readonly fieldId: "minimumLevel";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo";
        }, {
            readonly fieldId: "unit";
            readonly type: "string";
            readonly required: true;
            readonly description: "Unidade de medida do estoque do ingrediente";
            readonly enum: readonly ["kg", "liter", "portion", "unit"];
        }, {
            readonly fieldId: "lastDecrementAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora do último decremento de estoque por lançamento de pedido";
        }, {
            readonly fieldId: "lastAdjustmentAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora do último ajuste manual de reposição de estoque";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro de nível de estoque";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do nível de estoque";
        }];
    };
    export default cafeFlowEntityStockLevel;
}
declare module "_102045_/l4/operations/browseMenuItems.defs" {
    export const operationBrowseMenuItems: {
        readonly operationId: "browseMenuItems";
        readonly title: "Consultar itens do cardápio";
        readonly actor: "gerente";
        readonly entity: "MenuItem";
        readonly kind: "query";
        readonly reads: readonly ["MenuItem", "MenuCategory"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["simpleItemsOnly"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Consultar a lista de itens do cardápio para revisar, editar ou decidir ativação de itens cadastrados.";
            readonly steps: readonly ["O gerente abre a tela de gestão de cardápio.", "O sistema lista todos os itens do cardápio da empresa ativa com nome, categoria, preço, tipo e status.", "O gerente pode filtrar por status (rascunho, ativo, inativo) ou por categoria para localizar itens específicos."];
            readonly outcome: "O gerente visualiza a lista completa de itens do cardápio e pode identificar quais itens precisam de ingredientes vinculados ou ativação.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly entity: "MenuItem";
            readonly keyField: "MenuItem.menuItemId";
            readonly pagination: "optional";
            readonly selection: "none";
            readonly output: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.menuCategoryId", "MenuItem.price", "MenuItem.itemType", "MenuItem.status", "MenuItem.activatedAt", "MenuItem.createdAt", "MenuItem.updatedAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "statusFilter";
            readonly fieldRef: "MenuItem.status";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Filtro opcional por status do item (draft, active, inactive) informado pelo gerente";
        }, {
            readonly inputId: "menuCategoryIdFilter";
            readonly fieldRef: "MenuItem.menuCategoryId";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Filtro opcional por categoria do item informado pelo gerente";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "MenuItem.menuCategoryId";
            readonly source: "businessContext";
            readonly originRef: "businessContext.activeCompanyId";
            readonly description: "O backend resolve o escopo da consulta limitando os itens do cardápio à empresa ativa da sessão do gerente";
        }];
        readonly acceptanceAssertions: readonly ["A lista retornada contém apenas itens do cardápio pertencentes à empresa ativa do gerente", "Cada item da lista exibe nome, categoria, preço, tipo (simple ou variant) e status (draft, active ou inactive)", "O filtro por status retorna apenas itens cujo status corresponde ao valor informado", "O filtro por categoria retorna apenas itens cujo menuCategoryId corresponde ao valor informado", "Itens do tipo variant aparecem na lista como itens separados conforme a regra de apenas itens simples suportados"];
        readonly pageId: "menuItemLifecycle";
        readonly commandName: "browseMenuItems";
        readonly bffName: "cafeFlow.menuItemLifecycle.browseMenuItems";
        readonly capability: {
            readonly capabilityId: "menuItemLifecycle";
            readonly title: "Ciclo de vida do item de cardápio";
            readonly actor: "gerente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationBrowseMenuItems;
}
declare module "_102045_/l4/operations/browseStockItems.defs" {
    export const operationBrowseStockItems: {
        readonly operationId: "browseStockItems";
        readonly title: "Consultar itens de estoque e alertas";
        readonly actor: "gerente";
        readonly entity: "StockItem";
        readonly kind: "query";
        readonly reads: readonly ["StockItem", "StockLevel"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["lowStockAlertCalculation"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Visualizar todos os itens de estoque cadastrados e identificar quais estão com quantidade abaixo do mínimo configurado para planejar a reposição.";
            readonly steps: readonly ["O gerente abre a tela de consulta de estoque", "O sistema lista todos os itens de estoque com nome, unidade de medida e limite mínimo", "O sistema compara a quantidade atual de cada item (StockLevel) com o mínimo configurado (StockItem.minimumLevel)", "Itens cuja quantidade atual está abaixo ou igual ao mínimo são destacados como alerta de estoque baixo", "O gerente pode filtrar a lista por nome para localizar um ingrediente específico"];
            readonly outcome: "O gerente obtém uma visão completa do estoque com indicação clara de quais itens precisam de reposição imediata.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly entity: "StockItem";
            readonly keyField: "StockItem.stockItemId";
            readonly pagination: "optional";
            readonly selection: "none";
            readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unit", "StockItem.minimumLevel", "StockItem.createdAt", "StockItem.updatedAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "searchTerm";
            readonly fieldRef: "StockItem.name";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Termo de busca opcional para filtrar itens de estoque pelo nome.";
        }, {
            readonly inputId: "actorId";
            readonly fieldRef: "StockItem.stockItemId";
            readonly required: true;
            readonly source: "actorSession";
            readonly description: "Identificador do gerente autenticado que está consultando o estoque.";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "StockItem.stockItemId";
            readonly source: "actorSession";
            readonly originRef: "actorSession.actorId";
            readonly description: "O backend extrai o actorId da sessão autenticada do gerente para autorizar o acesso à lista de itens de estoque.";
        }];
        readonly acceptanceAssertions: readonly ["A lista exibe todos os itens de estoque cadastrados com nome, unidade de medida e limite mínimo configurado", "Itens cuja quantidade atual (StockLevel) está abaixo ou igual ao mínimo configurado (StockItem.minimumLevel) são destacados como alerta de estoque baixo", "O gerente pode filtrar a lista por nome do ingrediente para localizar um item específico", "A lista está ordenada por nome do item de estoque para facilitar a consulta", "A paginação é opcional e permite navegar por grandes volumes de itens de estoque"];
        readonly pageId: "browseStockItems";
        readonly commandName: "browseStockItems";
        readonly bffName: "cafeFlow.browseStockItems.browseStockItems";
        readonly capability: {
            readonly capabilityId: "browseStockItems";
            readonly title: "Consultar itens de estoque e alertas";
            readonly actor: "gerente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationBrowseStockItems;
}
declare module "_102045_/l4/operations/closeShift.defs" {
    export const operationCloseShift: {
        readonly operationId: "closeShift";
        readonly title: "Fechar turno diário";
        readonly actor: "gerente";
        readonly entity: "Shift";
        readonly kind: "update";
        readonly reads: readonly ["Shift", "Order", "ShiftClosingReport"];
        readonly writes: readonly ["Shift", "ShiftClosingReport"];
        readonly rulesApplied: readonly ["shiftClosingRecordsRevenue", "singleOpenShift", "dashboardCurrentShiftOnly"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Fechar o turno diário ao final do expediente, consolidando os pedidos do período e registrando o valor apurado para conferência.";
            readonly steps: readonly ["O gerente acessa a tela de fechamento de turno, onde o sistema identifica o turno atualmente aberto.", "O sistema consolida os pedidos do período e sugere o total apurado.", "O gerente confirma ou ajusta o valor apurado e adiciona observações se necessário.", "O sistema atualiza o status do turno para 'closed', registra a data/hora de fechamento e o gerente responsável, e gera o relatório de fechamento."];
            readonly outcome: "O turno é fechado com status 'closed', o valor apurado é registrado para conferência e o relatório de fechamento é gerado.";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "Shift";
            readonly keyField: "Shift.shiftId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["Shift.status", "Shift.closedAt", "Shift.closedBy", "Shift.totalApurado", "Shift.notes"];
        };
        readonly inputs: readonly [{
            readonly inputId: "totalApurado";
            readonly fieldRef: "Shift.totalApurado";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Valor total apurado no fechamento do turno, informado pelo gerente para conferência.";
        }, {
            readonly inputId: "notes";
            readonly fieldRef: "Shift.notes";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Observações gerais sobre o turno, opcionais.";
        }, {
            readonly inputId: "shiftId";
            readonly fieldRef: "Shift.shiftId";
            readonly required: true;
            readonly source: "activeLifecycleInstance";
            readonly description: "Identificador do turno atualmente aberto que será fechado.";
        }, {
            readonly inputId: "closedBy";
            readonly fieldRef: "Shift.closedBy";
            readonly required: true;
            readonly source: "actorSession";
            readonly description: "Identificador do gerente que está fechando o turno.";
        }, {
            readonly inputId: "closedAt";
            readonly fieldRef: "Shift.closedAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Data e hora do fechamento do turno, definida automaticamente pelo sistema.";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Shift.shiftId";
            readonly source: "activeLifecycleInstance";
            readonly originRef: "Shift.shiftId";
            readonly description: "O backend localiza o único Shift com status 'open' (turno ativo) e utiliza seu shiftId como alvo do fechamento.";
        }, {
            readonly targetRef: "Shift.closedBy";
            readonly source: "actorSession";
            readonly originRef: "actorSession.actorId";
            readonly description: "O backend obtém o identificador do gerente autenticado a partir da sessão ativa.";
        }, {
            readonly targetRef: "Shift.closedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend define a data e hora de fechamento como o timestamp atual no momento da confirmação.";
        }];
        readonly acceptanceAssertions: readonly ["Após o fechamento, o Shift possui status igual a 'closed'.", "Após o fechamento, o campo Shift.closedAt é preenchido com a data e hora do fechamento.", "Após o fechamento, o campo Shift.closedBy contém o identificador do gerente que executou o fechamento.", "Após o fechamento, o campo Shift.totalApurado reflete o valor informado pelo gerente para conferência.", "Após o fechamento, um ShiftClosingReport é gerado para o turno fechado.", "O fechamento só é permitido quando existe exatamente um turno com status 'open'.", "Após o fechamento, nenhum turno permanece com status 'open'."];
        readonly pageId: "shiftLifecycle";
        readonly commandName: "closeShift";
        readonly bffName: "cafeFlow.shiftLifecycle.closeShift";
        readonly capability: {
            readonly capabilityId: "shiftLifecycle";
            readonly title: "Ciclo de vida do turno";
            readonly actor: "gerente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationCloseShift;
}
declare module "_102045_/l4/operations/createOrder.defs" {
    export const operationCreateOrder: {
        readonly operationId: "createOrder";
        readonly title: "Lançar pedido no POS";
        readonly actor: "atendente";
        readonly entity: "Order";
        readonly kind: "create";
        readonly reads: readonly ["MenuItem", "StockLevel", "Shift"];
        readonly writes: readonly ["Order", "OrderItem", "StockConsumption", "StockLevel"];
        readonly rulesApplied: readonly ["stockDecrementOnOrderLaunch", "orderStatusFlow", "fifoKitchenQueue"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Registrar um novo pedido no POS para que a cozinha possa prepará-lo e o cliente possa acompanhá-lo";
            readonly steps: readonly ["O atendente seleciona o tipo de pedido (mesa ou takeout) e informa o número da mesa quando aplicável", "O atendente busca e adiciona os itens do cardápio solicitados pelo cliente, visualizando preço e categoria", "O atendente opcionalmente marca o pedido como prioritário com justificativa", "O sistema verifica alertas de estoque insuficiente nos ingredientes dos itens pedidos", "O atendente confirma o pedido e o sistema cria o registro com status 'registered', decrementa o estoque e gera o número do pedido"];
            readonly outcome: "O pedido é criado com status 'registered', vinculado ao turno aberto, com seus itens e consumo de estoque registrados, e o atendente recebe o número do pedido para repassar ao cliente";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "Order";
            readonly keyField: "Order.orderId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.createdAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "orderType";
            readonly fieldRef: "Order.orderType";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Tipo do pedido selecionado pelo atendente: 'table' (consumo na mesa) ou 'takeout' (para viagem)";
        }, {
            readonly inputId: "tableNumber";
            readonly fieldRef: "Order.tableNumber";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Número da mesa informado pelo atendente, obrigatório quando orderType = 'table'";
        }, {
            readonly inputId: "orderItems";
            readonly fieldRef: "OrderItem.menuItemId";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Lista de itens do cardápio selecionados pelo cliente, cada um com menuItemId e quantidade";
        }, {
            readonly inputId: "priority";
            readonly fieldRef: "Order.priority";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Indica se o atendente marcou o pedido como prioritário no preparo";
        }, {
            readonly inputId: "priorityReason";
            readonly fieldRef: "Order.priorityReason";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Justificativa da priorização, obrigatória quando priority = true";
        }, {
            readonly inputId: "shiftId";
            readonly fieldRef: "Order.shiftId";
            readonly required: true;
            readonly source: "activeLifecycleInstance";
            readonly description: "Turno aberto no momento do lançamento do pedido";
        }, {
            readonly inputId: "orderId";
            readonly fieldRef: "Order.orderId";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Identificador único gerado para o novo pedido";
        }, {
            readonly inputId: "createdAt";
            readonly fieldRef: "Order.createdAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Momento de criação do registro do pedido";
        }, {
            readonly inputId: "updatedAt";
            readonly fieldRef: "Order.updatedAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Momento da última atualização do registro do pedido";
        }];
        readonly contextResolution: readonly [{
            readonly inputId: "shiftId";
            readonly targetRef: "Order.shiftId";
            readonly source: "activeLifecycleInstance";
            readonly originRef: "Shift.shiftId";
            readonly description: "Resolves the single Shift with status open — the active shift at the moment of order creation";
        }, {
            readonly inputId: "orderId";
            readonly targetRef: "Order.orderId";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.uuid";
            readonly description: "Generates a new UUID to identify the order being created";
        }, {
            readonly inputId: "createdAt";
            readonly targetRef: "Order.createdAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "Sets the creation timestamp to the current server time at the moment of order launch";
        }, {
            readonly inputId: "updatedAt";
            readonly targetRef: "Order.updatedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "Sets the last-update timestamp to the current server time at the moment of order launch";
        }];
        readonly acceptanceAssertions: readonly ["Após a confirmação, o pedido existe com status 'registered'", "O pedido criado está vinculado ao turno atualmente aberto (shiftId não é nulo)", "Quando orderType é 'table', o campo tableNumber está preenchido", "Quando orderType é 'takeout', o campo tableNumber é nulo", "Para cada item do cardápio adicionado, existe um OrderItem correspondente vinculado ao pedido", "O estoque é decrementado no momento do lançamento do pedido conforme os ingredientes vinculados a cada item pedido", "Quando priority é true, o campo priorityReason está preenchido", "O pedido inicia no status 'registered', seguindo o fluxo de status obrigatório: registered → received → inPreparation → ready → delivered", "O sistema retorna o orderId gerado para que o atendente repasse ao cliente"];
        readonly pageId: "orderLifecycle";
        readonly commandName: "createOrder";
        readonly bffName: "cafeFlow.orderLifecycle.createOrder";
        readonly capability: {
            readonly capabilityId: "orderLifecycle";
            readonly title: "Ciclo de vida do pedido";
            readonly actor: "atendente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationCreateOrder;
}
declare module "_102045_/l4/operations/deliverOrder.defs" {
    export const operationDeliverOrder: {
        readonly operationId: "deliverOrder";
        readonly title: "Entregar pedido ao cliente";
        readonly actor: "atendente";
        readonly entity: "Order";
        readonly kind: "update";
        readonly reads: readonly ["Order"];
        readonly writes: readonly ["Order"];
        readonly rulesApplied: readonly ["orderStatusFlow", "readyBeforeDelivered"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Entregar o pedido pronto ao cliente (na mesa ou no balcão) e registrá-lo como entregue no sistema.";
            readonly steps: readonly ["O atendente consulta o painel de pedidos e identifica um pedido com status 'pronto'.", "O atendente seleciona o pedido e confirma a entrega ao cliente.", "O sistema valida que o status atual é 'ready' e atualiza o pedido para status 'delivered' registrando o momento da entrega."];
            readonly outcome: "O pedido é marcado como entregue com deliveredAt preenchido, concluindo o fluxo de acompanhamento do pedido.";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "Order";
            readonly keyField: "Order.orderId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["Order.orderId", "Order.status", "Order.deliveredAt", "Order.updatedAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "orderId";
            readonly fieldRef: "Order.orderId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Pedido selecionado pelo atendente no painel para entrega";
        }, {
            readonly inputId: "deliveredAt";
            readonly fieldRef: "Order.deliveredAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Momento em que o pedido foi entregue ao cliente, gerado automaticamente";
        }, {
            readonly inputId: "updatedAt";
            readonly fieldRef: "Order.updatedAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Momento da última atualização do registro do pedido, gerado automaticamente";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Order.orderId";
            readonly source: "selectedEntity";
            readonly originRef: "Order.orderId";
            readonly description: "O backend resolve o orderId a partir do pedido atualmente selecionado pelo atendente no painel de pedidos.";
        }, {
            readonly targetRef: "Order.deliveredAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend define deliveredAt com o timestamp atual no momento da confirmação da entrega.";
        }, {
            readonly targetRef: "Order.updatedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend define updatedAt com o timestamp atual no momento da atualização do registro.";
        }];
        readonly acceptanceAssertions: readonly ["O pedido selecionado deve ter status 'ready' antes de poder ser marcado como entregue.", "Após a confirmação, o pedido existe com status 'delivered'.", "Após a confirmação, o campo deliveredAt do pedido é preenchido com o momento da entrega.", "Após a confirmação, o campo updatedAt do pedido é atualizado com o momento da operação.", "Não é permitido marcar como entregue um pedido cujo status seja diferente de 'ready'."];
        readonly pageId: "orderLifecycle";
        readonly commandName: "deliverOrder";
        readonly bffName: "cafeFlow.orderLifecycle.deliverOrder";
        readonly capability: {
            readonly capabilityId: "orderLifecycle";
            readonly title: "Ciclo de vida do pedido";
            readonly actor: "atendente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationDeliverOrder;
}
declare module "_102045_/l4/operations/manageMenuItem.defs" {
    export const operationManageMenuItem: {
        readonly operationId: "manageMenuItem";
        readonly title: "Gerenciar item do cardápio";
        readonly actor: "gerente";
        readonly entity: "MenuItem";
        readonly kind: "update";
        readonly reads: readonly ["MenuItem", "MenuCategory", "MenuItemIngredient"];
        readonly writes: readonly ["MenuItem"];
        readonly rulesApplied: readonly ["simpleItemsOnly", "menuItemRequiresIngredient"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Atualizar os dados de um item do cardápio existente — nome, descrição, categoria, preço e status — para mantê-lo correto e disponível no POS.";
            readonly steps: readonly ["O gerente seleciona um item do cardápio na tela de gestão.", "O sistema carrega os dados atuais do item (nome, descrição, categoria, preço, tipo e status).", "O gerente edita os campos desejados e define o status (rascunho, ativo ou inativo).", "O sistema valida que o tipo do item é 'simple' e que, se for ativado, existe pelo menos um ingrediente de estoque vinculado.", "O sistema persiste as alterações atualizando updatedAt e, conforme o status, activatedAt ou inactivatedAt."];
            readonly outcome: "O item do cardápio é atualizado com os novos dados e o status reflete a disponibilidade no POS.";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "MenuItem";
            readonly keyField: "MenuItem.menuItemId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.menuCategoryId", "MenuItem.price", "MenuItem.itemType", "MenuItem.status", "MenuItem.activatedAt", "MenuItem.inactivatedAt", "MenuItem.updatedAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "menuItemId";
            readonly fieldRef: "MenuItem.menuItemId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Identificador do item do cardápio selecionado para edição";
        }, {
            readonly inputId: "name";
            readonly fieldRef: "MenuItem.name";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Nome do item do cardápio exibido no POS";
        }, {
            readonly inputId: "description";
            readonly fieldRef: "MenuItem.description";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Descrição detalhada do item do cardápio";
        }, {
            readonly inputId: "menuCategoryId";
            readonly fieldRef: "MenuItem.menuCategoryId";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Categoria de classificação à qual o item pertence";
        }, {
            readonly inputId: "price";
            readonly fieldRef: "MenuItem.price";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Preço de venda do item do cardápio";
        }, {
            readonly inputId: "itemType";
            readonly fieldRef: "MenuItem.itemType";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Tipo do item: deve ser 'simple' nesta fase";
        }, {
            readonly inputId: "status";
            readonly fieldRef: "MenuItem.status";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Status do item: rascunho, ativo ou inativo";
        }, {
            readonly inputId: "actorId";
            readonly fieldRef: "MenuItem.menuItemId";
            readonly required: true;
            readonly source: "actorSession";
            readonly description: "Identificador do gerente autenticado que realiza a alteração";
        }, {
            readonly inputId: "updatedAt";
            readonly fieldRef: "MenuItem.updatedAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Data e hora da última atualização do registro";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "MenuItem.menuItemId";
            readonly source: "selectedEntity";
            readonly originRef: "MenuItem.menuItemId";
            readonly description: "O backend resolve o menuItemId a partir do item atualmente selecionado na tela de gestão de cardápio";
        }, {
            readonly targetRef: "actorSession.actorId";
            readonly source: "actorSession";
            readonly originRef: "actorSession.actorId";
            readonly description: "O backend obtém o identificador do gerente a partir da sessão autenticada do usuário";
        }, {
            readonly targetRef: "MenuItem.updatedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend atribui o timestamp atual do sistema ao campo updatedAt no momento da persistência";
        }];
        readonly acceptanceAssertions: readonly ["Após a confirmação, o MenuItem existe com o nome, menuCategoryId e price informados pelo gerente.", "O itemType do MenuItem atualizado é 'simple', conforme a regra simpleItemsOnly.", "Se o status for alterado para 'active', o sistema verifica que existe pelo menos um MenuItemIngredient vinculado ao MenuItem, conforme a regra menuItemRequiresIngredient.", "Quando o status muda de 'draft' ou 'inactive' para 'active', o campo activatedAt é preenchido com o timestamp atual.", "Quando o status muda de 'active' para 'inactive', o campo inactivatedAt é preenchido com o timestamp atual.", "O campo updatedAt é sempre atualizado com o timestamp atual após a persistência."];
        readonly pageId: "menuItemLifecycle";
        readonly commandName: "manageMenuItem";
        readonly bffName: "cafeFlow.menuItemLifecycle.manageMenuItem";
        readonly capability: {
            readonly capabilityId: "menuItemLifecycle";
            readonly title: "Ciclo de vida do item de cardápio";
            readonly actor: "gerente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationManageMenuItem;
}
declare module "_102045_/l4/operations/manageStockItem.defs" {
    export const operationManageStockItem: {
        readonly operationId: "manageStockItem";
        readonly title: "Gerenciar itens de estoque";
        readonly actor: "gerente";
        readonly entity: "StockItem";
        readonly kind: "update";
        readonly reads: readonly ["StockItem"];
        readonly writes: readonly ["StockItem"];
        readonly rulesApplied: readonly ["lowStockAlertCalculation"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Atualizar os dados de um item de estoque existente — nome, unidade de medida e limite mínimo de alerta — para manter o cadastro de insumos confiável.";
            readonly steps: readonly ["O gerente seleciona um item de estoque existente na lista de insumos cadastrados.", "O sistema carrega os dados atuais do item (nome, unidade, limite mínimo).", "O gerente edita os campos desejados e confirma a atualização.", "O sistema persiste os novos valores e atualiza o timestamp updatedAt."];
            readonly outcome: "O item de estoque fica atualizado com os novos dados e o cálculo de alerta de estoque baixo passa a usar o novo limite mínimo configurado.";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "StockItem";
            readonly keyField: "StockItem.stockItemId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unit", "StockItem.minimumLevel", "StockItem.updatedAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "stockItemId";
            readonly fieldRef: "StockItem.stockItemId";
            readonly required: true;
            readonly source: "routeParam";
            readonly description: "Identificador do item de estoque a ser atualizado, obtido da rota de edição.";
        }, {
            readonly inputId: "name";
            readonly fieldRef: "StockItem.name";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Nome do ingrediente editado pelo gerente.";
        }, {
            readonly inputId: "unit";
            readonly fieldRef: "StockItem.unit";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Unidade de medida do ingrediente (kg, liter, portion ou unit).";
        }, {
            readonly inputId: "minimumLevel";
            readonly fieldRef: "StockItem.minimumLevel";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo.";
        }, {
            readonly inputId: "updatedAt";
            readonly fieldRef: "StockItem.updatedAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Data e hora da última atualização do item de estoque.";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "StockItem.stockItemId";
            readonly source: "routeParam";
            readonly originRef: "routeParam.stockItemId";
            readonly description: "O backend extrai o identificador do item de estoque do parâmetro de rota da tela de edição.";
        }, {
            readonly targetRef: "StockItem.updatedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend atribui automaticamente o timestamp atual no momento da persistência da atualização.";
        }];
        readonly acceptanceAssertions: readonly ["Após a confirmação, o StockItem existe com o nome, a unidade e o limite mínimo atualizados conforme os valores informados pelo gerente.", "Após a atualização, o campo StockItem.updatedAt reflete o timestamp atual do sistema.", "O cálculo do alerta de estoque baixo utiliza o novo valor de StockItem.minimumLevel atualizado para comparar com a quantidade atual em StockLevel."];
        readonly pageId: "manageStockItem";
        readonly commandName: "manageStockItem";
        readonly bffName: "cafeFlow.manageStockItem.manageStockItem";
        readonly capability: {
            readonly capabilityId: "manageStockItem";
            readonly title: "Gerenciar itens de estoque";
            readonly actor: "gerente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationManageStockItem;
}
declare module "_102045_/l4/operations/openShift.defs" {
    export const operationOpenShift: {
        readonly operationId: "openShift";
        readonly title: "Abrir turno diário";
        readonly actor: "gerente";
        readonly entity: "Shift";
        readonly kind: "create";
        readonly reads: readonly ["Shift"];
        readonly writes: readonly ["Shift"];
        readonly rulesApplied: readonly ["singleOpenShift"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Abrir o turno diário no início do expediente para iniciar o registro de pedidos do dia.";
            readonly steps: readonly ["O gerente solicita a abertura de um novo turno no início do expediente.", "O sistema verifica que não existe nenhum turno com status 'open' (regra singleOpenShift).", "O sistema cria um novo registro de Shift com status 'open', registrando o gerente e a data/hora de abertura.", "O turno fica ativo e pronto para receber pedidos."];
            readonly outcome: "Um novo turno é criado com status 'open', vinculado ao gerente responsável, permitindo o registro de pedidos do período.";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "Shift";
            readonly keyField: "Shift.shiftId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["Shift.shiftId", "Shift.status", "Shift.openedAt", "Shift.openedBy"];
        };
        readonly inputs: readonly [{
            readonly inputId: "notes";
            readonly fieldRef: "Shift.notes";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Observações gerais opcionais sobre o turno, informadas pelo gerente ao abrir.";
        }, {
            readonly inputId: "shiftId";
            readonly fieldRef: "Shift.shiftId";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Identificador único do turno, gerado automaticamente pelo sistema.";
        }, {
            readonly inputId: "status";
            readonly fieldRef: "Shift.status";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Situação inicial do turno, definida como 'open' no momento da criação.";
        }, {
            readonly inputId: "openedAt";
            readonly fieldRef: "Shift.openedAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Data e hora de abertura do turno, definida automaticamente como o momento atual.";
        }, {
            readonly inputId: "openedBy";
            readonly fieldRef: "Shift.openedBy";
            readonly required: true;
            readonly source: "actorSession";
            readonly description: "Identificador do gerente que abriu o turno, obtido da sessão ativa.";
        }, {
            readonly inputId: "createdAt";
            readonly fieldRef: "Shift.createdAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Data e hora de criação do registro, definida automaticamente como o momento atual.";
        }, {
            readonly inputId: "updatedAt";
            readonly fieldRef: "Shift.updatedAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Data e hora da última atualização do registro, definida automaticamente como o momento atual.";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Shift.shiftId";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.uuid";
            readonly description: "O backend gera um UUID para o novo turno no momento da criação.";
        }, {
            readonly targetRef: "Shift.status";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend define o status como 'open' fixamente na criação do turno.";
        }, {
            readonly targetRef: "Shift.openedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend registra o timestamp atual do servidor como data e hora de abertura do turno.";
        }, {
            readonly targetRef: "Shift.openedBy";
            readonly source: "actorSession";
            readonly originRef: "actorSession.actorId";
            readonly description: "O backend obtém o identificador do gerente autenticado a partir da sessão ativa.";
        }, {
            readonly targetRef: "Shift.createdAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend registra o timestamp atual do servidor como data de criação do registro.";
        }, {
            readonly targetRef: "Shift.updatedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend registra o timestamp atual do servidor como data da última atualização do registro.";
        }];
        readonly acceptanceAssertions: readonly ["Após a confirmação, existe um registro de Shift com status igual a 'open'.", "O campo Shift.openedBy corresponde ao identificador do gerente que executou a abertura.", "O campo Shift.openedAt contém a data e hora do momento da abertura.", "Não existe nenhum outro Shift com status 'open' além do recém-criado (regra singleOpenShift).", "Os campos Shift.closedAt, Shift.closedBy e Shift.totalApurado permanecem nulos após a abertura."];
        readonly pageId: "shiftLifecycle";
        readonly commandName: "openShift";
        readonly bffName: "cafeFlow.shiftLifecycle.openShift";
        readonly capability: {
            readonly capabilityId: "shiftLifecycle";
            readonly title: "Ciclo de vida do turno";
            readonly actor: "gerente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationOpenShift;
}
declare module "_102045_/l4/operations/requestAiPromoSuggestions.defs" {
    export const operationRequestAiPromoSuggestions: {
        readonly operationId: "requestAiPromoSuggestions";
        readonly title: "Solicitar sugestões de promoção por IA";
        readonly actor: "gerente";
        readonly entity: "Order";
        readonly kind: "query";
        readonly reads: readonly ["Order", "OrderItem", "StockLevel"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["aiPromoBasedOnLast7Days", "aiConsumesDomainData"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Obter sugestões de quais itens do cardápio promover com base nos dados de vendas dos últimos 7 dias, para planejar ações de marketing do próximo período.";
            readonly steps: readonly ["O gerente aciona o assistente IA solicitando sugestões de promoção", "O sistema agrega os dados de pedidos e itens vendidos dos últimos 7 dias, bem como os níveis atuais de estoque", "O assistente IA analisa os dados agregados do domínio e gera sugestões de promoção por item", "O gerente visualiza as sugestões geradas para decidir ações de marketing"];
            readonly outcome: "O gerente recebe sugestões de promoção baseadas exclusivamente nos dados de operação dos últimos 7 dias, sem acesso a fontes externas.";
        };
        readonly accessPattern: {
            readonly kind: "lookup";
            readonly entity: "Order";
            readonly keyField: "Order.orderId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Order.orderId", "Order.orderType", "Order.status", "Order.createdAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "actorId";
            readonly fieldRef: "Order.shiftId";
            readonly required: true;
            readonly source: "actorSession";
            readonly description: "Identidade do gerente que solicita as sugestões, para auditoria e contexto de permissão";
        }, {
            readonly inputId: "windowStart";
            readonly fieldRef: "Order.createdAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Data de início da janela de análise (7 dias antes do momento atual)";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Order.shiftId";
            readonly source: "actorSession";
            readonly originRef: "actorSession.actorId";
            readonly description: "O backend resolve o identificador do gerente a partir da sessão ativa para validar permissão e registrar auditoria da solicitação";
        }, {
            readonly targetRef: "Order.createdAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend calcula o início da janela de 7 dias subtraindo 7 dias do timestamp atual (systemDefault.now) para filtrar apenas pedidos dentro do período relevante";
        }];
        readonly acceptanceAssertions: readonly ["As sugestões de promoção retornadas são baseadas exclusivamente nos dados de pedidos dos últimos 7 dias calculados a partir do momento atual", "O assistente IA consome apenas dados agregados de pedidos (Order, OrderItem) e níveis de estoque (StockLevel) disponibilizados pelo domínio, sem acessar fontes externas", "A operação não altera nenhum registro de pedido, item ou estoque — é estritamente de leitura", "O resultado inclui sugestões de itens para promoção derivadas dos padrões de venda do período analisado"];
        readonly pageId: "requestAiPromoSuggestions";
        readonly commandName: "requestAiPromoSuggestions";
        readonly bffName: "cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions";
        readonly capability: {
            readonly capabilityId: "requestAiPromoSuggestions";
            readonly title: "Solicitar sugestões de promoção por IA";
            readonly actor: "gerente";
            readonly priority: "soon";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationRequestAiPromoSuggestions;
}
declare module "_102045_/l4/operations/requestAiSalesSummary.defs" {
    export const operationRequestAiSalesSummary: {
        readonly operationId: "requestAiSalesSummary";
        readonly title: "Solicitar resumo de vendas por IA";
        readonly actor: "gerente";
        readonly entity: "Order";
        readonly kind: "query";
        readonly reads: readonly ["Order", "OrderItem", "Shift", "StockLevel"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "aiConsumesDomainData", "topSellersFromDayOrders"];
        readonly story: {
            readonly actor: "Gerente";
            readonly goal: "Obter um resumo das vendas do dia gerado por IA para uma leitura rápida do desempenho sem precisar analisar os dados manualmente";
            readonly steps: readonly ["O gerente solicita o resumo de vendas do dia ao assistente IA", "O sistema identifica o turno atualmente aberto e agrega os pedidos do dia corrente", "O assistente IA processa os dados agregados de pedidos e estoque disponibilizados pelo domínio e gera o resumo de vendas"];
            readonly outcome: "O gerente recebe um resumo de vendas do turno/dia atual com indicadores de desempenho e itens mais vendidos";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly entity: "Order";
            readonly keyField: "Order.orderId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.createdAt", "Order.deliveredAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "shiftId";
            readonly fieldRef: "Order.shiftId";
            readonly required: true;
            readonly source: "activeLifecycleInstance";
            readonly description: "Turno atualmente aberto para filtrar apenas os pedidos do dia corrente";
        }, {
            readonly inputId: "actorId";
            readonly fieldRef: "Order.shiftId";
            readonly required: true;
            readonly source: "actorSession";
            readonly description: "Identificador do gerente autenticado que solicita o resumo";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Order.shiftId";
            readonly source: "activeLifecycleInstance";
            readonly originRef: "Shift.shiftId";
            readonly description: "Resolvido a partir do único Shift com status open, filtrando apenas pedidos do turno/dia corrente";
        }, {
            readonly targetRef: "Order.shiftId";
            readonly source: "actorSession";
            readonly originRef: "actorSession.actorId";
            readonly description: "Resolvido a partir da sessão autenticada do gerente para autorizar o acesso ao resumo de vendas";
        }];
        readonly acceptanceAssertions: readonly ["O resumo de vendas inclui apenas pedidos do turno atualmente aberto, excluindo pedidos de turnos anteriores", "O resumo apresenta os itens mais vendidos calculados a partir dos pedidos do dia corrente", "O assistente IA consome apenas dados agregados de pedidos e estoque disponibilizados pelo domínio, sem acessar fontes externas", "O resultado não permite consulta de períodos históricos ou consolidados de múltiplos turnos"];
        readonly pageId: "requestAiSalesSummary";
        readonly commandName: "requestAiSalesSummary";
        readonly bffName: "cafeFlow.requestAiSalesSummary.requestAiSalesSummary";
        readonly capability: {
            readonly capabilityId: "requestAiSalesSummary";
            readonly title: "Solicitar resumo de vendas por IA";
            readonly actor: "gerente";
            readonly priority: "soon";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationRequestAiSalesSummary;
}
declare module "_102045_/l4/operations/updateOrderStatus.defs" {
    export const operationUpdateOrderStatus: {
        readonly operationId: "updateOrderStatus";
        readonly title: "Atualizar status do pedido na cozinha";
        readonly actor: "cozinheiro";
        readonly entity: "Order";
        readonly kind: "update";
        readonly reads: readonly ["Order", "Shift"];
        readonly writes: readonly ["Order"];
        readonly rulesApplied: readonly ["orderStatusFlow", "inProgressBeforeReady"];
        readonly story: {
            readonly actor: "cozinheiro";
            readonly goal: "Atualizar o status de um pedido na fila da cozinha conforme avança o preparo";
            readonly steps: readonly ["O cozinheiro visualiza a fila de pedidos recebidos na cozinha", "Seleciona um pedido e marca como 'em preparo' ao iniciar o preparo", "Ao concluir o preparo, marca o pedido como 'pronto', avisando o atendente que pode entregar ao cliente"];
            readonly outcome: "O status do pedido é atualizado respeitando a sequência obrigatória received → inPreparation → ready, com os respectivos timestamps registrados, permitindo que o atendente acompanhe o progresso no painel";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "Order";
            readonly keyField: "Order.orderId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly [];
        };
        readonly inputs: readonly [{
            readonly inputId: "orderId";
            readonly fieldRef: "Order.orderId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Pedido selecionado pelo cozinheiro na fila da cozinha";
        }, {
            readonly inputId: "status";
            readonly fieldRef: "Order.status";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Novo status que o cozinheiro deseja atribuir ao pedido (inPreparation ou ready)";
        }, {
            readonly inputId: "shiftId";
            readonly fieldRef: "Order.shiftId";
            readonly required: true;
            readonly source: "activeLifecycleInstance";
            readonly description: "Turno aberto no momento da atualização, para validar que o pedido pertence ao turno atual";
        }, {
            readonly inputId: "inPreparationAt";
            readonly fieldRef: "Order.inPreparationAt";
            readonly required: false;
            readonly source: "systemDefault";
            readonly description: "Timestamp definido quando o status passa a inPreparation";
        }, {
            readonly inputId: "readyAt";
            readonly fieldRef: "Order.readyAt";
            readonly required: false;
            readonly source: "systemDefault";
            readonly description: "Timestamp definido quando o status passa a ready";
        }, {
            readonly inputId: "updatedAt";
            readonly fieldRef: "Order.updatedAt";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Timestamp da última atualização do registro";
        }];
        readonly contextResolution: readonly [{
            readonly inputId: "shiftId";
            readonly targetRef: "Order.shiftId";
            readonly source: "activeLifecycleInstance";
            readonly originRef: "Shift.shiftId";
            readonly description: "Resolve o turno atualmente aberto (single Shift with status open) para validar que o pedido pertence ao turno ativo";
        }, {
            readonly inputId: "inPreparationAt";
            readonly targetRef: "Order.inPreparationAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "Define o timestamp atual quando o status transita para inPreparation";
        }, {
            readonly inputId: "readyAt";
            readonly targetRef: "Order.readyAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "Define o timestamp atual quando o status transita para ready";
        }, {
            readonly inputId: "updatedAt";
            readonly targetRef: "Order.updatedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "Define o timestamp atual em toda atualização do registro";
        }];
        readonly acceptanceAssertions: readonly ["Após a confirmação, o pedido existe com o novo status informado (inPreparation ou ready)", "O pedido só pode ser marcado como inPreparation se o status atual for received", "O pedido só pode ser marcado como ready se o status atual for inPreparation", "O fluxo de status segue obrigatoriamente a sequência received → inPreparation → ready, sem permitir pulos de etapa", "O campo inPreparationAt é preenchido com o timestamp atual quando o status passa a inPreparation", "O campo readyAt é preenchido com o timestamp atual quando o status passa a ready", "O campo updatedAt é atualizado com o timestamp atual em toda alteração de status", "O pedido atualizado pertence ao turno atualmente aberto"];
        readonly pageId: "orderLifecycle";
        readonly commandName: "updateOrderStatus";
        readonly bffName: "cafeFlow.orderLifecycle.updateOrderStatus";
        readonly capability: {
            readonly capabilityId: "orderLifecycle";
            readonly title: "Ciclo de vida do pedido";
            readonly actor: "cozinheiro";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationUpdateOrderStatus;
}
declare module "_102045_/l4/operations/viewDashboard.defs" {
    export const operationViewDashboard: {
        readonly operationId: "viewDashboard";
        readonly title: "Consultar dashboard do dia";
        readonly actor: "gerente";
        readonly entity: "Order";
        readonly kind: "view";
        readonly reads: readonly ["Order", "OrderItem", "StockLevel", "Shift"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "topSellersFromDayOrders"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Obter uma visão geral do dia operacional incluindo total de vendas, itens mais vendidos e alertas de estoque baixo do turno atual.";
            readonly steps: readonly ["O gerente abre o dashboard do dia", "O sistema identifica o turno atualmente aberto para filtrar os dados", "O sistema agrega os pedidos do turno atual calculando o total de vendas", "O sistema calcula os itens mais vendidos com base nos pedidos do dia", "O sistema verifica os níveis de estoque abaixo do mínimo configurado", "O dashboard exibe vendas do dia, itens mais vendidos e alertas de estoque baixo"];
            readonly outcome: "O gerente visualiza um painel consolidado com vendas do dia, itens mais vendidos e alertas de estoque baixo, restrito ao turno atual.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly description: "Lista agregada de pedidos do turno atual para composição do dashboard com total de vendas, itens mais vendidos e alertas de estoque baixo";
            readonly entity: "Order";
            readonly keyField: "Order.orderId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Order.status", "Order.orderType", "Order.createdAt", "Order.shiftId", "Order.deliveredAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "shiftId";
            readonly fieldRef: "Order.shiftId";
            readonly required: true;
            readonly source: "activeLifecycleInstance";
            readonly description: "Turno atualmente aberto, usado para filtrar todos os dados do dashboard";
        }, {
            readonly inputId: "actorId";
            readonly fieldRef: "Order.shiftId";
            readonly required: true;
            readonly source: "actorSession";
            readonly description: "Identificador do gerente autenticado que solicita o dashboard";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Order.shiftId";
            readonly source: "activeLifecycleInstance";
            readonly originRef: "Shift.shiftId";
            readonly description: "O backend localiza o único Shift com status aberto no momento e usa seu shiftId para filtrar todos os pedidos e dados agregados do dashboard";
        }, {
            readonly targetRef: "Order.shiftId";
            readonly source: "actorSession";
            readonly originRef: "actorSession.actorId";
            readonly description: "O backend extrai o actorId da sessão autenticada do gerente para autorizar o acesso ao dashboard";
        }];
        readonly acceptanceAssertions: readonly ["O dashboard exibe apenas pedidos cujo shiftId corresponde ao turno atualmente aberto, sem incluir dados de turnos anteriores", "O total de vendas do dia é calculado somando os pedidos do turno atual", "Os itens mais vendidos são calculados com base nos OrderItem dos pedidos do dia corrente, não incluindo dados históricos", "O dashboard exibe alertas de estoque baixo para itens cujo StockLevel está abaixo do mínimo configurado", "O dashboard não permite consulta de períodos históricos ou consolidação de múltiplos turnos"];
        readonly pageId: "viewDashboard";
        readonly commandName: "viewDashboard";
        readonly bffName: "cafeFlow.viewDashboard.viewDashboard";
        readonly capability: {
            readonly capabilityId: "viewDashboard";
            readonly title: "Consultar dashboard do dia";
            readonly actor: "gerente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationViewDashboard;
}
declare module "_102045_/l4/operations/viewKitchenBoard.defs" {
    export const operationViewKitchenBoard: {
        readonly operationId: "viewKitchenBoard";
        readonly title: "Visualizar fila da cozinha";
        readonly actor: "cozinheiro";
        readonly entity: "Order";
        readonly kind: "view";
        readonly reads: readonly ["Order", "OrderItem"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["fifoKitchenQueue", "dashboardCurrentShiftOnly"];
        readonly story: {
            readonly actor: "cozinheiro";
            readonly goal: "Ver a fila de pedidos recebidos na cozinha para saber o que precisa ser preparado e em que ordem.";
            readonly steps: readonly ["O cozinheiro abre a tela da fila da cozinha", "O sistema lista os pedidos do turno atual com status 'recebido' ou 'em preparo'", "Os pedidos são ordenados por ordem de chegada (receivedAt), com pedidos priorizados destacados primeiro", "Cada pedido exibe seus itens, tipo (mesa ou viagem), número da mesa quando aplicável e status atual"];
            readonly outcome: "O cozinheiro visualiza a fila completa de pedidos a preparar, em ordem de chegada, podendo selecionar um pedido para iniciar o preparo.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly entity: "Order";
            readonly keyField: "Order.orderId";
            readonly filters: readonly ["Order.status", "Order.shiftId"];
            readonly sort: readonly ["Order.priority", "Order.receivedAt"];
            readonly pagination: "optional";
            readonly selection: "single";
            readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.priority", "Order.priorityReason", "Order.receivedAt", "Order.inPreparationAt", "Order.createdAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "shiftId";
            readonly fieldRef: "Order.shiftId";
            readonly required: true;
            readonly source: "activeLifecycleInstance";
            readonly description: "Turno aberto no momento, usado para filtrar apenas pedidos do turno atual";
        }, {
            readonly inputId: "statusFilter";
            readonly fieldRef: "Order.status";
            readonly required: false;
            readonly source: "systemDefault";
            readonly description: "Filtro padrão de status: exibe pedidos com status 'received' ou 'inPreparation'";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Order.shiftId";
            readonly source: "activeLifecycleInstance";
            readonly originRef: "Shift.shiftId";
            readonly description: "Resolvido buscando o único Shift com status 'open' no momento da consulta, garantindo que apenas pedidos do turno atual sejam exibidos";
        }, {
            readonly targetRef: "Order.status";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O filtro de status é aplicado automaticamente pelo backend, restringindo a lista aos status 'received' e 'inPreparation' sem exigir entrada do usuário";
        }];
        readonly acceptanceAssertions: readonly ["A fila da cozinha exibe apenas pedidos cujo status seja 'received' ou 'inPreparation'", "Todos os pedidos listados pertencem ao turno atualmente aberto (mesmo shiftId)", "Os pedidos são ordenados por receivedAt em ordem crescente, com pedidos prioritários (priority=true) destacados primeiro", "Cada pedido na lista exibe orderId, status, orderType, tableNumber (quando aplicável), priority e os itens do pedido", "Pedidos com status 'ready' ou 'delivered' não aparecem na fila da cozinha"];
        readonly pageId: "orderLifecycle";
        readonly commandName: "viewKitchenBoard";
        readonly bffName: "cafeFlow.orderLifecycle.viewKitchenBoard";
        readonly capability: {
            readonly capabilityId: "orderLifecycle";
            readonly title: "Ciclo de vida do pedido";
            readonly actor: "cozinheiro";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationViewKitchenBoard;
}
declare module "_102045_/l4/operations/viewOrderBoard.defs" {
    export const operationViewOrderBoard: {
        readonly operationId: "viewOrderBoard";
        readonly title: "Visualizar painel de pedidos";
        readonly actor: "atendente";
        readonly entity: "Order";
        readonly kind: "view";
        readonly reads: readonly ["Order", "Shift"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "fifoKitchenQueue", "orderStatusFlow"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Consultar o painel de status dos pedidos em andamento no turno atual para saber quais estão em preparo e quais já estão prontos.";
            readonly steps: readonly ["O atendente abre o painel de pedidos no POS", "O sistema identifica o turno atualmente aberto e filtra apenas os pedidos daquele turno", "O sistema lista os pedidos ordenados por data de criação (ordem de chegada)", "O painel exibe cada pedido com seu status atual, tipo, mesa e indicador de prioridade"];
            readonly outcome: "O atendente visualiza todos os pedidos do turno atual com seus respectivos status, podendo identificar quais estão em preparo e quais já estão prontos para entrega.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly entity: "Order";
            readonly keyField: "Order.orderId";
            readonly pagination: "optional";
            readonly selection: "none";
            readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.priority", "Order.priorityReason", "Order.receivedAt", "Order.inPreparationAt", "Order.readyAt", "Order.createdAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "shiftId";
            readonly fieldRef: "Order.shiftId";
            readonly required: true;
            readonly source: "activeLifecycleInstance";
            readonly description: "Turno atualmente aberto para filtrar apenas pedidos do turno corrente";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Order.shiftId";
            readonly source: "activeLifecycleInstance";
            readonly originRef: "Shift.shiftId";
            readonly description: "O backend resolve o turno atualmente aberto consultando a única Shift com status open e utiliza seu shiftId para filtrar os pedidos exibidos no painel";
        }];
        readonly acceptanceAssertions: readonly ["O painel exibe apenas pedidos cujo shiftId corresponde ao turno atualmente aberto", "Os pedidos são listados ordenados por Order.createdAt em ordem crescente (FIFO)", "Cada pedido no painel mostra seu status atual entre registered, received, inPreparation, ready ou delivered", "Pedidos com Order.priority verdadeiro são exibidos com indicador visual de priorização", "O painel não exibe pedidos de turnos anteriores ou fechados"];
        readonly pageId: "orderLifecycle";
        readonly commandName: "viewOrderBoard";
        readonly bffName: "cafeFlow.orderLifecycle.viewOrderBoard";
        readonly capability: {
            readonly capabilityId: "orderLifecycle";
            readonly title: "Ciclo de vida do pedido";
            readonly actor: "atendente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationViewOrderBoard;
}
declare module "_102045_/l4/operations/viewShiftClosingReport.defs" {
    export const operationViewShiftClosingReport: {
        readonly operationId: "viewShiftClosingReport";
        readonly title: "Revisar relatório de fechamento de turno";
        readonly actor: "gerente";
        readonly entity: "ShiftClosingReport";
        readonly kind: "view";
        readonly reads: readonly ["ShiftClosingReport", "Shift"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["shiftClosingRecordsRevenue", "shiftClosingConsolidatesPaidOrders"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Revisar o relatório de fechamento de turno com o total apurado e os pedidos pagos consolidados para conferência do dia.";
            readonly steps: readonly ["O gerente seleciona um turno fechado na lista de turnos.", "O sistema localiza o relatório de fechamento correspondente ao shiftId informado.", "O sistema exibe o total apurado, a quantidade de pedidos pagos consolidados e as datas de criação e atualização do relatório."];
            readonly outcome: "O gerente visualiza o relatório de fechamento do turno com o total apurado e os pedidos pagos consolidados para conferência.";
        };
        readonly accessPattern: {
            readonly kind: "getById";
            readonly entity: "ShiftClosingReport";
            readonly keyField: "ShiftClosingReport.shiftId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["ShiftClosingReport.shiftClosingReportId", "ShiftClosingReport.shiftId", "ShiftClosingReport.totalApurado", "ShiftClosingReport.paidOrderCount", "ShiftClosingReport.createdAt", "ShiftClosingReport.updatedAt"];
        };
        readonly inputs: readonly [{
            readonly inputId: "shiftId";
            readonly fieldRef: "ShiftClosingReport.shiftId";
            readonly required: true;
            readonly source: "routeParam";
            readonly description: "Identificador do turno fechado cujo relatório de fechamento será exibido.";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "ShiftClosingReport.shiftId";
            readonly source: "routeParam";
            readonly originRef: "routeParam.shiftId";
            readonly description: "O shiftId é extraído do parâmetro de rota para localizar o único relatório de fechamento correspondente ao turno fechado.";
        }];
        readonly acceptanceAssertions: readonly ["O relatório de fechamento exibido contém o total apurado do turno para conferência do gerente.", "O relatório de fechamento exibido contém a quantidade de pedidos pagos consolidados no período do turno.", "O relatório exibido corresponde exclusivamente ao turno identificado pelo shiftId informado.", "O relatório exibido não inclui pedidos não pagos ou pedidos de outros turnos."];
        readonly pageId: "shiftLifecycle";
        readonly commandName: "viewShiftClosingReport";
        readonly bffName: "cafeFlow.shiftLifecycle.viewShiftClosingReport";
        readonly capability: {
            readonly capabilityId: "shiftLifecycle";
            readonly title: "Ciclo de vida do turno";
            readonly actor: "gerente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationViewShiftClosingReport;
}
declare module "_102045_/l4/rules/cafeFlowRules.defs" {
    export const cafeFlowRules: {
        readonly ruleSetId: "cafeFlowRules";
        readonly rules: readonly [{
            readonly ruleId: "stockDecrementOnOrderLaunch";
            readonly title: "Decréscimo de estoque no lançamento do pedido";
            readonly description: "O estoque deve ser decrementado no momento do lançamento do pedido, não na entrega, conforme os ingredientes vinculados a cada item do cardápio pedido.";
            readonly appliesTo: readonly ["StockConsumption", "StockLevel", "Order"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "simpleItemsOnly";
            readonly title: "Apenas itens simples suportados";
            readonly description: "Apenas itens simples podem ser lançados e cadastrados no cardápio nesta fase; variantes devem ser cadastradas como itens separados, não como sub-opções de um mesmo item.";
            readonly appliesTo: readonly ["MenuItem", "OrderItem"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "insufficientStockAlertBeforeConfirm";
            readonly title: "Alerta de estoque insuficiente antes de confirmar";
            readonly description: "Se um item não tiver estoque suficiente, o atendente deve ser alertado antes de confirmar o pedido, impedindo o lançamento de itens sem cobertura de estoque.";
            readonly appliesTo: readonly ["StockLevel", "OrderItem"];
            readonly layer: "application";
        }, {
            readonly ruleId: "orderStatusFlow";
            readonly title: "Fluxo de status do pedido";
            readonly description: "O fluxo de status do pedido deve seguir obrigatoriamente a sequência: recebido → em preparo → pronto → entregue, sem permitir pulos de etapa.";
            readonly appliesTo: readonly ["Order"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "readyBeforeDelivered";
            readonly title: "Pedido pronto antes de entregue";
            readonly description: "Apenas pedidos cujo status atual seja 'pronto' podem ser marcados como 'entregue', proibindo a entrega de pedidos ainda em preparo ou recém-recebidos.";
            readonly appliesTo: readonly ["Order"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "inProgressBeforeReady";
            readonly title: "Marcar em preparo antes de pronto";
            readonly description: "O cozinheiro deve marcar o pedido como 'em preparo' antes de poder marcá-lo como 'pronto', garantindo que o preparo seja explicitamente iniciado.";
            readonly appliesTo: readonly ["Order"];
            readonly layer: "application";
        }, {
            readonly ruleId: "fifoKitchenQueue";
            readonly title: "Ordem de chegada na cozinha";
            readonly description: "Pedidos devem ser preparados na ordem de chegada, salvo quando houver priorização justificada, garantindo atendimento sequencial padrão na fila da cozinha.";
            readonly appliesTo: readonly ["Order"];
            readonly layer: "application";
        }, {
            readonly ruleId: "menuItemRequiresIngredient";
            readonly title: "Item do cardápio exige ingrediente vinculado";
            readonly description: "Um item do cardápio só pode ser ativado se tiver pelo menos um ingrediente de estoque vinculado, impedindo a ativação de itens sem rastreabilidade de consumo.";
            readonly appliesTo: readonly ["MenuItem", "MenuItemIngredient"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "lowStockAlertCalculation";
            readonly title: "Cálculo do alerta de estoque baixo";
            readonly description: "O alerta de estoque baixo deve ser calculado comparando a quantidade atual ao mínimo configurado por item de estoque, disparando aviso quando o atual atingir ou ficar abaixo do mínimo.";
            readonly appliesTo: readonly ["StockLevel", "StockItem"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "dashboardCurrentShiftOnly";
            readonly title: "Dashboard limitado ao turno/dia atual";
            readonly description: "O dashboard deve exibir apenas dados do turno ou dia atual, não permitindo consulta de períodos históricos ou consolidados de múltiplos turnos.";
            readonly appliesTo: readonly ["Shift", "Order"];
            readonly layer: "application";
        }, {
            readonly ruleId: "topSellersFromDayOrders";
            readonly title: "Itens mais vendidos calculados do dia";
            readonly description: "Os itens mais vendidos devem ser calculados com base nos pedidos do dia corrente, refletindo apenas o período atual e não dados históricos acumulados.";
            readonly appliesTo: readonly ["Order", "OrderItem"];
            readonly layer: "application";
        }, {
            readonly ruleId: "shiftClosingRecordsRevenue";
            readonly title: "Fechamento de turno registra valor apurado";
            readonly description: "O fechamento de turno deve registrar o valor apurado para conferência, sem realizar conciliação bancária, limitando-se ao registro do total apurado no período.";
            readonly appliesTo: readonly ["Shift", "ShiftClosingReport"];
            readonly layer: "application";
        }, {
            readonly ruleId: "shiftClosingConsolidatesPaidOrders";
            readonly title: "Relatório consolida pedidos pagos do turno";
            readonly description: "O relatório de fechamento deve consolidar apenas os pedidos pagos dentro do período do turno, excluindo pedidos não pagos ou de outros turnos.";
            readonly appliesTo: readonly ["ShiftClosingReport", "Order"];
            readonly layer: "application";
        }, {
            readonly ruleId: "singleOpenShift";
            readonly title: "Apenas um turno aberto por vez";
            readonly description: "Apenas um turno pode estar aberto por vez em toda a operação, impedindo a abertura simultânea de múltiplos turnos concorrentes.";
            readonly appliesTo: readonly ["Shift"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "aiConsumesDomainData";
            readonly title: "Assistente IA consome dados do domínio";
            readonly description: "O assistente IA deve consumir apenas dados agregados de pedidos e estoque disponibilizados pelo domínio, sem acessar diretamente fontes externas ou dados não expostos pelo módulo.";
            readonly appliesTo: readonly ["Order", "StockLevel"];
            readonly layer: "application";
        }, {
            readonly ruleId: "aiPromoBasedOnLast7Days";
            readonly title: "Sugestões de promoção baseadas em 7 dias";
            readonly description: "As sugestões de promoção geradas pelo assistente IA devem ser baseadas exclusivamente nos dados dos últimos 7 dias de operação, não considerando períodos mais longos.";
            readonly appliesTo: readonly ["Order"];
            readonly layer: "application";
        }];
    };
    export default cafeFlowRules;
}
declare module "_102045_/l4/workflows/menuItemLifecycle.defs" {
    export const workflowMenuItemLifecycle: {
        readonly workflowId: "menuItemLifecycle";
        readonly title: "Ciclo de vida do item de cardápio";
        readonly executionMode: "sequential";
        readonly trigger: "Gerente inicia o cadastro de um novo item de cardápio no sistema";
        readonly actors: readonly ["gerente"];
        readonly states: readonly ["draft", "active", "inactive"];
        readonly transitions: readonly [{
            readonly from: "draft";
            readonly to: "active";
            readonly on: "manageMenuItem";
            readonly by: "gerente";
            readonly guard: "Item deve ter pelo menos um ingrediente de estoque vinculado e ser do tipo simples";
        }, {
            readonly from: "active";
            readonly to: "inactive";
            readonly on: "manageMenuItem";
            readonly by: "gerente";
        }, {
            readonly from: "inactive";
            readonly to: "active";
            readonly on: "manageMenuItem";
            readonly by: "gerente";
            readonly guard: "Item deve ter pelo menos um ingrediente de estoque vinculado";
        }];
        readonly operationIds: readonly ["manageMenuItem", "browseMenuItems"];
        readonly entities: readonly ["MenuItem", "MenuCategory", "MenuItemIngredient", "StockItem"];
        readonly rulesApplied: readonly ["simpleItemsOnly", "menuItemRequiresIngredient"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Cadastrar e manter os itens do cardápio com categoria, preço e vínculo aos ingredientes de estoque";
            readonly steps: readonly ["O gerente cria um novo item de cardápio definindo nome, categoria e preço de venda.", "O gerente vincula os ingredientes de estoque que o item consome para garantir a rastreabilidade de consumo.", "O gerente ativa o item para que ele fique disponível para lançamento no POS.", "O gerente pode inativar o item quando ele não deve mais aparecer no POS."];
            readonly outcome: "Item do cardápio disponível no POS com vínculo de ingredientes configurado";
        };
        readonly pageId: "menuItemLifecycle";
        readonly capabilities: readonly [{
            readonly capabilityId: "menuItemLifecycle";
            readonly title: "Ciclo de vida do item de cardápio";
            readonly actor: "gerente";
            readonly priority: "now";
        }];
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default workflowMenuItemLifecycle;
}
declare module "_102045_/l4/workflows/orderLifecycle.defs" {
    export const workflowOrderLifecycle: {
        readonly workflowId: "orderLifecycle";
        readonly title: "Ciclo de vida do pedido";
        readonly executionMode: "sequential";
        readonly trigger: "Atendente lança um novo pedido no POS selecionando tipo e itens do cardápio";
        readonly actors: readonly ["atendente", "cozinheiro"];
        readonly states: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
        readonly transitions: readonly [{
            readonly from: "registered";
            readonly to: "received";
            readonly on: "createOrder";
            readonly by: "atendente";
            readonly guard: "Estoque deve ser suficiente para todos os itens do pedido antes da confirmação";
        }, {
            readonly from: "received";
            readonly to: "inPreparation";
            readonly on: "updateOrderStatus";
            readonly by: "cozinheiro";
            readonly guard: "Pedidos devem ser preparados na ordem de chegada, salvo priorização justificada";
        }, {
            readonly from: "inPreparation";
            readonly to: "ready";
            readonly on: "updateOrderStatus";
            readonly by: "cozinheiro";
            readonly guard: "O pedido deve estar em preparo antes de ser marcado como pronto";
        }, {
            readonly from: "ready";
            readonly to: "delivered";
            readonly on: "deliverOrder";
            readonly by: "atendente";
            readonly guard: "Apenas pedidos com status 'pronto' podem ser marcados como entregues";
        }];
        readonly operationIds: readonly ["createOrder", "updateOrderStatus", "deliverOrder", "viewOrderBoard", "viewKitchenBoard"];
        readonly entities: readonly ["Order", "OrderItem", "StockConsumption", "StockLevel", "Shift"];
        readonly rulesApplied: readonly ["stockDecrementOnOrderLaunch", "orderStatusFlow", "readyBeforeDelivered", "inProgressBeforeReady", "fifoKitchenQueue"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Registrar e acompanhar um pedido desde o lançamento no POS até a entrega ao cliente";
            readonly steps: readonly ["O atendente seleciona o tipo de pedido (mesa ou takeout) e adiciona os itens do cardápio solicitados pelo cliente.", "O atendente revisa o resumo do pedido, verifica alertas de estoque insuficiente e confirma, enviando à cozinha com o estoque decrementado conforme ingredientes vinculados.", "O cozinheiro visualiza a fila de pedidos recebidos na cozinha e inicia o preparo, marcando o pedido como 'em preparo'.", "Ao concluir o preparo, o cozinheiro marca o pedido como 'pronto', sinalizando o atendente pelo painel de status.", "O atendente consulta o painel de pedidos, confirma o status 'pronto' e entrega o pedido ao cliente, marcando-o como entregue."];
            readonly outcome: "Pedido entregue ao cliente com status finalizado e estoque atualizado conforme os ingredientes consumidos no preparo";
        };
        readonly pageId: "orderLifecycle";
        readonly capabilities: readonly [{
            readonly capabilityId: "orderLifecycle";
            readonly title: "Ciclo de vida do pedido";
            readonly actor: "atendente";
            readonly priority: "now";
        }];
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default workflowOrderLifecycle;
}
declare module "_102045_/l4/workflows/shiftLifecycle.defs" {
    export const workflowShiftLifecycle: {
        readonly workflowId: "shiftLifecycle";
        readonly title: "Ciclo de vida do turno";
        readonly executionMode: "sequential";
        readonly trigger: "Gerente abre o turno diário no início do expediente para iniciar o registro de pedidos";
        readonly actors: readonly ["gerente"];
        readonly states: readonly ["open", "closed"];
        readonly transitions: readonly [{
            readonly from: "open";
            readonly to: "closed";
            readonly on: "closeShift";
            readonly by: "gerente";
            readonly guard: "O turno deve estar aberto e apenas um turno pode estar aberto por vez";
        }, {
            readonly from: "closed";
            readonly to: "closed";
            readonly on: "viewShiftClosingReport";
            readonly by: "gerente";
        }];
        readonly operationIds: readonly ["openShift", "closeShift", "viewShiftClosingReport"];
        readonly entities: readonly ["Shift", "ShiftClosingReport", "Order"];
        readonly rulesApplied: readonly ["singleOpenShift", "shiftClosingRecordsRevenue", "shiftClosingConsolidatesPaidOrders"];
        readonly story: {
            readonly actor: "gerente";
            readonly goal: "Abrir e fechar o turno diário, gerando o relatório de fechamento para conferência";
            readonly steps: readonly ["O gerente abre o turno diário no início do expediente para iniciar o registro de pedidos do dia.", "Ao final do expediente, o gerente fecha o turno para consolidar os pedidos do período e registrar o valor apurado.", "O gerente revisa o relatório de fechamento com o total apurado e os pedidos pagos consolidados para conferência do dia."];
            readonly outcome: "Turno fechado com relatório consolidado disponível para conferência do gerente";
        };
        readonly pageId: "shiftLifecycle";
        readonly capabilities: readonly [{
            readonly capabilityId: "shiftLifecycle";
            readonly title: "Ciclo de vida do turno";
            readonly actor: "gerente";
            readonly priority: "now";
        }];
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default workflowShiftLifecycle;
}
declare module "_102045_/l5/runtimeConfig" {
    import type { ProjectsConfig } from "_102029_/l2/runtimeConfigTypes";
    export const runtimeConfig: ProjectsConfig;
}
declare module "_102045_/l5/cafeFlow/process.defs" {
    export const cafeFlowProcess: {
        readonly schemaVersion: "2026-06-25";
        readonly moduleName: "cafeFlow";
        readonly runs: readonly [{
            readonly runId: "ns3-1783487246951";
            readonly kind: "newSolution3-behavior";
            readonly startedAt: "2026-07-08T05:07:26.950Z";
            readonly finishedAt: "2026-07-08T05:07:26.951Z";
            readonly sourceRefs: {
                readonly module: "l4/cafeFlow/module.defs.ts";
                readonly health: "l4/trace/behavior-health-report.json";
                readonly journeys: "l4/cafeFlow/journeys/cafeFlowJourneys.defs.ts";
                readonly todoFrontend: "l5/cafeFlow/todoFrontend.defs.ts";
                readonly todoBackend: "l5/cafeFlow/todoBackend.defs.ts";
            };
            readonly handoffNotes: readonly ["capability.multiowned: capability 'orderLifecycle' is owned by 2 workspaces (kitchenQueue, posWorkspace)"];
            readonly nextSteps: readonly [{
                readonly id: "stage2-experience";
                readonly kind: "workflowExperience";
                readonly title: "Generate frontend experience (@@changeFrontend)";
                readonly description: "Materialize l2 pages from the l4 behavior model.";
                readonly status: "pending";
            }, {
                readonly id: "stage3-backend";
                readonly kind: "backendImplementation";
                readonly title: "Generate backend (@@changeBackend)";
                readonly description: "Materialize l1 hexagonal backend from the l4 behavior model.";
                readonly status: "pending";
            }];
        }];
    };
    export default cafeFlowProcess;
}
declare module "_102045_/l5/cafeFlow/todoBackend.defs" {
    export const cafeFlowTodoBackend: {
        readonly schemaVersion: "2026-07-02-layer-todo";
        readonly moduleName: "cafeFlow";
        readonly layer: "backend";
        readonly updatedAt: "2026-07-16T00:24:11.086Z";
        readonly owners: readonly [{
            readonly ownerType: "workflow";
            readonly ownerId: "orderLifecycle";
            readonly title: "Ciclo de vida do pedido";
            readonly status: "inProgress";
            readonly defPath: "l4/workflows/orderLifecycle.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "workflow";
            readonly ownerId: "menuItemLifecycle";
            readonly title: "Ciclo de vida do item de cardápio";
            readonly status: "inProgress";
            readonly defPath: "l4/workflows/menuItemLifecycle.defs.ts";
            readonly pageId: "menuItemLifecycle";
            readonly capabilityId: "menuItemLifecycle";
        }, {
            readonly ownerType: "workflow";
            readonly ownerId: "shiftLifecycle";
            readonly title: "Ciclo de vida do turno";
            readonly status: "inProgress";
            readonly defPath: "l4/workflows/shiftLifecycle.defs.ts";
            readonly pageId: "shiftLifecycle";
            readonly capabilityId: "shiftLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "createOrder";
            readonly title: "Lançar pedido no POS";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/createOrder.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "createOrder";
            readonly bffName: "cafeFlow.orderLifecycle.createOrder";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "updateOrderStatus";
            readonly title: "Atualizar status do pedido na cozinha";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/updateOrderStatus.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "updateOrderStatus";
            readonly bffName: "cafeFlow.orderLifecycle.updateOrderStatus";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "deliverOrder";
            readonly title: "Entregar pedido ao cliente";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/deliverOrder.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "deliverOrder";
            readonly bffName: "cafeFlow.orderLifecycle.deliverOrder";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewOrderBoard";
            readonly title: "Visualizar painel de pedidos";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/viewOrderBoard.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "viewOrderBoard";
            readonly bffName: "cafeFlow.orderLifecycle.viewOrderBoard";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewKitchenBoard";
            readonly title: "Visualizar fila da cozinha";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/viewKitchenBoard.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "viewKitchenBoard";
            readonly bffName: "cafeFlow.orderLifecycle.viewKitchenBoard";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "manageMenuItem";
            readonly title: "Gerenciar item do cardápio";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/manageMenuItem.defs.ts";
            readonly pageId: "menuItemLifecycle";
            readonly commandName: "manageMenuItem";
            readonly bffName: "cafeFlow.menuItemLifecycle.manageMenuItem";
            readonly capabilityId: "menuItemLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseMenuItems";
            readonly title: "Consultar itens do cardápio";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/browseMenuItems.defs.ts";
            readonly pageId: "menuItemLifecycle";
            readonly commandName: "browseMenuItems";
            readonly bffName: "cafeFlow.menuItemLifecycle.browseMenuItems";
            readonly capabilityId: "menuItemLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "manageStockItem";
            readonly title: "Gerenciar itens de estoque";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/manageStockItem.defs.ts";
            readonly pageId: "manageStockItem";
            readonly commandName: "manageStockItem";
            readonly bffName: "cafeFlow.manageStockItem.manageStockItem";
            readonly capabilityId: "manageStockItem";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseStockItems";
            readonly title: "Consultar itens de estoque e alertas";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/browseStockItems.defs.ts";
            readonly pageId: "browseStockItems";
            readonly commandName: "browseStockItems";
            readonly bffName: "cafeFlow.browseStockItems.browseStockItems";
            readonly capabilityId: "browseStockItems";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewDashboard";
            readonly title: "Consultar dashboard do dia";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/viewDashboard.defs.ts";
            readonly pageId: "viewDashboard";
            readonly commandName: "viewDashboard";
            readonly bffName: "cafeFlow.viewDashboard.viewDashboard";
            readonly capabilityId: "viewDashboard";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "openShift";
            readonly title: "Abrir turno diário";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/openShift.defs.ts";
            readonly pageId: "shiftLifecycle";
            readonly commandName: "openShift";
            readonly bffName: "cafeFlow.shiftLifecycle.openShift";
            readonly capabilityId: "shiftLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "closeShift";
            readonly title: "Fechar turno diário";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/closeShift.defs.ts";
            readonly pageId: "shiftLifecycle";
            readonly commandName: "closeShift";
            readonly bffName: "cafeFlow.shiftLifecycle.closeShift";
            readonly capabilityId: "shiftLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewShiftClosingReport";
            readonly title: "Revisar relatório de fechamento de turno";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/viewShiftClosingReport.defs.ts";
            readonly pageId: "shiftLifecycle";
            readonly commandName: "viewShiftClosingReport";
            readonly bffName: "cafeFlow.shiftLifecycle.viewShiftClosingReport";
            readonly capabilityId: "shiftLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "requestAiSalesSummary";
            readonly title: "Solicitar resumo de vendas por IA";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/requestAiSalesSummary.defs.ts";
            readonly pageId: "requestAiSalesSummary";
            readonly commandName: "requestAiSalesSummary";
            readonly bffName: "cafeFlow.requestAiSalesSummary.requestAiSalesSummary";
            readonly capabilityId: "requestAiSalesSummary";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "requestAiPromoSuggestions";
            readonly title: "Solicitar sugestões de promoção por IA";
            readonly status: "inProgress";
            readonly defPath: "l4/operations/requestAiPromoSuggestions.defs.ts";
            readonly pageId: "requestAiPromoSuggestions";
            readonly commandName: "requestAiPromoSuggestions";
            readonly bffName: "cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions";
            readonly capabilityId: "requestAiPromoSuggestions";
        }];
    };
    export default cafeFlowTodoBackend;
}
declare module "_102045_/l5/cafeFlow/todoFrontend.defs" {
    export const cafeFlowTodoFrontend: {
        readonly schemaVersion: "2026-07-02-layer-todo";
        readonly moduleName: "cafeFlow";
        readonly layer: "frontend";
        readonly variants: 3;
        readonly updatedAt: "2026-07-15T23:40:28.899Z";
        readonly owners: readonly [{
            readonly ownerType: "workflow";
            readonly ownerId: "orderLifecycle";
            readonly title: "Ciclo de vida do pedido";
            readonly status: "done";
            readonly defPath: "l4/workflows/orderLifecycle.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "workflow";
            readonly ownerId: "menuItemLifecycle";
            readonly title: "Ciclo de vida do item de cardápio";
            readonly status: "done";
            readonly defPath: "l4/workflows/menuItemLifecycle.defs.ts";
            readonly pageId: "menuItemLifecycle";
            readonly capabilityId: "menuItemLifecycle";
        }, {
            readonly ownerType: "workflow";
            readonly ownerId: "shiftLifecycle";
            readonly title: "Ciclo de vida do turno";
            readonly status: "done";
            readonly defPath: "l4/workflows/shiftLifecycle.defs.ts";
            readonly pageId: "shiftLifecycle";
            readonly capabilityId: "shiftLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "createOrder";
            readonly title: "Lançar pedido no POS";
            readonly status: "done";
            readonly defPath: "l4/operations/createOrder.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "createOrder";
            readonly bffName: "cafeFlow.orderLifecycle.createOrder";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "updateOrderStatus";
            readonly title: "Atualizar status do pedido na cozinha";
            readonly status: "done";
            readonly defPath: "l4/operations/updateOrderStatus.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "updateOrderStatus";
            readonly bffName: "cafeFlow.orderLifecycle.updateOrderStatus";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "deliverOrder";
            readonly title: "Entregar pedido ao cliente";
            readonly status: "done";
            readonly defPath: "l4/operations/deliverOrder.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "deliverOrder";
            readonly bffName: "cafeFlow.orderLifecycle.deliverOrder";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewOrderBoard";
            readonly title: "Visualizar painel de pedidos";
            readonly status: "done";
            readonly defPath: "l4/operations/viewOrderBoard.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "viewOrderBoard";
            readonly bffName: "cafeFlow.orderLifecycle.viewOrderBoard";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewKitchenBoard";
            readonly title: "Visualizar fila da cozinha";
            readonly status: "done";
            readonly defPath: "l4/operations/viewKitchenBoard.defs.ts";
            readonly pageId: "orderLifecycle";
            readonly commandName: "viewKitchenBoard";
            readonly bffName: "cafeFlow.orderLifecycle.viewKitchenBoard";
            readonly capabilityId: "orderLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "manageMenuItem";
            readonly title: "Gerenciar item do cardápio";
            readonly status: "done";
            readonly defPath: "l4/operations/manageMenuItem.defs.ts";
            readonly pageId: "menuItemLifecycle";
            readonly commandName: "manageMenuItem";
            readonly bffName: "cafeFlow.menuItemLifecycle.manageMenuItem";
            readonly capabilityId: "menuItemLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseMenuItems";
            readonly title: "Consultar itens do cardápio";
            readonly status: "done";
            readonly defPath: "l4/operations/browseMenuItems.defs.ts";
            readonly pageId: "menuItemLifecycle";
            readonly commandName: "browseMenuItems";
            readonly bffName: "cafeFlow.menuItemLifecycle.browseMenuItems";
            readonly capabilityId: "menuItemLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "manageStockItem";
            readonly title: "Gerenciar itens de estoque";
            readonly status: "done";
            readonly defPath: "l4/operations/manageStockItem.defs.ts";
            readonly pageId: "manageStockItem";
            readonly commandName: "manageStockItem";
            readonly bffName: "cafeFlow.manageStockItem.manageStockItem";
            readonly capabilityId: "manageStockItem";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseStockItems";
            readonly title: "Consultar itens de estoque e alertas";
            readonly status: "done";
            readonly defPath: "l4/operations/browseStockItems.defs.ts";
            readonly pageId: "browseStockItems";
            readonly commandName: "browseStockItems";
            readonly bffName: "cafeFlow.browseStockItems.browseStockItems";
            readonly capabilityId: "browseStockItems";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewDashboard";
            readonly title: "Consultar dashboard do dia";
            readonly status: "done";
            readonly defPath: "l4/operations/viewDashboard.defs.ts";
            readonly pageId: "viewDashboard";
            readonly commandName: "viewDashboard";
            readonly bffName: "cafeFlow.viewDashboard.viewDashboard";
            readonly capabilityId: "viewDashboard";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "openShift";
            readonly title: "Abrir turno diário";
            readonly status: "done";
            readonly defPath: "l4/operations/openShift.defs.ts";
            readonly pageId: "shiftLifecycle";
            readonly commandName: "openShift";
            readonly bffName: "cafeFlow.shiftLifecycle.openShift";
            readonly capabilityId: "shiftLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "closeShift";
            readonly title: "Fechar turno diário";
            readonly status: "done";
            readonly defPath: "l4/operations/closeShift.defs.ts";
            readonly pageId: "shiftLifecycle";
            readonly commandName: "closeShift";
            readonly bffName: "cafeFlow.shiftLifecycle.closeShift";
            readonly capabilityId: "shiftLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewShiftClosingReport";
            readonly title: "Revisar relatório de fechamento de turno";
            readonly status: "done";
            readonly defPath: "l4/operations/viewShiftClosingReport.defs.ts";
            readonly pageId: "shiftLifecycle";
            readonly commandName: "viewShiftClosingReport";
            readonly bffName: "cafeFlow.shiftLifecycle.viewShiftClosingReport";
            readonly capabilityId: "shiftLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "requestAiSalesSummary";
            readonly title: "Solicitar resumo de vendas por IA";
            readonly status: "done";
            readonly defPath: "l4/operations/requestAiSalesSummary.defs.ts";
            readonly pageId: "requestAiSalesSummary";
            readonly commandName: "requestAiSalesSummary";
            readonly bffName: "cafeFlow.requestAiSalesSummary.requestAiSalesSummary";
            readonly capabilityId: "requestAiSalesSummary";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "requestAiPromoSuggestions";
            readonly title: "Solicitar sugestões de promoção por IA";
            readonly status: "done";
            readonly defPath: "l4/operations/requestAiPromoSuggestions.defs.ts";
            readonly pageId: "requestAiPromoSuggestions";
            readonly commandName: "requestAiPromoSuggestions";
            readonly bffName: "cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions";
            readonly capabilityId: "requestAiPromoSuggestions";
        }];
    };
    export default cafeFlowTodoFrontend;
}
