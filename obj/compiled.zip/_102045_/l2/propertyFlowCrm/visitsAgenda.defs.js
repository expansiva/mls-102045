/// <mls fileReference="_102045_/l2/propertyFlowCrm/visitsAgenda.defs.ts" enhancement="_blank"/>
export const visitsAgendaPagePlan = {
    "schemaVersion": "2026-06-06",
    "artifactType": "page",
    "artifactId": "visitsAgenda",
    "moduleName": "propertyFlowCrm",
    "status": "draft",
    "source": {
        "agentName": "agentPlanPageDefinition",
        "stepId": 62,
        "planId": ""
    },
    "data": {
        "pageDefinition": {
            "pageId": "visitsAgenda",
            "pageName": "Agenda de visitas",
            "actor": "corretor",
            "purpose": "Agendar, confirmar, reagendar e cancelar visitas.",
            "capabilities": [
                "scheduleVisits"
            ],
            "flowRefs": {
                "experienceFlows": [],
                "entityLifecycles": [
                    "visitSchedulingFlow"
                ],
                "taskWorkflows": [],
                "automations": []
            },
            "pluginRefs": [],
            "mdmRefs": [
                "visit",
                "property",
                "lead"
            ],
            "pageInputs": [],
            "navigationRefs": [],
            "sections": [
                {
                    "sectionName": "Filtros e agenda",
                    "mode": "view",
                    "organisms": [
                        {
                            "organismName": "visitFilters",
                            "purpose": "Filtrar visitas por período, imóvel e lead.",
                            "userActions": [
                                "filtrarVisitas",
                                "limparFiltros"
                            ],
                            "requiredEntities": [
                                "Visit",
                                "Property",
                                "Lead"
                            ],
                            "readsFields": [
                                "Visit.visitId",
                                "Visit.status",
                                "Visit.scheduledAt",
                                "Visit.propertyId",
                                "Visit.leadId",
                                "Property.propertyId",
                                "Property.title",
                                "Lead.leadId",
                                "Lead.name"
                            ],
                            "writesFields": [],
                            "rulesApplied": [
                                "ruleVisitStatus"
                            ]
                        },
                        {
                            "organismName": "visitCalendarList",
                            "purpose": "Exibir visitas agendadas em lista/calendário.",
                            "userActions": [
                                "selecionarVisita",
                                "abrirDetalhesVisita"
                            ],
                            "requiredEntities": [
                                "Visit"
                            ],
                            "readsFields": [
                                "Visit.visitId",
                                "Visit.status",
                                "Visit.scheduledAt",
                                "Visit.propertyId",
                                "Visit.leadId"
                            ],
                            "writesFields": [],
                            "rulesApplied": [
                                "ruleVisitStatus"
                            ]
                        }
                    ]
                },
                {
                    "sectionName": "Novo agendamento",
                    "mode": "edit",
                    "organisms": [
                        {
                            "organismName": "visitScheduleForm",
                            "purpose": "Criar novo agendamento de visita.",
                            "userActions": [
                                "selecionarImovel",
                                "selecionarLead",
                                "definirDataHora",
                                "agendarVisita"
                            ],
                            "requiredEntities": [
                                "Property",
                                "Lead",
                                "VisitScheduleRequest"
                            ],
                            "readsFields": [
                                "Property.propertyId",
                                "Property.title",
                                "Lead.leadId",
                                "Lead.name"
                            ],
                            "writesFields": [
                                "VisitScheduleRequest.propertyId",
                                "VisitScheduleRequest.leadId",
                                "VisitScheduleRequest.requestedStartAt",
                                "VisitScheduleRequest.requestedEndAt",
                                "VisitScheduleRequest.notes"
                            ],
                            "rulesApplied": [
                                "ruleVisitStatus"
                            ]
                        }
                    ]
                },
                {
                    "sectionName": "Detalhes e ações da visita",
                    "mode": "view",
                    "organisms": [
                        {
                            "organismName": "visitDetailsPanel",
                            "purpose": "Visualizar detalhes da visita selecionada.",
                            "userActions": [
                                "carregarDetalhesVisita"
                            ],
                            "requiredEntities": [
                                "Visit"
                            ],
                            "readsFields": [
                                "Visit.visitId",
                                "Visit.status",
                                "Visit.scheduledAt",
                                "Visit.propertyId",
                                "Visit.leadId"
                            ],
                            "writesFields": [],
                            "rulesApplied": [
                                "ruleVisitStatus"
                            ]
                        },
                        {
                            "organismName": "visitStatusActions",
                            "purpose": "Confirmar, reagendar, finalizar ou cancelar visita.",
                            "userActions": [
                                "confirmarVisita",
                                "reagendarVisita",
                                "finalizarVisita",
                                "cancelarVisita"
                            ],
                            "requiredEntities": [
                                "VisitScheduleRequest",
                                "Visit"
                            ],
                            "readsFields": [
                                "Visit.visitId",
                                "Visit.status",
                                "Visit.scheduledAt"
                            ],
                            "writesFields": [
                                "VisitScheduleRequest.status",
                                "VisitScheduleRequest.requestedStartAt",
                                "VisitScheduleRequest.requestedEndAt"
                            ],
                            "rulesApplied": [
                                "ruleVisitStatus"
                            ]
                        }
                    ]
                },
                {
                    "sectionName": "Solicitações de agendamento",
                    "mode": "view",
                    "organisms": [
                        {
                            "organismName": "visitScheduleRequestsList",
                            "purpose": "Exibir histórico de solicitações de agendamento.",
                            "userActions": [
                                "listarSolicitacoesAgendamento",
                                "selecionarSolicitacao"
                            ],
                            "requiredEntities": [
                                "VisitScheduleRequest"
                            ],
                            "readsFields": [
                                "VisitScheduleRequest.visitScheduleRequestId",
                                "VisitScheduleRequest.status",
                                "VisitScheduleRequest.requestedStartAt",
                                "VisitScheduleRequest.propertyId",
                                "VisitScheduleRequest.leadId",
                                "VisitScheduleRequest.visitId"
                            ],
                            "writesFields": [],
                            "rulesApplied": [
                                "ruleVisitStatus"
                            ]
                        }
                    ]
                }
            ]
        },
        "bffCommands": [
            {
                "commandName": "listarVisitas",
                "purpose": "Carregar agenda e filtros de visitas.",
                "kind": "query",
                "input": [
                    {
                        "name": "dataInicio",
                        "type": "datetime",
                        "required": true
                    },
                    {
                        "name": "dataFim",
                        "type": "datetime",
                        "required": true
                    },
                    {
                        "name": "propertyId",
                        "type": "PropertyId",
                        "required": false
                    },
                    {
                        "name": "leadId",
                        "type": "LeadId",
                        "required": false
                    },
                    {
                        "name": "status",
                        "type": "string",
                        "required": false
                    }
                ],
                "output": [
                    {
                        "name": "visitId",
                        "type": "VisitId"
                    },
                    {
                        "name": "status",
                        "type": "string"
                    },
                    {
                        "name": "scheduledAt",
                        "type": "datetime"
                    },
                    {
                        "name": "propertyId",
                        "type": "PropertyId"
                    },
                    {
                        "name": "leadId",
                        "type": "LeadId"
                    }
                ],
                "readsEntities": [
                    "Visit"
                ],
                "writesEntities": [],
                "readsTables": [],
                "writesTables": [],
                "usecaseRefs": [
                    "listarVisitas"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": [
                    "ruleVisitStatus"
                ]
            },
            {
                "commandName": "agendarVisita",
                "purpose": "Criar novo agendamento.",
                "kind": "command",
                "input": [
                    {
                        "name": "propertyId",
                        "type": "PropertyId",
                        "required": true
                    },
                    {
                        "name": "leadId",
                        "type": "LeadId",
                        "required": true
                    },
                    {
                        "name": "requestedStartAt",
                        "type": "datetime",
                        "required": true
                    },
                    {
                        "name": "requestedEndAt",
                        "type": "datetime",
                        "required": false
                    },
                    {
                        "name": "notes",
                        "type": "string",
                        "required": false
                    }
                ],
                "output": [
                    {
                        "name": "visitId",
                        "type": "VisitId"
                    },
                    {
                        "name": "status",
                        "type": "string"
                    }
                ],
                "readsEntities": [
                    "Property",
                    "Lead"
                ],
                "writesEntities": [
                    "Visit",
                    "VisitScheduleRequest"
                ],
                "readsTables": [],
                "writesTables": [
                    "visit_schedule_request",
                    "broker_activity_metrics"
                ],
                "usecaseRefs": [
                    "agendarVisita"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": [
                    "ruleVisitStatus"
                ]
            },
            {
                "commandName": "obterVisita",
                "purpose": "Carregar detalhes de uma visita selecionada.",
                "kind": "query",
                "input": [
                    {
                        "name": "visitId",
                        "type": "VisitId",
                        "required": true
                    }
                ],
                "output": [
                    {
                        "name": "visitId",
                        "type": "VisitId"
                    },
                    {
                        "name": "status",
                        "type": "string"
                    },
                    {
                        "name": "scheduledAt",
                        "type": "datetime"
                    },
                    {
                        "name": "propertyId",
                        "type": "PropertyId"
                    },
                    {
                        "name": "leadId",
                        "type": "LeadId"
                    }
                ],
                "readsEntities": [
                    "Visit"
                ],
                "writesEntities": [],
                "readsTables": [],
                "writesTables": [],
                "usecaseRefs": [
                    "obterVisita"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": [
                    "ruleVisitStatus"
                ]
            },
            {
                "commandName": "atualizarStatusVisita",
                "purpose": "Atualizar status ou reagendar visita.",
                "kind": "command",
                "input": [
                    {
                        "name": "visitId",
                        "type": "VisitId",
                        "required": true
                    },
                    {
                        "name": "novoStatus",
                        "type": "string",
                        "required": true
                    },
                    {
                        "name": "requestedStartAt",
                        "type": "datetime",
                        "required": false
                    },
                    {
                        "name": "requestedEndAt",
                        "type": "datetime",
                        "required": false
                    }
                ],
                "output": [
                    {
                        "name": "visitId",
                        "type": "VisitId"
                    },
                    {
                        "name": "status",
                        "type": "string"
                    },
                    {
                        "name": "scheduledAt",
                        "type": "datetime"
                    }
                ],
                "readsEntities": [
                    "Visit"
                ],
                "writesEntities": [
                    "Visit",
                    "VisitScheduleRequest"
                ],
                "readsTables": [],
                "writesTables": [
                    "broker_activity_metrics"
                ],
                "usecaseRefs": [
                    "atualizarStatusVisita"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": [
                    "ruleVisitStatus"
                ]
            },
            {
                "commandName": "listarSolicitacoesAgendamentoVisita",
                "purpose": "Listar histórico de solicitações de agendamento.",
                "kind": "query",
                "input": [
                    {
                        "name": "dataInicio",
                        "type": "datetime",
                        "required": false
                    },
                    {
                        "name": "dataFim",
                        "type": "datetime",
                        "required": false
                    },
                    {
                        "name": "status",
                        "type": "string",
                        "required": false
                    },
                    {
                        "name": "propertyId",
                        "type": "PropertyId",
                        "required": false
                    },
                    {
                        "name": "leadId",
                        "type": "LeadId",
                        "required": false
                    }
                ],
                "output": [
                    {
                        "name": "visitScheduleRequestId",
                        "type": "VisitScheduleRequestId"
                    },
                    {
                        "name": "status",
                        "type": "string"
                    },
                    {
                        "name": "requestedStartAt",
                        "type": "datetime"
                    },
                    {
                        "name": "propertyId",
                        "type": "PropertyId"
                    },
                    {
                        "name": "leadId",
                        "type": "LeadId"
                    },
                    {
                        "name": "visitId",
                        "type": "VisitId"
                    }
                ],
                "readsEntities": [
                    "VisitScheduleRequest"
                ],
                "writesEntities": [],
                "readsTables": [
                    "visit_schedule_request"
                ],
                "writesTables": [],
                "usecaseRefs": [
                    "listarSolicitacoesAgendamentoVisita"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": [
                    "ruleVisitStatus"
                ]
            }
        ]
    }
};
export default visitsAgendaPagePlan;
