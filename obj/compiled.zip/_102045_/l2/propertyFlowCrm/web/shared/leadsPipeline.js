var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102045_/l2/propertyFlowCrm/web/shared/leadsPipeline.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Property Flow CRM',
    pageTitle: 'Pipeline de Leads',
    loaded: 'Dados carregados',
    couldNotLoad: 'Não foi possível carregar',
    loadingListarLeads: 'Carregando leads',
    loadingListarMudancasEtapaLead: 'Carregando mudanças de etapa',
    moverEtapaLeadLabel: 'Mover etapa',
    moverEtapaLeadLoading: 'Movendo etapa',
    couldNotMoverEtapaLead: 'Não foi possível mover etapa',
    criarLeadLabel: 'Criar lead',
    criarLeadLoading: 'Criando lead',
    couldNotCriarLead: 'Não foi possível criar lead',
    solicitarQualificacaoLeadLabel: 'Solicitar qualificação',
    solicitarQualificacaoLeadLoading: 'Solicitando qualificação',
    couldNotSolicitarQualificacaoLead: 'Não foi possível solicitar qualificação',
    navigateToLeadDetails: 'abrir detalhes do lead',
};
const message_en = {
    brand: 'Property Flow CRM',
    pageTitle: 'Leads Pipeline',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingListarLeads: 'Loading leads',
    loadingListarMudancasEtapaLead: 'Loading stage changes',
    moverEtapaLeadLabel: 'Move stage',
    moverEtapaLeadLoading: 'Moving stage',
    couldNotMoverEtapaLead: 'Could not move stage',
    criarLeadLabel: 'Create lead',
    criarLeadLoading: 'Creating lead',
    couldNotCriarLead: 'Could not create lead',
    solicitarQualificacaoLeadLabel: 'Request qualification',
    solicitarQualificacaoLeadLoading: 'Requesting qualification',
    couldNotSolicitarQualificacaoLead: 'Could not request qualification',
    navigateToLeadDetails: 'open lead details',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LeadsPipelineLeadsPipelineBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.leadsPipeline.leads',
            'ui.leadsPipeline.mudancasEtapaLead',
            'ui.leadsPipeline.moverEtapaLead',
            'ui.leadsPipeline.criarLead',
            'ui.leadsPipeline.solicitarQualificacaoLead',
        ];
        this.leads = [];
        this.mudancasEtapaLead = [];
        this.moverEtapaLeadState = 'idle';
        this.criarLeadState = 'idle';
        this.solicitarQualificacaoLeadState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.leadsPipeline.leads':
                this.leads = value ?? [];
                break;
            case 'ui.leadsPipeline.mudancasEtapaLead':
                this.mudancasEtapaLead = value ?? [];
                break;
            case 'ui.leadsPipeline.moverEtapaLead':
                this.moverEtapaLeadState = value ?? 'idle';
                break;
            case 'ui.leadsPipeline.criarLead':
                this.criarLeadState = value ?? 'idle';
                break;
            case 'ui.leadsPipeline.solicitarQualificacaoLead':
                this.solicitarQualificacaoLeadState = value ?? 'idle';
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadListarLeads(params, options);
        await this.loadListarMudancasEtapaLead(params, options);
    }
    async loadListarLeads(params, options) {
        if (window.mls) {
            this.leads = [
                {
                    leadId: 'id-001',
                    leadName: 'Ana Silva',
                    leadStage: 'novo',
                    leadTemperature: 'quente',
                    leadUpdatedAt: '2026-06-23',
                },
                {
                    leadId: 'id-002',
                    leadName: 'Bruno Lima',
                    leadStage: 'contato',
                    leadTemperature: 'morno',
                    leadUpdatedAt: '2026-06-22',
                },
            ];
            setState('ui.leadsPipeline.leads', this.leads);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.leadsPipeline.listarLeads', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.leads = response.data;
        setState('ui.leadsPipeline.leads', this.leads);
        this.status = this.msg.loaded;
    }
    async loadListarMudancasEtapaLead(params, options) {
        if (window.mls) {
            this.mudancasEtapaLead = [
                {
                    leadStageChangeId: 'id-001',
                    fromStage: 'novo',
                    toStage: 'contato',
                    changedAt: '2026-06-21',
                    changedByBrokerId: 'id-001',
                    note: 'Contato inicial realizado',
                },
                {
                    leadStageChangeId: 'id-002',
                    fromStage: 'contato',
                    toStage: 'visita',
                    changedAt: '2026-06-22',
                    changedByBrokerId: 'id-002',
                    note: 'Visita agendada',
                },
            ];
            setState('ui.leadsPipeline.mudancasEtapaLead', this.mudancasEtapaLead);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.leadsPipeline.listarMudancasEtapaLead', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.mudancasEtapaLead = response.data;
        setState('ui.leadsPipeline.mudancasEtapaLead', this.mudancasEtapaLead);
        this.status = this.msg.loaded;
    }
    async moverEtapaLead(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.leadsPipeline.moverEtapaLead', params);
            this.moverEtapaLeadState = 'success';
            setState('ui.leadsPipeline.moverEtapaLead', 'success');
            return;
        }
        this.moverEtapaLeadState = 'loading';
        setState('ui.leadsPipeline.moverEtapaLead', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.leadsPipeline.moverEtapaLead', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.moverEtapaLeadState = 'success';
            setState('ui.leadsPipeline.moverEtapaLead', 'success');
            await this.loadListarLeads(undefined, { mode: 'silent' });
        }
        catch (e) {
            this.moverEtapaLeadState = 'error';
            setState('ui.leadsPipeline.moverEtapaLead', 'error');
            throw e;
        }
    }
    handleMoverEtapaLeadClick() {
        const lead = this.leads[0];
        const params = {
            leadId: lead?.leadId ?? 'id-001',
            fromStage: lead?.leadStage ?? 'novo',
            toStage: 'contato',
        };
        void runBlockingUiAction(async (signal) => {
            await this.moverEtapaLead(params, signal);
        }, {
            busyLabel: this.msg.moverEtapaLeadLoading,
            errorTitle: this.msg.couldNotMoverEtapaLead,
            retry: () => this.moverEtapaLead(params),
        });
    }
    async criarLead(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.leadsPipeline.criarLead', params);
            this.criarLeadState = 'success';
            setState('ui.leadsPipeline.criarLead', 'success');
            return;
        }
        this.criarLeadState = 'loading';
        setState('ui.leadsPipeline.criarLead', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.leadsPipeline.criarLead', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.criarLeadState = 'success';
            setState('ui.leadsPipeline.criarLead', 'success');
            await this.loadListarLeads(undefined, { mode: 'silent' });
        }
        catch (e) {
            this.criarLeadState = 'error';
            setState('ui.leadsPipeline.criarLead', 'error');
            throw e;
        }
    }
    handleCriarLeadClick() {
        const params = {
            leadName: 'Ana Silva',
            initialStage: 'novo',
            leadEmail: 'ana@exemplo.com',
            leadPhone: '11999999999',
            leadSource: 'Indicação',
            leadInterest: 'Apartamento',
        };
        void runBlockingUiAction(async (signal) => {
            await this.criarLead(params, signal);
        }, {
            busyLabel: this.msg.criarLeadLoading,
            errorTitle: this.msg.couldNotCriarLead,
            retry: () => this.criarLead(params),
        });
    }
    async solicitarQualificacaoLead(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.leadsPipeline.solicitarQualificacaoLead', params);
            this.solicitarQualificacaoLeadState = 'success';
            setState('ui.leadsPipeline.solicitarQualificacaoLead', 'success');
            return;
        }
        this.solicitarQualificacaoLeadState = 'loading';
        setState('ui.leadsPipeline.solicitarQualificacaoLead', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.leadsPipeline.solicitarQualificacaoLead', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.solicitarQualificacaoLeadState = 'success';
            setState('ui.leadsPipeline.solicitarQualificacaoLead', 'success');
            await this.loadListarLeads(undefined, { mode: 'silent' });
        }
        catch (e) {
            this.solicitarQualificacaoLeadState = 'error';
            setState('ui.leadsPipeline.solicitarQualificacaoLead', 'error');
            throw e;
        }
    }
    handleSolicitarQualificacaoLeadClick() {
        const lead = this.leads[0];
        const params = {
            leadId: lead?.leadId ?? 'id-001',
            leadContext: 'Lead interessado em imóvel residencial',
        };
        void runBlockingUiAction(async (signal) => {
            await this.solicitarQualificacaoLead(params, signal);
        }, {
            busyLabel: this.msg.solicitarQualificacaoLeadLoading,
            errorTitle: this.msg.couldNotSolicitarQualificacaoLead,
            retry: () => this.solicitarQualificacaoLead(params),
        });
    }
    handleNavigateToLeadDetailsClick(params) {
        if (window.mls) {
            console.log('[mls mock] navigate to leadDetails', params);
            return;
        }
        setState('navigation.request', { pageId: 'leadDetails', params: params ?? {} });
    }
}
__decorate([
    property()
], LeadsPipelineLeadsPipelineBase.prototype, "leads", void 0);
__decorate([
    property()
], LeadsPipelineLeadsPipelineBase.prototype, "mudancasEtapaLead", void 0);
__decorate([
    property()
], LeadsPipelineLeadsPipelineBase.prototype, "moverEtapaLeadState", void 0);
__decorate([
    property()
], LeadsPipelineLeadsPipelineBase.prototype, "criarLeadState", void 0);
__decorate([
    property()
], LeadsPipelineLeadsPipelineBase.prototype, "solicitarQualificacaoLeadState", void 0);
__decorate([
    property()
], LeadsPipelineLeadsPipelineBase.prototype, "status", void 0);
