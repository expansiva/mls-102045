/// <mls fileReference="_102045_/l2/propertyFlowCrm/web/shared/visitsAgenda.ts" enhancement="_102027_/l2/enhancementLit.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Property Flow CRM',
    pageTitle: 'Agenda de Visitas',
    loaded: 'Dados carregados',
    couldNotLoad: 'Não foi possível carregar',
    loadingListarVisitas: 'Carregando visitas...',
    loadingObterVisita: 'Carregando visita...',
    loadingListarSolicitacoesAgendamentoVisita: 'Carregando solicitações...',
    agendarVisitaLabel: 'Agendar visita',
    agendarVisitaLoading: 'Agendando...',
    couldNotAgendarVisita: 'Não foi possível agendar',
    atualizarStatusVisitaLabel: 'Atualizar status',
    atualizarStatusVisitaLoading: 'Atualizando...',
    couldNotAtualizarStatusVisita: 'Não foi possível atualizar',
};
const message_en = {
    brand: 'Property Flow CRM',
    pageTitle: 'Visits Agenda',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingListarVisitas: 'Loading visits...',
    loadingObterVisita: 'Loading visit...',
    loadingListarSolicitacoesAgendamentoVisita: 'Loading requests...',
    agendarVisitaLabel: 'Schedule visit',
    agendarVisitaLoading: 'Scheduling...',
    couldNotAgendarVisita: 'Could not schedule',
    atualizarStatusVisitaLabel: 'Update status',
    atualizarStatusVisitaLoading: 'Updating...',
    couldNotAtualizarStatusVisita: 'Could not update',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class VisitsAgendaVisitsAgendaBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.visitsAgenda.visitas',
            'ui.visitsAgenda.visita',
            'ui.visitsAgenda.solicitacoesAgendamentoVisita',
            'ui.visitsAgenda.agendarVisita',
            'ui.visitsAgenda.atualizarStatusVisita',
        ];
        this.visitas = [];
        this.visita = undefined;
        this.solicitacoesAgendamentoVisita = [];
        this.agendarVisitaState = 'idle';
        this.atualizarStatusVisitaState = 'idle';
        this.status = '';
        this.agendarPropertyId = '';
        this.agendarLeadId = '';
        this.agendarRequestedStartAt = '';
        this.agendarRequestedEndAt = undefined;
        this.agendarNotes = undefined;
        this.atualizarNovoStatus = '';
        this.atualizarRequestedStartAt = undefined;
        this.atualizarRequestedEndAt = undefined;
        this.msg = messages['en'];
    }
    createRenderRoot() { return this; }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.visitsAgenda.visitas':
                this.visitas = value ?? [];
                break;
            case 'ui.visitsAgenda.visita':
                this.visita = value;
                break;
            case 'ui.visitsAgenda.solicitacoesAgendamentoVisita':
                this.solicitacoesAgendamentoVisita = value ?? [];
                break;
            case 'ui.visitsAgenda.agendarVisita':
                this.agendarVisitaState = value ?? 'idle';
                break;
            case 'ui.visitsAgenda.atualizarStatusVisita':
                this.atualizarStatusVisitaState = value ?? 'idle';
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadListarVisitas(params, options);
        await this.loadObterVisita(undefined, options);
        await this.loadListarSolicitacoesAgendamentoVisita(undefined, options);
    }
    async loadListarVisitas(params, options) {
        if (window.mls) {
            this.visitas = [
                {
                    visitId: 'id-001',
                    status: 'scheduled',
                    scheduledAt: '2026-06-23T10:00:00Z',
                    propertyId: 'prop-001',
                    leadId: 'lead-001',
                },
                {
                    visitId: 'id-002',
                    status: 'completed',
                    scheduledAt: '2026-06-24T14:00:00Z',
                    propertyId: 'prop-002',
                    leadId: 'lead-002',
                },
            ];
            setState('ui.visitsAgenda.visitas', this.visitas);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.visitsAgenda.listarVisitas', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.visitas = response.data;
        setState('ui.visitsAgenda.visitas', this.visitas);
        this.status = this.msg.loaded;
    }
    async loadObterVisita(params, options) {
        if (window.mls) {
            this.visita = {
                visitId: 'id-001',
                status: 'scheduled',
                scheduledAt: '2026-06-23T10:00:00Z',
                propertyId: 'prop-001',
                leadId: 'lead-001',
            };
            setState('ui.visitsAgenda.visita', this.visita);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.visitsAgenda.obterVisita', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.visita = response.data;
        setState('ui.visitsAgenda.visita', this.visita);
        this.status = this.msg.loaded;
    }
    async loadListarSolicitacoesAgendamentoVisita(params, options) {
        if (window.mls) {
            this.solicitacoesAgendamentoVisita = [
                {
                    visitScheduleRequestId: 'id-001',
                    status: 'pending',
                    requestedStartAt: '2026-06-25T09:00:00Z',
                    propertyId: 'prop-001',
                    leadId: 'lead-001',
                    visitId: 'visit-001',
                },
                {
                    visitScheduleRequestId: 'id-002',
                    status: 'approved',
                    requestedStartAt: '2026-06-26T11:00:00Z',
                    propertyId: 'prop-002',
                    leadId: 'lead-002',
                    visitId: 'visit-002',
                },
            ];
            setState('ui.visitsAgenda.solicitacoesAgendamentoVisita', this.solicitacoesAgendamentoVisita);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.visitsAgenda.listarSolicitacoesAgendamentoVisita', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.solicitacoesAgendamentoVisita = response.data;
        setState('ui.visitsAgenda.solicitacoesAgendamentoVisita', this.solicitacoesAgendamentoVisita);
        this.status = this.msg.loaded;
    }
    async agendarVisita(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.visitsAgenda.agendarVisita', params);
            this.agendarVisitaState = 'success';
            setState('ui.visitsAgenda.agendarVisita', 'success');
            return;
        }
        this.agendarVisitaState = 'loading';
        setState('ui.visitsAgenda.agendarVisita', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.visitsAgenda.agendarVisita', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.agendarVisitaState = 'success';
            setState('ui.visitsAgenda.agendarVisita', 'success');
        }
        catch (e) {
            this.agendarVisitaState = 'error';
            setState('ui.visitsAgenda.agendarVisita', 'error');
            throw e;
        }
    }
    handleAgendarVisitaClick() {
        const params = {
            propertyId: this.agendarPropertyId,
            leadId: this.agendarLeadId,
            requestedStartAt: this.agendarRequestedStartAt,
            requestedEndAt: this.agendarRequestedEndAt,
            notes: this.agendarNotes,
        };
        void runBlockingUiAction(async (signal) => { await this.agendarVisita(params, signal); }, {
            busyLabel: this.msg.agendarVisitaLoading,
            errorTitle: this.msg.couldNotAgendarVisita,
            retry: () => this.agendarVisita(params),
        });
    }
    async atualizarStatusVisita(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.visitsAgenda.atualizarStatusVisita', params);
            this.atualizarStatusVisitaState = 'success';
            setState('ui.visitsAgenda.atualizarStatusVisita', 'success');
            return;
        }
        this.atualizarStatusVisitaState = 'loading';
        setState('ui.visitsAgenda.atualizarStatusVisita', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.visitsAgenda.atualizarStatusVisita', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.atualizarStatusVisitaState = 'success';
            setState('ui.visitsAgenda.atualizarStatusVisita', 'success');
        }
        catch (e) {
            this.atualizarStatusVisitaState = 'error';
            setState('ui.visitsAgenda.atualizarStatusVisita', 'error');
            throw e;
        }
    }
    handleAtualizarStatusVisitaClick() {
        const params = {
            visitId: this.visita?.visitId ?? '',
            novoStatus: this.atualizarNovoStatus,
            requestedStartAt: this.atualizarRequestedStartAt,
            requestedEndAt: this.atualizarRequestedEndAt,
        };
        void runBlockingUiAction(async (signal) => { await this.atualizarStatusVisita(params, signal); }, {
            busyLabel: this.msg.atualizarStatusVisitaLoading,
            errorTitle: this.msg.couldNotAtualizarStatusVisita,
            retry: () => this.atualizarStatusVisita(params),
        });
    }
}
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "visitas", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "visita", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "solicitacoesAgendamentoVisita", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "agendarVisitaState", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "atualizarStatusVisitaState", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "status", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "agendarPropertyId", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "agendarLeadId", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "agendarRequestedStartAt", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "agendarRequestedEndAt", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "agendarNotes", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "atualizarNovoStatus", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "atualizarRequestedStartAt", void 0);
__decorate([
    property()
], VisitsAgendaVisitsAgendaBase.prototype, "atualizarRequestedEndAt", void 0);
