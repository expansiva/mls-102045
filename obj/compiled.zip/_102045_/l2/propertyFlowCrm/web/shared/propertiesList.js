var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102045_/l2/propertyFlowCrm/web/shared/propertiesList.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Property Flow CRM',
    pageTitle: 'Lista de imóveis',
    loaded: 'Dados carregados',
    couldNotLoad: 'Nao foi possivel carregar',
    loadingListarImoveis: 'Carregando imóveis',
    criarImovelLabel: 'Cadastrar imóvel',
    criarImovelLoading: 'Cadastrando imóvel',
    couldNotCriarImovel: 'Nao foi possivel criar imóvel',
    navigateToPropertyDetails: 'selecionar imóvel',
};
const message_en = {
    brand: 'Property Flow CRM',
    pageTitle: 'Properties List',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingListarImoveis: 'Loading properties',
    criarImovelLabel: 'Create property',
    criarImovelLoading: 'Creating property',
    couldNotCriarImovel: 'Could not create property',
    navigateToPropertyDetails: 'select property',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class PropertiesListPropertiesListBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.propertiesList.imoveis',
            'ui.propertiesList.criarImovel',
        ];
        this.imoveis = [];
        this.criarImovelState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.propertiesList.imoveis':
                this.imoveis = (value ?? []);
                break;
            case 'ui.propertiesList.criarImovel':
                this.criarImovelState = (value ?? 'idle');
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadListarImoveis(params, options);
    }
    async loadListarImoveis(params, options) {
        if (window.mls) {
            this.imoveis = [
                {
                    propertyId: 'id-001',
                    title: 'Apartamento Central',
                    status: 'ativo',
                    price: 350000,
                    city: 'São Paulo',
                    neighborhood: 'Centro',
                },
                {
                    propertyId: 'id-002',
                    title: 'Casa Jardim',
                    status: 'reservado',
                    price: 520000,
                    city: 'Campinas',
                    neighborhood: 'Jardim das Flores',
                },
                {
                    propertyId: 'id-003',
                    title: 'Cobertura Vista Mar',
                    status: 'vendido',
                    price: 980000,
                    city: 'Rio de Janeiro',
                    neighborhood: 'Copacabana',
                },
            ];
            setState('ui.propertiesList.imoveis', this.imoveis);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.propertiesList.listarImoveis', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.imoveis = response.data;
        setState('ui.propertiesList.imoveis', this.imoveis);
        this.status = this.msg.loaded;
    }
    async criarImovel(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.propertiesList.criarImovel', params);
            this.criarImovelState = 'success';
            setState('ui.propertiesList.criarImovel', 'success');
            return;
        }
        this.criarImovelState = 'loading';
        setState('ui.propertiesList.criarImovel', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.propertiesList.criarImovel', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.criarImovelState = 'success';
            setState('ui.propertiesList.criarImovel', 'success');
            await this.loadListarImoveis(undefined);
        }
        catch (e) {
            this.criarImovelState = 'error';
            setState('ui.propertiesList.criarImovel', 'error');
            throw e;
        }
    }
    handleCriarImovelClick() {
        const params = {
            title: '',
            propertyType: '',
            price: 0,
            city: '',
            neighborhood: '',
            status: '',
            brokerId: '',
        };
        void runBlockingUiAction(async (signal) => { await this.criarImovel(params, signal); }, {
            busyLabel: this.msg.criarImovelLoading,
            errorTitle: this.msg.couldNotCriarImovel,
            retry: () => this.criarImovel(params),
        });
    }
    handleNavigateToPropertyDetailsClick(params) {
        if (window.mls) {
            console.log('[mls mock] navigate to propertyDetails', params);
            return;
        }
        setState('navigation.request', { pageId: 'propertyDetails', params: params ?? {} });
    }
}
__decorate([
    property()
], PropertiesListPropertiesListBase.prototype, "imoveis", void 0);
__decorate([
    property()
], PropertiesListPropertiesListBase.prototype, "criarImovelState", void 0);
__decorate([
    property()
], PropertiesListPropertiesListBase.prototype, "status", void 0);
