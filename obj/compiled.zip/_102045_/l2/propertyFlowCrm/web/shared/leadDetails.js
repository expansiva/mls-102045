var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102045_/l2/propertyFlowCrm/web/shared/leadDetails.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Property Flow Crm',
    pageTitle: 'Detalhes do Lead',
    loaded: 'Dados carregados',
    couldNotLoad: 'Não foi possível carregar',
    loadingObterLead: 'Carregando lead',
    atualizarLeadLabel: 'Atualizar lead',
    atualizarLeadLoading: 'Atualizando lead',
    couldNotAtualizarLead: 'Não foi possível atualizar lead',
};
const message_en = {
    brand: 'Property Flow Crm',
    pageTitle: 'Lead Details',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingObterLead: 'Loading lead',
    atualizarLeadLabel: 'Update lead',
    atualizarLeadLoading: 'Updating lead',
    couldNotAtualizarLead: 'Could not update lead',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class LeadDetailsLeadDetailsBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.leadDetails.leadId',
            'ui.leadDetails.name',
            'ui.leadDetails.email',
            'ui.leadDetails.phone',
            'ui.leadDetails.preferences',
            'ui.leadDetails.stage',
            'ui.leadDetails.history',
            'ui.leadDetails.atualizarLead',
        ];
        this.leadId = undefined;
        this.name = undefined;
        this.email = undefined;
        this.phone = undefined;
        this.preferences = undefined;
        this.stage = undefined;
        this.history = undefined;
        this.atualizarLeadState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.leadDetails.leadId':
                this.leadId = (value ?? undefined);
                break;
            case 'ui.leadDetails.name':
                this.name = (value ?? undefined);
                break;
            case 'ui.leadDetails.email':
                this.email = (value ?? undefined);
                break;
            case 'ui.leadDetails.phone':
                this.phone = (value ?? undefined);
                break;
            case 'ui.leadDetails.preferences':
                this.preferences = (value ?? undefined);
                break;
            case 'ui.leadDetails.stage':
                this.stage = (value ?? undefined);
                break;
            case 'ui.leadDetails.history':
                this.history = (value ?? undefined);
                break;
            case 'ui.leadDetails.atualizarLead':
                this.atualizarLeadState = (value ?? 'idle');
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadObterLead(params, options);
    }
    async loadObterLead(params, options) {
        if (window.mls) {
            this.leadId = 'id-001';
            setState('ui.leadDetails.leadId', this.leadId);
            this.name = 'Ana Silva';
            setState('ui.leadDetails.name', this.name);
            this.email = 'ana@exemplo.com';
            setState('ui.leadDetails.email', this.email);
            this.phone = '11999990000';
            setState('ui.leadDetails.phone', this.phone);
            this.preferences = 'Apartamento com varanda';
            setState('ui.leadDetails.preferences', this.preferences);
            this.stage = 'Qualificado';
            setState('ui.leadDetails.stage', this.stage);
            this.history = 'Contato inicial em 2026-06-20';
            setState('ui.leadDetails.history', this.history);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.leadDetails.obterLead', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? {
                    code: 'UNEXPECTED_ERROR',
                    message: this.msg.couldNotLoad,
                });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.leadId = response.data.leadId;
        setState('ui.leadDetails.leadId', this.leadId);
        this.name = response.data.name;
        setState('ui.leadDetails.name', this.name);
        this.email = response.data.email;
        setState('ui.leadDetails.email', this.email);
        this.phone = response.data.phone;
        setState('ui.leadDetails.phone', this.phone);
        this.preferences = response.data.preferences;
        setState('ui.leadDetails.preferences', this.preferences);
        this.stage = response.data.stage;
        setState('ui.leadDetails.stage', this.stage);
        this.history = response.data.history;
        setState('ui.leadDetails.history', this.history);
        this.status = this.msg.loaded;
    }
    async atualizarLead(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.leadDetails.atualizarLead', params);
            this.atualizarLeadState = 'success';
            setState('ui.leadDetails.atualizarLead', 'success');
            return;
        }
        this.atualizarLeadState = 'loading';
        setState('ui.leadDetails.atualizarLead', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.leadDetails.atualizarLead', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.atualizarLeadState = 'success';
            setState('ui.leadDetails.atualizarLead', 'success');
            await this.loadObterLead({ leadId: params.leadId }, { mode: 'silent' });
        }
        catch (e) {
            this.atualizarLeadState = 'error';
            setState('ui.leadDetails.atualizarLead', 'error');
            throw e;
        }
    }
    handleAtualizarLeadClick() {
        const params = {
            leadId: this.leadId ?? '',
            name: this.name,
            email: this.email,
            phone: this.phone,
            preferences: this.preferences,
            stage: this.stage,
        };
        void runBlockingUiAction(async (signal) => {
            await this.atualizarLead(params, signal);
        }, {
            busyLabel: this.msg.atualizarLeadLoading,
            errorTitle: this.msg.couldNotAtualizarLead,
            retry: () => this.atualizarLead(params),
        });
    }
}
__decorate([
    property()
], LeadDetailsLeadDetailsBase.prototype, "leadId", void 0);
__decorate([
    property()
], LeadDetailsLeadDetailsBase.prototype, "name", void 0);
__decorate([
    property()
], LeadDetailsLeadDetailsBase.prototype, "email", void 0);
__decorate([
    property()
], LeadDetailsLeadDetailsBase.prototype, "phone", void 0);
__decorate([
    property()
], LeadDetailsLeadDetailsBase.prototype, "preferences", void 0);
__decorate([
    property()
], LeadDetailsLeadDetailsBase.prototype, "stage", void 0);
__decorate([
    property()
], LeadDetailsLeadDetailsBase.prototype, "history", void 0);
__decorate([
    property()
], LeadDetailsLeadDetailsBase.prototype, "atualizarLeadState", void 0);
__decorate([
    property()
], LeadDetailsLeadDetailsBase.prototype, "status", void 0);
