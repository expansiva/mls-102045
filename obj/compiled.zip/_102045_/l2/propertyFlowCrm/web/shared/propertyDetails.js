var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102045_/l2/propertyFlowCrm/web/shared/propertyDetails.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Property Flow CRM',
    pageTitle: 'Detalhes do Imóvel',
    loaded: 'Dados carregados',
    couldNotLoad: 'Não foi possível carregar',
    loadingObterImovel: 'Carregando imóvel...',
    loadingListarSolicitacoesDescricaoImovel: 'Carregando solicitações...',
    atualizarImovelLabel: 'Atualizar imóvel',
    atualizarImovelLoading: 'Atualizando imóvel...',
    couldNotAtualizarImovel: 'Não foi possível atualizar o imóvel',
    solicitarDescricaoImovelLabel: 'Solicitar descrição',
    solicitarDescricaoImovelLoading: 'Solicitando descrição...',
    couldNotSolicitarDescricaoImovel: 'Não foi possível solicitar a descrição',
};
const message_en = {
    brand: 'Property Flow CRM',
    pageTitle: 'Property Details',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingObterImovel: 'Loading property...',
    loadingListarSolicitacoesDescricaoImovel: 'Loading requests...',
    atualizarImovelLabel: 'Update property',
    atualizarImovelLoading: 'Updating property...',
    couldNotAtualizarImovel: 'Could not update property',
    solicitarDescricaoImovelLabel: 'Request description',
    solicitarDescricaoImovelLoading: 'Requesting description...',
    couldNotSolicitarDescricaoImovel: 'Could not request description',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class PropertyDetailsPropertyDetailsBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.propertyDetails.propertyId',
            'ui.propertyDetails.title',
            'ui.propertyDetails.address',
            'ui.propertyDetails.price',
            'ui.propertyDetails.status',
            'ui.propertyDetails.description',
            'ui.propertyDetails.features',
            'ui.propertyDetails.bedrooms',
            'ui.propertyDetails.bathrooms',
            'ui.propertyDetails.area',
            'ui.propertyDetails.solicitacoesDescricaoImovel',
            'ui.propertyDetails.atualizarImovel',
            'ui.propertyDetails.solicitarDescricaoImovel',
        ];
        this.propertyId = undefined;
        this.propertyTitle = undefined;
        this.address = undefined;
        this.price = undefined;
        this.propertyStatus = undefined;
        this.description = undefined;
        this.features = undefined;
        this.bedrooms = undefined;
        this.bathrooms = undefined;
        this.area = undefined;
        this.solicitacoesDescricaoImovel = [];
        this.bullets = '';
        this.atualizarImovelState = 'idle';
        this.solicitarDescricaoImovelState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() { return this; }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.propertyDetails.propertyId':
                this.propertyId = value ?? undefined;
                break;
            case 'ui.propertyDetails.title':
                this.propertyTitle = value ?? undefined;
                break;
            case 'ui.propertyDetails.address':
                this.address = value ?? undefined;
                break;
            case 'ui.propertyDetails.price':
                this.price = value ?? undefined;
                break;
            case 'ui.propertyDetails.status':
                this.propertyStatus = value ?? undefined;
                break;
            case 'ui.propertyDetails.description':
                this.description = value ?? undefined;
                break;
            case 'ui.propertyDetails.features':
                this.features = value ?? undefined;
                break;
            case 'ui.propertyDetails.bedrooms':
                this.bedrooms = value ?? undefined;
                break;
            case 'ui.propertyDetails.bathrooms':
                this.bathrooms = value ?? undefined;
                break;
            case 'ui.propertyDetails.area':
                this.area = value ?? undefined;
                break;
            case 'ui.propertyDetails.solicitacoesDescricaoImovel':
                this.solicitacoesDescricaoImovel = value ?? [];
                break;
            case 'ui.propertyDetails.atualizarImovel':
                this.atualizarImovelState = value ?? 'idle';
                break;
            case 'ui.propertyDetails.solicitarDescricaoImovel':
                this.solicitarDescricaoImovelState = value ?? 'idle';
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadObterImovel(params, options);
        await this.loadListarSolicitacoesDescricaoImovel(params, options);
    }
    async loadObterImovel(params, options) {
        if (window.mls) {
            this.propertyId = 'id-001';
            this.propertyTitle = 'Casa Espaçosa';
            this.address = 'Rua das Flores, 123';
            this.price = 450000;
            this.propertyStatus = 'ativo';
            this.description = 'Linda casa com jardim';
            this.features = 'Piscina, Churrasqueira';
            this.bedrooms = 3;
            this.bathrooms = 2;
            this.area = 180;
            setState('ui.propertyDetails.propertyId', this.propertyId);
            setState('ui.propertyDetails.title', this.propertyTitle);
            setState('ui.propertyDetails.address', this.address);
            setState('ui.propertyDetails.price', this.price);
            setState('ui.propertyDetails.status', this.propertyStatus);
            setState('ui.propertyDetails.description', this.description);
            setState('ui.propertyDetails.features', this.features);
            setState('ui.propertyDetails.bedrooms', this.bedrooms);
            setState('ui.propertyDetails.bathrooms', this.bathrooms);
            setState('ui.propertyDetails.area', this.area);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.propertyDetails.obterImovel', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.propertyId = response.data.propertyId;
        this.propertyTitle = response.data.title;
        this.address = response.data.address;
        this.price = response.data.price;
        this.propertyStatus = response.data.status;
        this.description = response.data.description;
        this.features = response.data.features;
        this.bedrooms = response.data.bedrooms;
        this.bathrooms = response.data.bathrooms;
        this.area = response.data.area;
        setState('ui.propertyDetails.propertyId', this.propertyId);
        setState('ui.propertyDetails.title', this.propertyTitle);
        setState('ui.propertyDetails.address', this.address);
        setState('ui.propertyDetails.price', this.price);
        setState('ui.propertyDetails.status', this.propertyStatus);
        setState('ui.propertyDetails.description', this.description);
        setState('ui.propertyDetails.features', this.features);
        setState('ui.propertyDetails.bedrooms', this.bedrooms);
        setState('ui.propertyDetails.bathrooms', this.bathrooms);
        setState('ui.propertyDetails.area', this.area);
        this.status = this.msg.loaded;
    }
    async loadListarSolicitacoesDescricaoImovel(params, options) {
        if (window.mls) {
            this.solicitacoesDescricaoImovel = [
                { requests: 'req-001' },
                { requests: 'req-002' },
            ];
            setState('ui.propertyDetails.solicitacoesDescricaoImovel', this.solicitacoesDescricaoImovel);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.propertyDetails.listarSolicitacoesDescricaoImovel', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.solicitacoesDescricaoImovel = response.data;
        setState('ui.propertyDetails.solicitacoesDescricaoImovel', this.solicitacoesDescricaoImovel);
        this.status = this.msg.loaded;
    }
    async atualizarImovel(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.propertyDetails.atualizarImovel', params);
            this.atualizarImovelState = 'success';
            setState('ui.propertyDetails.atualizarImovel', 'success');
            return;
        }
        this.atualizarImovelState = 'loading';
        setState('ui.propertyDetails.atualizarImovel', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.propertyDetails.atualizarImovel', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.atualizarImovelState = 'success';
            setState('ui.propertyDetails.atualizarImovel', 'success');
            await this.loadObterImovel({ propertyId: params.propertyId });
        }
        catch (e) {
            this.atualizarImovelState = 'error';
            setState('ui.propertyDetails.atualizarImovel', 'error');
            throw e;
        }
    }
    handleAtualizarImovelClick() {
        const params = {
            propertyId: this.propertyId ?? '',
            title: this.propertyTitle,
            address: this.address,
            price: this.price,
            status: this.propertyStatus,
            description: this.description,
            features: this.features,
            bedrooms: this.bedrooms,
            bathrooms: this.bathrooms,
            area: this.area,
        };
        void runBlockingUiAction(async (signal) => { await this.atualizarImovel(params, signal); }, {
            busyLabel: this.msg.atualizarImovelLoading,
            errorTitle: this.msg.couldNotAtualizarImovel,
            retry: () => this.atualizarImovel(params),
        });
    }
    async solicitarDescricaoImovel(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.propertyDetails.solicitarDescricaoImovel', params);
            this.solicitarDescricaoImovelState = 'success';
            setState('ui.propertyDetails.solicitarDescricaoImovel', 'success');
            return;
        }
        this.solicitarDescricaoImovelState = 'loading';
        setState('ui.propertyDetails.solicitarDescricaoImovel', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.propertyDetails.solicitarDescricaoImovel', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.solicitarDescricaoImovelState = 'success';
            setState('ui.propertyDetails.solicitarDescricaoImovel', 'success');
            await this.loadListarSolicitacoesDescricaoImovel({ propertyId: params.propertyId });
        }
        catch (e) {
            this.solicitarDescricaoImovelState = 'error';
            setState('ui.propertyDetails.solicitarDescricaoImovel', 'error');
            throw e;
        }
    }
    handleSolicitarDescricaoImovelClick() {
        const params = {
            propertyId: this.propertyId ?? '',
            bullets: this.bullets,
        };
        void runBlockingUiAction(async (signal) => { await this.solicitarDescricaoImovel(params, signal); }, {
            busyLabel: this.msg.solicitarDescricaoImovelLoading,
            errorTitle: this.msg.couldNotSolicitarDescricaoImovel,
            retry: () => this.solicitarDescricaoImovel(params),
        });
    }
}
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "propertyId", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "propertyTitle", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "address", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "price", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "propertyStatus", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "description", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "features", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "bedrooms", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "bathrooms", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "area", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "solicitacoesDescricaoImovel", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "bullets", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "atualizarImovelState", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "solicitarDescricaoImovelState", void 0);
__decorate([
    property()
], PropertyDetailsPropertyDetailsBase.prototype, "status", void 0);
