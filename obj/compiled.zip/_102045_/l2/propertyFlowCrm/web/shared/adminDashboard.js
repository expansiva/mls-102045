var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102045_/l2/propertyFlowCrm/web/shared/adminDashboard.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Property Flow CRM',
    pageTitle: 'Dashboard administrativo',
    loaded: 'Dados carregados',
    couldNotLoad: 'Nao foi possivel carregar',
    loadingVisualizarAdminDashboard: 'Carregando indicadores administrativos',
    loadingListarAtualizacoesMetricas: 'Carregando atualizações de métricas',
    atualizarMetricasDashboardLabel: 'Atualizar métricas',
    atualizarMetricasDashboardLoading: 'Atualizando métricas',
    couldNotAtualizarMetricasDashboard: 'Nao foi possivel atualizar métricas',
};
const message_en = {
    brand: 'Property Flow CRM',
    pageTitle: 'Admin dashboard',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingVisualizarAdminDashboard: 'Loading admin indicators',
    loadingListarAtualizacoesMetricas: 'Loading metric updates',
    atualizarMetricasDashboardLabel: 'Update metrics',
    atualizarMetricasDashboardLoading: 'Updating metrics',
    couldNotAtualizarMetricasDashboard: 'Could not update metrics',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class AdminDashboardAdminDashboardBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.adminDashboard.dashboardMetrics',
            'ui.adminDashboard.lastUpdateAt',
            'ui.adminDashboard.atualizacoesMetricas',
            'ui.adminDashboard.atualizarMetricasDashboard',
        ];
        this.dashboardMetrics = undefined;
        this.lastUpdateAt = undefined;
        this.atualizacoesMetricas = [];
        this.atualizarMetricasDashboardState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.adminDashboard.dashboardMetrics':
                this.dashboardMetrics = value ?? undefined;
                break;
            case 'ui.adminDashboard.lastUpdateAt':
                this.lastUpdateAt = value ?? undefined;
                break;
            case 'ui.adminDashboard.atualizacoesMetricas':
                this.atualizacoesMetricas = value ?? [];
                break;
            case 'ui.adminDashboard.atualizarMetricasDashboard':
                this.atualizarMetricasDashboardState = value ?? 'idle';
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadVisualizarAdminDashboard(params, options);
        await this.loadListarAtualizacoesMetricas(params, options);
    }
    async loadVisualizarAdminDashboard(params, options) {
        if (window.mls) {
            this.dashboardMetrics = 'Resumo das métricas do período';
            setState('ui.adminDashboard.dashboardMetrics', this.dashboardMetrics);
            this.lastUpdateAt = '2026-06-23T10:00:00Z';
            setState('ui.adminDashboard.lastUpdateAt', this.lastUpdateAt);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.adminDashboard.visualizarAdminDashboard', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.dashboardMetrics = response.data.dashboardMetrics;
        setState('ui.adminDashboard.dashboardMetrics', this.dashboardMetrics);
        this.lastUpdateAt = response.data.lastUpdateAt;
        setState('ui.adminDashboard.lastUpdateAt', this.lastUpdateAt);
        this.status = this.msg.loaded;
    }
    async loadListarAtualizacoesMetricas(params, options) {
        if (window.mls) {
            this.atualizacoesMetricas = [
                { dashboardMetricUpdates: '2026-06-22T18:00:00Z' },
                { dashboardMetricUpdates: '2026-06-21T18:00:00Z' },
            ];
            setState('ui.adminDashboard.atualizacoesMetricas', this.atualizacoesMetricas);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('propertyFlowCrm.adminDashboard.listarAtualizacoesMetricas', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.atualizacoesMetricas = response.data;
        setState('ui.adminDashboard.atualizacoesMetricas', this.atualizacoesMetricas);
        this.status = this.msg.loaded;
    }
    async atualizarMetricasDashboard(params, signal) {
        if (window.mls) {
            console.log('[mls mock] propertyFlowCrm.adminDashboard.atualizarMetricasDashboard', params);
            this.atualizarMetricasDashboardState = 'success';
            setState('ui.adminDashboard.atualizarMetricasDashboard', 'success');
            return;
        }
        this.atualizarMetricasDashboardState = 'loading';
        setState('ui.adminDashboard.atualizarMetricasDashboard', 'loading');
        try {
            const response = await execBff('propertyFlowCrm.adminDashboard.atualizarMetricasDashboard', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.atualizarMetricasDashboardState = 'success';
            setState('ui.adminDashboard.atualizarMetricasDashboard', 'success');
            await this.loadVisualizarAdminDashboard(undefined, { mode: 'silent' });
            await this.loadListarAtualizacoesMetricas(undefined, { mode: 'silent' });
        }
        catch (e) {
            this.atualizarMetricasDashboardState = 'error';
            setState('ui.adminDashboard.atualizarMetricasDashboard', 'error');
            throw e;
        }
    }
    handleAtualizarMetricasDashboardClick() {
        const params = {};
        void runBlockingUiAction(async (signal) => {
            await this.atualizarMetricasDashboard(params, signal);
        }, {
            busyLabel: this.msg.atualizarMetricasDashboardLoading,
            errorTitle: this.msg.couldNotAtualizarMetricasDashboard,
            retry: () => this.atualizarMetricasDashboard(params),
        });
    }
}
__decorate([
    property()
], AdminDashboardAdminDashboardBase.prototype, "dashboardMetrics", void 0);
__decorate([
    property()
], AdminDashboardAdminDashboardBase.prototype, "lastUpdateAt", void 0);
__decorate([
    property()
], AdminDashboardAdminDashboardBase.prototype, "atualizacoesMetricas", void 0);
__decorate([
    property()
], AdminDashboardAdminDashboardBase.prototype, "atualizarMetricasDashboardState", void 0);
__decorate([
    property()
], AdminDashboardAdminDashboardBase.prototype, "status", void 0);
