/// <mls fileReference="_102045_/l2/cafeFlow/web/contracts/menuManagement.test.ts" enhancement="_blank"/>
export {};
