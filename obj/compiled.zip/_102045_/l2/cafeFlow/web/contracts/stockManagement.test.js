/// <mls fileReference="_102045_/l2/cafeFlow/web/contracts/stockManagement.test.ts" enhancement="_blank"/>
export {};
