/// <mls fileReference="_102045_/l2/cafeFlow/web/contracts/managerDashboard.ts" enhancement="_blank"/>
export {};
