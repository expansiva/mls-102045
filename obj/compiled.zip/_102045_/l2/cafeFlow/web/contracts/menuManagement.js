/// <mls fileReference="_102045_/l2/cafeFlow/web/contracts/menuManagement.ts" enhancement="_blank"/>
export {};
