/// <mls fileReference="_102045_/l2/cafeFlow/web/contracts/stockManagement.ts" enhancement="_blank"/>
export {};
