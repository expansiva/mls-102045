/// <mls fileReference="_102045_/l2/cafeFlow/web/contracts/kitchenQueue.test.ts" enhancement="_blank"/>
export {};
