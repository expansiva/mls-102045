/// <mls fileReference="_102045_/l2/cafeFlow/web/contracts/kitchenQueue.ts" enhancement="_blank"/>
export {};
