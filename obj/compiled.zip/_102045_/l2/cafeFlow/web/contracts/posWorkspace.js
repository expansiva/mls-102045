/// <mls fileReference="_102045_/l2/cafeFlow/web/contracts/posWorkspace.ts" enhancement="_blank"/>
export {};
