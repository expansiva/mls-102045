/// <mls fileReference="_102045_/l2/cafeFlow/web/shared/posWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "section.orderBoard.title": "Painel de Pedidos",
    "section.createOrder.title": "Novo Pedido",
    "section.deliverOrder.title": "Entregar Pedido",
    "organism.orderBoardCards.title": "Pedidos do Turno",
    "organism.createOrderForm.title": "Lançar Pedido",
    "organism.deliverOrderSheet.title": "Confirmar Entrega",
    "intention.orderBoard.list.title": "Fila de Pedidos",
    "intention.createOrder.form.title": "Dados do Pedido",
    "intention.deliverOrder.form.title": "Entrega ao Cliente",
    "column.orderId": "Pedido",
    "column.status": "Status",
    "column.orderType": "Tipo",
    "column.tableNumber": "Mesa",
    "column.priority": "Prioridade",
    "column.createdAt": "Criado em",
    "filter.status": "Filtrar por status",
    "filter.orderType": "Filtrar por tipo",
    "field.orderType": "Tipo de Pedido",
    "field.tableNumber": "Número da Mesa",
    "field.orderItems": "Itens do Pedido",
    "field.priority": "Pedido Prioritário",
    "field.priorityReason": "Motivo da Prioridade",
    "field.orderId": "Pedido Selecionado",
    "action.viewOrderBoard.label": "Atualizar Painel",
    "action.selectForDelivery": "Selecionar para Entrega",
    "action.createOrder.submit": "Confirmar Pedido",
    "action.deliverOrder.submit": "Confirmar Entrega",
    "action.createOrder.success": "Pedido lançado com sucesso e enviado à cozinha.",
    "action.createOrder.error": "Erro ao lançar pedido. Verifique os dados e tente novamente.",
    "action.deliverOrder.success": "Pedido entregue ao cliente com sucesso.",
    "action.deliverOrder.error": "Não foi possível entregar o pedido. Verifique se o status atual é 'pronto'.",
    "empty.orderBoard": "Nenhum pedido no painel. Lance um novo pedido para começar.",
    "empty.deliverOrder": "Selecione um pedido pronto no painel para entregar.",
    "page.posWorkspace.title": "POS — Lançamento e acompanhamento de pedidos",
    "section.board.title": "Painel de Pedidos",
    "section.review.title": "Resumo das Ações",
    "intention.board.title": "Painel de Pedidos",
    "intention.createOrder.title": "Lançar Novo Pedido",
    "intention.deliverOrder.title": "Entregar Pedido Selecionado",
    "intention.review.title": "Resumo das Ações",
    "field.orderType.label": "Tipo de Pedido",
    "field.tableNumber.label": "Número da Mesa",
    "field.orderItems.label": "Itens do Pedido",
    "field.priority.label": "Prioridade",
    "field.priorityReason.label": "Justificativa de Prioridade",
    "field.orderId.label": "Pedido",
    "field.status.label": "Status",
    "field.receivedAt.label": "Recebido em",
    "field.inPreparationAt.label": "Em Preparo desde",
    "field.readyAt.label": "Pronto desde",
    "field.createdAt.label": "Criado em",
    "action.createOrder.label": "Lançar Pedido",
    "action.deliverOrder.label": "Entregar",
    "action.selectOrder.label": "Selecionar",
    "empty.board": "Nenhum pedido encontrado no turno atual.",
    "empty.createOrder": "Preencha os dados do pedido para lançá-lo.",
    "empty.review": "Nenhuma ação realizada ainda.",
    "lane.registered": "Registrado",
    "lane.received": "Recebido",
    "lane.inPreparation": "Em Preparo",
    "lane.ready": "Pronto",
    "lane.delivered": "Entregue",
    "sec.board.title": "Sec board",
    "org.orderKanbanBoard.title": "Visualizar pedidos agrupados por status em colunas kanban, identificar gargalos e selecionar pedidos para entrega",
    "sec.createOrder.title": "Sec create Order",
    "org.createOrderForm.title": "Formulário para lançar novo pedido no POS com tipo, mesa, itens e prioridade opcional",
    "sec.deliverOrder.title": "Sec deliver Order",
    "org.deliverOrderPanel.title": "Entregar pedido selecionado ao cliente, confirmando a entrega de um pedido com status pronto",
    "sec.review.title": "Sec review",
    "org.reviewSummary.title": "Revisar o contexto e o resultado das ações principais da página: pedidos criados e entregas realizadas",
    "section.queue.title": "Painel de Pedidos",
    "section.queue.deliverTitle": "Entregar Pedido",
    "column.priorityReason": "Motivo",
    "column.receivedAt": "Recebido",
    "column.inPreparationAt": "Em Preparo",
    "column.readyAt": "Pronto",
    "column.deliveredAt": "Entregue em",
    "column.updatedAt": "Atualizado em",
    "action.refresh.label": "Atualizar Painel",
    "action.confirmDeliver.label": "Confirmar Entrega",
    "empty.queue": "Nenhum pedido no painel. Lance um novo pedido para começar.",
    "queueSection.title": "Queue Section",
    "orderBoard.title": "Painel ao vivo dos pedidos do turno atual, ordenados por chegada, com status, prioridade e ação contextual de entrega para pedidos prontos",
    "createOrderSection.title": "Create Order Section",
    "createOrderForm.title": "Formulário de lançamento de pedido: tipo, mesa, itens, prioridade opcional e confirmação para envio à cozinha",
    "reviewSection.title": "Review Section",
    "actionSummary.title": "Resumo do último pedido criado e da última entrega realizada, com feedback textual dismissible de sucesso ou erro"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowPosWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.createOrderState = 'idle';
        this.createOrderOrderType = '';
        this.createOrderTableNumber = '';
        this.createOrderOrderItems = '';
        this.createOrderPriority = '';
        this.createOrderPriorityReason = '';
        this.createOrderOutput = null;
        this.createOrderError = '';
        this.viewOrderBoardState = 'idle';
        this.viewOrderBoardData = { items: [], total: 0 };
        this.deliverOrderState = 'idle';
        this.deliverOrderOrderId = '';
        this.deliverOrderOutput = null;
        this.deliverOrderError = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    /* ── Lifecycle ─────────────────────────────────────────────── */
    connectedCallback() {
        super.connectedCallback();
        const savedStatus = getState('ui.posWorkspace.status');
        if (typeof savedStatus === 'string') {
            this.status = savedStatus;
        }
        const savedCreateOrderState = getState('ui.posWorkspace.action.createOrder.status');
        if (typeof savedCreateOrderState === 'string') {
            this.createOrderState = savedCreateOrderState;
        }
        const savedViewOrderBoardState = getState('ui.posWorkspace.action.viewOrderBoard.status');
        if (typeof savedViewOrderBoardState === 'string') {
            this.viewOrderBoardState = savedViewOrderBoardState;
        }
        const savedDeliverOrderState = getState('ui.posWorkspace.action.deliverOrder.status');
        if (typeof savedDeliverOrderState === 'string') {
            this.deliverOrderState = savedDeliverOrderState;
        }
        this.loadViewOrderBoard();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    /* ── Query: viewOrderBoard ─────────────────────────────────── */
    async loadViewOrderBoard() {
        this.viewOrderBoardState = 'loading';
        setState('ui.posWorkspace.action.viewOrderBoard.status', 'loading');
        this.requestUpdate();
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.orderLifecycle.viewOrderBoard', params, options);
        if (response.ok) {
            if (response.data) {
                this.viewOrderBoardData = response.data;
                setState('ui.posWorkspace.data.viewOrderBoard', response.data);
            }
            else {
                this.viewOrderBoardData = { items: [], total: 0 };
                setState('ui.posWorkspace.data.viewOrderBoard', { items: [], total: 0 });
            }
            this.viewOrderBoardState = 'success';
            setState('ui.posWorkspace.action.viewOrderBoard.status', 'success');
        }
        else {
            this.viewOrderBoardState = 'error';
            setState('ui.posWorkspace.action.viewOrderBoard.status', 'error');
        }
        this.requestUpdate();
    }
    handleViewOrderBoardClick() {
        this.loadViewOrderBoard();
    }
    /* ── Command: createOrder ──────────────────────────────────── */
    async createOrder(signal) {
        this.createOrderState = 'loading';
        setState('ui.posWorkspace.action.createOrder.status', 'loading');
        this.requestUpdate();
        const params = {
            orderType: this.createOrderOrderType,
            orderItems: this.createOrderOrderItems,
        };
        if (this.createOrderTableNumber) {
            params.tableNumber = this.createOrderTableNumber;
        }
        if (this.createOrderPriority === 'true') {
            params.priority = true;
        }
        if (this.createOrderPriorityReason) {
            params.priorityReason = this.createOrderPriorityReason;
        }
        const options = { mode: 'blocking', signal };
        const response = await execBff('cafeFlow.orderLifecycle.createOrder', params, options);
        if (response.ok && response.data) {
            this.createOrderOutput = response.data;
            setState('ui.posWorkspace.output.createOrder', response.data);
            // Refresh viewOrderBoard before declaring success
            await this.loadViewOrderBoard();
            if (this.viewOrderBoardState === 'error') {
                this.createOrderError = this.msg['action.createOrder.error'];
                setState('ui.posWorkspace.action.createOrder.error', this.createOrderError);
                this.createOrderState = 'error';
                setState('ui.posWorkspace.action.createOrder.status', 'error');
                this.requestUpdate();
                return;
            }
            // Clear form inputs
            this.createOrderOrderType = '';
            setState('ui.posWorkspace.input.createOrder.orderType', '');
            this.createOrderTableNumber = '';
            setState('ui.posWorkspace.input.createOrder.tableNumber', '');
            this.createOrderOrderItems = '';
            setState('ui.posWorkspace.input.createOrder.orderItems', '');
            this.createOrderPriority = '';
            setState('ui.posWorkspace.input.createOrder.priority', '');
            this.createOrderPriorityReason = '';
            setState('ui.posWorkspace.input.createOrder.priorityReason', '');
            this.createOrderError = '';
            setState('ui.posWorkspace.action.createOrder.error', '');
            this.createOrderState = 'success';
            setState('ui.posWorkspace.action.createOrder.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.createOrder.error'];
            this.createOrderError = errorMsg;
            setState('ui.posWorkspace.action.createOrder.error', errorMsg);
            this.createOrderState = 'error';
            setState('ui.posWorkspace.action.createOrder.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateOrderClick() {
        runBlockingUiAction(async (signal) => {
            await this.createOrder(signal);
        }).catch(() => {
            // Blocking UI error already displayed; action status set by createOrder
        });
    }
    /* ── Command: deliverOrder ─────────────────────────────────── */
    async deliverOrder(signal) {
        if (!this.deliverOrderOrderId) {
            this.deliverOrderState = 'idle';
            setState('ui.posWorkspace.action.deliverOrder.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.deliverOrderState = 'loading';
        setState('ui.posWorkspace.action.deliverOrder.status', 'loading');
        this.requestUpdate();
        const params = {
            orderId: this.deliverOrderOrderId,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('cafeFlow.orderLifecycle.deliverOrder', params, options);
        if (response.ok && response.data) {
            this.deliverOrderOutput = response.data;
            setState('ui.posWorkspace.output.deliverOrder', response.data);
            // Refresh viewOrderBoard before declaring success
            await this.loadViewOrderBoard();
            if (this.viewOrderBoardState === 'error') {
                this.deliverOrderError = this.msg['action.deliverOrder.error'];
                setState('ui.posWorkspace.action.deliverOrder.error', this.deliverOrderError);
                this.deliverOrderState = 'error';
                setState('ui.posWorkspace.action.deliverOrder.status', 'error');
                this.requestUpdate();
                return;
            }
            // Clear selection input
            this.deliverOrderOrderId = '';
            setState('ui.posWorkspace.input.deliverOrder.orderId', '');
            this.deliverOrderError = '';
            setState('ui.posWorkspace.action.deliverOrder.error', '');
            this.deliverOrderState = 'success';
            setState('ui.posWorkspace.action.deliverOrder.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.deliverOrder.error'];
            this.deliverOrderError = errorMsg;
            setState('ui.posWorkspace.action.deliverOrder.error', errorMsg);
            this.deliverOrderState = 'error';
            setState('ui.posWorkspace.action.deliverOrder.status', 'error');
        }
        this.requestUpdate();
    }
    handleDeliverOrderClick() {
        runBlockingUiAction(async (signal) => {
            await this.deliverOrder(signal);
        }).catch(() => {
            // Blocking UI error already displayed; action status set by deliverOrder
        });
    }
    /* ── State setters: createOrder form inputs ────────────────── */
    setCreateOrderOrderType(value) {
        this.createOrderOrderType = value;
        setState('ui.posWorkspace.input.createOrder.orderType', value);
        this.requestUpdate();
    }
    handleCreateOrderOrderTypeChange(e) {
        const target = e.target;
        this.setCreateOrderOrderType(target.value);
    }
    setCreateOrderTableNumber(value) {
        this.createOrderTableNumber = value;
        setState('ui.posWorkspace.input.createOrder.tableNumber', value);
        this.requestUpdate();
    }
    handleCreateOrderTableNumberChange(e) {
        const target = e.target;
        this.setCreateOrderTableNumber(target.value);
    }
    setCreateOrderOrderItems(value) {
        this.createOrderOrderItems = value;
        setState('ui.posWorkspace.input.createOrder.orderItems', value);
        this.requestUpdate();
    }
    handleCreateOrderOrderItemsChange(e) {
        const target = e.target;
        this.setCreateOrderOrderItems(target.value);
    }
    setCreateOrderPriority(value) {
        this.createOrderPriority = value;
        setState('ui.posWorkspace.input.createOrder.priority', value);
        this.requestUpdate();
    }
    handleCreateOrderPriorityChange(e) {
        const target = e.target;
        this.setCreateOrderPriority(target.checked ? 'true' : 'false');
    }
    setCreateOrderPriorityReason(value) {
        this.createOrderPriorityReason = value;
        setState('ui.posWorkspace.input.createOrder.priorityReason', value);
        this.requestUpdate();
    }
    handleCreateOrderPriorityReasonChange(e) {
        const target = e.target;
        this.setCreateOrderPriorityReason(target.value);
    }
    /* ── State setters: deliverOrder selection ─────────────────── */
    setDeliverOrderOrderId(value) {
        this.deliverOrderOrderId = value;
        setState('ui.posWorkspace.input.deliverOrder.orderId', value);
        this.requestUpdate();
    }
    handleDeliverOrderOrderIdChange(e) {
        const target = e.target;
        this.setDeliverOrderOrderId(target.value);
    }
}
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "createOrderState", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "createOrderOrderType", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "createOrderTableNumber", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "createOrderOrderItems", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "createOrderPriority", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "createOrderPriorityReason", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "createOrderOutput", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "createOrderError", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "viewOrderBoardState", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "viewOrderBoardData", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "deliverOrderState", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "deliverOrderOrderId", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "deliverOrderOutput", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "deliverOrderError", void 0);
