/// <mls fileReference="_102045_/l2/cafeFlow/web/shared/managerDashboard.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "page.title": "Dashboard e assistente IA",
    "section.dashboard.title": "Dashboard do Dia",
    "section.aiAssistant.title": "Assistente IA",
    "organism.dashboardMetrics.title": "Métricas do Dashboard",
    "organism.aiSalesSummary.title": "Resumo de vendas por IA",
    "organism.aiPromoSuggestions.title": "Sugestões de promoção por IA",
    "column.status": "Status",
    "column.orderType": "Tipo de pedido",
    "column.createdAt": "Criado em",
    "column.shiftId": "Turno",
    "column.deliveredAt": "Entregue em",
    "column.orderId": "Pedido",
    "action.viewDashboard.label": "Atualizar dashboard",
    "action.requestAiSalesSummary.label": "Gerar resumo de vendas",
    "action.requestAiPromoSuggestions.label": "Gerar sugestões de promoção",
    "empty.viewDashboard": "Nenhum dado disponível para o dashboard do dia.",
    "empty.requestAiSalesSummary": "Toque em \"Solicitar Resumo de Vendas\" para gerar o resumo do dia.",
    "empty.requestAiPromoSuggestions": "Toque em \"Solicitar Sugestões de Promoção\" para gerar sugestões.",
    "sec.dashboard.title": "Sec dashboard",
    "org.dashboard.metrics.title": "Exibir vendas do dia, itens mais vendidos e alertas de estoque baixo agrupados por status do pedido",
    "sec.ai.assistant.title": "Sec ai assistant",
    "org.ai.sales.summary.title": "Exibir resumo de vendas do dia gerado pelo assistente IA para apoio à decisão do gerente",
    "org.ai.promo.suggestions.title": "Exibir sugestões de promoção por item geradas pelo assistente IA para ações de marketing",
    "section.dashboardList.title": "Pedidos do dia",
    "section.aiAssistant.empty": "Solicite insights à IA para visualizar resumos e sugestões.",
    "organism.dashboardOrdersList.title": "Dashboard do dia",
    "organism.dashboardOrdersList.empty": "Nenhum pedido encontrado para o turno atual.",
    "organism.aiSalesSummary.empty": "Solicite o resumo de vendas para ver os insights do dia.",
    "organism.aiPromoSuggestions.empty": "Solicite sugestões de promoção para ver recomendações de marketing.",
    "sec.dashboard.list.title": "Sec dashboard list",
    "org.dashboard.orders.title": "Exibir pedidos do turno atual com status, tipo e timestamps para revisão do gerente",
    "section.discover.title": "Dashboard do dia",
    "section.review.title": "Revisão",
    "organism.dashboard.title": "Pedidos do dia",
    "organism.dashboard.empty": "Nenhum pedido encontrado para o turno atual",
    "organism.aiSales.title": "Resumo de vendas por IA",
    "organism.aiSales.empty": "Solicite o resumo de vendas ao assistente IA",
    "organism.aiPromo.title": "Sugestões de promoção por IA",
    "organism.aiPromo.empty": "Solicite sugestões de promoção ao assistente IA",
    "organism.review.title": "Resumo geral",
    "organism.review.empty": "Revise os dados do dashboard acima",
    "field.status.label": "Status",
    "field.orderType.label": "Tipo de pedido",
    "field.createdAt.label": "Criado em",
    "field.shiftId.label": "Turno",
    "field.deliveredAt.label": "Entregue em",
    "field.orderId.label": "Pedido",
    "action.viewDashboard.success": "Dashboard atualizado com sucesso",
    "action.viewDashboard.error": "Erro ao carregar dashboard",
    "action.requestAiSalesSummary.success": "Resumo de vendas gerado com sucesso",
    "action.requestAiSalesSummary.error": "Erro ao gerar resumo de vendas",
    "action.requestAiPromoSuggestions.success": "Sugestões de promoção geradas com sucesso",
    "action.requestAiPromoSuggestions.error": "Erro ao gerar sugestões de promoção"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowManagerDashboardBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewDashboardState = 'idle';
        this.viewDashboardData = [];
        this.requestAiSalesSummaryState = 'idle';
        this.requestAiSalesSummaryData = [];
        this.requestAiPromoSuggestionsState = 'idle';
        this.requestAiPromoSuggestionsData = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const savedStatus = getState('ui.managerDashboard.status');
        if (typeof savedStatus === 'string') {
            this.status = savedStatus;
        }
        const savedViewDashboardState = getState('ui.managerDashboard.action.viewDashboard.status');
        if (typeof savedViewDashboardState === 'string') {
            this.viewDashboardState = savedViewDashboardState;
        }
        const savedViewDashboardData = getState('ui.managerDashboard.data.viewDashboard');
        if (Array.isArray(savedViewDashboardData)) {
            this.viewDashboardData = savedViewDashboardData;
        }
        const savedRequestAiSalesSummaryState = getState('ui.managerDashboard.action.requestAiSalesSummary.status');
        if (typeof savedRequestAiSalesSummaryState === 'string') {
            this.requestAiSalesSummaryState = savedRequestAiSalesSummaryState;
        }
        const savedRequestAiSalesSummaryData = getState('ui.managerDashboard.data.requestAiSalesSummary');
        if (Array.isArray(savedRequestAiSalesSummaryData)) {
            this.requestAiSalesSummaryData = savedRequestAiSalesSummaryData;
        }
        const savedRequestAiPromoSuggestionsState = getState('ui.managerDashboard.action.requestAiPromoSuggestions.status');
        if (typeof savedRequestAiPromoSuggestionsState === 'string') {
            this.requestAiPromoSuggestionsState = savedRequestAiPromoSuggestionsState;
        }
        const savedRequestAiPromoSuggestionsData = getState('ui.managerDashboard.data.requestAiPromoSuggestions');
        if (Array.isArray(savedRequestAiPromoSuggestionsData)) {
            this.requestAiPromoSuggestionsData = savedRequestAiPromoSuggestionsData;
        }
        this.loadViewDashboard();
        this.loadRequestAiSalesSummary();
        this.loadRequestAiPromoSuggestions();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    async loadViewDashboard() {
        this.viewDashboardState = 'loading';
        setState('ui.managerDashboard.action.viewDashboard.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.viewDashboard.viewDashboard', {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.viewDashboardData = data;
            setState('ui.managerDashboard.data.viewDashboard', data);
            this.viewDashboardState = 'success';
            setState('ui.managerDashboard.action.viewDashboard.status', 'success');
        }
        else {
            this.viewDashboardData = [];
            setState('ui.managerDashboard.data.viewDashboard', []);
            this.viewDashboardState = 'error';
            setState('ui.managerDashboard.action.viewDashboard.status', 'error');
            if (response.error) {
                console.error('[managerDashboard] viewDashboard error:', response.error.message);
            }
        }
    }
    handleViewDashboardClick(_event) {
        this.loadViewDashboard();
    }
    async loadRequestAiSalesSummary() {
        this.requestAiSalesSummaryState = 'loading';
        setState('ui.managerDashboard.action.requestAiSalesSummary.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.requestAiSalesSummary.requestAiSalesSummary', {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.requestAiSalesSummaryData = data;
            setState('ui.managerDashboard.data.requestAiSalesSummary', data);
            this.requestAiSalesSummaryState = 'success';
            setState('ui.managerDashboard.action.requestAiSalesSummary.status', 'success');
        }
        else {
            this.requestAiSalesSummaryData = [];
            setState('ui.managerDashboard.data.requestAiSalesSummary', []);
            this.requestAiSalesSummaryState = 'error';
            setState('ui.managerDashboard.action.requestAiSalesSummary.status', 'error');
            if (response.error) {
                console.error('[managerDashboard] requestAiSalesSummary error:', response.error.message);
            }
        }
    }
    handleRequestAiSalesSummaryClick(_event) {
        this.loadRequestAiSalesSummary();
    }
    async loadRequestAiPromoSuggestions() {
        this.requestAiPromoSuggestionsState = 'loading';
        setState('ui.managerDashboard.action.requestAiPromoSuggestions.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions', {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.requestAiPromoSuggestionsData = data;
            setState('ui.managerDashboard.data.requestAiPromoSuggestions', data);
            this.requestAiPromoSuggestionsState = 'success';
            setState('ui.managerDashboard.action.requestAiPromoSuggestions.status', 'success');
        }
        else {
            this.requestAiPromoSuggestionsData = [];
            setState('ui.managerDashboard.data.requestAiPromoSuggestions', []);
            this.requestAiPromoSuggestionsState = 'error';
            setState('ui.managerDashboard.action.requestAiPromoSuggestions.status', 'error');
            if (response.error) {
                console.error('[managerDashboard] requestAiPromoSuggestions error:', response.error.message);
            }
        }
    }
    handleRequestAiPromoSuggestionsClick(_event) {
        this.loadRequestAiPromoSuggestions();
    }
}
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "viewDashboardState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowManagerDashboardBase.prototype, "viewDashboardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "requestAiSalesSummaryState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowManagerDashboardBase.prototype, "requestAiSalesSummaryData", void 0);
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "requestAiPromoSuggestionsState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowManagerDashboardBase.prototype, "requestAiPromoSuggestionsData", void 0);
