/// <mls fileReference="_102045_/l2/cafeFlow/web/shared/kitchenQueue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "page.title": "Fila da Cozinha — Preparo de Pedidos",
    "section.kitchenBoard.title": "Fila da Cozinha",
    "section.orderTransition.title": "Atualizar Status do Pedido",
    "intention.boardList.title": "Pedidos na Cozinha",
    "intention.transitionForm.title": "Transicao de Status",
    "empty.kitchenBoard": "Nenhum pedido na fila no momento",
    "empty.transitionPanel": "Selecione um pedido na fila para atualizar o status",
    "field.orderId": "Pedido selecionado",
    "field.status": "Próximo status",
    "field.orderType": "Tipo",
    "field.tableNumber": "Mesa",
    "field.priority": "Prioridade",
    "field.priorityReason": "Motivo da Prioridade",
    "field.receivedAt": "Recebido as",
    "field.inPreparationAt": "Em preparo desde",
    "field.createdAt": "Criado em",
    "action.selectOrder": "Selecionar",
    "action.updateOrderStatus.submit": "Atualizar Status",
    "action.updateOrderStatus.success": "Status do pedido atualizado com sucesso",
    "action.updateOrderStatus.error": "Erro ao atualizar status do pedido",
    "sec.kitchen.board.title": "Sec kitchen board",
    "org.kitchen.board.title": "Exibir fila de pedidos da cozinha ordenados por prioridade e ordem de chegada, permitindo seleção para transição de status",
    "sec.transition.title": "Sec transition",
    "org.transition.panel.title": "Atualizar status do pedido selecionado para o proximo estado do ciclo de vida",
    "section.discover.title": "Fila da Cozinha",
    "section.discover.empty": "Nenhum pedido na fila no momento",
    "section.execute.title": "Atualizar Status do Pedido",
    "section.review.title": "Resumo",
    "field.orderId.label": "Pedido",
    "field.status.label": "Status",
    "field.orderType.label": "Tipo",
    "field.tableNumber.label": "Mesa",
    "field.priority.label": "Prioridade",
    "field.priorityReason.label": "Motivo da Prioridade",
    "field.receivedAt.label": "Recebido às",
    "field.inPreparationAt.label": "Em preparo desde",
    "field.createdAt.label": "Criado em",
    "filter.status.label": "Filtrar por status",
    "action.viewKitchenBoard.label": "Atualizar fila",
    "action.updateOrderStatus.label": "Confirmar",
    "action.selectOrder.label": "Selecionar pedido",
    "status.received.label": "Recebido",
    "status.inPreparation.label": "Em preparo",
    "status.ready.label": "Pronto",
    "status.delivered.label": "Entregue",
    "status.registered.label": "Registrado",
    "sec.discover.title": "Sec discover",
    "sec.execute.title": "Sec execute",
    "org.update.status.title": "Permitir ao cozinheiro atualizar o status do pedido selecionado, marcando como em preparo ou pronto",
    "sec.review.title": "Sec review",
    "org.review.title": "Exibir feedback da última ação e resumo do estado atual da fila",
    "section.queue.title": "Fila de Pedidos",
    "section.queue.empty": "Nenhum pedido na fila no momento",
    "section.transition.title": "Atualizar Status do Pedido",
    "section.transition.empty": "Selecione um pedido da fila para atualizar o status",
    "column.orderId": "Pedido",
    "column.status": "Status",
    "column.orderType": "Tipo",
    "column.tableNumber": "Mesa",
    "column.priority": "Prioridade",
    "column.priorityReason": "Motivo da Prioridade",
    "column.receivedAt": "Recebido às",
    "column.inPreparationAt": "Em preparo desde",
    "column.createdAt": "Criado em",
    "action.select": "Selecionar",
    "action.refresh": "Atualizar fila",
    "action.updateOrderStatus": "Confirmar alteração",
    "sec.kitchen.queue.title": "Sec kitchen queue",
    "sec.order.transition.title": "Sec order transition",
    "org.status.transition.title": "Atualizar status do pedido selecionado na fila, apresentando a próxima transição válida do ciclo de vida"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowKitchenQueueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewKitchenBoardState = 'idle';
        this.viewKitchenBoardData = { items: [], total: 0 };
        this.updateOrderStatusState = 'idle';
        this.updateOrderStatusOrderId = '';
        this.updateOrderStatusStatus = '';
        this.updateOrderStatusOutput = null;
        this.updateOrderStatusError = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const savedStatus = getState('ui.kitchenQueue.status');
        if (typeof savedStatus === 'string') {
            this.status = savedStatus;
        }
        const savedViewStatus = getState('ui.kitchenQueue.action.viewKitchenBoard.status');
        if (typeof savedViewStatus === 'string') {
            this.viewKitchenBoardState = savedViewStatus;
        }
        const savedViewData = getState('ui.kitchenQueue.data.viewKitchenBoard');
        if (savedViewData && typeof savedViewData === 'object') {
            this.viewKitchenBoardData = savedViewData;
        }
        const savedUpdateStatus = getState('ui.kitchenQueue.action.updateOrderStatus.status');
        if (typeof savedUpdateStatus === 'string') {
            this.updateOrderStatusState = savedUpdateStatus;
        }
        const savedOrderId = getState('ui.kitchenQueue.input.updateOrderStatus.orderId');
        if (typeof savedOrderId === 'string') {
            this.updateOrderStatusOrderId = savedOrderId;
        }
        const savedOrderStatusInput = getState('ui.kitchenQueue.input.updateOrderStatus.status');
        if (typeof savedOrderStatusInput === 'string') {
            this.updateOrderStatusStatus = savedOrderStatusInput;
        }
        const savedOutput = getState('ui.kitchenQueue.output.updateOrderStatus');
        if (savedOutput !== undefined && savedOutput !== null) {
            this.updateOrderStatusOutput = savedOutput;
        }
        const savedError = getState('ui.kitchenQueue.action.updateOrderStatus.error');
        if (typeof savedError === 'string') {
            this.updateOrderStatusError = savedError;
        }
        subscribe([
            'ui.kitchenQueue.status',
            'ui.kitchenQueue.action.viewKitchenBoard.status',
            'ui.kitchenQueue.data.viewKitchenBoard',
            'ui.kitchenQueue.action.updateOrderStatus.status',
            'ui.kitchenQueue.input.updateOrderStatus.orderId',
            'ui.kitchenQueue.input.updateOrderStatus.status',
            'ui.kitchenQueue.output.updateOrderStatus',
            'ui.kitchenQueue.action.updateOrderStatus.error',
        ], this);
        this.loadViewKitchenBoard();
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.kitchenQueue.status',
            'ui.kitchenQueue.action.viewKitchenBoard.status',
            'ui.kitchenQueue.data.viewKitchenBoard',
            'ui.kitchenQueue.action.updateOrderStatus.status',
            'ui.kitchenQueue.input.updateOrderStatus.orderId',
            'ui.kitchenQueue.input.updateOrderStatus.status',
            'ui.kitchenQueue.output.updateOrderStatus',
            'ui.kitchenQueue.action.updateOrderStatus.error',
        ], this);
        super.disconnectedCallback();
    }
    // --- Query: viewKitchenBoard ---
    async loadViewKitchenBoard() {
        this.viewKitchenBoardState = 'loading';
        setState('ui.kitchenQueue.action.viewKitchenBoard.status', 'loading');
        this.requestUpdate();
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.orderLifecycle.viewKitchenBoard', {}, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.viewKitchenBoardData = data;
            setState('ui.kitchenQueue.data.viewKitchenBoard', data);
            this.viewKitchenBoardState = 'success';
            setState('ui.kitchenQueue.action.viewKitchenBoard.status', 'success');
        }
        else {
            this.viewKitchenBoardData = { items: [], total: 0 };
            setState('ui.kitchenQueue.data.viewKitchenBoard', { items: [], total: 0 });
            this.viewKitchenBoardState = 'error';
            setState('ui.kitchenQueue.action.viewKitchenBoard.status', 'error');
            if (response.error) {
                console.error('[viewKitchenBoard]', response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleViewKitchenBoardClick(_e) {
        this.loadViewKitchenBoard();
    }
    // --- Command: updateOrderStatus ---
    async updateOrderStatus() {
        const orderId = this.updateOrderStatusOrderId;
        const statusValue = this.updateOrderStatusStatus;
        if (!orderId || !statusValue) {
            this.updateOrderStatusState = 'idle';
            setState('ui.kitchenQueue.action.updateOrderStatus.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.updateOrderStatusState = 'loading';
        setState('ui.kitchenQueue.action.updateOrderStatus.status', 'loading');
        this.requestUpdate();
        const params = {
            orderId,
            status: statusValue,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.orderLifecycle.updateOrderStatus', params, options);
        if (response.ok) {
            const data = response.data ?? {};
            this.updateOrderStatusOutput = data;
            setState('ui.kitchenQueue.output.updateOrderStatus', data);
            // Refresh query actions
            await this.loadViewKitchenBoard();
            // Clear input state keys
            this.updateOrderStatusOrderId = '';
            setState('ui.kitchenQueue.input.updateOrderStatus.orderId', '');
            this.updateOrderStatusStatus = '';
            setState('ui.kitchenQueue.input.updateOrderStatus.status', '');
            // Clear error
            this.updateOrderStatusError = '';
            setState('ui.kitchenQueue.action.updateOrderStatus.error', '');
            this.updateOrderStatusState = 'success';
            setState('ui.kitchenQueue.action.updateOrderStatus.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.updateOrderStatus.error'];
            this.updateOrderStatusError = errorMsg;
            setState('ui.kitchenQueue.action.updateOrderStatus.error', errorMsg);
            this.updateOrderStatusState = 'error';
            setState('ui.kitchenQueue.action.updateOrderStatus.status', 'error');
            if (response.error) {
                console.error('[updateOrderStatus]', response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleUpdateOrderStatusClick(_e) {
        runBlockingUiAction(async (_signal) => {
            await this.updateOrderStatus();
        }, { mode: 'blocking' });
    }
    // --- StateSetter: setUpdateOrderStatusOrderId ---
    setUpdateOrderStatusOrderId(value) {
        this.updateOrderStatusOrderId = value;
        setState('ui.kitchenQueue.input.updateOrderStatus.orderId', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusOrderIdChange(e) {
        const target = e.target;
        if (!target)
            return;
        const value = target.value ?? '';
        this.setUpdateOrderStatusOrderId(value);
    }
    // --- StateSetter: setUpdateOrderStatusStatus ---
    setUpdateOrderStatusStatus(value) {
        this.updateOrderStatusStatus = value;
        setState('ui.kitchenQueue.input.updateOrderStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusStatusChange(e) {
        const target = e.target;
        if (!target)
            return;
        const value = target.value ?? '';
        this.setUpdateOrderStatusStatus(value);
    }
}
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "viewKitchenBoardState", void 0);
__decorate([
    property({ type: Object })
], CafeFlowKitchenQueueBase.prototype, "viewKitchenBoardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "updateOrderStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "updateOrderStatusOrderId", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "updateOrderStatusStatus", void 0);
__decorate([
    property({ type: Object })
], CafeFlowKitchenQueueBase.prototype, "updateOrderStatusOutput", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "updateOrderStatusError", void 0);
