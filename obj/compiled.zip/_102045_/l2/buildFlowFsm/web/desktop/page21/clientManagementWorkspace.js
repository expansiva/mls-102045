/// <mls fileReference="_102045_/l2/buildFlowFsm/web/desktop/page21/clientManagementWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var _BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgLang, _BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgCache;
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmClientManagementWorkspaceBase, messages as sharedMessages } from '/_102045_/l2/buildFlowFsm/web/shared/clientManagementWorkspace.js';
const sharedFallback = sharedMessages[Object.keys(sharedMessages)[0]];
/// **collab_i18n_start**
const s_en = sharedMessages['en'] ?? sharedFallback;
const pageMessage_en = {
    'empty': s_en['intent.clientManagementWorkspace.listClients.list.empty'],
    'filter.name': s_en['intent.clientManagementWorkspace.listClients.list.filter.name.label'],
    'filter.company': s_en['intent.clientManagementWorkspace.listClients.list.filter.company.label'],
    'filter.email': s_en['intent.clientManagementWorkspace.listClients.list.filter.email.label'],
    'search': 'Search',
    'newClient': 'New client',
    'col.name': s_en['intent.clientManagementWorkspace.listClients.list.filter.name.label'],
    'col.company': s_en['intent.clientManagementWorkspace.listClients.list.filter.company.label'],
    'col.email': s_en['intent.clientManagementWorkspace.listClients.list.filter.email.label'],
    'total': s_en['intent.clientManagementWorkspace.listClients.list.column.total.label'],
    'selectHint': 'Select a client to view their profile',
    'noSelection': 'No client selected',
    'identity': 'Identity',
    'companyBlock': 'Company',
    'contactBlock': 'Contact',
    'field.name': s_en['intent.clientManagementWorkspace.createClientCmd.form.field.name.label'],
    'field.email': s_en['intent.clientManagementWorkspace.createClientCmd.form.field.email.label'],
    'field.company': s_en['intent.clientManagementWorkspace.createClientCmd.form.field.company.label'],
    'field.phone': s_en['intent.clientManagementWorkspace.createClientCmd.form.field.phone.label'],
    'field.address': s_en['intent.clientManagementWorkspace.createClientCmd.form.field.address.label'],
    'required': 'Required',
    'createClient': s_en['intent.clientManagementWorkspace.createClientCmd.form.action.createClientCmd'],
    'saveClient': 'Save client',
    'edit': 'Edit',
    'cancel': 'Cancel',
    'deleteClient': s_en['intent.clientManagementWorkspace.deleteClientCmd.form.action.deleteClientCmd'],
    'delete.confirmPrefix': 'Delete client',
    'delete.confirmSuffix': '? This cannot be undone.',
    'create.success': s_en['action.createClientCmd.success'],
    'create.error': s_en['action.createClientCmd.error'],
    'update.success': s_en['action.updateClientCmd.success'],
    'update.error': s_en['action.updateClientCmd.error'],
    'delete.success': s_en['action.deleteClientCmd.success'],
    'delete.error': s_en['action.deleteClientCmd.error'],
    'prev': 'Previous',
    'next': 'Next',
    'page': 'Page',
    'loading': 'Loading…',
    'saving': 'Saving…',
    'deleting': 'Deleting…',
    'creating': 'Creating…',
    'dismiss': 'Dismiss',
};
const s_pt_br = sharedMessages['pt-br'] ?? sharedFallback;
const pageMessage_pt_br = {
    'empty': s_pt_br['intent.clientManagementWorkspace.listClients.list.empty'],
    'filter.name': s_pt_br['intent.clientManagementWorkspace.listClients.list.filter.name.label'],
    'filter.company': s_pt_br['intent.clientManagementWorkspace.listClients.list.filter.company.label'],
    'filter.email': s_pt_br['intent.clientManagementWorkspace.listClients.list.filter.email.label'],
    'search': 'Buscar',
    'newClient': 'Novo cliente',
    'col.name': s_pt_br['intent.clientManagementWorkspace.listClients.list.filter.name.label'],
    'col.company': s_pt_br['intent.clientManagementWorkspace.listClients.list.filter.company.label'],
    'col.email': s_pt_br['intent.clientManagementWorkspace.listClients.list.filter.email.label'],
    'total': s_pt_br['intent.clientManagementWorkspace.listClients.list.column.total.label'],
    'selectHint': 'Selecione um cliente para ver o perfil',
    'noSelection': 'Nenhum cliente selecionado',
    'identity': 'Identidade',
    'companyBlock': 'Empresa',
    'contactBlock': 'Contato',
    'field.name': s_pt_br['intent.clientManagementWorkspace.createClientCmd.form.field.name.label'],
    'field.email': s_pt_br['intent.clientManagementWorkspace.createClientCmd.form.field.email.label'],
    'field.company': s_pt_br['intent.clientManagementWorkspace.createClientCmd.form.field.company.label'],
    'field.phone': s_pt_br['intent.clientManagementWorkspace.createClientCmd.form.field.phone.label'],
    'field.address': s_pt_br['intent.clientManagementWorkspace.createClientCmd.form.field.address.label'],
    'required': 'Obrigatório',
    'createClient': s_pt_br['intent.clientManagementWorkspace.createClientCmd.form.action.createClientCmd'],
    'saveClient': 'Salvar cliente',
    'edit': 'Editar',
    'cancel': 'Cancelar',
    'deleteClient': s_pt_br['intent.clientManagementWorkspace.deleteClientCmd.form.action.deleteClientCmd'],
    'delete.confirmPrefix': 'Excluir cliente',
    'delete.confirmSuffix': '? Esta ação não pode ser desfeita.',
    'create.success': s_pt_br['action.createClientCmd.success'],
    'create.error': s_pt_br['action.createClientCmd.error'],
    'update.success': s_pt_br['action.updateClientCmd.success'],
    'update.error': s_pt_br['action.updateClientCmd.error'],
    'delete.success': s_pt_br['action.deleteClientCmd.success'],
    'delete.error': s_pt_br['action.deleteClientCmd.error'],
    'prev': 'Anterior',
    'next': 'Próxima',
    'page': 'Página',
    'loading': 'Carregando…',
    'saving': 'Salvando…',
    'deleting': 'Excluindo…',
    'creating': 'Criando…',
    'dismiss': 'Fechar',
};
const s_es = sharedMessages['es'] ?? sharedFallback;
const pageMessage_es = {
    'empty': s_es['intent.clientManagementWorkspace.listClients.list.empty'],
    'filter.name': s_es['intent.clientManagementWorkspace.listClients.list.filter.name.label'],
    'filter.company': s_es['intent.clientManagementWorkspace.listClients.list.filter.company.label'],
    'filter.email': s_es['intent.clientManagementWorkspace.listClients.list.filter.email.label'],
    'search': 'Buscar',
    'newClient': 'Nuevo cliente',
    'col.name': s_es['intent.clientManagementWorkspace.listClients.list.filter.name.label'],
    'col.company': s_es['intent.clientManagementWorkspace.listClients.list.filter.company.label'],
    'col.email': s_es['intent.clientManagementWorkspace.listClients.list.filter.email.label'],
    'total': s_es['intent.clientManagementWorkspace.listClients.list.column.total.label'],
    'selectHint': 'Seleccione un cliente para ver su perfil',
    'noSelection': 'Ningún cliente seleccionado',
    'identity': 'Identidad',
    'companyBlock': 'Empresa',
    'contactBlock': 'Contacto',
    'field.name': s_es['intent.clientManagementWorkspace.createClientCmd.form.field.name.label'],
    'field.email': s_es['intent.clientManagementWorkspace.createClientCmd.form.field.email.label'],
    'field.company': s_es['intent.clientManagementWorkspace.createClientCmd.form.field.company.label'],
    'field.phone': s_es['intent.clientManagementWorkspace.createClientCmd.form.field.phone.label'],
    'field.address': s_es['intent.clientManagementWorkspace.createClientCmd.form.field.address.label'],
    'required': 'Obligatorio',
    'createClient': s_es['intent.clientManagementWorkspace.createClientCmd.form.action.createClientCmd'],
    'saveClient': 'Guardar cliente',
    'edit': 'Editar',
    'cancel': 'Cancelar',
    'deleteClient': s_es['intent.clientManagementWorkspace.deleteClientCmd.form.action.deleteClientCmd'],
    'delete.confirmPrefix': 'Eliminar cliente',
    'delete.confirmSuffix': '? Esta acción no se puede deshacer.',
    'create.success': s_es['action.createClientCmd.success'],
    'create.error': s_es['action.createClientCmd.error'],
    'update.success': s_es['action.updateClientCmd.success'],
    'update.error': s_es['action.updateClientCmd.error'],
    'delete.success': s_es['action.deleteClientCmd.success'],
    'delete.error': s_es['action.deleteClientCmd.error'],
    'prev': 'Anterior',
    'next': 'Siguiente',
    'page': 'Página',
    'loading': 'Cargando…',
    'saving': 'Guardando…',
    'deleting': 'Eliminando…',
    'creating': 'Creando…',
    'dismiss': 'Cerrar',
};
const pageMessages = { 'en': pageMessage_en, 'pt-br': pageMessage_pt_br, 'es': pageMessage_es };
/// **collab_i18n_end**
const pageFallback = pageMessages[Object.keys(pageMessages)[0]];
let BuildFlowFsmDesktopPage21ClientManagementWorkspacePage = class BuildFlowFsmDesktopPage21ClientManagementWorkspacePage extends BuildFlowFsmClientManagementWorkspaceBase {
    constructor() {
        super(...arguments);
        _BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgLang.set(this, null);
        _BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgCache.set(this, pageFallback);
        /** Presentation-only: view selected profile, edit it, or create a new client. */
        this._profileMode = 'view';
    }
    /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
    get msg() {
        const lang = (document.documentElement.lang || '').toLowerCase();
        if (lang !== __classPrivateFieldGet(this, _BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgLang, "f")) {
            __classPrivateFieldSet(this, _BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgLang, lang, "f");
            __classPrivateFieldSet(this, _BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgCache, pageMessages[this.getMessageKey(pageMessages)] || pageFallback, "f");
        }
        return __classPrivateFieldGet(this, _BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgCache, "f");
    }
    rowId(row) {
        const r = row;
        if (typeof r.clientId === 'string' && r.clientId) {
            return r.clientId;
        }
        if (typeof r.id === 'string' && r.id) {
            return r.id;
        }
        return '';
    }
    rowName(row) {
        const r = row;
        return typeof r.name === 'string' ? r.name : '';
    }
    rowCompany(row) {
        const r = row;
        return typeof r.company === 'string' ? r.company : '';
    }
    rowEmail(row) {
        const r = row;
        return typeof r.email === 'string' ? r.email : '';
    }
    rowPhone(row) {
        const r = row;
        return typeof r.phone === 'string' ? r.phone : '';
    }
    rowAddress(row) {
        const r = row;
        return typeof r.address === 'string' ? r.address : '';
    }
    currentPage() {
        const n = Number(this.listClientsPage);
        if (!Number.isNaN(n) && n > 0) {
            return n;
        }
        return 1;
    }
    currentPageSize() {
        const n = Number(this.listClientsPageSize);
        if (!Number.isNaN(n) && n > 0) {
            return n;
        }
        return 10;
    }
    selectedClient() {
        const selectedId = this.updateClientCmdClientId || this.deleteClientCmdClientId;
        if (!selectedId) {
            return null;
        }
        const clients = this.listClientsData?.clients ?? [];
        const found = clients.find((c) => this.rowId(c) === selectedId);
        return found ?? null;
    }
    selectClient(row) {
        const id = this.rowId(row);
        this.setUpdateClientCmdClientId(id);
        this.setDeleteClientCmdClientId(id);
        this.setUpdateClientCmdName(this.rowName(row));
        this.setUpdateClientCmdCompany(this.rowCompany(row));
        this.setUpdateClientCmdEmail(this.rowEmail(row));
        this.setUpdateClientCmdPhone(this.rowPhone(row));
        this.setUpdateClientCmdAddress(this.rowAddress(row));
        this._profileMode = 'view';
        this.requestUpdate();
    }
    openCreate() {
        this._profileMode = 'create';
        this.setCreateClientCmdName('');
        this.setCreateClientCmdEmail('');
        this.setCreateClientCmdCompany('');
        this.setCreateClientCmdPhone('');
        this.setCreateClientCmdAddress('');
        this.requestUpdate();
    }
    openEdit() {
        const selected = this.selectedClient();
        if (!selected) {
            return;
        }
        this.setUpdateClientCmdClientId(this.rowId(selected));
        this.setUpdateClientCmdName(this.rowName(selected));
        this.setUpdateClientCmdCompany(this.rowCompany(selected));
        this.setUpdateClientCmdEmail(this.rowEmail(selected));
        this.setUpdateClientCmdPhone(this.rowPhone(selected));
        this.setUpdateClientCmdAddress(this.rowAddress(selected));
        this._profileMode = 'edit';
        this.requestUpdate();
    }
    cancelEdit() {
        const selected = this.selectedClient();
        if (selected) {
            this.setUpdateClientCmdName(this.rowName(selected));
            this.setUpdateClientCmdCompany(this.rowCompany(selected));
            this.setUpdateClientCmdEmail(this.rowEmail(selected));
            this.setUpdateClientCmdPhone(this.rowPhone(selected));
            this.setUpdateClientCmdAddress(this.rowAddress(selected));
        }
        this._profileMode = 'view';
        this.requestUpdate();
    }
    cancelCreate() {
        this._profileMode = 'view';
        this.requestUpdate();
    }
    confirmDelete(row) {
        if (!row) {
            return;
        }
        const msg = this.msg;
        const name = this.rowName(row) || this.rowId(row);
        const ok = window.confirm(`${msg['delete.confirmPrefix']} "${name}"${msg['delete.confirmSuffix']}`);
        if (!ok) {
            return;
        }
        this.setDeleteClientCmdClientId(this.rowId(row));
        this.handleDeleteClientCmdClick();
    }
    goToPage(page) {
        if (page < 1) {
            return;
        }
        this.setListClientsPage(String(page));
        this.handleListClientsClick();
    }
    /** Main render. Split the page into render<Name>() methods and call them from here. */
    render() {
        if (this.createClientCmdState === 'success' && this._profileMode === 'create') {
            this._profileMode = 'view';
        }
        if (this.updateClientCmdState === 'success' && this._profileMode === 'edit') {
            this._profileMode = 'view';
        }
        if (this.deleteClientCmdState === 'success') {
            // selection may have been cleared by the base after delete
            if (!this.deleteClientCmdClientId && !this.updateClientCmdClientId) {
                this._profileMode = 'view';
            }
        }
        return html `
      <div class="min-h-full bg-[var(--page-bg,#f8fafc)] text-[var(--text-default,#0f172a)] p-4 md:p-6">
        <div class="grid grid-cols-1 md:grid-cols-5 gap-4 md:gap-6 items-start">
          <div class="md:col-span-2 flex flex-col gap-3">
            ${this.renderFinder()}
          </div>
          <div class="md:col-span-3 flex flex-col gap-3">
            ${this.renderProfilePanel()}
          </div>
        </div>
      </div>
    `;
    }
    renderFinder() {
        const msg = this.msg;
        return html `
      <section class="rounded-lg border border-[var(--border-default,#e2e8f0)] bg-[var(--surface-bg,#ffffff)] shadow-sm">
        <div class="p-3 border-b border-[var(--border-subtle,#e2e8f0)] flex flex-wrap items-end gap-2">
          <label class="flex flex-col gap-1 text-sm flex-1 min-w-[7rem]">
            <span class="text-[var(--text-muted,#64748b)]">${msg['filter.name']}</span>
            <input
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              type="search"
              .value=${this.listClientsName}
              @input=${(e) => this.handleListClientsNameChange(e)}
              @keydown=${(e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.setListClientsPage('1');
                this.handleListClientsClick();
            }
        }}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm flex-1 min-w-[7rem]">
            <span class="text-[var(--text-muted,#64748b)]">${msg['filter.company']}</span>
            <input
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              type="search"
              .value=${this.listClientsCompany}
              @input=${(e) => this.handleListClientsCompanyChange(e)}
              @keydown=${(e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.setListClientsPage('1');
                this.handleListClientsClick();
            }
        }}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm flex-1 min-w-[7rem]">
            <span class="text-[var(--text-muted,#64748b)]">${msg['filter.email']}</span>
            <input
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              type="search"
              .value=${this.listClientsEmail}
              @input=${(e) => this.handleListClientsEmailChange(e)}
              @keydown=${(e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.setListClientsPage('1');
                this.handleListClientsClick();
            }
        }}
            />
          </label>
          <button
            type="button"
            class="rounded-md px-3 py-1.5 text-sm font-medium bg-[var(--button-secondary-bg,#f1f5f9)] text-[var(--button-secondary-text,#0f172a)] border border-[var(--button-secondary-border,#e2e8f0)]"
            ?disabled=${this.listClientsState === 'loading'}
            @click=${(e) => {
            e.preventDefault();
            this.setListClientsPage('1');
            this.handleListClientsClick();
        }}
          >
            ${msg['search']}
          </button>
          <button
            type="button"
            class="rounded-md px-3 py-1.5 text-sm font-medium bg-[var(--button-primary-bg,#2563eb)] text-[var(--button-primary-text,#ffffff)]"
            @click=${(e) => {
            e.preventDefault();
            this.openCreate();
        }}
          >
            ${msg['newClient']}
          </button>
        </div>
        ${this.renderClientList()}
        ${this.renderPagination()}
      </section>
    `;
    }
    renderClientList() {
        const msg = this.msg;
        if (this.listClientsState === 'loading' && !(this.listClientsData?.clients?.length)) {
            return html `
        <div class="p-4 text-sm text-[var(--text-muted,#64748b)]" aria-busy="true">
          ${msg['loading']}
        </div>
      `;
        }
        const clients = this.listClientsData?.clients ?? [];
        if (!clients.length) {
            return html `
        <div class="p-4 text-sm text-[var(--text-muted,#64748b)]">
          ${msg['empty']}
        </div>
      `;
        }
        const selectedId = this.updateClientCmdClientId || this.deleteClientCmdClientId;
        return html `
      <ul class="divide-y divide-[var(--border-subtle,#e2e8f0)] max-h-[28rem] overflow-y-auto" role="listbox">
        ${clients.map((row) => {
            const id = this.rowId(row);
            const isSelected = id !== '' && id === selectedId;
            return html `
            <li>
              <button
                type="button"
                role="option"
                aria-selected=${isSelected ? 'true' : 'false'}
                class="w-full text-left px-3 py-2.5 transition-colors ${isSelected
                ? 'bg-[var(--selected-bg,#dbeafe)] text-[var(--selected-text,#0f172a)] border-l-2 border-[var(--selected-border,#2563eb)]'
                : 'hover:bg-[var(--surface-alt-bg,#f8fafc)] text-[var(--text-default,#0f172a)]'}"
                @click=${(e) => {
                e.preventDefault();
                this.selectClient(row);
            }}
              >
                <div class="font-medium text-[var(--text-strong,#0f172a)] truncate">
                  ${this.rowName(row) || id}
                </div>
                <div class="text-sm text-[var(--text-muted,#64748b)] truncate">
                  ${this.rowCompany(row) || this.rowEmail(row) || ''}
                </div>
              </button>
            </li>
          `;
        })}
      </ul>
    `;
    }
    renderPagination() {
        const msg = this.msg;
        const total = typeof this.listClientsData?.total === 'number' ? this.listClientsData.total : 0;
        const page = this.currentPage();
        const pageSize = this.currentPageSize();
        const totalPages = Math.max(1, Math.ceil(total / pageSize) || 1);
        const canPrev = page > 1;
        const canNext = page < totalPages;
        return html `
      <div class="flex items-center justify-between gap-2 px-3 py-2 border-t border-[var(--border-subtle,#e2e8f0)] text-sm text-[var(--text-muted,#64748b)]">
        <span>${msg['total']}: ${total}</span>
        <div class="flex items-center gap-2">
          <button
            type="button"
            class="rounded-md px-2 py-1 bg-[var(--button-secondary-bg,#f1f5f9)] text-[var(--button-secondary-text,#0f172a)] border border-[var(--button-secondary-border,#e2e8f0)] disabled:opacity-50"
            ?disabled=${!canPrev || this.listClientsState === 'loading'}
            @click=${(e) => {
            e.preventDefault();
            this.goToPage(page - 1);
        }}
          >
            ${msg['prev']}
          </button>
          <span>${msg['page']} ${page}</span>
          <button
            type="button"
            class="rounded-md px-2 py-1 bg-[var(--button-secondary-bg,#f1f5f9)] text-[var(--button-secondary-text,#0f172a)] border border-[var(--button-secondary-border,#e2e8f0)] disabled:opacity-50"
            ?disabled=${!canNext || this.listClientsState === 'loading'}
            @click=${(e) => {
            e.preventDefault();
            this.goToPage(page + 1);
        }}
          >
            ${msg['next']}
          </button>
        </div>
      </div>
    `;
    }
    renderProfilePanel() {
        if (this._profileMode === 'create') {
            return this.renderCreateForm();
        }
        const selected = this.selectedClient();
        if (!selected && !this.updateClientCmdClientId) {
            return this.renderEmptyProfile();
        }
        if (this._profileMode === 'edit') {
            return this.renderEditForm(selected);
        }
        return this.renderProfileRead(selected);
    }
    renderEmptyProfile() {
        const msg = this.msg;
        return html `
      <section class="rounded-lg border border-[var(--border-default,#e2e8f0)] bg-[var(--surface-bg,#ffffff)] p-6 min-h-[16rem] flex items-center justify-center">
        <p class="text-[var(--text-muted,#64748b)] text-sm">${msg['selectHint']}</p>
      </section>
    `;
    }
    renderProfileRead(selected) {
        const msg = this.msg;
        const name = selected ? this.rowName(selected) : this.updateClientCmdName;
        const company = selected ? this.rowCompany(selected) : this.updateClientCmdCompany;
        const email = selected ? this.rowEmail(selected) : this.updateClientCmdEmail;
        const phone = selected ? this.rowPhone(selected) : this.updateClientCmdPhone;
        const address = selected ? this.rowAddress(selected) : this.updateClientCmdAddress;
        const displayName = name || msg['noSelection'];
        return html `
      <section class="rounded-lg border border-[var(--border-default,#e2e8f0)] bg-[var(--surface-bg,#ffffff)] shadow-sm">
        <div class="flex items-start justify-between gap-3 p-4 border-b border-[var(--border-subtle,#e2e8f0)]">
          <h2 class="text-xl font-semibold text-[var(--text-strong,#0f172a)] m-0">${displayName}</h2>
          <button
            type="button"
            class="rounded-md px-3 py-1.5 text-sm font-medium bg-[var(--button-secondary-bg,#f1f5f9)] text-[var(--button-secondary-text,#0f172a)] border border-[var(--button-secondary-border,#e2e8f0)]"
            ?disabled=${!selected && !this.updateClientCmdClientId}
            @click=${(e) => {
            e.preventDefault();
            this.openEdit();
        }}
          >
            ${msg['edit']}
          </button>
        </div>

        ${this.renderUpdateFeedback()}
        ${this.renderDeleteFeedback()}

        <div class="p-4 flex flex-col gap-5">
          <div>
            <h3 class="text-xs font-semibold uppercase tracking-wide text-[var(--text-muted,#64748b)] mb-2">${msg['identity']}</h3>
            <dl class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              <div>
                <dt class="text-[var(--text-muted,#64748b)]">${msg['field.name']}</dt>
                <dd class="m-0 text-[var(--text-default,#0f172a)] font-medium">${name || '—'}</dd>
              </div>
            </dl>
          </div>

          <div>
            <h3 class="text-xs font-semibold uppercase tracking-wide text-[var(--text-muted,#64748b)] mb-2">${msg['companyBlock']}</h3>
            <dl class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              <div>
                <dt class="text-[var(--text-muted,#64748b)]">${msg['field.company']}</dt>
                <dd class="m-0 text-[var(--text-default,#0f172a)]">${company || '—'}</dd>
              </div>
              <div>
                <dt class="text-[var(--text-muted,#64748b)]">${msg['field.address']}</dt>
                <dd class="m-0 text-[var(--text-default,#0f172a)]">${address || '—'}</dd>
              </div>
            </dl>
          </div>

          <div>
            <h3 class="text-xs font-semibold uppercase tracking-wide text-[var(--text-muted,#64748b)] mb-2">${msg['contactBlock']}</h3>
            <dl class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              <div>
                <dt class="text-[var(--text-muted,#64748b)]">${msg['field.email']}</dt>
                <dd class="m-0">
                  ${email
            ? html `<a class="text-[var(--link-text,#2563eb)] underline-offset-2 hover:underline" href=${`mailto:${email}`}>${email}</a>`
            : html `<span class="text-[var(--text-default,#0f172a)]">—</span>`}
                </dd>
              </div>
              <div>
                <dt class="text-[var(--text-muted,#64748b)]">${msg['field.phone']}</dt>
                <dd class="m-0">
                  ${phone
            ? html `<a class="text-[var(--link-text,#2563eb)] underline-offset-2 hover:underline" href=${`tel:${phone}`}>${phone}</a>`
            : html `<span class="text-[var(--text-default,#0f172a)]">—</span>`}
                </dd>
              </div>
            </dl>
          </div>
        </div>

        <div class="px-4 py-3 border-t border-[var(--border-subtle,#e2e8f0)] flex justify-end">
          <button
            type="button"
            class="rounded-md px-3 py-1.5 text-sm font-medium bg-[var(--button-danger-bg,#dc2626)] text-[var(--button-danger-text,#ffffff)] disabled:opacity-50"
            ?disabled=${this.deleteClientCmdState === 'loading' || (!selected && !this.deleteClientCmdClientId)}
            @click=${(e) => {
            e.preventDefault();
            this.confirmDelete(selected);
        }}
          >
            ${this.deleteClientCmdState === 'loading' ? msg['deleting'] : msg['deleteClient']}
          </button>
        </div>
      </section>
    `;
    }
    renderCreateForm() {
        const msg = this.msg;
        const loading = this.createClientCmdState === 'loading';
        const canSubmit = !loading &&
            this.createClientCmdName.trim() !== '' &&
            this.createClientCmdEmail.trim() !== '';
        return html `
      <section class="rounded-lg border border-[var(--border-default,#e2e8f0)] bg-[var(--surface-bg,#ffffff)] shadow-sm">
        <div class="flex items-start justify-between gap-3 p-4 border-b border-[var(--border-subtle,#e2e8f0)]">
          <h2 class="text-xl font-semibold text-[var(--text-strong,#0f172a)] m-0">${msg['newClient']}</h2>
          <button
            type="button"
            class="rounded-md px-3 py-1.5 text-sm bg-[var(--button-secondary-bg,#f1f5f9)] text-[var(--button-secondary-text,#0f172a)] border border-[var(--button-secondary-border,#e2e8f0)]"
            @click=${(e) => {
            e.preventDefault();
            this.cancelCreate();
        }}
          >
            ${msg['cancel']}
          </button>
        </div>

        ${this.renderCreateFeedback()}

        <form
          class="p-4 flex flex-col gap-3"
          @submit=${(e) => {
            e.preventDefault();
            if (canSubmit) {
                this.handleCreateClientCmdClick(e);
            }
        }}
        >
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.name']} <span class="text-[var(--status-error-text,#b91c1c)]">*</span></span>
            <input
              required
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.createClientCmdName}
              @input=${(e) => this.handleCreateClientCmdNameChange(e)}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.email']} <span class="text-[var(--status-error-text,#b91c1c)]">*</span></span>
            <input
              required
              type="email"
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.createClientCmdEmail}
              @input=${(e) => this.handleCreateClientCmdEmailChange(e)}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.company']}</span>
            <input
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.createClientCmdCompany}
              @input=${(e) => this.handleCreateClientCmdCompanyChange(e)}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.phone']}</span>
            <input
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.createClientCmdPhone}
              @input=${(e) => this.handleCreateClientCmdPhoneChange(e)}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.address']}</span>
            <input
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.createClientCmdAddress}
              @input=${(e) => this.handleCreateClientCmdAddressChange(e)}
            />
          </label>

          <div class="flex justify-end pt-2">
            <button
              type="submit"
              class="rounded-md px-3 py-1.5 text-sm font-medium bg-[var(--button-primary-bg,#2563eb)] text-[var(--button-primary-text,#ffffff)] disabled:opacity-50"
              ?disabled=${!canSubmit}
            >
              ${loading ? msg['creating'] : msg['createClient']}
            </button>
          </div>
        </form>
      </section>
    `;
    }
    renderEditForm(selected) {
        const msg = this.msg;
        const loading = this.updateClientCmdState === 'loading';
        const titleName = (selected ? this.rowName(selected) : '') ||
            this.updateClientCmdName ||
            msg['noSelection'];
        const canSubmit = !loading &&
            this.updateClientCmdClientId.trim() !== '' &&
            this.updateClientCmdName.trim() !== '' &&
            this.updateClientCmdEmail.trim() !== '';
        return html `
      <section class="rounded-lg border border-[var(--border-default,#e2e8f0)] bg-[var(--surface-bg,#ffffff)] shadow-sm">
        <div class="flex items-start justify-between gap-3 p-4 border-b border-[var(--border-subtle,#e2e8f0)]">
          <h2 class="text-xl font-semibold text-[var(--text-strong,#0f172a)] m-0">${titleName}</h2>
          <button
            type="button"
            class="rounded-md px-3 py-1.5 text-sm bg-[var(--button-secondary-bg,#f1f5f9)] text-[var(--button-secondary-text,#0f172a)] border border-[var(--button-secondary-border,#e2e8f0)]"
            @click=${(e) => {
            e.preventDefault();
            this.cancelEdit();
        }}
          >
            ${msg['cancel']}
          </button>
        </div>

        ${this.renderUpdateFeedback()}

        <form
          class="p-4 flex flex-col gap-3"
          @submit=${(e) => {
            e.preventDefault();
            if (canSubmit) {
                this.handleUpdateClientCmdClick(e);
            }
        }}
        >
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.name']} <span class="text-[var(--status-error-text,#b91c1c)]">*</span></span>
            <input
              required
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.updateClientCmdName}
              @input=${(e) => this.handleUpdateClientCmdNameChange(e)}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.email']} <span class="text-[var(--status-error-text,#b91c1c)]">*</span></span>
            <input
              required
              type="email"
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.updateClientCmdEmail}
              @input=${(e) => this.handleUpdateClientCmdEmailChange(e)}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.company']}</span>
            <input
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.updateClientCmdCompany}
              @input=${(e) => this.handleUpdateClientCmdCompanyChange(e)}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.phone']}</span>
            <input
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.updateClientCmdPhone}
              @input=${(e) => this.handleUpdateClientCmdPhoneChange(e)}
            />
          </label>
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-[var(--text-muted,#64748b)]">${msg['field.address']}</span>
            <input
              class="rounded-md border border-[var(--border-default,#e2e8f0)] bg-[var(--input-bg,#ffffff)] px-2 py-1.5 text-[var(--text-default,#0f172a)]"
              .value=${this.updateClientCmdAddress}
              @input=${(e) => this.handleUpdateClientCmdAddressChange(e)}
            />
          </label>

          <div class="flex justify-end pt-2">
            <button
              type="submit"
              class="rounded-md px-3 py-1.5 text-sm font-medium bg-[var(--button-primary-bg,#2563eb)] text-[var(--button-primary-text,#ffffff)] disabled:opacity-50"
              ?disabled=${!canSubmit}
            >
              ${loading ? msg['saving'] : msg['saveClient']}
            </button>
          </div>
        </form>
      </section>
    `;
    }
    renderCreateFeedback() {
        const msg = this.msg;
        if (this.createClientCmdState === 'success') {
            return html `
        <div class="mx-4 mt-3 rounded-md px-3 py-2 text-sm bg-[var(--status-success-bg,#dcfce7)] text-[var(--status-success-text,#166534)]" role="status">
          ${msg['create.success']}
        </div>
      `;
        }
        if (this.createClientCmdState === 'error') {
            const errText = this.createClientCmdError && this.createClientCmdError !== 'action.createClientCmd.error'
                ? this.createClientCmdError
                : msg['create.error'];
            return html `
        <div class="mx-4 mt-3 rounded-md px-3 py-2 text-sm bg-[var(--status-error-bg,#fee2e2)] text-[var(--status-error-text,#b91c1c)]" role="alert">
          <div class="flex items-start justify-between gap-2">
            <span>${errText}</span>
            <button
              type="button"
              class="underline text-sm"
              @click=${(e) => {
                e.preventDefault();
                this.handleCreateClientCmdClick(e);
            }}
            >
              ${msg['createClient']}
            </button>
          </div>
        </div>
      `;
        }
        return nothing;
    }
    renderUpdateFeedback() {
        const msg = this.msg;
        if (this.updateClientCmdState === 'success') {
            return html `
        <div class="mx-4 mt-3 rounded-md px-3 py-2 text-sm bg-[var(--status-success-bg,#dcfce7)] text-[var(--status-success-text,#166534)]" role="status">
          ${msg['update.success']}
        </div>
      `;
        }
        if (this.updateClientCmdState === 'error') {
            const errText = this.updateClientCmdError && this.updateClientCmdError !== 'action.updateClientCmd.error'
                ? this.updateClientCmdError
                : msg['update.error'];
            return html `
        <div class="mx-4 mt-3 rounded-md px-3 py-2 text-sm bg-[var(--status-error-bg,#fee2e2)] text-[var(--status-error-text,#b91c1c)]" role="alert">
          <div class="flex items-start justify-between gap-2">
            <span>${errText}</span>
            <button
              type="button"
              class="underline text-sm"
              @click=${(e) => {
                e.preventDefault();
                this.handleUpdateClientCmdClick(e);
            }}
            >
              ${msg['saveClient']}
            </button>
          </div>
        </div>
      `;
        }
        return nothing;
    }
    renderDeleteFeedback() {
        const msg = this.msg;
        if (this.deleteClientCmdState === 'success') {
            return html `
        <div class="mx-4 mt-3 rounded-md px-3 py-2 text-sm bg-[var(--status-success-bg,#dcfce7)] text-[var(--status-success-text,#166534)]" role="status">
          ${msg['delete.success']}
        </div>
      `;
        }
        if (this.deleteClientCmdState === 'error') {
            const errText = this.deleteClientCmdError && this.deleteClientCmdError !== 'action.deleteClientCmd.error'
                ? this.deleteClientCmdError
                : msg['delete.error'];
            return html `
        <div class="mx-4 mt-3 rounded-md px-3 py-2 text-sm bg-[var(--status-error-bg,#fee2e2)] text-[var(--status-error-text,#b91c1c)]" role="alert">
          ${errText}
        </div>
      `;
        }
        return nothing;
    }
};
_BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgLang = new WeakMap();
_BuildFlowFsmDesktopPage21ClientManagementWorkspacePage_msgCache = new WeakMap();
BuildFlowFsmDesktopPage21ClientManagementWorkspacePage = __decorate([
    customElement('build-flow-fsm--web--desktop--page21--client-management-workspace-102045')
], BuildFlowFsmDesktopPage21ClientManagementWorkspacePage);
export { BuildFlowFsmDesktopPage21ClientManagementWorkspacePage };
