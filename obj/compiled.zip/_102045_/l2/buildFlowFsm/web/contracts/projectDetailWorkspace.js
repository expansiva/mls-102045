/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/projectDetailWorkspace.ts" enhancement="_blank"/>
export const getProjectDetailRoute = 'buildFlowFsm.projectDetailWorkspace.getProjectDetail';
export const listWorkTasksRoute = 'buildFlowFsm.projectDetailWorkspace.listWorkTasks';
export const listChangeOrdersRoute = 'buildFlowFsm.projectDetailWorkspace.listChangeOrders';
export const getChangeOrderDetailRoute = 'buildFlowFsm.projectDetailWorkspace.getChangeOrderDetail';
export const listTimeLogsRoute = 'buildFlowFsm.projectDetailWorkspace.listTimeLogs';
export const listMaterialUsagesRoute = 'buildFlowFsm.projectDetailWorkspace.listMaterialUsages';
export const triggerDelayRiskSuggestionsRoute = 'buildFlowFsm.projectDetailWorkspace.triggerDelayRiskSuggestions';
export const listDelayRiskSuggestionsRoute = 'buildFlowFsm.projectDetailWorkspace.listDelayRiskSuggestions';
