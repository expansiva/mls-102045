/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/clientManagementWorkspace.ts" enhancement="_blank"/>
export const listClientsRoute = 'buildFlowFsm.clientManagementWorkspace.listClients';
export const createClientCmdRoute = 'buildFlowFsm.clientManagementWorkspace.createClientCmd';
export const updateClientCmdRoute = 'buildFlowFsm.clientManagementWorkspace.updateClientCmd';
export const deleteClientCmdRoute = 'buildFlowFsm.clientManagementWorkspace.deleteClientCmd';
