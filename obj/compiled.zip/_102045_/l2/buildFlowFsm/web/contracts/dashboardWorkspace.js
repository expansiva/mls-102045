/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/dashboardWorkspace.ts" enhancement="_blank"/>
export const getDashboardSummaryRoute = 'buildFlowFsm.dashboardWorkspace.getDashboardSummary';
export const getProjectListRoute = 'buildFlowFsm.dashboardWorkspace.getProjectList';
