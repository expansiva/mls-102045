/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/billingSummaryWorkspace.ts" enhancement="_blank"/>
export const listBillingSummariesRoute = 'buildFlowFsm.billingSummaryWorkspace.listBillingSummaries';
export const createBillingSummaryCmdRoute = 'buildFlowFsm.billingSummaryWorkspace.createBillingSummaryCmd';
export const shareBillingSummaryCmdRoute = 'buildFlowFsm.billingSummaryWorkspace.shareBillingSummaryCmd';
