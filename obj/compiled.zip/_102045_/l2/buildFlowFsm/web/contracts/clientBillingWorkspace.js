/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/clientBillingWorkspace.ts" enhancement="_blank"/>
export const getBillingSummaryRoute = 'buildFlowFsm.clientBillingWorkspace.getBillingSummary';
export const getInvoiceRoute = 'buildFlowFsm.clientBillingWorkspace.getInvoice';
