/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/clientStatusWorkspace.ts" enhancement="_blank"/>
export const viewStatusReportRoute = 'buildFlowFsm.clientStatusWorkspace.viewStatusReport';
