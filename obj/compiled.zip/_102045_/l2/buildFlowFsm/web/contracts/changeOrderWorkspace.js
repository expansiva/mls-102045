/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/changeOrderWorkspace.ts" enhancement="_blank"/>
export const cmdCreateChangeOrderRoute = 'buildFlowFsm.changeOrderWorkspace.cmdCreateChangeOrder';
export const cmdUpdateChangeOrderRoute = 'buildFlowFsm.changeOrderWorkspace.cmdUpdateChangeOrder';
export const cmdUpdateChangeOrderStatusRoute = 'buildFlowFsm.changeOrderWorkspace.cmdUpdateChangeOrderStatus';
