/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/fieldLoggingWorkspace.ts" enhancement="_blank"/>
export const submitTimeLogRoute = 'buildFlowFsm.fieldLoggingWorkspace.submitTimeLog';
export const submitVoidTimeLogRoute = 'buildFlowFsm.fieldLoggingWorkspace.submitVoidTimeLog';
export const submitMaterialUsageRoute = 'buildFlowFsm.fieldLoggingWorkspace.submitMaterialUsage';
export const submitVoidMaterialUsageRoute = 'buildFlowFsm.fieldLoggingWorkspace.submitVoidMaterialUsage';
