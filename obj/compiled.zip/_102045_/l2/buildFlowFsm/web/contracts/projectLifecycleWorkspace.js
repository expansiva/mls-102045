/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/projectLifecycleWorkspace.ts" enhancement="_blank"/>
export const createProjectCmdRoute = 'buildFlowFsm.projectLifecycleWorkspace.createProjectCmd';
export const updateProjectCmdRoute = 'buildFlowFsm.projectLifecycleWorkspace.updateProjectCmd';
export const updateProjectStatusCmdRoute = 'buildFlowFsm.projectLifecycleWorkspace.updateProjectStatusCmd';
