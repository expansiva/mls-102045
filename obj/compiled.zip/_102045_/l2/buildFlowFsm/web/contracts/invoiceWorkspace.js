/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/invoiceWorkspace.ts" enhancement="_blank"/>
export const listInvoicesRoute = 'buildFlowFsm.invoiceWorkspace.listInvoices';
export const createInvoiceCmdRoute = 'buildFlowFsm.invoiceWorkspace.createInvoiceCmd';
export const sendInvoiceCmdRoute = 'buildFlowFsm.invoiceWorkspace.sendInvoiceCmd';
