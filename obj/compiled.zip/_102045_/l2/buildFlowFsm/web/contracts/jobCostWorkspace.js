/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/jobCostWorkspace.ts" enhancement="_blank"/>
export const viewJobCostSummaryRoute = 'buildFlowFsm.jobCostWorkspace.viewJobCostSummary';
