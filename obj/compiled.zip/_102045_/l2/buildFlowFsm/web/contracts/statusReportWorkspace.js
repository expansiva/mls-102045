/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/statusReportWorkspace.ts" enhancement="_blank"/>
export const generateReportRoute = 'buildFlowFsm.statusReportWorkspace.generateReport';
export const updateReportContentRoute = 'buildFlowFsm.statusReportWorkspace.updateReportContent';
export const updateReportStatusRoute = 'buildFlowFsm.statusReportWorkspace.updateReportStatus';
