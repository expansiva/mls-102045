/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/myTasksWorkspace.ts" enhancement="_blank"/>
export const listMyWorkTasksRoute = 'buildFlowFsm.myTasksWorkspace.listMyWorkTasks';
export const getWorkTaskDetailRoute = 'buildFlowFsm.myTasksWorkspace.getWorkTaskDetail';
