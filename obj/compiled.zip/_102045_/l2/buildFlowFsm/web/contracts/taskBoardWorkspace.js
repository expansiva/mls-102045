/// <mls fileReference="_102045_/l2/buildFlowFsm/web/contracts/taskBoardWorkspace.ts" enhancement="_blank"/>
export const cmdCreateWorkTaskRoute = 'buildFlowFsm.taskBoardWorkspace.cmdCreateWorkTask';
export const cmdUpdateWorkTaskRoute = 'buildFlowFsm.taskBoardWorkspace.cmdUpdateWorkTask';
export const cmdUpdateWorkTaskStatusRoute = 'buildFlowFsm.taskBoardWorkspace.cmdUpdateWorkTaskStatus';
