/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/projectDetailWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getProjectDetailRoute, listWorkTasksRoute, listChangeOrdersRoute, getChangeOrderDetailRoute, listTimeLogsRoute, listMaterialUsagesRoute, triggerDelayRiskSuggestionsRoute, listDelayRiskSuggestionsRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/projectDetailWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    'section.projectDetailWorkspace.sec-projectHeader.title': 'Project Header',
    'organism.projectDetailWorkspace.getProjectDetail.title': 'View project detail and timeline',
    'intent.projectDetailWorkspace.getProjectDetail.list.title': 'View project detail and timeline',
    'intent.projectDetailWorkspace.getProjectDetail.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.projectId.label': 'Project Id',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.name.label': 'Name',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.clientId.label': 'Client Id',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.clientName.label': 'Client Name',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.clientCompany.label': 'Client Company',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.siteAddress.label': 'Site Address',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.budget.label': 'Budget',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.startDate.label': 'Start Date',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.endDate.label': 'End Date',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.status.label': 'Status',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.holdReason.label': 'Hold Reason',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.closedAt.label': 'Closed At',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.cancelledAt.label': 'Cancelled At',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.cancellationReason.label': 'Cancellation Reason',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.createdAt.label': 'Created At',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.updatedAt.label': 'Updated At',
    'section.projectDetailWorkspace.sec-taskTimeline.title': 'Work Tasks & Timeline',
    'organism.projectDetailWorkspace.listWorkTasks.title': 'Browse work tasks',
    'intent.projectDetailWorkspace.listWorkTasks.list.title': 'Browse work tasks',
    'intent.projectDetailWorkspace.listWorkTasks.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listWorkTasks.list.column.workTasks.label': 'Work Tasks',
    'intent.projectDetailWorkspace.listWorkTasks.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.projectId.label': 'Project Id',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.pageSize.label': 'Page Size',
    'section.projectDetailWorkspace.sec-changeOrders.title': 'Change Orders',
    'organism.projectDetailWorkspace.listChangeOrders.title': 'Browse change orders',
    'intent.projectDetailWorkspace.listChangeOrders.list.title': 'Browse change orders',
    'intent.projectDetailWorkspace.listChangeOrders.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listChangeOrders.list.column.changeOrders.label': 'Change Orders',
    'intent.projectDetailWorkspace.listChangeOrders.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.impactType.label': 'Impact Type',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.pageSize.label': 'Page Size',
    'organism.projectDetailWorkspace.getChangeOrderDetail.title': 'View change order and cost impact',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.title': 'View change order and cost impact',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.changeOrderId.label': 'Change Order Id',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.projectId.label': 'Project Id',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.title.label': 'Title',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.description.label': 'Description',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.impactType.label': 'Impact Type',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.costAdjustment.label': 'Cost Adjustment',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.scheduleAdjustmentDays.label': 'Schedule Adjustment Days',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.status.label': 'Status',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.rejectionReason.label': 'Rejection Reason',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.approvedAt.label': 'Approved At',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.rejectedAt.label': 'Rejected At',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.projectName.label': 'Project Name',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.projectBudget.label': 'Project Budget',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.affectsJobCosting.label': 'Affects Job Costing',
    'section.projectDetailWorkspace.sec-costTracking.title': 'Cost Tracking — Time Logs',
    'organism.projectDetailWorkspace.listTimeLogs.title': 'Browse time logs',
    'intent.projectDetailWorkspace.listTimeLogs.list.title': 'Browse time logs',
    'intent.projectDetailWorkspace.listTimeLogs.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listTimeLogs.list.column.timeLogs.label': 'Time Logs',
    'intent.projectDetailWorkspace.listTimeLogs.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.workTaskId.label': 'Work Task Id',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.workerName.label': 'Worker Name',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.logDate.label': 'Log Date',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.pageSize.label': 'Page Size',
    'section.projectDetailWorkspace.sec-materialUsage.title': 'Material Usage',
    'organism.projectDetailWorkspace.listMaterialUsages.title': 'Browse material usage',
    'intent.projectDetailWorkspace.listMaterialUsages.list.title': 'Browse material usage',
    'intent.projectDetailWorkspace.listMaterialUsages.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listMaterialUsages.list.column.materialUsages.label': 'Material Usages',
    'intent.projectDetailWorkspace.listMaterialUsages.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listMaterialUsages.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listMaterialUsages.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listMaterialUsages.list.filter.pageSize.label': 'Page Size',
    'section.projectDetailWorkspace.sec-delayRiskInsights.title': 'Delay Risk Insights',
    'organism.projectDetailWorkspace.triggerDelayRiskSuggestions.title': 'Generate delay-risk suggestions',
    'intent.projectDetailWorkspace.triggerDelayRiskSuggestions.form.title': 'Generate delay-risk suggestions',
    'intent.projectDetailWorkspace.triggerDelayRiskSuggestions.form.action.triggerDelayRiskSuggestions': 'Generate delay-risk suggestions',
    'organism.projectDetailWorkspace.listDelayRiskSuggestions.title': 'Review delay-risk suggestions',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.title': 'Review delay-risk suggestions',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.delayRiskSuggestionId.label': 'Delay Risk Suggestion Id',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.workTaskId.label': 'Work Task Id',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.workTaskTitle.label': 'Work Task Title',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.riskLevel.label': 'Risk Level',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.reason.label': 'Reason',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.suggestedAction.label': 'Suggested Action',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.acknowledged.label': 'Acknowledged',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.createdAt.label': 'Created At',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.filter.acknowledged.label': 'Acknowledged',
    'action.triggerDelayRiskSuggestions.success': 'Generate delay-risk suggestions: OK',
    'action.triggerDelayRiskSuggestions.error': 'Generate delay-risk suggestions: falhou',
    'section.projectDetailWorkspace.sec-project-header.title': 'Project Header',
    'section.projectDetailWorkspace.sec-task-timeline.title': 'Work Task Timeline',
    'section.projectDetailWorkspace.sec-change-orders.title': 'Change Orders',
    'section.projectDetailWorkspace.sec-cost-tracking.title': 'Cost Tracking',
    'section.projectDetailWorkspace.sec-delay-risk-insights.title': 'Delay Risk Insights',
};
const message_pt_br = {
    'section.projectDetailWorkspace.sec-projectHeader.title': 'Project Header',
    'organism.projectDetailWorkspace.getProjectDetail.title': 'View project detail and timeline',
    'intent.projectDetailWorkspace.getProjectDetail.list.title': 'View project detail and timeline',
    'intent.projectDetailWorkspace.getProjectDetail.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.projectId.label': 'Project Id',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.name.label': 'Name',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.clientId.label': 'Client Id',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.clientName.label': 'Client Name',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.clientCompany.label': 'Client Company',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.siteAddress.label': 'Site Address',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.budget.label': 'Budget',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.startDate.label': 'Start Date',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.endDate.label': 'End Date',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.status.label': 'Status',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.holdReason.label': 'Hold Reason',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.closedAt.label': 'Closed At',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.cancelledAt.label': 'Cancelled At',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.cancellationReason.label': 'Cancellation Reason',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.createdAt.label': 'Created At',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.updatedAt.label': 'Updated At',
    'section.projectDetailWorkspace.sec-taskTimeline.title': 'Work Tasks & Timeline',
    'organism.projectDetailWorkspace.listWorkTasks.title': 'Browse work tasks',
    'intent.projectDetailWorkspace.listWorkTasks.list.title': 'Browse work tasks',
    'intent.projectDetailWorkspace.listWorkTasks.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listWorkTasks.list.column.workTasks.label': 'Work Tasks',
    'intent.projectDetailWorkspace.listWorkTasks.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.projectId.label': 'Project Id',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.pageSize.label': 'Page Size',
    'section.projectDetailWorkspace.sec-changeOrders.title': 'Change Orders',
    'organism.projectDetailWorkspace.listChangeOrders.title': 'Browse change orders',
    'intent.projectDetailWorkspace.listChangeOrders.list.title': 'Browse change orders',
    'intent.projectDetailWorkspace.listChangeOrders.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listChangeOrders.list.column.changeOrders.label': 'Change Orders',
    'intent.projectDetailWorkspace.listChangeOrders.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.impactType.label': 'Impact Type',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.pageSize.label': 'Page Size',
    'organism.projectDetailWorkspace.getChangeOrderDetail.title': 'View change order and cost impact',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.title': 'View change order and cost impact',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.changeOrderId.label': 'Change Order Id',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.projectId.label': 'Project Id',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.title.label': 'Title',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.description.label': 'Description',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.impactType.label': 'Impact Type',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.costAdjustment.label': 'Cost Adjustment',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.scheduleAdjustmentDays.label': 'Schedule Adjustment Days',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.status.label': 'Status',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.rejectionReason.label': 'Rejection Reason',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.approvedAt.label': 'Approved At',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.rejectedAt.label': 'Rejected At',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.projectName.label': 'Project Name',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.projectBudget.label': 'Project Budget',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.affectsJobCosting.label': 'Affects Job Costing',
    'section.projectDetailWorkspace.sec-costTracking.title': 'Cost Tracking — Time Logs',
    'organism.projectDetailWorkspace.listTimeLogs.title': 'Browse time logs',
    'intent.projectDetailWorkspace.listTimeLogs.list.title': 'Browse time logs',
    'intent.projectDetailWorkspace.listTimeLogs.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listTimeLogs.list.column.timeLogs.label': 'Time Logs',
    'intent.projectDetailWorkspace.listTimeLogs.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.workTaskId.label': 'Work Task Id',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.workerName.label': 'Worker Name',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.logDate.label': 'Log Date',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.pageSize.label': 'Page Size',
    'section.projectDetailWorkspace.sec-materialUsage.title': 'Material Usage',
    'organism.projectDetailWorkspace.listMaterialUsages.title': 'Browse material usage',
    'intent.projectDetailWorkspace.listMaterialUsages.list.title': 'Browse material usage',
    'intent.projectDetailWorkspace.listMaterialUsages.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listMaterialUsages.list.column.materialUsages.label': 'Material Usages',
    'intent.projectDetailWorkspace.listMaterialUsages.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listMaterialUsages.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listMaterialUsages.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listMaterialUsages.list.filter.pageSize.label': 'Page Size',
    'section.projectDetailWorkspace.sec-delayRiskInsights.title': 'Delay Risk Insights',
    'organism.projectDetailWorkspace.triggerDelayRiskSuggestions.title': 'Generate delay-risk suggestions',
    'intent.projectDetailWorkspace.triggerDelayRiskSuggestions.form.title': 'Generate delay-risk suggestions',
    'intent.projectDetailWorkspace.triggerDelayRiskSuggestions.form.action.triggerDelayRiskSuggestions': 'Generate delay-risk suggestions',
    'organism.projectDetailWorkspace.listDelayRiskSuggestions.title': 'Review delay-risk suggestions',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.title': 'Review delay-risk suggestions',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.delayRiskSuggestionId.label': 'Delay Risk Suggestion Id',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.workTaskId.label': 'Work Task Id',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.workTaskTitle.label': 'Work Task Title',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.riskLevel.label': 'Risk Level',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.reason.label': 'Reason',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.suggestedAction.label': 'Suggested Action',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.acknowledged.label': 'Acknowledged',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.createdAt.label': 'Created At',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.filter.acknowledged.label': 'Acknowledged',
    'action.triggerDelayRiskSuggestions.success': 'Generate delay-risk suggestions: OK',
    'action.triggerDelayRiskSuggestions.error': 'Generate delay-risk suggestions: falhou',
    'section.projectDetailWorkspace.sec-project-header.title': 'Project Header',
    'section.projectDetailWorkspace.sec-task-timeline.title': 'Work Task Timeline',
    'section.projectDetailWorkspace.sec-change-orders.title': 'Change Orders',
    'section.projectDetailWorkspace.sec-cost-tracking.title': 'Cost Tracking',
    'section.projectDetailWorkspace.sec-delay-risk-insights.title': 'Delay Risk Insights',
};
const message_es = {
    'section.projectDetailWorkspace.sec-projectHeader.title': 'Project Header',
    'organism.projectDetailWorkspace.getProjectDetail.title': 'View project detail and timeline',
    'intent.projectDetailWorkspace.getProjectDetail.list.title': 'View project detail and timeline',
    'intent.projectDetailWorkspace.getProjectDetail.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.projectId.label': 'Project Id',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.name.label': 'Name',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.clientId.label': 'Client Id',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.clientName.label': 'Client Name',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.clientCompany.label': 'Client Company',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.siteAddress.label': 'Site Address',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.budget.label': 'Budget',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.startDate.label': 'Start Date',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.endDate.label': 'End Date',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.status.label': 'Status',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.holdReason.label': 'Hold Reason',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.closedAt.label': 'Closed At',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.cancelledAt.label': 'Cancelled At',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.cancellationReason.label': 'Cancellation Reason',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.createdAt.label': 'Created At',
    'intent.projectDetailWorkspace.getProjectDetail.list.column.updatedAt.label': 'Updated At',
    'section.projectDetailWorkspace.sec-taskTimeline.title': 'Work Tasks & Timeline',
    'organism.projectDetailWorkspace.listWorkTasks.title': 'Browse work tasks',
    'intent.projectDetailWorkspace.listWorkTasks.list.title': 'Browse work tasks',
    'intent.projectDetailWorkspace.listWorkTasks.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listWorkTasks.list.column.workTasks.label': 'Work Tasks',
    'intent.projectDetailWorkspace.listWorkTasks.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.projectId.label': 'Project Id',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listWorkTasks.list.filter.pageSize.label': 'Page Size',
    'section.projectDetailWorkspace.sec-changeOrders.title': 'Change Orders',
    'organism.projectDetailWorkspace.listChangeOrders.title': 'Browse change orders',
    'intent.projectDetailWorkspace.listChangeOrders.list.title': 'Browse change orders',
    'intent.projectDetailWorkspace.listChangeOrders.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listChangeOrders.list.column.changeOrders.label': 'Change Orders',
    'intent.projectDetailWorkspace.listChangeOrders.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.impactType.label': 'Impact Type',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listChangeOrders.list.filter.pageSize.label': 'Page Size',
    'organism.projectDetailWorkspace.getChangeOrderDetail.title': 'View change order and cost impact',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.title': 'View change order and cost impact',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.changeOrderId.label': 'Change Order Id',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.projectId.label': 'Project Id',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.title.label': 'Title',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.description.label': 'Description',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.impactType.label': 'Impact Type',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.costAdjustment.label': 'Cost Adjustment',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.scheduleAdjustmentDays.label': 'Schedule Adjustment Days',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.status.label': 'Status',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.rejectionReason.label': 'Rejection Reason',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.approvedAt.label': 'Approved At',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.rejectedAt.label': 'Rejected At',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.projectName.label': 'Project Name',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.projectBudget.label': 'Project Budget',
    'intent.projectDetailWorkspace.getChangeOrderDetail.list.column.affectsJobCosting.label': 'Affects Job Costing',
    'section.projectDetailWorkspace.sec-costTracking.title': 'Cost Tracking — Time Logs',
    'organism.projectDetailWorkspace.listTimeLogs.title': 'Browse time logs',
    'intent.projectDetailWorkspace.listTimeLogs.list.title': 'Browse time logs',
    'intent.projectDetailWorkspace.listTimeLogs.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listTimeLogs.list.column.timeLogs.label': 'Time Logs',
    'intent.projectDetailWorkspace.listTimeLogs.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.workTaskId.label': 'Work Task Id',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.workerName.label': 'Worker Name',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.logDate.label': 'Log Date',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listTimeLogs.list.filter.pageSize.label': 'Page Size',
    'section.projectDetailWorkspace.sec-materialUsage.title': 'Material Usage',
    'organism.projectDetailWorkspace.listMaterialUsages.title': 'Browse material usage',
    'intent.projectDetailWorkspace.listMaterialUsages.list.title': 'Browse material usage',
    'intent.projectDetailWorkspace.listMaterialUsages.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listMaterialUsages.list.column.materialUsages.label': 'Material Usages',
    'intent.projectDetailWorkspace.listMaterialUsages.list.column.total.label': 'Total',
    'intent.projectDetailWorkspace.listMaterialUsages.list.filter.status.label': 'Status',
    'intent.projectDetailWorkspace.listMaterialUsages.list.filter.page.label': 'Page',
    'intent.projectDetailWorkspace.listMaterialUsages.list.filter.pageSize.label': 'Page Size',
    'section.projectDetailWorkspace.sec-delayRiskInsights.title': 'Delay Risk Insights',
    'organism.projectDetailWorkspace.triggerDelayRiskSuggestions.title': 'Generate delay-risk suggestions',
    'intent.projectDetailWorkspace.triggerDelayRiskSuggestions.form.title': 'Generate delay-risk suggestions',
    'intent.projectDetailWorkspace.triggerDelayRiskSuggestions.form.action.triggerDelayRiskSuggestions': 'Generate delay-risk suggestions',
    'organism.projectDetailWorkspace.listDelayRiskSuggestions.title': 'Review delay-risk suggestions',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.title': 'Review delay-risk suggestions',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.empty': 'Nenhum registro encontrado',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.delayRiskSuggestionId.label': 'Delay Risk Suggestion Id',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.workTaskId.label': 'Work Task Id',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.workTaskTitle.label': 'Work Task Title',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.riskLevel.label': 'Risk Level',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.reason.label': 'Reason',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.suggestedAction.label': 'Suggested Action',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.acknowledged.label': 'Acknowledged',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.column.createdAt.label': 'Created At',
    'intent.projectDetailWorkspace.listDelayRiskSuggestions.list.filter.acknowledged.label': 'Acknowledged',
    'action.triggerDelayRiskSuggestions.success': 'Generate delay-risk suggestions: OK',
    'action.triggerDelayRiskSuggestions.error': 'Generate delay-risk suggestions: falhou',
    'section.projectDetailWorkspace.sec-project-header.title': 'Project Header',
    'section.projectDetailWorkspace.sec-task-timeline.title': 'Work Task Timeline',
    'section.projectDetailWorkspace.sec-change-orders.title': 'Change Orders',
    'section.projectDetailWorkspace.sec-cost-tracking.title': 'Cost Tracking',
    'section.projectDetailWorkspace.sec-delay-risk-insights.title': 'Delay Risk Insights',
};
export const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
const LIST_WORK_TASKS_DATA_DEFAULT = { workTasks: [], total: 0 };
const LIST_CHANGE_ORDERS_DATA_DEFAULT = { changeOrders: [], total: 0 };
const LIST_TIME_LOGS_DATA_DEFAULT = { timeLogs: [], total: 0 };
const LIST_MATERIAL_USAGES_DATA_DEFAULT = { materialUsages: [], total: 0 };
const SUBSCRIBED_STATE_KEYS = [
    'ui.projectDetailWorkspace.status',
    'ui.projectDetailWorkspace.action.getProjectDetail.status',
    'ui.projectDetailWorkspace.input.getProjectDetail.projectId',
    'ui.projectDetailWorkspace.data.getProjectDetail',
    'ui.projectDetailWorkspace.action.listWorkTasks.status',
    'ui.projectDetailWorkspace.input.listWorkTasks.projectId',
    'ui.projectDetailWorkspace.input.listWorkTasks.status',
    'ui.projectDetailWorkspace.input.listWorkTasks.assignedWorkerId',
    'ui.projectDetailWorkspace.input.listWorkTasks.page',
    'ui.projectDetailWorkspace.input.listWorkTasks.pageSize',
    'ui.projectDetailWorkspace.data.listWorkTasks',
    'ui.projectDetailWorkspace.action.listChangeOrders.status',
    'ui.projectDetailWorkspace.input.listChangeOrders.projectId',
    'ui.projectDetailWorkspace.input.listChangeOrders.status',
    'ui.projectDetailWorkspace.input.listChangeOrders.impactType',
    'ui.projectDetailWorkspace.input.listChangeOrders.page',
    'ui.projectDetailWorkspace.input.listChangeOrders.pageSize',
    'ui.projectDetailWorkspace.data.listChangeOrders',
    'ui.projectDetailWorkspace.action.getChangeOrderDetail.status',
    'ui.projectDetailWorkspace.input.getChangeOrderDetail.changeOrderId',
    'ui.projectDetailWorkspace.data.getChangeOrderDetail',
    'ui.projectDetailWorkspace.action.listTimeLogs.status',
    'ui.projectDetailWorkspace.input.listTimeLogs.workTaskId',
    'ui.projectDetailWorkspace.input.listTimeLogs.workerName',
    'ui.projectDetailWorkspace.input.listTimeLogs.logDate',
    'ui.projectDetailWorkspace.input.listTimeLogs.status',
    'ui.projectDetailWorkspace.input.listTimeLogs.page',
    'ui.projectDetailWorkspace.input.listTimeLogs.pageSize',
    'ui.projectDetailWorkspace.data.listTimeLogs',
    'ui.projectDetailWorkspace.action.listMaterialUsages.status',
    'ui.projectDetailWorkspace.input.listMaterialUsages.projectId',
    'ui.projectDetailWorkspace.input.listMaterialUsages.status',
    'ui.projectDetailWorkspace.input.listMaterialUsages.page',
    'ui.projectDetailWorkspace.input.listMaterialUsages.pageSize',
    'ui.projectDetailWorkspace.data.listMaterialUsages',
    'ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status',
    'ui.projectDetailWorkspace.input.triggerDelayRiskSuggestions.statusReportId',
    'ui.projectDetailWorkspace.output.triggerDelayRiskSuggestions',
    'ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.error',
    'ui.projectDetailWorkspace.action.listDelayRiskSuggestions.status',
    'ui.projectDetailWorkspace.input.listDelayRiskSuggestions.statusReportId',
    'ui.projectDetailWorkspace.input.listDelayRiskSuggestions.acknowledged',
    'ui.projectDetailWorkspace.data.listDelayRiskSuggestions',
];
export class BuildFlowFsmProjectDetailWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state getProjectDetailState — actionStatus, values: idle|loading|success|error */
        this.getProjectDetailState = 'idle';
        /** state getProjectDetailProjectId — input */
        this.getProjectDetailProjectId = '';
        /** state getProjectDetailData — queryResult, outputShape: object */
        this.getProjectDetailData = null;
        /** state listWorkTasksState — actionStatus, values: idle|loading|success|error */
        this.listWorkTasksState = 'idle';
        /** state listWorkTasksProjectId — input */
        this.listWorkTasksProjectId = '';
        /** state listWorkTasksStatus — input */
        this.listWorkTasksStatus = '';
        /** state listWorkTasksAssignedWorkerId — input */
        this.listWorkTasksAssignedWorkerId = '';
        /** state listWorkTasksPage — input */
        this.listWorkTasksPage = '';
        /** state listWorkTasksPageSize — input */
        this.listWorkTasksPageSize = '';
        /** state listWorkTasksData — queryResult, outputShape: paginated */
        this.listWorkTasksData = LIST_WORK_TASKS_DATA_DEFAULT;
        /** state listChangeOrdersState — actionStatus, values: idle|loading|success|error */
        this.listChangeOrdersState = 'idle';
        /** state listChangeOrdersProjectId — input */
        this.listChangeOrdersProjectId = '';
        /** state listChangeOrdersStatus — input */
        this.listChangeOrdersStatus = '';
        /** state listChangeOrdersImpactType — input */
        this.listChangeOrdersImpactType = '';
        /** state listChangeOrdersPage — input */
        this.listChangeOrdersPage = '';
        /** state listChangeOrdersPageSize — input */
        this.listChangeOrdersPageSize = '';
        /** state listChangeOrdersData — queryResult, outputShape: paginated */
        this.listChangeOrdersData = LIST_CHANGE_ORDERS_DATA_DEFAULT;
        /** state getChangeOrderDetailState — actionStatus, values: idle|loading|success|error */
        this.getChangeOrderDetailState = 'idle';
        /** state getChangeOrderDetailChangeOrderId — input */
        this.getChangeOrderDetailChangeOrderId = '';
        /** state getChangeOrderDetailData — queryResult, outputShape: object */
        this.getChangeOrderDetailData = null;
        /** state listTimeLogsState — actionStatus, values: idle|loading|success|error */
        this.listTimeLogsState = 'idle';
        /** state listTimeLogsWorkTaskId — input */
        this.listTimeLogsWorkTaskId = '';
        /** state listTimeLogsWorkerName — input */
        this.listTimeLogsWorkerName = '';
        /** state listTimeLogsLogDate — input */
        this.listTimeLogsLogDate = '';
        /** state listTimeLogsStatus — input */
        this.listTimeLogsStatus = '';
        /** state listTimeLogsPage — input */
        this.listTimeLogsPage = '';
        /** state listTimeLogsPageSize — input */
        this.listTimeLogsPageSize = '';
        /** state listTimeLogsData — queryResult, outputShape: paginated */
        this.listTimeLogsData = LIST_TIME_LOGS_DATA_DEFAULT;
        /** state listMaterialUsagesState — actionStatus, values: idle|loading|success|error */
        this.listMaterialUsagesState = 'idle';
        /** state listMaterialUsagesProjectId — input */
        this.listMaterialUsagesProjectId = '';
        /** state listMaterialUsagesStatus — input */
        this.listMaterialUsagesStatus = '';
        /** state listMaterialUsagesPage — input */
        this.listMaterialUsagesPage = '';
        /** state listMaterialUsagesPageSize — input */
        this.listMaterialUsagesPageSize = '';
        /** state listMaterialUsagesData — queryResult, outputShape: paginated */
        this.listMaterialUsagesData = LIST_MATERIAL_USAGES_DATA_DEFAULT;
        /** state triggerDelayRiskSuggestionsState — actionStatus, values: idle|loading|success|error */
        this.triggerDelayRiskSuggestionsState = 'idle';
        /** state triggerDelayRiskSuggestionsStatusReportId — input */
        this.triggerDelayRiskSuggestionsStatusReportId = '';
        /** state triggerDelayRiskSuggestionsOutput — commandOutput */
        this.triggerDelayRiskSuggestionsOutput = null;
        /** state triggerDelayRiskSuggestionsError — actionError */
        this.triggerDelayRiskSuggestionsError = '';
        /** state listDelayRiskSuggestionsState — actionStatus, values: idle|loading|success|error */
        this.listDelayRiskSuggestionsState = 'idle';
        /** state listDelayRiskSuggestionsStatusReportId — input */
        this.listDelayRiskSuggestionsStatusReportId = '';
        /** state listDelayRiskSuggestionsAcknowledged — input */
        this.listDelayRiskSuggestionsAcknowledged = '';
        /** state listDelayRiskSuggestionsData — queryResult, outputShape: array */
        this.listDelayRiskSuggestionsData = [];
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.projectDetailWorkspace.status', '');
        this.initStateValue('ui.projectDetailWorkspace.action.getProjectDetail.status', 'idle');
        this.initStateValue('ui.projectDetailWorkspace.input.getProjectDetail.projectId', '');
        this.initStateValue('ui.projectDetailWorkspace.data.getProjectDetail', null);
        this.initStateValue('ui.projectDetailWorkspace.action.listWorkTasks.status', 'idle');
        this.initStateValue('ui.projectDetailWorkspace.input.listWorkTasks.projectId', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listWorkTasks.status', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listWorkTasks.assignedWorkerId', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listWorkTasks.page', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listWorkTasks.pageSize', '');
        this.initStateValue('ui.projectDetailWorkspace.data.listWorkTasks', LIST_WORK_TASKS_DATA_DEFAULT);
        this.initStateValue('ui.projectDetailWorkspace.action.listChangeOrders.status', 'idle');
        this.initStateValue('ui.projectDetailWorkspace.input.listChangeOrders.projectId', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listChangeOrders.status', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listChangeOrders.impactType', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listChangeOrders.page', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listChangeOrders.pageSize', '');
        this.initStateValue('ui.projectDetailWorkspace.data.listChangeOrders', LIST_CHANGE_ORDERS_DATA_DEFAULT);
        this.initStateValue('ui.projectDetailWorkspace.action.getChangeOrderDetail.status', 'idle');
        this.initStateValue('ui.projectDetailWorkspace.input.getChangeOrderDetail.changeOrderId', '');
        this.initStateValue('ui.projectDetailWorkspace.data.getChangeOrderDetail', null);
        this.initStateValue('ui.projectDetailWorkspace.action.listTimeLogs.status', 'idle');
        this.initStateValue('ui.projectDetailWorkspace.input.listTimeLogs.workTaskId', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listTimeLogs.workerName', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listTimeLogs.logDate', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listTimeLogs.status', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listTimeLogs.page', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listTimeLogs.pageSize', '');
        this.initStateValue('ui.projectDetailWorkspace.data.listTimeLogs', LIST_TIME_LOGS_DATA_DEFAULT);
        this.initStateValue('ui.projectDetailWorkspace.action.listMaterialUsages.status', 'idle');
        this.initStateValue('ui.projectDetailWorkspace.input.listMaterialUsages.projectId', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listMaterialUsages.status', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listMaterialUsages.page', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listMaterialUsages.pageSize', '');
        this.initStateValue('ui.projectDetailWorkspace.data.listMaterialUsages', LIST_MATERIAL_USAGES_DATA_DEFAULT);
        this.initStateValue('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'idle');
        this.initStateValue('ui.projectDetailWorkspace.input.triggerDelayRiskSuggestions.statusReportId', '');
        this.initStateValue('ui.projectDetailWorkspace.output.triggerDelayRiskSuggestions', null);
        this.initStateValue('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.error', '');
        this.initStateValue('ui.projectDetailWorkspace.action.listDelayRiskSuggestions.status', 'idle');
        this.initStateValue('ui.projectDetailWorkspace.input.listDelayRiskSuggestions.statusReportId', '');
        this.initStateValue('ui.projectDetailWorkspace.input.listDelayRiskSuggestions.acknowledged', '');
        this.initStateValue('ui.projectDetailWorkspace.data.listDelayRiskSuggestions', []);
        this.syncRouteParams();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadListTimeLogs();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.projectDetailWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.action.getProjectDetail.status':
                this.getProjectDetailState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.getProjectDetail.projectId':
                this.getProjectDetailProjectId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.getProjectDetail':
                this.getProjectDetailData = value ?? null;
                break;
            case 'ui.projectDetailWorkspace.action.listWorkTasks.status':
                this.listWorkTasksState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.projectId':
                this.listWorkTasksProjectId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.status':
                this.listWorkTasksStatus = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.assignedWorkerId':
                this.listWorkTasksAssignedWorkerId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.page':
                this.listWorkTasksPage = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.pageSize':
                this.listWorkTasksPageSize = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listWorkTasks':
                this.listWorkTasksData = value ?? LIST_WORK_TASKS_DATA_DEFAULT;
                break;
            case 'ui.projectDetailWorkspace.action.listChangeOrders.status':
                this.listChangeOrdersState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.projectId':
                this.listChangeOrdersProjectId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.status':
                this.listChangeOrdersStatus = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.impactType':
                this.listChangeOrdersImpactType = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.page':
                this.listChangeOrdersPage = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.pageSize':
                this.listChangeOrdersPageSize = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listChangeOrders':
                this.listChangeOrdersData = value ?? LIST_CHANGE_ORDERS_DATA_DEFAULT;
                break;
            case 'ui.projectDetailWorkspace.action.getChangeOrderDetail.status':
                this.getChangeOrderDetailState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.getChangeOrderDetail.changeOrderId':
                this.getChangeOrderDetailChangeOrderId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.getChangeOrderDetail':
                this.getChangeOrderDetailData = value ?? null;
                break;
            case 'ui.projectDetailWorkspace.action.listTimeLogs.status':
                this.listTimeLogsState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.workTaskId':
                this.listTimeLogsWorkTaskId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.workerName':
                this.listTimeLogsWorkerName = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.logDate':
                this.listTimeLogsLogDate = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.status':
                this.listTimeLogsStatus = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.page':
                this.listTimeLogsPage = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.pageSize':
                this.listTimeLogsPageSize = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listTimeLogs':
                this.listTimeLogsData = value ?? LIST_TIME_LOGS_DATA_DEFAULT;
                break;
            case 'ui.projectDetailWorkspace.action.listMaterialUsages.status':
                this.listMaterialUsagesState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listMaterialUsages.projectId':
                this.listMaterialUsagesProjectId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listMaterialUsages.status':
                this.listMaterialUsagesStatus = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listMaterialUsages.page':
                this.listMaterialUsagesPage = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listMaterialUsages.pageSize':
                this.listMaterialUsagesPageSize = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listMaterialUsages':
                this.listMaterialUsagesData = value ?? LIST_MATERIAL_USAGES_DATA_DEFAULT;
                break;
            case 'ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status':
                this.triggerDelayRiskSuggestionsState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.triggerDelayRiskSuggestions.statusReportId':
                this.triggerDelayRiskSuggestionsStatusReportId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.output.triggerDelayRiskSuggestions':
                this.triggerDelayRiskSuggestionsOutput = value ?? null;
                break;
            case 'ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.error':
                this.triggerDelayRiskSuggestionsError = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.action.listDelayRiskSuggestions.status':
                this.listDelayRiskSuggestionsState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listDelayRiskSuggestions.statusReportId':
                this.listDelayRiskSuggestionsStatusReportId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listDelayRiskSuggestions.acknowledged':
                this.listDelayRiskSuggestionsAcknowledged = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listDelayRiskSuggestions':
                this.listDelayRiskSuggestionsData = value ?? [];
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.projectDetailWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.action.getProjectDetail.status':
                this.getProjectDetailState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.getProjectDetail.projectId':
                this.getProjectDetailProjectId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.getProjectDetail':
                this.getProjectDetailData = value ?? null;
                break;
            case 'ui.projectDetailWorkspace.action.listWorkTasks.status':
                this.listWorkTasksState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.projectId':
                this.listWorkTasksProjectId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.status':
                this.listWorkTasksStatus = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.assignedWorkerId':
                this.listWorkTasksAssignedWorkerId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.page':
                this.listWorkTasksPage = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listWorkTasks.pageSize':
                this.listWorkTasksPageSize = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listWorkTasks':
                this.listWorkTasksData = value ?? LIST_WORK_TASKS_DATA_DEFAULT;
                break;
            case 'ui.projectDetailWorkspace.action.listChangeOrders.status':
                this.listChangeOrdersState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.projectId':
                this.listChangeOrdersProjectId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.status':
                this.listChangeOrdersStatus = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.impactType':
                this.listChangeOrdersImpactType = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.page':
                this.listChangeOrdersPage = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listChangeOrders.pageSize':
                this.listChangeOrdersPageSize = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listChangeOrders':
                this.listChangeOrdersData = value ?? LIST_CHANGE_ORDERS_DATA_DEFAULT;
                break;
            case 'ui.projectDetailWorkspace.action.getChangeOrderDetail.status':
                this.getChangeOrderDetailState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.getChangeOrderDetail.changeOrderId':
                this.getChangeOrderDetailChangeOrderId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.getChangeOrderDetail':
                this.getChangeOrderDetailData = value ?? null;
                break;
            case 'ui.projectDetailWorkspace.action.listTimeLogs.status':
                this.listTimeLogsState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.workTaskId':
                this.listTimeLogsWorkTaskId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.workerName':
                this.listTimeLogsWorkerName = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.logDate':
                this.listTimeLogsLogDate = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.status':
                this.listTimeLogsStatus = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.page':
                this.listTimeLogsPage = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listTimeLogs.pageSize':
                this.listTimeLogsPageSize = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listTimeLogs':
                this.listTimeLogsData = value ?? LIST_TIME_LOGS_DATA_DEFAULT;
                break;
            case 'ui.projectDetailWorkspace.action.listMaterialUsages.status':
                this.listMaterialUsagesState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listMaterialUsages.projectId':
                this.listMaterialUsagesProjectId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listMaterialUsages.status':
                this.listMaterialUsagesStatus = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listMaterialUsages.page':
                this.listMaterialUsagesPage = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listMaterialUsages.pageSize':
                this.listMaterialUsagesPageSize = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listMaterialUsages':
                this.listMaterialUsagesData = value ?? LIST_MATERIAL_USAGES_DATA_DEFAULT;
                break;
            case 'ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status':
                this.triggerDelayRiskSuggestionsState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.triggerDelayRiskSuggestions.statusReportId':
                this.triggerDelayRiskSuggestionsStatusReportId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.output.triggerDelayRiskSuggestions':
                this.triggerDelayRiskSuggestionsOutput = value ?? null;
                break;
            case 'ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.error':
                this.triggerDelayRiskSuggestionsError = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.action.listDelayRiskSuggestions.status':
                this.listDelayRiskSuggestionsState = value ?? 'idle';
                break;
            case 'ui.projectDetailWorkspace.input.listDelayRiskSuggestions.statusReportId':
                this.listDelayRiskSuggestionsStatusReportId = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.input.listDelayRiskSuggestions.acknowledged':
                this.listDelayRiskSuggestionsAcknowledged = value ?? '';
                break;
            case 'ui.projectDetailWorkspace.data.listDelayRiskSuggestions':
                this.listDelayRiskSuggestionsData = value ?? [];
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    syncRouteParams() {
        const pathname = window.location.pathname;
        const match = pathname.match(/^\/buildFlowFsm\/projectDetailWorkspace(?:\/([^/]+))?(?:\/([^/]+))?\/?$/);
        const rawProjectId = match && match[1] ? match[1] : '';
        let projectId = '';
        if (rawProjectId) {
            try {
                projectId = decodeURIComponent(rawProjectId);
            }
            catch {
                projectId = rawProjectId;
            }
        }
        if (projectId) {
            if (!this.getProjectDetailProjectId) {
                this.getProjectDetailProjectId = projectId;
                setState('ui.projectDetailWorkspace.input.getProjectDetail.projectId', projectId);
            }
        }
        const rawChangeOrderId = match && match[2] ? match[2] : '';
        let changeOrderId = '';
        if (rawChangeOrderId) {
            try {
                changeOrderId = decodeURIComponent(rawChangeOrderId);
            }
            catch {
                changeOrderId = rawChangeOrderId;
            }
        }
        if (changeOrderId) {
            if (!this.getChangeOrderDetailChangeOrderId) {
                this.getChangeOrderDetailChangeOrderId = changeOrderId;
                setState('ui.projectDetailWorkspace.input.getChangeOrderDetail.changeOrderId', changeOrderId);
            }
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action getProjectDetail (query) — route buildFlowFsm.projectDetailWorkspace.getProjectDetail; inputs: projectId; writes ui.projectDetailWorkspace.data.getProjectDetail; status ui.projectDetailWorkspace.action.getProjectDetail.status */
    async loadGetProjectDetail() {
        this.syncRouteParams();
        if (!this.getProjectDetailProjectId) {
            this.getProjectDetailState = 'idle';
            setState('ui.projectDetailWorkspace.action.getProjectDetail.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.getProjectDetailState = 'loading';
        setState('ui.projectDetailWorkspace.action.getProjectDetail.status', 'loading');
        const params = {
            projectId: this.getProjectDetailProjectId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(getProjectDetailRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.getProjectDetailData = data;
            setState('ui.projectDetailWorkspace.data.getProjectDetail', data);
            this.getProjectDetailState = 'success';
            setState('ui.projectDetailWorkspace.action.getProjectDetail.status', 'success');
        }
        else {
            this.getProjectDetailState = 'error';
            setState('ui.projectDetailWorkspace.action.getProjectDetail.status', 'error');
            if (response.error) {
                console.error('getProjectDetail failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action getProjectDetail — bind UI events here */
    handleGetProjectDetailClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadGetProjectDetail();
    }
    /** action listWorkTasks (query) — route buildFlowFsm.projectDetailWorkspace.listWorkTasks; inputs: projectId, status, assignedWorkerId, page, pageSize; writes ui.projectDetailWorkspace.data.listWorkTasks; status ui.projectDetailWorkspace.action.listWorkTasks.status */
    async loadListWorkTasks() {
        this.syncRouteParams();
        this.listWorkTasksState = 'loading';
        setState('ui.projectDetailWorkspace.action.listWorkTasks.status', 'loading');
        const params = {
            projectId: this.listWorkTasksProjectId,
        };
        if (this.listWorkTasksStatus) {
            params.status = this.listWorkTasksStatus;
        }
        if (this.listWorkTasksAssignedWorkerId) {
            params.assignedWorkerId = this.listWorkTasksAssignedWorkerId;
        }
        if (this.listWorkTasksPage !== '') {
            const pageNum = Number(this.listWorkTasksPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.listWorkTasksPageSize !== '') {
            const pageSizeNum = Number(this.listWorkTasksPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(listWorkTasksRoute, params, options);
        if (response.ok) {
            const data = response.data ?? LIST_WORK_TASKS_DATA_DEFAULT;
            this.listWorkTasksData = data;
            setState('ui.projectDetailWorkspace.data.listWorkTasks', data);
            this.listWorkTasksState = 'success';
            setState('ui.projectDetailWorkspace.action.listWorkTasks.status', 'success');
        }
        else {
            this.listWorkTasksState = 'error';
            setState('ui.projectDetailWorkspace.action.listWorkTasks.status', 'error');
            if (response.error) {
                console.error('listWorkTasks failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action listWorkTasks — bind UI events here */
    handleListWorkTasksClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadListWorkTasks();
    }
    /** action listChangeOrders (query) — route buildFlowFsm.projectDetailWorkspace.listChangeOrders; inputs: projectId, status, impactType, page, pageSize; writes ui.projectDetailWorkspace.data.listChangeOrders; status ui.projectDetailWorkspace.action.listChangeOrders.status */
    async loadListChangeOrders() {
        this.syncRouteParams();
        if (!this.listChangeOrdersProjectId) {
            this.listChangeOrdersState = 'idle';
            setState('ui.projectDetailWorkspace.action.listChangeOrders.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.listChangeOrdersState = 'loading';
        setState('ui.projectDetailWorkspace.action.listChangeOrders.status', 'loading');
        const params = {
            projectId: this.listChangeOrdersProjectId,
        };
        if (this.listChangeOrdersStatus) {
            params.status = this.listChangeOrdersStatus;
        }
        if (this.listChangeOrdersImpactType) {
            params.impactType = this.listChangeOrdersImpactType;
        }
        if (this.listChangeOrdersPage !== '') {
            const pageNum = Number(this.listChangeOrdersPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.listChangeOrdersPageSize !== '') {
            const pageSizeNum = Number(this.listChangeOrdersPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(listChangeOrdersRoute, params, options);
        if (response.ok) {
            const data = response.data ?? LIST_CHANGE_ORDERS_DATA_DEFAULT;
            this.listChangeOrdersData = data;
            setState('ui.projectDetailWorkspace.data.listChangeOrders', data);
            this.listChangeOrdersState = 'success';
            setState('ui.projectDetailWorkspace.action.listChangeOrders.status', 'success');
        }
        else {
            this.listChangeOrdersState = 'error';
            setState('ui.projectDetailWorkspace.action.listChangeOrders.status', 'error');
            if (response.error) {
                console.error('listChangeOrders failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action listChangeOrders — bind UI events here */
    handleListChangeOrdersClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadListChangeOrders();
    }
    /** action getChangeOrderDetail (query) — route buildFlowFsm.projectDetailWorkspace.getChangeOrderDetail; inputs: changeOrderId; writes ui.projectDetailWorkspace.data.getChangeOrderDetail; status ui.projectDetailWorkspace.action.getChangeOrderDetail.status */
    async loadGetChangeOrderDetail() {
        this.syncRouteParams();
        if (!this.getChangeOrderDetailChangeOrderId) {
            this.getChangeOrderDetailState = 'idle';
            setState('ui.projectDetailWorkspace.action.getChangeOrderDetail.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.getChangeOrderDetailState = 'loading';
        setState('ui.projectDetailWorkspace.action.getChangeOrderDetail.status', 'loading');
        const params = {
            changeOrderId: this.getChangeOrderDetailChangeOrderId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(getChangeOrderDetailRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.getChangeOrderDetailData = data;
            setState('ui.projectDetailWorkspace.data.getChangeOrderDetail', data);
            this.getChangeOrderDetailState = 'success';
            setState('ui.projectDetailWorkspace.action.getChangeOrderDetail.status', 'success');
        }
        else {
            this.getChangeOrderDetailState = 'error';
            setState('ui.projectDetailWorkspace.action.getChangeOrderDetail.status', 'error');
            if (response.error) {
                console.error('getChangeOrderDetail failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action getChangeOrderDetail — bind UI events here */
    handleGetChangeOrderDetailClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadGetChangeOrderDetail();
    }
    /** action listTimeLogs (query) — route buildFlowFsm.projectDetailWorkspace.listTimeLogs; inputs: workTaskId, workerName, logDate, status, page, pageSize; writes ui.projectDetailWorkspace.data.listTimeLogs; status ui.projectDetailWorkspace.action.listTimeLogs.status */
    async loadListTimeLogs() {
        this.syncRouteParams();
        this.listTimeLogsState = 'loading';
        setState('ui.projectDetailWorkspace.action.listTimeLogs.status', 'loading');
        const params = {};
        if (this.listTimeLogsWorkTaskId) {
            params.workTaskId = this.listTimeLogsWorkTaskId;
        }
        if (this.listTimeLogsWorkerName) {
            params.workerName = this.listTimeLogsWorkerName;
        }
        if (this.listTimeLogsLogDate) {
            params.logDate = this.listTimeLogsLogDate;
        }
        if (this.listTimeLogsStatus) {
            params.status = this.listTimeLogsStatus;
        }
        if (this.listTimeLogsPage !== '') {
            const pageNum = Number(this.listTimeLogsPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.listTimeLogsPageSize !== '') {
            const pageSizeNum = Number(this.listTimeLogsPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(listTimeLogsRoute, params, options);
        if (response.ok) {
            const data = response.data ?? LIST_TIME_LOGS_DATA_DEFAULT;
            this.listTimeLogsData = data;
            setState('ui.projectDetailWorkspace.data.listTimeLogs', data);
            this.listTimeLogsState = 'success';
            setState('ui.projectDetailWorkspace.action.listTimeLogs.status', 'success');
        }
        else {
            this.listTimeLogsState = 'error';
            setState('ui.projectDetailWorkspace.action.listTimeLogs.status', 'error');
            if (response.error) {
                console.error('listTimeLogs failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action listTimeLogs — bind UI events here */
    handleListTimeLogsClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadListTimeLogs();
    }
    /** action listMaterialUsages (query) — route buildFlowFsm.projectDetailWorkspace.listMaterialUsages; inputs: projectId, status, page, pageSize; writes ui.projectDetailWorkspace.data.listMaterialUsages; status ui.projectDetailWorkspace.action.listMaterialUsages.status */
    async loadListMaterialUsages() {
        this.syncRouteParams();
        if (!this.listMaterialUsagesProjectId) {
            this.listMaterialUsagesState = 'idle';
            setState('ui.projectDetailWorkspace.action.listMaterialUsages.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.listMaterialUsagesState = 'loading';
        setState('ui.projectDetailWorkspace.action.listMaterialUsages.status', 'loading');
        const params = {
            projectId: this.listMaterialUsagesProjectId,
        };
        if (this.listMaterialUsagesStatus) {
            params.status = this.listMaterialUsagesStatus;
        }
        if (this.listMaterialUsagesPage !== '') {
            const pageNum = Number(this.listMaterialUsagesPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.listMaterialUsagesPageSize !== '') {
            const pageSizeNum = Number(this.listMaterialUsagesPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(listMaterialUsagesRoute, params, options);
        if (response.ok) {
            const data = response.data ?? LIST_MATERIAL_USAGES_DATA_DEFAULT;
            this.listMaterialUsagesData = data;
            setState('ui.projectDetailWorkspace.data.listMaterialUsages', data);
            this.listMaterialUsagesState = 'success';
            setState('ui.projectDetailWorkspace.action.listMaterialUsages.status', 'success');
        }
        else {
            this.listMaterialUsagesState = 'error';
            setState('ui.projectDetailWorkspace.action.listMaterialUsages.status', 'error');
            if (response.error) {
                console.error('listMaterialUsages failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action listMaterialUsages — bind UI events here */
    handleListMaterialUsagesClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadListMaterialUsages();
    }
    /** action triggerDelayRiskSuggestions (command) — route buildFlowFsm.projectDetailWorkspace.triggerDelayRiskSuggestions; inputs: statusReportId; writes ui.projectDetailWorkspace.output.triggerDelayRiskSuggestions; status ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status; feedback keys action.triggerDelayRiskSuggestions.success / action.triggerDelayRiskSuggestions.error */
    async triggerDelayRiskSuggestions() {
        this.syncRouteParams();
        if (!this.triggerDelayRiskSuggestionsStatusReportId) {
            this.triggerDelayRiskSuggestionsState = 'idle';
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.triggerDelayRiskSuggestionsState = 'loading';
        setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'loading');
        this.triggerDelayRiskSuggestionsError = '';
        setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.error', '');
        const params = {
            statusReportId: this.triggerDelayRiskSuggestionsStatusReportId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(triggerDelayRiskSuggestionsRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.triggerDelayRiskSuggestions.error');
            this.triggerDelayRiskSuggestionsError = errMsg;
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.error', errMsg);
            this.triggerDelayRiskSuggestionsState = 'error';
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.triggerDelayRiskSuggestionsOutput = data;
        setState('ui.projectDetailWorkspace.output.triggerDelayRiskSuggestions', data);
        try {
            await this.loadGetProjectDetail();
            if (this.getProjectDetailState === 'error') {
                this.triggerDelayRiskSuggestionsState = 'error';
                setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('triggerDelayRiskSuggestions refresh failed', refreshError);
            this.triggerDelayRiskSuggestionsState = 'error';
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadListWorkTasks();
            if (this.listWorkTasksState === 'error') {
                this.triggerDelayRiskSuggestionsState = 'error';
                setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('triggerDelayRiskSuggestions refresh failed', refreshError);
            this.triggerDelayRiskSuggestionsState = 'error';
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadListChangeOrders();
            if (this.listChangeOrdersState === 'error') {
                this.triggerDelayRiskSuggestionsState = 'error';
                setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('triggerDelayRiskSuggestions refresh failed', refreshError);
            this.triggerDelayRiskSuggestionsState = 'error';
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadGetChangeOrderDetail();
            if (this.getChangeOrderDetailState === 'error') {
                this.triggerDelayRiskSuggestionsState = 'error';
                setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('triggerDelayRiskSuggestions refresh failed', refreshError);
            this.triggerDelayRiskSuggestionsState = 'error';
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadListTimeLogs();
            if (this.listTimeLogsState === 'error') {
                this.triggerDelayRiskSuggestionsState = 'error';
                setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('triggerDelayRiskSuggestions refresh failed', refreshError);
            this.triggerDelayRiskSuggestionsState = 'error';
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadListMaterialUsages();
            if (this.listMaterialUsagesState === 'error') {
                this.triggerDelayRiskSuggestionsState = 'error';
                setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('triggerDelayRiskSuggestions refresh failed', refreshError);
            this.triggerDelayRiskSuggestionsState = 'error';
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadListDelayRiskSuggestions();
            if (this.listDelayRiskSuggestionsState === 'error') {
                this.triggerDelayRiskSuggestionsState = 'error';
                setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('triggerDelayRiskSuggestions refresh failed', refreshError);
            this.triggerDelayRiskSuggestionsState = 'error';
            setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'error');
            this.requestUpdate();
            return;
        }
        this.triggerDelayRiskSuggestionsStatusReportId = '';
        setState('ui.projectDetailWorkspace.input.triggerDelayRiskSuggestions.statusReportId', '');
        this.triggerDelayRiskSuggestionsState = 'success';
        setState('ui.projectDetailWorkspace.action.triggerDelayRiskSuggestions.status', 'success');
        this.requestUpdate();
    }
    /** handler for action triggerDelayRiskSuggestions — bind UI events here */
    handleTriggerDelayRiskSuggestionsClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.triggerDelayRiskSuggestions();
        });
    }
    /** action listDelayRiskSuggestions (query) — route buildFlowFsm.projectDetailWorkspace.listDelayRiskSuggestions; inputs: statusReportId, acknowledged; writes ui.projectDetailWorkspace.data.listDelayRiskSuggestions; status ui.projectDetailWorkspace.action.listDelayRiskSuggestions.status */
    async loadListDelayRiskSuggestions() {
        this.syncRouteParams();
        if (!this.listDelayRiskSuggestionsStatusReportId) {
            this.listDelayRiskSuggestionsState = 'idle';
            setState('ui.projectDetailWorkspace.action.listDelayRiskSuggestions.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.listDelayRiskSuggestionsState = 'loading';
        setState('ui.projectDetailWorkspace.action.listDelayRiskSuggestions.status', 'loading');
        const params = {
            statusReportId: this.listDelayRiskSuggestionsStatusReportId,
        };
        if (this.listDelayRiskSuggestionsAcknowledged !== '') {
            params.acknowledged = this.listDelayRiskSuggestionsAcknowledged === 'true';
        }
        const options = { mode: 'silent' };
        const response = await execBff(listDelayRiskSuggestionsRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.listDelayRiskSuggestionsData = data;
            setState('ui.projectDetailWorkspace.data.listDelayRiskSuggestions', data);
            this.listDelayRiskSuggestionsState = 'success';
            setState('ui.projectDetailWorkspace.action.listDelayRiskSuggestions.status', 'success');
        }
        else {
            this.listDelayRiskSuggestionsState = 'error';
            setState('ui.projectDetailWorkspace.action.listDelayRiskSuggestions.status', 'error');
            if (response.error) {
                console.error('listDelayRiskSuggestions failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action listDelayRiskSuggestions — bind UI events here */
    handleListDelayRiskSuggestionsClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadListDelayRiskSuggestions();
    }
    /** setter for state ui.projectDetailWorkspace.input.getProjectDetail.projectId */
    setGetProjectDetailProjectId(value) {
        this.getProjectDetailProjectId = value;
        setState('ui.projectDetailWorkspace.input.getProjectDetail.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.getProjectDetailProjectId — bind UI events here */
    handleGetProjectDetailProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetProjectDetailProjectId(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listWorkTasks.projectId */
    setListWorkTasksProjectId(value) {
        this.listWorkTasksProjectId = value;
        setState('ui.projectDetailWorkspace.input.listWorkTasks.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.listWorkTasksProjectId — bind UI events here */
    handleListWorkTasksProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListWorkTasksProjectId(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listWorkTasks.status */
    setListWorkTasksStatus(value) {
        this.listWorkTasksStatus = value;
        setState('ui.projectDetailWorkspace.input.listWorkTasks.status', value);
        this.requestUpdate();
    }
    /** handler for action set.listWorkTasksStatus — bind UI events here */
    handleListWorkTasksStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListWorkTasksStatus(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listWorkTasks.assignedWorkerId */
    setListWorkTasksAssignedWorkerId(value) {
        this.listWorkTasksAssignedWorkerId = value;
        setState('ui.projectDetailWorkspace.input.listWorkTasks.assignedWorkerId', value);
        this.requestUpdate();
    }
    /** handler for action set.listWorkTasksAssignedWorkerId — bind UI events here */
    handleListWorkTasksAssignedWorkerIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListWorkTasksAssignedWorkerId(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listWorkTasks.page */
    setListWorkTasksPage(value) {
        this.listWorkTasksPage = value;
        setState('ui.projectDetailWorkspace.input.listWorkTasks.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listWorkTasksPage — bind UI events here */
    handleListWorkTasksPageChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListWorkTasksPage(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listWorkTasks.pageSize */
    setListWorkTasksPageSize(value) {
        this.listWorkTasksPageSize = value;
        setState('ui.projectDetailWorkspace.input.listWorkTasks.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listWorkTasksPageSize — bind UI events here */
    handleListWorkTasksPageSizeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListWorkTasksPageSize(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listChangeOrders.projectId */
    setListChangeOrdersProjectId(value) {
        this.listChangeOrdersProjectId = value;
        setState('ui.projectDetailWorkspace.input.listChangeOrders.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.listChangeOrdersProjectId — bind UI events here */
    handleListChangeOrdersProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListChangeOrdersProjectId(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listChangeOrders.status */
    setListChangeOrdersStatus(value) {
        this.listChangeOrdersStatus = value;
        setState('ui.projectDetailWorkspace.input.listChangeOrders.status', value);
        this.requestUpdate();
    }
    /** handler for action set.listChangeOrdersStatus — bind UI events here */
    handleListChangeOrdersStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListChangeOrdersStatus(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listChangeOrders.impactType */
    setListChangeOrdersImpactType(value) {
        this.listChangeOrdersImpactType = value;
        setState('ui.projectDetailWorkspace.input.listChangeOrders.impactType', value);
        this.requestUpdate();
    }
    /** handler for action set.listChangeOrdersImpactType — bind UI events here */
    handleListChangeOrdersImpactTypeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListChangeOrdersImpactType(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listChangeOrders.page */
    setListChangeOrdersPage(value) {
        this.listChangeOrdersPage = value;
        setState('ui.projectDetailWorkspace.input.listChangeOrders.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listChangeOrdersPage — bind UI events here */
    handleListChangeOrdersPageChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListChangeOrdersPage(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listChangeOrders.pageSize */
    setListChangeOrdersPageSize(value) {
        this.listChangeOrdersPageSize = value;
        setState('ui.projectDetailWorkspace.input.listChangeOrders.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listChangeOrdersPageSize — bind UI events here */
    handleListChangeOrdersPageSizeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListChangeOrdersPageSize(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.getChangeOrderDetail.changeOrderId */
    setGetChangeOrderDetailChangeOrderId(value) {
        this.getChangeOrderDetailChangeOrderId = value;
        setState('ui.projectDetailWorkspace.input.getChangeOrderDetail.changeOrderId', value);
        this.requestUpdate();
    }
    /** handler for action set.getChangeOrderDetailChangeOrderId — bind UI events here */
    handleGetChangeOrderDetailChangeOrderIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetChangeOrderDetailChangeOrderId(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listTimeLogs.workTaskId */
    setListTimeLogsWorkTaskId(value) {
        this.listTimeLogsWorkTaskId = value;
        setState('ui.projectDetailWorkspace.input.listTimeLogs.workTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.listTimeLogsWorkTaskId — bind UI events here */
    handleListTimeLogsWorkTaskIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListTimeLogsWorkTaskId(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listTimeLogs.workerName */
    setListTimeLogsWorkerName(value) {
        this.listTimeLogsWorkerName = value;
        setState('ui.projectDetailWorkspace.input.listTimeLogs.workerName', value);
        this.requestUpdate();
    }
    /** handler for action set.listTimeLogsWorkerName — bind UI events here */
    handleListTimeLogsWorkerNameChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListTimeLogsWorkerName(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listTimeLogs.logDate */
    setListTimeLogsLogDate(value) {
        this.listTimeLogsLogDate = value;
        setState('ui.projectDetailWorkspace.input.listTimeLogs.logDate', value);
        this.requestUpdate();
    }
    /** handler for action set.listTimeLogsLogDate — bind UI events here */
    handleListTimeLogsLogDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListTimeLogsLogDate(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listTimeLogs.status */
    setListTimeLogsStatus(value) {
        this.listTimeLogsStatus = value;
        setState('ui.projectDetailWorkspace.input.listTimeLogs.status', value);
        this.requestUpdate();
    }
    /** handler for action set.listTimeLogsStatus — bind UI events here */
    handleListTimeLogsStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListTimeLogsStatus(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listTimeLogs.page */
    setListTimeLogsPage(value) {
        this.listTimeLogsPage = value;
        setState('ui.projectDetailWorkspace.input.listTimeLogs.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listTimeLogsPage — bind UI events here */
    handleListTimeLogsPageChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListTimeLogsPage(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listTimeLogs.pageSize */
    setListTimeLogsPageSize(value) {
        this.listTimeLogsPageSize = value;
        setState('ui.projectDetailWorkspace.input.listTimeLogs.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listTimeLogsPageSize — bind UI events here */
    handleListTimeLogsPageSizeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListTimeLogsPageSize(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listMaterialUsages.projectId */
    setListMaterialUsagesProjectId(value) {
        this.listMaterialUsagesProjectId = value;
        setState('ui.projectDetailWorkspace.input.listMaterialUsages.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.listMaterialUsagesProjectId — bind UI events here */
    handleListMaterialUsagesProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListMaterialUsagesProjectId(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listMaterialUsages.status */
    setListMaterialUsagesStatus(value) {
        this.listMaterialUsagesStatus = value;
        setState('ui.projectDetailWorkspace.input.listMaterialUsages.status', value);
        this.requestUpdate();
    }
    /** handler for action set.listMaterialUsagesStatus — bind UI events here */
    handleListMaterialUsagesStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListMaterialUsagesStatus(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listMaterialUsages.page */
    setListMaterialUsagesPage(value) {
        this.listMaterialUsagesPage = value;
        setState('ui.projectDetailWorkspace.input.listMaterialUsages.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listMaterialUsagesPage — bind UI events here */
    handleListMaterialUsagesPageChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListMaterialUsagesPage(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listMaterialUsages.pageSize */
    setListMaterialUsagesPageSize(value) {
        this.listMaterialUsagesPageSize = value;
        setState('ui.projectDetailWorkspace.input.listMaterialUsages.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listMaterialUsagesPageSize — bind UI events here */
    handleListMaterialUsagesPageSizeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListMaterialUsagesPageSize(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.triggerDelayRiskSuggestions.statusReportId */
    setTriggerDelayRiskSuggestionsStatusReportId(value) {
        this.triggerDelayRiskSuggestionsStatusReportId = value;
        setState('ui.projectDetailWorkspace.input.triggerDelayRiskSuggestions.statusReportId', value);
        this.requestUpdate();
    }
    /** handler for action set.triggerDelayRiskSuggestionsStatusReportId — bind UI events here */
    handleTriggerDelayRiskSuggestionsStatusReportIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setTriggerDelayRiskSuggestionsStatusReportId(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listDelayRiskSuggestions.statusReportId */
    setListDelayRiskSuggestionsStatusReportId(value) {
        this.listDelayRiskSuggestionsStatusReportId = value;
        setState('ui.projectDetailWorkspace.input.listDelayRiskSuggestions.statusReportId', value);
        this.requestUpdate();
    }
    /** handler for action set.listDelayRiskSuggestionsStatusReportId — bind UI events here */
    handleListDelayRiskSuggestionsStatusReportIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListDelayRiskSuggestionsStatusReportId(value);
    }
    /** setter for state ui.projectDetailWorkspace.input.listDelayRiskSuggestions.acknowledged */
    setListDelayRiskSuggestionsAcknowledged(value) {
        this.listDelayRiskSuggestionsAcknowledged = value;
        setState('ui.projectDetailWorkspace.input.listDelayRiskSuggestions.acknowledged', value);
        this.requestUpdate();
    }
    /** handler for action set.listDelayRiskSuggestionsAcknowledged — bind UI events here */
    handleListDelayRiskSuggestionsAcknowledgedChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListDelayRiskSuggestionsAcknowledged(value);
    }
}
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "getProjectDetailState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "getProjectDetailProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "getProjectDetailData", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listWorkTasksState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listWorkTasksProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listWorkTasksStatus", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listWorkTasksAssignedWorkerId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listWorkTasksPage", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listWorkTasksPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listWorkTasksData", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listChangeOrdersState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listChangeOrdersProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listChangeOrdersStatus", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listChangeOrdersImpactType", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listChangeOrdersPage", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listChangeOrdersPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listChangeOrdersData", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "getChangeOrderDetailState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "getChangeOrderDetailChangeOrderId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "getChangeOrderDetailData", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listTimeLogsState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listTimeLogsWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listTimeLogsWorkerName", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listTimeLogsLogDate", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listTimeLogsStatus", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listTimeLogsPage", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listTimeLogsPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listTimeLogsData", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listMaterialUsagesState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listMaterialUsagesProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listMaterialUsagesStatus", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listMaterialUsagesPage", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listMaterialUsagesPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listMaterialUsagesData", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "triggerDelayRiskSuggestionsState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "triggerDelayRiskSuggestionsStatusReportId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "triggerDelayRiskSuggestionsOutput", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "triggerDelayRiskSuggestionsError", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listDelayRiskSuggestionsState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listDelayRiskSuggestionsStatusReportId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listDelayRiskSuggestionsAcknowledged", void 0);
__decorate([
    property()
], BuildFlowFsmProjectDetailWorkspaceBase.prototype, "listDelayRiskSuggestionsData", void 0);
