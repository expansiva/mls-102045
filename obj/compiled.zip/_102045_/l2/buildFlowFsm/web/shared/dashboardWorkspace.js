/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/dashboardWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { getDashboardSummaryRoute, getProjectListRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/dashboardWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    'section.dashboardWorkspace.kpiAndBudgetSection.title': 'KPI & Budget Overview',
    'organism.dashboardWorkspace.inline-row-command10.title': 'Inline row command',
    'intent.dashboardWorkspace.inline-row-command10.content.title': 'Inline row command',
    'organism.dashboardWorkspace.getDashboardSummary.title': 'View operational dashboard',
    'intent.dashboardWorkspace.getDashboardSummary.list.title': 'View operational dashboard',
    'intent.dashboardWorkspace.getDashboardSummary.list.empty': 'Nenhum registro encontrado',
    'intent.dashboardWorkspace.getDashboardSummary.list.column.projects.label': 'Projects',
    'intent.dashboardWorkspace.getDashboardSummary.list.column.total.label': 'Total',
    'intent.dashboardWorkspace.getDashboardSummary.list.filter.status.label': 'Status',
    'intent.dashboardWorkspace.getDashboardSummary.list.filter.page.label': 'Page',
    'intent.dashboardWorkspace.getDashboardSummary.list.filter.pageSize.label': 'Page Size',
    'section.dashboardWorkspace.projectListSection.title': 'Project List',
    'organism.dashboardWorkspace.getProjectList.title': 'Browse projects',
    'intent.dashboardWorkspace.getProjectList.list.title': 'Browse projects',
    'intent.dashboardWorkspace.getProjectList.list.empty': 'Nenhum registro encontrado',
    'intent.dashboardWorkspace.getProjectList.list.column.projects.label': 'Projects',
    'intent.dashboardWorkspace.getProjectList.list.column.total.label': 'Total',
    'intent.dashboardWorkspace.getProjectList.list.filter.status.label': 'Status',
    'intent.dashboardWorkspace.getProjectList.list.filter.page.label': 'Page',
    'intent.dashboardWorkspace.getProjectList.list.filter.pageSize.label': 'Page Size',
    'section.dashboardWorkspace.sec-kpi.title': 'KPI & Budget Overview',
    'section.dashboardWorkspace.sec-project-list.title': 'Project List',
};
const message_pt_br = {
    'section.dashboardWorkspace.kpiAndBudgetSection.title': 'KPI & Budget Overview',
    'organism.dashboardWorkspace.inline-row-command10.title': 'Inline row command',
    'intent.dashboardWorkspace.inline-row-command10.content.title': 'Inline row command',
    'organism.dashboardWorkspace.getDashboardSummary.title': 'View operational dashboard',
    'intent.dashboardWorkspace.getDashboardSummary.list.title': 'View operational dashboard',
    'intent.dashboardWorkspace.getDashboardSummary.list.empty': 'Nenhum registro encontrado',
    'intent.dashboardWorkspace.getDashboardSummary.list.column.projects.label': 'Projects',
    'intent.dashboardWorkspace.getDashboardSummary.list.column.total.label': 'Total',
    'intent.dashboardWorkspace.getDashboardSummary.list.filter.status.label': 'Status',
    'intent.dashboardWorkspace.getDashboardSummary.list.filter.page.label': 'Page',
    'intent.dashboardWorkspace.getDashboardSummary.list.filter.pageSize.label': 'Page Size',
    'section.dashboardWorkspace.projectListSection.title': 'Project List',
    'organism.dashboardWorkspace.getProjectList.title': 'Browse projects',
    'intent.dashboardWorkspace.getProjectList.list.title': 'Browse projects',
    'intent.dashboardWorkspace.getProjectList.list.empty': 'Nenhum registro encontrado',
    'intent.dashboardWorkspace.getProjectList.list.column.projects.label': 'Projects',
    'intent.dashboardWorkspace.getProjectList.list.column.total.label': 'Total',
    'intent.dashboardWorkspace.getProjectList.list.filter.status.label': 'Status',
    'intent.dashboardWorkspace.getProjectList.list.filter.page.label': 'Page',
    'intent.dashboardWorkspace.getProjectList.list.filter.pageSize.label': 'Page Size',
    'section.dashboardWorkspace.sec-kpi.title': 'KPI & Budget Overview',
    'section.dashboardWorkspace.sec-project-list.title': 'Project List',
};
const message_es = {
    'section.dashboardWorkspace.kpiAndBudgetSection.title': 'KPI & Budget Overview',
    'organism.dashboardWorkspace.inline-row-command10.title': 'Inline row command',
    'intent.dashboardWorkspace.inline-row-command10.content.title': 'Inline row command',
    'organism.dashboardWorkspace.getDashboardSummary.title': 'View operational dashboard',
    'intent.dashboardWorkspace.getDashboardSummary.list.title': 'View operational dashboard',
    'intent.dashboardWorkspace.getDashboardSummary.list.empty': 'Nenhum registro encontrado',
    'intent.dashboardWorkspace.getDashboardSummary.list.column.projects.label': 'Projects',
    'intent.dashboardWorkspace.getDashboardSummary.list.column.total.label': 'Total',
    'intent.dashboardWorkspace.getDashboardSummary.list.filter.status.label': 'Status',
    'intent.dashboardWorkspace.getDashboardSummary.list.filter.page.label': 'Page',
    'intent.dashboardWorkspace.getDashboardSummary.list.filter.pageSize.label': 'Page Size',
    'section.dashboardWorkspace.projectListSection.title': 'Project List',
    'organism.dashboardWorkspace.getProjectList.title': 'Browse projects',
    'intent.dashboardWorkspace.getProjectList.list.title': 'Browse projects',
    'intent.dashboardWorkspace.getProjectList.list.empty': 'Nenhum registro encontrado',
    'intent.dashboardWorkspace.getProjectList.list.column.projects.label': 'Projects',
    'intent.dashboardWorkspace.getProjectList.list.column.total.label': 'Total',
    'intent.dashboardWorkspace.getProjectList.list.filter.status.label': 'Status',
    'intent.dashboardWorkspace.getProjectList.list.filter.page.label': 'Page',
    'intent.dashboardWorkspace.getProjectList.list.filter.pageSize.label': 'Page Size',
    'section.dashboardWorkspace.sec-kpi.title': 'KPI & Budget Overview',
    'section.dashboardWorkspace.sec-project-list.title': 'Project List',
};
export const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
const GET_DASHBOARD_SUMMARY_DATA_DEFAULT = { projects: [], total: 0 };
const GET_PROJECT_LIST_DATA_DEFAULT = { projects: [], total: 0 };
const SUBSCRIBED_STATE_KEYS = [
    'ui.dashboardWorkspace.status',
    'ui.dashboardWorkspace.action.getDashboardSummary.status',
    'ui.dashboardWorkspace.input.getDashboardSummary.status',
    'ui.dashboardWorkspace.input.getDashboardSummary.page',
    'ui.dashboardWorkspace.input.getDashboardSummary.pageSize',
    'ui.dashboardWorkspace.data.getDashboardSummary',
    'ui.dashboardWorkspace.action.getProjectList.status',
    'ui.dashboardWorkspace.input.getProjectList.status',
    'ui.dashboardWorkspace.input.getProjectList.page',
    'ui.dashboardWorkspace.input.getProjectList.pageSize',
    'ui.dashboardWorkspace.data.getProjectList',
];
export class BuildFlowFsmDashboardWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state getDashboardSummaryState — actionStatus, values: idle|loading|success|error */
        this.getDashboardSummaryState = 'idle';
        /** state getDashboardSummaryStatus — input */
        this.getDashboardSummaryStatus = '';
        /** state getDashboardSummaryPage — input */
        this.getDashboardSummaryPage = '';
        /** state getDashboardSummaryPageSize — input */
        this.getDashboardSummaryPageSize = '';
        /** state getDashboardSummaryData — queryResult, outputShape: paginated */
        this.getDashboardSummaryData = GET_DASHBOARD_SUMMARY_DATA_DEFAULT;
        /** state getProjectListState — actionStatus, values: idle|loading|success|error */
        this.getProjectListState = 'idle';
        /** state getProjectListStatus — input */
        this.getProjectListStatus = '';
        /** state getProjectListPage — input */
        this.getProjectListPage = '';
        /** state getProjectListPageSize — input */
        this.getProjectListPageSize = '';
        /** state getProjectListData — queryResult, outputShape: paginated */
        this.getProjectListData = GET_PROJECT_LIST_DATA_DEFAULT;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.dashboardWorkspace.status', '');
        this.initStateValue('ui.dashboardWorkspace.action.getDashboardSummary.status', 'idle');
        this.initStateValue('ui.dashboardWorkspace.input.getDashboardSummary.status', '');
        this.initStateValue('ui.dashboardWorkspace.input.getDashboardSummary.page', '');
        this.initStateValue('ui.dashboardWorkspace.input.getDashboardSummary.pageSize', '');
        this.initStateValue('ui.dashboardWorkspace.data.getDashboardSummary', GET_DASHBOARD_SUMMARY_DATA_DEFAULT);
        this.initStateValue('ui.dashboardWorkspace.action.getProjectList.status', 'idle');
        this.initStateValue('ui.dashboardWorkspace.input.getProjectList.status', '');
        this.initStateValue('ui.dashboardWorkspace.input.getProjectList.page', '');
        this.initStateValue('ui.dashboardWorkspace.input.getProjectList.pageSize', '');
        this.initStateValue('ui.dashboardWorkspace.data.getProjectList', GET_PROJECT_LIST_DATA_DEFAULT);
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadGetDashboardSummary();
        void this.loadGetProjectList();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.dashboardWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.dashboardWorkspace.action.getDashboardSummary.status':
                this.getDashboardSummaryState = value ?? 'idle';
                break;
            case 'ui.dashboardWorkspace.input.getDashboardSummary.status':
                this.getDashboardSummaryStatus = value ?? '';
                break;
            case 'ui.dashboardWorkspace.input.getDashboardSummary.page':
                this.getDashboardSummaryPage = value ?? '';
                break;
            case 'ui.dashboardWorkspace.input.getDashboardSummary.pageSize':
                this.getDashboardSummaryPageSize = value ?? '';
                break;
            case 'ui.dashboardWorkspace.data.getDashboardSummary':
                this.getDashboardSummaryData = value ?? GET_DASHBOARD_SUMMARY_DATA_DEFAULT;
                break;
            case 'ui.dashboardWorkspace.action.getProjectList.status':
                this.getProjectListState = value ?? 'idle';
                break;
            case 'ui.dashboardWorkspace.input.getProjectList.status':
                this.getProjectListStatus = value ?? '';
                break;
            case 'ui.dashboardWorkspace.input.getProjectList.page':
                this.getProjectListPage = value ?? '';
                break;
            case 'ui.dashboardWorkspace.input.getProjectList.pageSize':
                this.getProjectListPageSize = value ?? '';
                break;
            case 'ui.dashboardWorkspace.data.getProjectList':
                this.getProjectListData = value ?? GET_PROJECT_LIST_DATA_DEFAULT;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.dashboardWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.dashboardWorkspace.action.getDashboardSummary.status':
                this.getDashboardSummaryState = value ?? 'idle';
                break;
            case 'ui.dashboardWorkspace.input.getDashboardSummary.status':
                this.getDashboardSummaryStatus = value ?? '';
                break;
            case 'ui.dashboardWorkspace.input.getDashboardSummary.page':
                this.getDashboardSummaryPage = value ?? '';
                break;
            case 'ui.dashboardWorkspace.input.getDashboardSummary.pageSize':
                this.getDashboardSummaryPageSize = value ?? '';
                break;
            case 'ui.dashboardWorkspace.data.getDashboardSummary':
                this.getDashboardSummaryData = value ?? GET_DASHBOARD_SUMMARY_DATA_DEFAULT;
                break;
            case 'ui.dashboardWorkspace.action.getProjectList.status':
                this.getProjectListState = value ?? 'idle';
                break;
            case 'ui.dashboardWorkspace.input.getProjectList.status':
                this.getProjectListStatus = value ?? '';
                break;
            case 'ui.dashboardWorkspace.input.getProjectList.page':
                this.getProjectListPage = value ?? '';
                break;
            case 'ui.dashboardWorkspace.input.getProjectList.pageSize':
                this.getProjectListPageSize = value ?? '';
                break;
            case 'ui.dashboardWorkspace.data.getProjectList':
                this.getProjectListData = value ?? GET_PROJECT_LIST_DATA_DEFAULT;
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    /** action getDashboardSummary (query) — route buildFlowFsm.dashboardWorkspace.getDashboardSummary; inputs: status, page, pageSize; writes ui.dashboardWorkspace.data.getDashboardSummary; status ui.dashboardWorkspace.action.getDashboardSummary.status */
    async loadGetDashboardSummary() {
        this.getDashboardSummaryState = 'loading';
        setState('ui.dashboardWorkspace.action.getDashboardSummary.status', 'loading');
        const params = {};
        if (this.getDashboardSummaryStatus) {
            params.status = this.getDashboardSummaryStatus;
        }
        if (this.getDashboardSummaryPage !== '') {
            const pageNum = Number(this.getDashboardSummaryPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.getDashboardSummaryPageSize !== '') {
            const pageSizeNum = Number(this.getDashboardSummaryPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(getDashboardSummaryRoute, params, options);
        if (response.ok) {
            const data = response.data ?? GET_DASHBOARD_SUMMARY_DATA_DEFAULT;
            this.getDashboardSummaryData = data;
            setState('ui.dashboardWorkspace.data.getDashboardSummary', data);
            this.getDashboardSummaryState = 'success';
            setState('ui.dashboardWorkspace.action.getDashboardSummary.status', 'success');
        }
        else {
            this.getDashboardSummaryState = 'error';
            setState('ui.dashboardWorkspace.action.getDashboardSummary.status', 'error');
            if (response.error) {
                console.error('getDashboardSummary failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action getDashboardSummary — bind UI events here */
    handleGetDashboardSummaryClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadGetDashboardSummary();
    }
    /** action getProjectList (query) — route buildFlowFsm.dashboardWorkspace.getProjectList; inputs: status, page, pageSize; writes ui.dashboardWorkspace.data.getProjectList; status ui.dashboardWorkspace.action.getProjectList.status */
    async loadGetProjectList() {
        this.getProjectListState = 'loading';
        setState('ui.dashboardWorkspace.action.getProjectList.status', 'loading');
        const params = {};
        if (this.getProjectListStatus) {
            params.status = this.getProjectListStatus;
        }
        if (this.getProjectListPage !== '') {
            const pageNum = Number(this.getProjectListPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.getProjectListPageSize !== '') {
            const pageSizeNum = Number(this.getProjectListPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(getProjectListRoute, params, options);
        if (response.ok) {
            const data = response.data ?? GET_PROJECT_LIST_DATA_DEFAULT;
            this.getProjectListData = data;
            setState('ui.dashboardWorkspace.data.getProjectList', data);
            this.getProjectListState = 'success';
            setState('ui.dashboardWorkspace.action.getProjectList.status', 'success');
        }
        else {
            this.getProjectListState = 'error';
            setState('ui.dashboardWorkspace.action.getProjectList.status', 'error');
            if (response.error) {
                console.error('getProjectList failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action getProjectList — bind UI events here */
    handleGetProjectListClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadGetProjectList();
    }
    /** setter for state ui.dashboardWorkspace.input.getDashboardSummary.status */
    setGetDashboardSummaryStatus(value) {
        this.getDashboardSummaryStatus = value;
        setState('ui.dashboardWorkspace.input.getDashboardSummary.status', value);
        this.requestUpdate();
    }
    /** handler for action set.getDashboardSummaryStatus — bind UI events here */
    handleGetDashboardSummaryStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetDashboardSummaryStatus(value);
    }
    /** setter for state ui.dashboardWorkspace.input.getDashboardSummary.page */
    setGetDashboardSummaryPage(value) {
        this.getDashboardSummaryPage = value;
        setState('ui.dashboardWorkspace.input.getDashboardSummary.page', value);
        this.requestUpdate();
    }
    /** handler for action set.getDashboardSummaryPage — bind UI events here */
    handleGetDashboardSummaryPageChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetDashboardSummaryPage(value);
    }
    /** setter for state ui.dashboardWorkspace.input.getDashboardSummary.pageSize */
    setGetDashboardSummaryPageSize(value) {
        this.getDashboardSummaryPageSize = value;
        setState('ui.dashboardWorkspace.input.getDashboardSummary.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.getDashboardSummaryPageSize — bind UI events here */
    handleGetDashboardSummaryPageSizeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetDashboardSummaryPageSize(value);
    }
    /** setter for state ui.dashboardWorkspace.input.getProjectList.status */
    setGetProjectListStatus(value) {
        this.getProjectListStatus = value;
        setState('ui.dashboardWorkspace.input.getProjectList.status', value);
        this.requestUpdate();
    }
    /** handler for action set.getProjectListStatus — bind UI events here */
    handleGetProjectListStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetProjectListStatus(value);
    }
    /** setter for state ui.dashboardWorkspace.input.getProjectList.page */
    setGetProjectListPage(value) {
        this.getProjectListPage = value;
        setState('ui.dashboardWorkspace.input.getProjectList.page', value);
        this.requestUpdate();
    }
    /** handler for action set.getProjectListPage — bind UI events here */
    handleGetProjectListPageChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetProjectListPage(value);
    }
    /** setter for state ui.dashboardWorkspace.input.getProjectList.pageSize */
    setGetProjectListPageSize(value) {
        this.getProjectListPageSize = value;
        setState('ui.dashboardWorkspace.input.getProjectList.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.getProjectListPageSize — bind UI events here */
    handleGetProjectListPageSizeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetProjectListPageSize(value);
    }
}
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getDashboardSummaryState", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getDashboardSummaryStatus", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getDashboardSummaryPage", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getDashboardSummaryPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getDashboardSummaryData", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getProjectListState", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getProjectListStatus", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getProjectListPage", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getProjectListPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmDashboardWorkspaceBase.prototype, "getProjectListData", void 0);
