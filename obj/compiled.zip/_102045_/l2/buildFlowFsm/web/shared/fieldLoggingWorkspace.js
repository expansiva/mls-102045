/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/fieldLoggingWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
import { submitTimeLogRoute, submitVoidTimeLogRoute, submitMaterialUsageRoute, submitVoidMaterialUsageRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/fieldLoggingWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    "section.fieldLoggingWorkspace.sec-time-logging.title": "Time Logging",
    "organism.fieldLoggingWorkspace.submitTimeLog.title": "Log hours worked",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.title": "Log hours worked",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.action.submitTimeLog": "Log hours worked",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.workTaskId.label": "Work Task Id",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.logDate.label": "Log Date",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.hoursWorked.label": "Hours Worked",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.workerName.label": "Worker Name",
    "organism.fieldLoggingWorkspace.submitVoidTimeLog.title": "Void time log",
    "intent.fieldLoggingWorkspace.submitVoidTimeLog.form.title": "Void time log",
    "intent.fieldLoggingWorkspace.submitVoidTimeLog.form.action.submitVoidTimeLog": "Void time log",
    "intent.fieldLoggingWorkspace.submitVoidTimeLog.form.field.voidReason.label": "Void Reason",
    "section.fieldLoggingWorkspace.sec-material-logging.title": "Material Logging",
    "organism.fieldLoggingWorkspace.submitMaterialUsage.title": "Log materials used",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.title": "Log materials used",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.action.submitMaterialUsage": "Log materials used",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.materialName.label": "Material Name",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.quantity.label": "Quantity",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unit.label": "Unit",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unitCost.label": "Unit Cost",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.costCode.label": "Cost Code",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.usageDate.label": "Usage Date",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.recordedBy.label": "Recorded By",
    "organism.fieldLoggingWorkspace.submitVoidMaterialUsage.title": "Void material usage",
    "intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.title": "Void material usage",
    "intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.action.submitVoidMaterialUsage": "Void material usage",
    "intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.field.voidedReason.label": "Voided Reason"
};
const message_pt_br = {
    "section.fieldLoggingWorkspace.sec-time-logging.title": "Registro de Tempo",
    "organism.fieldLoggingWorkspace.submitTimeLog.title": "Registrar horas trabalhadas",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.title": "Registrar horas trabalhadas",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.action.submitTimeLog": "Registrar horas trabalhadas",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.workTaskId.label": "ID da Tarefa",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.logDate.label": "Data do Registro",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.hoursWorked.label": "Horas Trabalhadas",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.workerName.label": "Nome do Trabalhador",
    "organism.fieldLoggingWorkspace.submitVoidTimeLog.title": "Anular registro de tempo",
    "intent.fieldLoggingWorkspace.submitVoidTimeLog.form.title": "Anular registro de tempo",
    "intent.fieldLoggingWorkspace.submitVoidTimeLog.form.action.submitVoidTimeLog": "Anular registro de tempo",
    "intent.fieldLoggingWorkspace.submitVoidTimeLog.form.field.voidReason.label": "Motivo da Anulação",
    "section.fieldLoggingWorkspace.sec-material-logging.title": "Registro de Materiais",
    "organism.fieldLoggingWorkspace.submitMaterialUsage.title": "Registrar materiais usados",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.title": "Registrar materiais usados",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.action.submitMaterialUsage": "Registrar materiais usados",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.materialName.label": "Nome do Material",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.quantity.label": "Quantidade",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unit.label": "Unidade",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unitCost.label": "Custo Unitário",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.costCode.label": "Código de Custo",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.usageDate.label": "Data de Uso",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.recordedBy.label": "Registrado Por",
    "organism.fieldLoggingWorkspace.submitVoidMaterialUsage.title": "Anular uso de material",
    "intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.title": "Anular uso de material",
    "intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.action.submitVoidMaterialUsage": "Anular uso de material",
    "intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.field.voidedReason.label": "Motivo da Anulação"
};
const message_es = {
    "section.fieldLoggingWorkspace.sec-time-logging.title": "Registro de Tiempo",
    "organism.fieldLoggingWorkspace.submitTimeLog.title": "Registrar horas trabajadas",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.title": "Registrar horas trabajadas",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.action.submitTimeLog": "Registrar horas trabajadas",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.workTaskId.label": "ID de la Tarea",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.logDate.label": "Fecha de Registro",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.hoursWorked.label": "Horas Trabajadas",
    "intent.fieldLoggingWorkspace.submitTimeLog.form.field.workerName.label": "Nombre del Trabajador",
    "organism.fieldLoggingWorkspace.submitVoidTimeLog.title": "Anular registro de tiempo",
    "intent.fieldLoggingWorkspace.submitVoidTimeLog.form.title": "Anular registro de tiempo",
    "intent.fieldLoggingWorkspace.submitVoidTimeLog.form.action.submitVoidTimeLog": "Anular registro de tiempo",
    "intent.fieldLoggingWorkspace.submitVoidTimeLog.form.field.voidReason.label": "Motivo de Anulación",
    "section.fieldLoggingWorkspace.sec-material-logging.title": "Registro de Materiales",
    "organism.fieldLoggingWorkspace.submitMaterialUsage.title": "Registrar materiales usados",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.title": "Registrar materiales usados",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.action.submitMaterialUsage": "Registrar materiales usados",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.materialName.label": "Nombre del Material",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.quantity.label": "Cantidad",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unit.label": "Unidad",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unitCost.label": "Costo Unitario",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.costCode.label": "Código de Costo",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.usageDate.label": "Fecha de Uso",
    "intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.recordedBy.label": "Registrado Por",
    "organism.fieldLoggingWorkspace.submitVoidMaterialUsage.title": "Anular uso de material",
    "intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.title": "Anular uso de material",
    "intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.action.submitVoidMaterialUsage": "Anular uso de material",
    "intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.field.voidedReason.label": "Motivo de Anulación"
};
const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
export class BuildFlowFsmFieldLoggingWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state ui.fieldLoggingWorkspace.status — pageStatus */
        this.status = '';
        /** state ui.fieldLoggingWorkspace.action.submitTimeLog.status — actionStatus, values: idle|loading|success|error */
        this.submitTimeLogState = 'idle';
        /** state ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId — input, presentation: form */
        this.submitTimeLogWorkTaskId = '';
        /** state ui.fieldLoggingWorkspace.input.submitTimeLog.logDate — input, presentation: form */
        this.submitTimeLogLogDate = '';
        /** state ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked — input, presentation: form */
        this.submitTimeLogHoursWorked = '';
        /** state ui.fieldLoggingWorkspace.input.submitTimeLog.workerName — input, presentation: form */
        this.submitTimeLogWorkerName = '';
        /** state ui.fieldLoggingWorkspace.output.submitTimeLog — commandOutput, outputShape: object */
        this.submitTimeLogOutput = null;
        /** state ui.fieldLoggingWorkspace.action.submitTimeLog.error — actionError */
        this.submitTimeLogError = '';
        /** state ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status — actionStatus, values: idle|loading|success|error */
        this.submitVoidTimeLogState = 'idle';
        /** state ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId — input, presentation: selection */
        this.submitVoidTimeLogTimeLogId = '';
        /** state ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason — input, presentation: form */
        this.submitVoidTimeLogVoidReason = '';
        /** state ui.fieldLoggingWorkspace.output.submitVoidTimeLog — commandOutput, outputShape: object */
        this.submitVoidTimeLogOutput = null;
        /** state ui.fieldLoggingWorkspace.action.submitVoidTimeLog.error — actionError */
        this.submitVoidTimeLogError = '';
        /** state ui.fieldLoggingWorkspace.action.submitMaterialUsage.status — actionStatus, values: idle|loading|success|error */
        this.submitMaterialUsageState = 'idle';
        /** state ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId — input, presentation: selection */
        this.submitMaterialUsageProjectId = '';
        /** state ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName — input, presentation: form */
        this.submitMaterialUsageMaterialName = '';
        /** state ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity — input, presentation: form */
        this.submitMaterialUsageQuantity = '';
        /** state ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit — input, presentation: form */
        this.submitMaterialUsageUnit = '';
        /** state ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost — input, presentation: form */
        this.submitMaterialUsageUnitCost = '';
        /** state ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode — input, presentation: form */
        this.submitMaterialUsageCostCode = '';
        /** state ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate — input, presentation: form */
        this.submitMaterialUsageUsageDate = '';
        /** state ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy — input, presentation: form */
        this.submitMaterialUsageRecordedBy = '';
        /** state ui.fieldLoggingWorkspace.output.submitMaterialUsage — commandOutput, outputShape: object */
        this.submitMaterialUsageOutput = null;
        /** state ui.fieldLoggingWorkspace.action.submitMaterialUsage.error — actionError */
        this.submitMaterialUsageError = '';
        /** state ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status — actionStatus, values: idle|loading|success|error */
        this.submitVoidMaterialUsageState = 'idle';
        /** state ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId — input, presentation: selection */
        this.submitVoidMaterialUsageMaterialUsageId = '';
        /** state ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason — input, presentation: form */
        this.submitVoidMaterialUsageVoidedReason = '';
        /** state ui.fieldLoggingWorkspace.output.submitVoidMaterialUsage — commandOutput, outputShape: object */
        this.submitVoidMaterialUsageOutput = null;
        /** state ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.error — actionError */
        this.submitVoidMaterialUsageError = '';
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    /** action submitTimeLog (command) — route buildFlowFsm.fieldLoggingWorkspace.submitTimeLog; inputs: workTaskId, logDate, hoursWorked, workerName; writes ui.fieldLoggingWorkspace.output.submitTimeLog; status ui.fieldLoggingWorkspace.action.submitTimeLog.status; feedback keys action.submitTimeLog.success / action.submitTimeLog.error */
    async submitTimeLog(signal) {
        this.submitTimeLogState = 'loading';
        setState('ui.fieldLoggingWorkspace.action.submitTimeLog.status', 'loading');
        const params = {
            workTaskId: this.submitTimeLogWorkTaskId,
            logDate: this.submitTimeLogLogDate,
            hoursWorked: Number(this.submitTimeLogHoursWorked),
            workerName: this.submitTimeLogWorkerName,
        };
        const options = { mode: 'blocking' };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff(submitTimeLogRoute, params, options);
        if (response.ok) {
            this.submitTimeLogOutput = response.data ?? null;
            setState('ui.fieldLoggingWorkspace.output.submitTimeLog', response.data ?? null);
            this.submitTimeLogWorkTaskId = '';
            this.submitTimeLogLogDate = '';
            this.submitTimeLogHoursWorked = '';
            this.submitTimeLogWorkerName = '';
            setState('ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId', '');
            setState('ui.fieldLoggingWorkspace.input.submitTimeLog.logDate', '');
            setState('ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked', '');
            setState('ui.fieldLoggingWorkspace.input.submitTimeLog.workerName', '');
            this.submitTimeLogError = '';
            setState('ui.fieldLoggingWorkspace.action.submitTimeLog.error', '');
            this.submitTimeLogState = 'success';
            setState('ui.fieldLoggingWorkspace.action.submitTimeLog.status', 'success');
        }
        else {
            const errorMsg = response.error ? String(response.error.message ?? '') : '';
            this.submitTimeLogError = errorMsg;
            setState('ui.fieldLoggingWorkspace.action.submitTimeLog.error', errorMsg);
            this.submitTimeLogState = 'error';
            setState('ui.fieldLoggingWorkspace.action.submitTimeLog.status', 'error');
        }
    }
    /** handler for action submitTimeLog — bind UI events here */
    handleSubmitTimeLogClick() {
        runBlockingUiAction(async (signal) => {
            await this.submitTimeLog(signal);
        });
    }
    /** action submitVoidTimeLog (command) — route buildFlowFsm.fieldLoggingWorkspace.submitVoidTimeLog; inputs: timeLogId, voidReason; writes ui.fieldLoggingWorkspace.output.submitVoidTimeLog; status ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status; feedback keys action.submitVoidTimeLog.success / action.submitVoidTimeLog.error */
    async submitVoidTimeLog(signal) {
        this.submitVoidTimeLogState = 'loading';
        setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status', 'loading');
        const params = {
            timeLogId: this.submitVoidTimeLogTimeLogId,
            voidReason: this.submitVoidTimeLogVoidReason,
        };
        const options = { mode: 'blocking' };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff(submitVoidTimeLogRoute, params, options);
        if (response.ok) {
            this.submitVoidTimeLogOutput = response.data ?? null;
            setState('ui.fieldLoggingWorkspace.output.submitVoidTimeLog', response.data ?? null);
            this.submitVoidTimeLogTimeLogId = '';
            this.submitVoidTimeLogVoidReason = '';
            setState('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId', '');
            setState('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason', '');
            this.submitVoidTimeLogError = '';
            setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.error', '');
            this.submitVoidTimeLogState = 'success';
            setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status', 'success');
        }
        else {
            const errorMsg = response.error ? String(response.error.message ?? '') : '';
            this.submitVoidTimeLogError = errorMsg;
            setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.error', errorMsg);
            this.submitVoidTimeLogState = 'error';
            setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status', 'error');
        }
    }
    /** handler for action submitVoidTimeLog — bind UI events here */
    handleSubmitVoidTimeLogClick() {
        runBlockingUiAction(async (signal) => {
            await this.submitVoidTimeLog(signal);
        });
    }
    /** action submitMaterialUsage (command) — route buildFlowFsm.fieldLoggingWorkspace.submitMaterialUsage; inputs: projectId, materialName, quantity, unit, unitCost, costCode, usageDate, recordedBy; writes ui.fieldLoggingWorkspace.output.submitMaterialUsage; status ui.fieldLoggingWorkspace.action.submitMaterialUsage.status; feedback keys action.submitMaterialUsage.success / action.submitMaterialUsage.error */
    async submitMaterialUsage(signal) {
        this.submitMaterialUsageState = 'loading';
        setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.status', 'loading');
        const params = {
            projectId: this.submitMaterialUsageProjectId,
            materialName: this.submitMaterialUsageMaterialName,
            quantity: Number(this.submitMaterialUsageQuantity),
            unit: this.submitMaterialUsageUnit,
            unitCost: Number(this.submitMaterialUsageUnitCost),
            costCode: this.submitMaterialUsageCostCode || undefined,
            usageDate: this.submitMaterialUsageUsageDate,
            recordedBy: this.submitMaterialUsageRecordedBy,
        };
        const options = { mode: 'blocking' };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff(submitMaterialUsageRoute, params, options);
        if (response.ok) {
            this.submitMaterialUsageOutput = response.data ?? null;
            setState('ui.fieldLoggingWorkspace.output.submitMaterialUsage', response.data ?? null);
            this.submitMaterialUsageProjectId = '';
            this.submitMaterialUsageMaterialName = '';
            this.submitMaterialUsageQuantity = '';
            this.submitMaterialUsageUnit = '';
            this.submitMaterialUsageUnitCost = '';
            this.submitMaterialUsageCostCode = '';
            this.submitMaterialUsageUsageDate = '';
            this.submitMaterialUsageRecordedBy = '';
            setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId', '');
            setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName', '');
            setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity', '');
            setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit', '');
            setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost', '');
            setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode', '');
            setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate', '');
            setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy', '');
            this.submitMaterialUsageError = '';
            setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.error', '');
            this.submitMaterialUsageState = 'success';
            setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.status', 'success');
        }
        else {
            const errorMsg = response.error ? String(response.error.message ?? '') : '';
            this.submitMaterialUsageError = errorMsg;
            setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.error', errorMsg);
            this.submitMaterialUsageState = 'error';
            setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.status', 'error');
        }
    }
    /** handler for action submitMaterialUsage — bind UI events here */
    handleSubmitMaterialUsageClick() {
        runBlockingUiAction(async (signal) => {
            await this.submitMaterialUsage(signal);
        });
    }
    /** action submitVoidMaterialUsage (command) — route buildFlowFsm.fieldLoggingWorkspace.submitVoidMaterialUsage; inputs: materialUsageId, voidedReason; writes ui.fieldLoggingWorkspace.output.submitVoidMaterialUsage; status ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status; feedback keys action.submitVoidMaterialUsage.success / action.submitVoidMaterialUsage.error */
    async submitVoidMaterialUsage(signal) {
        this.submitVoidMaterialUsageState = 'loading';
        setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status', 'loading');
        const params = {
            materialUsageId: this.submitVoidMaterialUsageMaterialUsageId,
            voidedReason: this.submitVoidMaterialUsageVoidedReason,
        };
        const options = { mode: 'blocking' };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff(submitVoidMaterialUsageRoute, params, options);
        if (response.ok) {
            this.submitVoidMaterialUsageOutput = response.data ?? null;
            setState('ui.fieldLoggingWorkspace.output.submitVoidMaterialUsage', response.data ?? null);
            this.submitVoidMaterialUsageMaterialUsageId = '';
            this.submitVoidMaterialUsageVoidedReason = '';
            setState('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId', '');
            setState('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason', '');
            this.submitVoidMaterialUsageError = '';
            setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.error', '');
            this.submitVoidMaterialUsageState = 'success';
            setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status', 'success');
        }
        else {
            const errorMsg = response.error ? String(response.error.message ?? '') : '';
            this.submitVoidMaterialUsageError = errorMsg;
            setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.error', errorMsg);
            this.submitVoidMaterialUsageState = 'error';
            setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status', 'error');
        }
    }
    /** handler for action submitVoidMaterialUsage — bind UI events here */
    handleSubmitVoidMaterialUsageClick() {
        runBlockingUiAction(async (signal) => {
            await this.submitVoidMaterialUsage(signal);
        });
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId */
    setSubmitTimeLogWorkTaskId(value) {
        this.submitTimeLogWorkTaskId = value;
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.submitTimeLogWorkTaskId — bind UI events here */
    handleSubmitTimeLogWorkTaskIdChange(e) {
        const target = e.target;
        this.setSubmitTimeLogWorkTaskId(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitTimeLog.logDate */
    setSubmitTimeLogLogDate(value) {
        this.submitTimeLogLogDate = value;
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.logDate', value);
        this.requestUpdate();
    }
    /** handler for action set.submitTimeLogLogDate — bind UI events here */
    handleSubmitTimeLogLogDateChange(e) {
        const target = e.target;
        this.setSubmitTimeLogLogDate(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked */
    setSubmitTimeLogHoursWorked(value) {
        this.submitTimeLogHoursWorked = value;
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked', value);
        this.requestUpdate();
    }
    /** handler for action set.submitTimeLogHoursWorked — bind UI events here */
    handleSubmitTimeLogHoursWorkedChange(e) {
        const target = e.target;
        this.setSubmitTimeLogHoursWorked(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitTimeLog.workerName */
    setSubmitTimeLogWorkerName(value) {
        this.submitTimeLogWorkerName = value;
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.workerName', value);
        this.requestUpdate();
    }
    /** handler for action set.submitTimeLogWorkerName — bind UI events here */
    handleSubmitTimeLogWorkerNameChange(e) {
        const target = e.target;
        this.setSubmitTimeLogWorkerName(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId */
    setSubmitVoidTimeLogTimeLogId(value) {
        this.submitVoidTimeLogTimeLogId = value;
        setState('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId', value);
        this.requestUpdate();
    }
    /** handler for action set.submitVoidTimeLogTimeLogId — bind UI events here */
    handleSubmitVoidTimeLogTimeLogIdChange(e) {
        const target = e.target;
        this.setSubmitVoidTimeLogTimeLogId(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason */
    setSubmitVoidTimeLogVoidReason(value) {
        this.submitVoidTimeLogVoidReason = value;
        setState('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason', value);
        this.requestUpdate();
    }
    /** handler for action set.submitVoidTimeLogVoidReason — bind UI events here */
    handleSubmitVoidTimeLogVoidReasonChange(e) {
        const target = e.target;
        this.setSubmitVoidTimeLogVoidReason(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId */
    setSubmitMaterialUsageProjectId(value) {
        this.submitMaterialUsageProjectId = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageProjectId — bind UI events here */
    handleSubmitMaterialUsageProjectIdChange(e) {
        const target = e.target;
        this.setSubmitMaterialUsageProjectId(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName */
    setSubmitMaterialUsageMaterialName(value) {
        this.submitMaterialUsageMaterialName = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageMaterialName — bind UI events here */
    handleSubmitMaterialUsageMaterialNameChange(e) {
        const target = e.target;
        this.setSubmitMaterialUsageMaterialName(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity */
    setSubmitMaterialUsageQuantity(value) {
        this.submitMaterialUsageQuantity = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageQuantity — bind UI events here */
    handleSubmitMaterialUsageQuantityChange(e) {
        const target = e.target;
        this.setSubmitMaterialUsageQuantity(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit */
    setSubmitMaterialUsageUnit(value) {
        this.submitMaterialUsageUnit = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageUnit — bind UI events here */
    handleSubmitMaterialUsageUnitChange(e) {
        const target = e.target;
        this.setSubmitMaterialUsageUnit(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost */
    setSubmitMaterialUsageUnitCost(value) {
        this.submitMaterialUsageUnitCost = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageUnitCost — bind UI events here */
    handleSubmitMaterialUsageUnitCostChange(e) {
        const target = e.target;
        this.setSubmitMaterialUsageUnitCost(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode */
    setSubmitMaterialUsageCostCode(value) {
        this.submitMaterialUsageCostCode = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageCostCode — bind UI events here */
    handleSubmitMaterialUsageCostCodeChange(e) {
        const target = e.target;
        this.setSubmitMaterialUsageCostCode(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate */
    setSubmitMaterialUsageUsageDate(value) {
        this.submitMaterialUsageUsageDate = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageUsageDate — bind UI events here */
    handleSubmitMaterialUsageUsageDateChange(e) {
        const target = e.target;
        this.setSubmitMaterialUsageUsageDate(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy */
    setSubmitMaterialUsageRecordedBy(value) {
        this.submitMaterialUsageRecordedBy = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageRecordedBy — bind UI events here */
    handleSubmitMaterialUsageRecordedByChange(e) {
        const target = e.target;
        this.setSubmitMaterialUsageRecordedBy(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId */
    setSubmitVoidMaterialUsageMaterialUsageId(value) {
        this.submitVoidMaterialUsageMaterialUsageId = value;
        setState('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId', value);
        this.requestUpdate();
    }
    /** handler for action set.submitVoidMaterialUsageMaterialUsageId — bind UI events here */
    handleSubmitVoidMaterialUsageMaterialUsageIdChange(e) {
        const target = e.target;
        this.setSubmitVoidMaterialUsageMaterialUsageId(target.value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason */
    setSubmitVoidMaterialUsageVoidedReason(value) {
        this.submitVoidMaterialUsageVoidedReason = value;
        setState('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason', value);
        this.requestUpdate();
    }
    /** handler for action set.submitVoidMaterialUsageVoidedReason — bind UI events here */
    handleSubmitVoidMaterialUsageVoidedReasonChange(e) {
        const target = e.target;
        this.setSubmitVoidMaterialUsageVoidedReason(target.value);
    }
    connectedCallback() {
        super.connectedCallback();
        const savedStatus = getState('ui.fieldLoggingWorkspace.status');
        if (savedStatus !== undefined && savedStatus !== null) {
            this.status = savedStatus;
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogWorkTaskId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogLogDate", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogHoursWorked", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogWorkerName", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogError", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogTimeLogId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogVoidReason", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogError", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageProjectId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageMaterialName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageQuantity", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageUnit", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageUnitCost", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageCostCode", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageUsageDate", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageRecordedBy", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageError", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageMaterialUsageId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageVoidedReason", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageError", void 0);
