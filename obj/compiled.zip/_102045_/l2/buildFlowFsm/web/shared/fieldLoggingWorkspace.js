/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/fieldLoggingWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { submitTimeLogRoute, submitVoidTimeLogRoute, submitMaterialUsageRoute, submitVoidMaterialUsageRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/fieldLoggingWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    'section.fieldLoggingWorkspace.sec-time-logging.title': 'Time Logging',
    'organism.fieldLoggingWorkspace.submitTimeLog.title': 'Log hours worked',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.title': 'Log hours worked',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.action.submitTimeLog': 'Log hours worked',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.workTaskId.label': 'Work Task Id',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.logDate.label': 'Log Date',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.hoursWorked.label': 'Hours Worked',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.workerName.label': 'Worker Name',
    'organism.fieldLoggingWorkspace.submitVoidTimeLog.title': 'Void time log',
    'intent.fieldLoggingWorkspace.submitVoidTimeLog.form.title': 'Void time log',
    'intent.fieldLoggingWorkspace.submitVoidTimeLog.form.action.submitVoidTimeLog': 'Void time log',
    'intent.fieldLoggingWorkspace.submitVoidTimeLog.form.field.voidReason.label': 'Void Reason',
    'section.fieldLoggingWorkspace.sec-material-logging.title': 'Material Logging',
    'organism.fieldLoggingWorkspace.submitMaterialUsage.title': 'Log materials used',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.title': 'Log materials used',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.action.submitMaterialUsage': 'Log materials used',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.materialName.label': 'Material Name',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.quantity.label': 'Quantity',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unit.label': 'Unit',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unitCost.label': 'Unit Cost',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.costCode.label': 'Cost Code',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.usageDate.label': 'Usage Date',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.recordedBy.label': 'Recorded By',
    'organism.fieldLoggingWorkspace.submitVoidMaterialUsage.title': 'Void material usage',
    'intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.title': 'Void material usage',
    'intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.action.submitVoidMaterialUsage': 'Void material usage',
    'intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.field.voidedReason.label': 'Voided Reason',
    'action.submitTimeLog.success': 'Log hours worked: OK',
    'action.submitTimeLog.error': 'Log hours worked: falhou',
    'action.submitVoidTimeLog.success': 'Void time log: OK',
    'action.submitVoidTimeLog.error': 'Void time log: falhou',
    'action.submitMaterialUsage.success': 'Log materials used: OK',
    'action.submitMaterialUsage.error': 'Log materials used: falhou',
    'action.submitVoidMaterialUsage.success': 'Void material usage: OK',
    'action.submitVoidMaterialUsage.error': 'Void material usage: falhou',
};
const message_pt_br = {
    'section.fieldLoggingWorkspace.sec-time-logging.title': 'Registro de Tempo',
    'organism.fieldLoggingWorkspace.submitTimeLog.title': 'Registrar horas trabalhadas',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.title': 'Registrar horas trabalhadas',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.action.submitTimeLog': 'Registrar horas trabalhadas',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.workTaskId.label': 'ID da Tarefa de Trabalho',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.logDate.label': 'Data do Registro',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.hoursWorked.label': 'Horas Trabalhadas',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.workerName.label': 'Nome do Trabalhador',
    'organism.fieldLoggingWorkspace.submitVoidTimeLog.title': 'Anular registro de tempo',
    'intent.fieldLoggingWorkspace.submitVoidTimeLog.form.title': 'Anular registro de tempo',
    'intent.fieldLoggingWorkspace.submitVoidTimeLog.form.action.submitVoidTimeLog': 'Anular registro de tempo',
    'intent.fieldLoggingWorkspace.submitVoidTimeLog.form.field.voidReason.label': 'Motivo da Anulação',
    'section.fieldLoggingWorkspace.sec-material-logging.title': 'Registro de Materiais',
    'organism.fieldLoggingWorkspace.submitMaterialUsage.title': 'Registrar materiais usados',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.title': 'Registrar materiais usados',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.action.submitMaterialUsage': 'Registrar materiais usados',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.materialName.label': 'Nome do Material',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.quantity.label': 'Quantidade',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unit.label': 'Unidade',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unitCost.label': 'Custo Unitário',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.costCode.label': 'Código de Custo',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.usageDate.label': 'Data de Uso',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.recordedBy.label': 'Registrado Por',
    'organism.fieldLoggingWorkspace.submitVoidMaterialUsage.title': 'Anular uso de material',
    'intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.title': 'Anular uso de material',
    'intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.action.submitVoidMaterialUsage': 'Anular uso de material',
    'intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.field.voidedReason.label': 'Motivo da Anulação',
    'action.submitTimeLog.success': 'Registro de horas trabalhadas: OK',
    'action.submitTimeLog.error': 'Registro de horas trabalhadas: falhou',
    'action.submitVoidTimeLog.success': 'Anulação do registro de tempo: OK',
    'action.submitVoidTimeLog.error': 'Anulação do registro de tempo: falhou',
    'action.submitMaterialUsage.success': 'Registro de materiais usados: OK',
    'action.submitMaterialUsage.error': 'Registro de materiais usados: falhou',
    'action.submitVoidMaterialUsage.success': 'Anulação do uso de material: OK',
    'action.submitVoidMaterialUsage.error': 'Anulação do uso de material: falhou',
};
const message_es = {
    'section.fieldLoggingWorkspace.sec-time-logging.title': 'Registro de Tiempo',
    'organism.fieldLoggingWorkspace.submitTimeLog.title': 'Registrar horas trabajadas',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.title': 'Registrar horas trabajadas',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.action.submitTimeLog': 'Registrar horas trabajadas',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.workTaskId.label': 'ID de la Tarea de Trabajo',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.logDate.label': 'Fecha del Registro',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.hoursWorked.label': 'Horas Trabajadas',
    'intent.fieldLoggingWorkspace.submitTimeLog.form.field.workerName.label': 'Nombre del Trabajador',
    'organism.fieldLoggingWorkspace.submitVoidTimeLog.title': 'Anular registro de tiempo',
    'intent.fieldLoggingWorkspace.submitVoidTimeLog.form.title': 'Anular registro de tiempo',
    'intent.fieldLoggingWorkspace.submitVoidTimeLog.form.action.submitVoidTimeLog': 'Anular registro de tiempo',
    'intent.fieldLoggingWorkspace.submitVoidTimeLog.form.field.voidReason.label': 'Motivo de la Anulación',
    'section.fieldLoggingWorkspace.sec-material-logging.title': 'Registro de Materiales',
    'organism.fieldLoggingWorkspace.submitMaterialUsage.title': 'Registrar materiales usados',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.title': 'Registrar materiales usados',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.action.submitMaterialUsage': 'Registrar materiales usados',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.materialName.label': 'Nombre del Material',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.quantity.label': 'Cantidad',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unit.label': 'Unidad',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.unitCost.label': 'Costo Unitario',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.costCode.label': 'Código de Costo',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.usageDate.label': 'Fecha de Uso',
    'intent.fieldLoggingWorkspace.submitMaterialUsage.form.field.recordedBy.label': 'Registrado Por',
    'organism.fieldLoggingWorkspace.submitVoidMaterialUsage.title': 'Anular uso de material',
    'intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.title': 'Anular uso de material',
    'intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.action.submitVoidMaterialUsage': 'Anular uso de material',
    'intent.fieldLoggingWorkspace.submitVoidMaterialUsage.form.field.voidedReason.label': 'Motivo de la Anulación',
    'action.submitTimeLog.success': 'Registro de horas trabajadas: OK',
    'action.submitTimeLog.error': 'Registro de horas trabajadas: falló',
    'action.submitVoidTimeLog.success': 'Anulación del registro de tiempo: OK',
    'action.submitVoidTimeLog.error': 'Anulación del registro de tiempo: falló',
    'action.submitMaterialUsage.success': 'Registro de materiales usados: OK',
    'action.submitMaterialUsage.error': 'Registro de materiales usados: falló',
    'action.submitVoidMaterialUsage.success': 'Anulación del uso de material: OK',
    'action.submitVoidMaterialUsage.error': 'Anulación del uso de material: falló',
};
export const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.fieldLoggingWorkspace.status',
    'ui.fieldLoggingWorkspace.action.submitTimeLog.status',
    'ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId',
    'ui.fieldLoggingWorkspace.input.submitTimeLog.logDate',
    'ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked',
    'ui.fieldLoggingWorkspace.input.submitTimeLog.workerName',
    'ui.fieldLoggingWorkspace.output.submitTimeLog',
    'ui.fieldLoggingWorkspace.action.submitTimeLog.error',
    'ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status',
    'ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId',
    'ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason',
    'ui.fieldLoggingWorkspace.output.submitVoidTimeLog',
    'ui.fieldLoggingWorkspace.action.submitVoidTimeLog.error',
    'ui.fieldLoggingWorkspace.action.submitMaterialUsage.status',
    'ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId',
    'ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName',
    'ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity',
    'ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit',
    'ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost',
    'ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode',
    'ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate',
    'ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy',
    'ui.fieldLoggingWorkspace.output.submitMaterialUsage',
    'ui.fieldLoggingWorkspace.action.submitMaterialUsage.error',
    'ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status',
    'ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId',
    'ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason',
    'ui.fieldLoggingWorkspace.output.submitVoidMaterialUsage',
    'ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.error',
];
export class BuildFlowFsmFieldLoggingWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state submitTimeLogState — actionStatus, values: idle|loading|success|error */
        this.submitTimeLogState = 'idle';
        /** state submitTimeLogWorkTaskId — input */
        this.submitTimeLogWorkTaskId = '';
        /** state submitTimeLogLogDate — input */
        this.submitTimeLogLogDate = '';
        /** state submitTimeLogHoursWorked — input */
        this.submitTimeLogHoursWorked = '';
        /** state submitTimeLogWorkerName — input */
        this.submitTimeLogWorkerName = '';
        /** state submitTimeLogOutput — commandOutput */
        this.submitTimeLogOutput = null;
        /** state submitTimeLogError — actionError */
        this.submitTimeLogError = '';
        /** state submitVoidTimeLogState — actionStatus, values: idle|loading|success|error */
        this.submitVoidTimeLogState = 'idle';
        /** state submitVoidTimeLogTimeLogId — input */
        this.submitVoidTimeLogTimeLogId = '';
        /** state submitVoidTimeLogVoidReason — input */
        this.submitVoidTimeLogVoidReason = '';
        /** state submitVoidTimeLogOutput — commandOutput */
        this.submitVoidTimeLogOutput = null;
        /** state submitVoidTimeLogError — actionError */
        this.submitVoidTimeLogError = '';
        /** state submitMaterialUsageState — actionStatus, values: idle|loading|success|error */
        this.submitMaterialUsageState = 'idle';
        /** state submitMaterialUsageProjectId — input */
        this.submitMaterialUsageProjectId = '';
        /** state submitMaterialUsageMaterialName — input */
        this.submitMaterialUsageMaterialName = '';
        /** state submitMaterialUsageQuantity — input */
        this.submitMaterialUsageQuantity = '';
        /** state submitMaterialUsageUnit — input */
        this.submitMaterialUsageUnit = '';
        /** state submitMaterialUsageUnitCost — input */
        this.submitMaterialUsageUnitCost = '';
        /** state submitMaterialUsageCostCode — input */
        this.submitMaterialUsageCostCode = '';
        /** state submitMaterialUsageUsageDate — input */
        this.submitMaterialUsageUsageDate = '';
        /** state submitMaterialUsageRecordedBy — input */
        this.submitMaterialUsageRecordedBy = '';
        /** state submitMaterialUsageOutput — commandOutput */
        this.submitMaterialUsageOutput = null;
        /** state submitMaterialUsageError — actionError */
        this.submitMaterialUsageError = '';
        /** state submitVoidMaterialUsageState — actionStatus, values: idle|loading|success|error */
        this.submitVoidMaterialUsageState = 'idle';
        /** state submitVoidMaterialUsageMaterialUsageId — input */
        this.submitVoidMaterialUsageMaterialUsageId = '';
        /** state submitVoidMaterialUsageVoidedReason — input */
        this.submitVoidMaterialUsageVoidedReason = '';
        /** state submitVoidMaterialUsageOutput — commandOutput */
        this.submitVoidMaterialUsageOutput = null;
        /** state submitVoidMaterialUsageError — actionError */
        this.submitVoidMaterialUsageError = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.fieldLoggingWorkspace.status', '');
        this.initStateValue('ui.fieldLoggingWorkspace.action.submitTimeLog.status', 'idle');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitTimeLog.logDate', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitTimeLog.workerName', '');
        this.initStateValue('ui.fieldLoggingWorkspace.output.submitTimeLog', null);
        this.initStateValue('ui.fieldLoggingWorkspace.action.submitTimeLog.error', '');
        this.initStateValue('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status', 'idle');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason', '');
        this.initStateValue('ui.fieldLoggingWorkspace.output.submitVoidTimeLog', null);
        this.initStateValue('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.error', '');
        this.initStateValue('ui.fieldLoggingWorkspace.action.submitMaterialUsage.status', 'idle');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy', '');
        this.initStateValue('ui.fieldLoggingWorkspace.output.submitMaterialUsage', null);
        this.initStateValue('ui.fieldLoggingWorkspace.action.submitMaterialUsage.error', '');
        this.initStateValue('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status', 'idle');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId', '');
        this.initStateValue('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason', '');
        this.initStateValue('ui.fieldLoggingWorkspace.output.submitVoidMaterialUsage', null);
        this.initStateValue('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.error', '');
        subscribe(SUBSCRIBED_STATE_KEYS, this);
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.fieldLoggingWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.action.submitTimeLog.status':
                this.submitTimeLogState = value ?? 'idle';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId':
                this.submitTimeLogWorkTaskId = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitTimeLog.logDate':
                this.submitTimeLogLogDate = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked':
                this.submitTimeLogHoursWorked = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitTimeLog.workerName':
                this.submitTimeLogWorkerName = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.output.submitTimeLog':
                this.submitTimeLogOutput = value ?? null;
                break;
            case 'ui.fieldLoggingWorkspace.action.submitTimeLog.error':
                this.submitTimeLogError = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status':
                this.submitVoidTimeLogState = value ?? 'idle';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId':
                this.submitVoidTimeLogTimeLogId = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason':
                this.submitVoidTimeLogVoidReason = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.output.submitVoidTimeLog':
                this.submitVoidTimeLogOutput = value ?? null;
                break;
            case 'ui.fieldLoggingWorkspace.action.submitVoidTimeLog.error':
                this.submitVoidTimeLogError = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.action.submitMaterialUsage.status':
                this.submitMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId':
                this.submitMaterialUsageProjectId = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName':
                this.submitMaterialUsageMaterialName = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity':
                this.submitMaterialUsageQuantity = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit':
                this.submitMaterialUsageUnit = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost':
                this.submitMaterialUsageUnitCost = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode':
                this.submitMaterialUsageCostCode = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate':
                this.submitMaterialUsageUsageDate = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy':
                this.submitMaterialUsageRecordedBy = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.output.submitMaterialUsage':
                this.submitMaterialUsageOutput = value ?? null;
                break;
            case 'ui.fieldLoggingWorkspace.action.submitMaterialUsage.error':
                this.submitMaterialUsageError = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status':
                this.submitVoidMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId':
                this.submitVoidMaterialUsageMaterialUsageId = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason':
                this.submitVoidMaterialUsageVoidedReason = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.output.submitVoidMaterialUsage':
                this.submitVoidMaterialUsageOutput = value ?? null;
                break;
            case 'ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.error':
                this.submitVoidMaterialUsageError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.fieldLoggingWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.action.submitTimeLog.status':
                this.submitTimeLogState = value ?? 'idle';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId':
                this.submitTimeLogWorkTaskId = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitTimeLog.logDate':
                this.submitTimeLogLogDate = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked':
                this.submitTimeLogHoursWorked = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitTimeLog.workerName':
                this.submitTimeLogWorkerName = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.output.submitTimeLog':
                this.submitTimeLogOutput = value ?? null;
                break;
            case 'ui.fieldLoggingWorkspace.action.submitTimeLog.error':
                this.submitTimeLogError = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status':
                this.submitVoidTimeLogState = value ?? 'idle';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId':
                this.submitVoidTimeLogTimeLogId = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason':
                this.submitVoidTimeLogVoidReason = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.output.submitVoidTimeLog':
                this.submitVoidTimeLogOutput = value ?? null;
                break;
            case 'ui.fieldLoggingWorkspace.action.submitVoidTimeLog.error':
                this.submitVoidTimeLogError = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.action.submitMaterialUsage.status':
                this.submitMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId':
                this.submitMaterialUsageProjectId = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName':
                this.submitMaterialUsageMaterialName = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity':
                this.submitMaterialUsageQuantity = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit':
                this.submitMaterialUsageUnit = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost':
                this.submitMaterialUsageUnitCost = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode':
                this.submitMaterialUsageCostCode = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate':
                this.submitMaterialUsageUsageDate = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy':
                this.submitMaterialUsageRecordedBy = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.output.submitMaterialUsage':
                this.submitMaterialUsageOutput = value ?? null;
                break;
            case 'ui.fieldLoggingWorkspace.action.submitMaterialUsage.error':
                this.submitMaterialUsageError = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status':
                this.submitVoidMaterialUsageState = value ?? 'idle';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId':
                this.submitVoidMaterialUsageMaterialUsageId = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason':
                this.submitVoidMaterialUsageVoidedReason = value ?? '';
                break;
            case 'ui.fieldLoggingWorkspace.output.submitVoidMaterialUsage':
                this.submitVoidMaterialUsageOutput = value ?? null;
                break;
            case 'ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.error':
                this.submitVoidMaterialUsageError = value ?? '';
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action submitTimeLog (command) — route buildFlowFsm.fieldLoggingWorkspace.submitTimeLog; inputs: workTaskId, logDate, hoursWorked, workerName; writes ui.fieldLoggingWorkspace.output.submitTimeLog; status ui.fieldLoggingWorkspace.action.submitTimeLog.status; feedback keys action.submitTimeLog.success / action.submitTimeLog.error */
    async submitTimeLog() {
        this.submitTimeLogState = 'loading';
        setState('ui.fieldLoggingWorkspace.action.submitTimeLog.status', 'loading');
        this.submitTimeLogError = '';
        setState('ui.fieldLoggingWorkspace.action.submitTimeLog.error', '');
        const hoursWorkedNum = Number(this.submitTimeLogHoursWorked);
        const params = {
            workTaskId: this.submitTimeLogWorkTaskId,
            logDate: this.submitTimeLogLogDate,
            hoursWorked: Number.isNaN(hoursWorkedNum) ? 0 : hoursWorkedNum,
            workerName: this.submitTimeLogWorkerName,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(submitTimeLogRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.submitTimeLog.error');
            this.submitTimeLogError = errMsg;
            setState('ui.fieldLoggingWorkspace.action.submitTimeLog.error', errMsg);
            this.submitTimeLogState = 'error';
            setState('ui.fieldLoggingWorkspace.action.submitTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.submitTimeLogOutput = data;
        setState('ui.fieldLoggingWorkspace.output.submitTimeLog', data);
        this.submitTimeLogWorkTaskId = '';
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId', '');
        this.submitTimeLogLogDate = '';
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.logDate', '');
        this.submitTimeLogHoursWorked = '';
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked', '');
        this.submitTimeLogWorkerName = '';
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.workerName', '');
        this.submitTimeLogState = 'success';
        setState('ui.fieldLoggingWorkspace.action.submitTimeLog.status', 'success');
        this.requestUpdate();
    }
    /** handler for action submitTimeLog — bind UI events here */
    handleSubmitTimeLogClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.submitTimeLog();
        });
    }
    /** action submitVoidTimeLog (command) — route buildFlowFsm.fieldLoggingWorkspace.submitVoidTimeLog; inputs: timeLogId, voidReason; writes ui.fieldLoggingWorkspace.output.submitVoidTimeLog; status ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status; feedback keys action.submitVoidTimeLog.success / action.submitVoidTimeLog.error */
    async submitVoidTimeLog() {
        if (!this.submitVoidTimeLogTimeLogId) {
            this.submitVoidTimeLogState = 'idle';
            setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.submitVoidTimeLogState = 'loading';
        setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status', 'loading');
        this.submitVoidTimeLogError = '';
        setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.error', '');
        const params = {
            timeLogId: this.submitVoidTimeLogTimeLogId,
            voidReason: this.submitVoidTimeLogVoidReason,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(submitVoidTimeLogRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.submitVoidTimeLog.error');
            this.submitVoidTimeLogError = errMsg;
            setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.error', errMsg);
            this.submitVoidTimeLogState = 'error';
            setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.submitVoidTimeLogOutput = data;
        setState('ui.fieldLoggingWorkspace.output.submitVoidTimeLog', data);
        this.submitVoidTimeLogTimeLogId = '';
        setState('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId', '');
        this.submitVoidTimeLogVoidReason = '';
        setState('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason', '');
        this.submitVoidTimeLogState = 'success';
        setState('ui.fieldLoggingWorkspace.action.submitVoidTimeLog.status', 'success');
        this.requestUpdate();
    }
    /** handler for action submitVoidTimeLog — bind UI events here */
    handleSubmitVoidTimeLogClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.submitVoidTimeLog();
        });
    }
    /** action submitMaterialUsage (command) — route buildFlowFsm.fieldLoggingWorkspace.submitMaterialUsage; inputs: projectId, materialName, quantity, unit, unitCost, costCode, usageDate, recordedBy; writes ui.fieldLoggingWorkspace.output.submitMaterialUsage; status ui.fieldLoggingWorkspace.action.submitMaterialUsage.status; feedback keys action.submitMaterialUsage.success / action.submitMaterialUsage.error */
    async submitMaterialUsage() {
        if (!this.submitMaterialUsageProjectId) {
            this.submitMaterialUsageState = 'idle';
            setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.submitMaterialUsageState = 'loading';
        setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.status', 'loading');
        this.submitMaterialUsageError = '';
        setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.error', '');
        const quantityNum = Number(this.submitMaterialUsageQuantity);
        const unitCostNum = Number(this.submitMaterialUsageUnitCost);
        const params = {
            projectId: this.submitMaterialUsageProjectId,
            materialName: this.submitMaterialUsageMaterialName,
            quantity: Number.isNaN(quantityNum) ? 0 : quantityNum,
            unit: this.submitMaterialUsageUnit,
            unitCost: Number.isNaN(unitCostNum) ? 0 : unitCostNum,
            usageDate: this.submitMaterialUsageUsageDate,
            recordedBy: this.submitMaterialUsageRecordedBy,
        };
        if (this.submitMaterialUsageCostCode) {
            params.costCode = this.submitMaterialUsageCostCode;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(submitMaterialUsageRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.submitMaterialUsage.error');
            this.submitMaterialUsageError = errMsg;
            setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.error', errMsg);
            this.submitMaterialUsageState = 'error';
            setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.submitMaterialUsageOutput = data;
        setState('ui.fieldLoggingWorkspace.output.submitMaterialUsage', data);
        this.submitMaterialUsageProjectId = '';
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId', '');
        this.submitMaterialUsageMaterialName = '';
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName', '');
        this.submitMaterialUsageQuantity = '';
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity', '');
        this.submitMaterialUsageUnit = '';
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit', '');
        this.submitMaterialUsageUnitCost = '';
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost', '');
        this.submitMaterialUsageCostCode = '';
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode', '');
        this.submitMaterialUsageUsageDate = '';
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate', '');
        this.submitMaterialUsageRecordedBy = '';
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy', '');
        this.submitMaterialUsageState = 'success';
        setState('ui.fieldLoggingWorkspace.action.submitMaterialUsage.status', 'success');
        this.requestUpdate();
    }
    /** handler for action submitMaterialUsage — bind UI events here */
    handleSubmitMaterialUsageClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.submitMaterialUsage();
        });
    }
    /** action submitVoidMaterialUsage (command) — route buildFlowFsm.fieldLoggingWorkspace.submitVoidMaterialUsage; inputs: materialUsageId, voidedReason; writes ui.fieldLoggingWorkspace.output.submitVoidMaterialUsage; status ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status; feedback keys action.submitVoidMaterialUsage.success / action.submitVoidMaterialUsage.error */
    async submitVoidMaterialUsage() {
        if (!this.submitVoidMaterialUsageMaterialUsageId) {
            this.submitVoidMaterialUsageState = 'idle';
            setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.submitVoidMaterialUsageState = 'loading';
        setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status', 'loading');
        this.submitVoidMaterialUsageError = '';
        setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.error', '');
        const params = {
            materialUsageId: this.submitVoidMaterialUsageMaterialUsageId,
            voidedReason: this.submitVoidMaterialUsageVoidedReason,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(submitVoidMaterialUsageRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.submitVoidMaterialUsage.error');
            this.submitVoidMaterialUsageError = errMsg;
            setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.error', errMsg);
            this.submitVoidMaterialUsageState = 'error';
            setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.submitVoidMaterialUsageOutput = data;
        setState('ui.fieldLoggingWorkspace.output.submitVoidMaterialUsage', data);
        this.submitVoidMaterialUsageMaterialUsageId = '';
        setState('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId', '');
        this.submitVoidMaterialUsageVoidedReason = '';
        setState('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason', '');
        this.submitVoidMaterialUsageState = 'success';
        setState('ui.fieldLoggingWorkspace.action.submitVoidMaterialUsage.status', 'success');
        this.requestUpdate();
    }
    /** handler for action submitVoidMaterialUsage — bind UI events here */
    handleSubmitVoidMaterialUsageClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.submitVoidMaterialUsage();
        });
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId */
    setSubmitTimeLogWorkTaskId(value) {
        this.submitTimeLogWorkTaskId = value;
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.workTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.submitTimeLogWorkTaskId — bind UI events here */
    handleSubmitTimeLogWorkTaskIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitTimeLogWorkTaskId(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitTimeLog.logDate */
    setSubmitTimeLogLogDate(value) {
        this.submitTimeLogLogDate = value;
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.logDate', value);
        this.requestUpdate();
    }
    /** handler for action set.submitTimeLogLogDate — bind UI events here */
    handleSubmitTimeLogLogDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitTimeLogLogDate(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked */
    setSubmitTimeLogHoursWorked(value) {
        this.submitTimeLogHoursWorked = value;
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.hoursWorked', value);
        this.requestUpdate();
    }
    /** handler for action set.submitTimeLogHoursWorked — bind UI events here */
    handleSubmitTimeLogHoursWorkedChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitTimeLogHoursWorked(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitTimeLog.workerName */
    setSubmitTimeLogWorkerName(value) {
        this.submitTimeLogWorkerName = value;
        setState('ui.fieldLoggingWorkspace.input.submitTimeLog.workerName', value);
        this.requestUpdate();
    }
    /** handler for action set.submitTimeLogWorkerName — bind UI events here */
    handleSubmitTimeLogWorkerNameChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitTimeLogWorkerName(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId */
    setSubmitVoidTimeLogTimeLogId(value) {
        this.submitVoidTimeLogTimeLogId = value;
        setState('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.timeLogId', value);
        this.requestUpdate();
    }
    /** handler for action set.submitVoidTimeLogTimeLogId — bind UI events here */
    handleSubmitVoidTimeLogTimeLogIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitVoidTimeLogTimeLogId(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason */
    setSubmitVoidTimeLogVoidReason(value) {
        this.submitVoidTimeLogVoidReason = value;
        setState('ui.fieldLoggingWorkspace.input.submitVoidTimeLog.voidReason', value);
        this.requestUpdate();
    }
    /** handler for action set.submitVoidTimeLogVoidReason — bind UI events here */
    handleSubmitVoidTimeLogVoidReasonChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitVoidTimeLogVoidReason(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId */
    setSubmitMaterialUsageProjectId(value) {
        this.submitMaterialUsageProjectId = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageProjectId — bind UI events here */
    handleSubmitMaterialUsageProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitMaterialUsageProjectId(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName */
    setSubmitMaterialUsageMaterialName(value) {
        this.submitMaterialUsageMaterialName = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.materialName', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageMaterialName — bind UI events here */
    handleSubmitMaterialUsageMaterialNameChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitMaterialUsageMaterialName(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity */
    setSubmitMaterialUsageQuantity(value) {
        this.submitMaterialUsageQuantity = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.quantity', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageQuantity — bind UI events here */
    handleSubmitMaterialUsageQuantityChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitMaterialUsageQuantity(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit */
    setSubmitMaterialUsageUnit(value) {
        this.submitMaterialUsageUnit = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unit', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageUnit — bind UI events here */
    handleSubmitMaterialUsageUnitChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitMaterialUsageUnit(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost */
    setSubmitMaterialUsageUnitCost(value) {
        this.submitMaterialUsageUnitCost = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.unitCost', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageUnitCost — bind UI events here */
    handleSubmitMaterialUsageUnitCostChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitMaterialUsageUnitCost(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode */
    setSubmitMaterialUsageCostCode(value) {
        this.submitMaterialUsageCostCode = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.costCode', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageCostCode — bind UI events here */
    handleSubmitMaterialUsageCostCodeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitMaterialUsageCostCode(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate */
    setSubmitMaterialUsageUsageDate(value) {
        this.submitMaterialUsageUsageDate = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.usageDate', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageUsageDate — bind UI events here */
    handleSubmitMaterialUsageUsageDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitMaterialUsageUsageDate(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy */
    setSubmitMaterialUsageRecordedBy(value) {
        this.submitMaterialUsageRecordedBy = value;
        setState('ui.fieldLoggingWorkspace.input.submitMaterialUsage.recordedBy', value);
        this.requestUpdate();
    }
    /** handler for action set.submitMaterialUsageRecordedBy — bind UI events here */
    handleSubmitMaterialUsageRecordedByChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitMaterialUsageRecordedBy(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId */
    setSubmitVoidMaterialUsageMaterialUsageId(value) {
        this.submitVoidMaterialUsageMaterialUsageId = value;
        setState('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.materialUsageId', value);
        this.requestUpdate();
    }
    /** handler for action set.submitVoidMaterialUsageMaterialUsageId — bind UI events here */
    handleSubmitVoidMaterialUsageMaterialUsageIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitVoidMaterialUsageMaterialUsageId(value);
    }
    /** setter for state ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason */
    setSubmitVoidMaterialUsageVoidedReason(value) {
        this.submitVoidMaterialUsageVoidedReason = value;
        setState('ui.fieldLoggingWorkspace.input.submitVoidMaterialUsage.voidedReason', value);
        this.requestUpdate();
    }
    /** handler for action set.submitVoidMaterialUsageVoidedReason — bind UI events here */
    handleSubmitVoidMaterialUsageVoidedReasonChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSubmitVoidMaterialUsageVoidedReason(value);
    }
}
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogState", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogLogDate", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogHoursWorked", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogWorkerName", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogOutput", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitTimeLogError", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogState", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogTimeLogId", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogVoidReason", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogOutput", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidTimeLogError", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageState", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageMaterialName", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageQuantity", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageUnit", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageUnitCost", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageCostCode", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageUsageDate", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageRecordedBy", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageOutput", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitMaterialUsageError", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageState", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageMaterialUsageId", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageVoidedReason", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageOutput", void 0);
__decorate([
    property()
], BuildFlowFsmFieldLoggingWorkspaceBase.prototype, "submitVoidMaterialUsageError", void 0);
