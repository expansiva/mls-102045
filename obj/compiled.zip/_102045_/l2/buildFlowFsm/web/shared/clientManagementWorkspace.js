/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/clientManagementWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { listClientsRoute, createClientCmdRoute, updateClientCmdRoute, deleteClientCmdRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/clientManagementWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    "section.clientManagementWorkspace.clientListSection.title": "Client Directory",
    "organism.clientManagementWorkspace.listClients.title": "Browse clients",
    "intent.clientManagementWorkspace.listClients.list.title": "Browse clients",
    "intent.clientManagementWorkspace.listClients.list.empty": "Nenhum registro encontrado",
    "intent.clientManagementWorkspace.listClients.list.column.clients.label": "Clients",
    "intent.clientManagementWorkspace.listClients.list.column.total.label": "Total",
    "intent.clientManagementWorkspace.listClients.list.filter.name.label": "Name",
    "intent.clientManagementWorkspace.listClients.list.filter.company.label": "Company",
    "intent.clientManagementWorkspace.listClients.list.filter.email.label": "Email",
    "intent.clientManagementWorkspace.listClients.list.filter.page.label": "Page",
    "intent.clientManagementWorkspace.listClients.list.filter.pageSize.label": "Page Size",
    "organism.clientManagementWorkspace.createClientCmd.title": "Create client",
    "intent.clientManagementWorkspace.createClientCmd.form.title": "Create client",
    "intent.clientManagementWorkspace.createClientCmd.form.action.createClientCmd": "Create client",
    "intent.clientManagementWorkspace.createClientCmd.form.field.name.label": "Name",
    "intent.clientManagementWorkspace.createClientCmd.form.field.email.label": "Email",
    "intent.clientManagementWorkspace.createClientCmd.form.field.company.label": "Company",
    "intent.clientManagementWorkspace.createClientCmd.form.field.phone.label": "Phone",
    "intent.clientManagementWorkspace.createClientCmd.form.field.address.label": "Address",
    "organism.clientManagementWorkspace.updateClientCmd.title": "Update client",
    "intent.clientManagementWorkspace.updateClientCmd.form.title": "Update client",
    "intent.clientManagementWorkspace.updateClientCmd.form.action.updateClientCmd": "Update client",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.name.label": "Name",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.company.label": "Company",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.email.label": "Email",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.phone.label": "Phone",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.address.label": "Address",
    "organism.clientManagementWorkspace.deleteClientCmd.title": "Delete client",
    "intent.clientManagementWorkspace.deleteClientCmd.form.title": "Delete client",
    "intent.clientManagementWorkspace.deleteClientCmd.form.action.deleteClientCmd": "Delete client",
    "organism.clientManagementWorkspace.summary-first10.title": "Summary first",
    "intent.clientManagementWorkspace.summary-first10.content.title": "Summary first"
};
const message_pt_br = {
    "section.clientManagementWorkspace.clientListSection.title": "Diretório de Clientes",
    "organism.clientManagementWorkspace.listClients.title": "Navegar clientes",
    "intent.clientManagementWorkspace.listClients.list.title": "Navegar clientes",
    "intent.clientManagementWorkspace.listClients.list.empty": "Nenhum registro encontrado",
    "intent.clientManagementWorkspace.listClients.list.column.clients.label": "Clientes",
    "intent.clientManagementWorkspace.listClients.list.column.total.label": "Total",
    "intent.clientManagementWorkspace.listClients.list.filter.name.label": "Nome",
    "intent.clientManagementWorkspace.listClients.list.filter.company.label": "Empresa",
    "intent.clientManagementWorkspace.listClients.list.filter.email.label": "Email",
    "intent.clientManagementWorkspace.listClients.list.filter.page.label": "Página",
    "intent.clientManagementWorkspace.listClients.list.filter.pageSize.label": "Tamanho da página",
    "organism.clientManagementWorkspace.createClientCmd.title": "Criar cliente",
    "intent.clientManagementWorkspace.createClientCmd.form.title": "Criar cliente",
    "intent.clientManagementWorkspace.createClientCmd.form.action.createClientCmd": "Criar cliente",
    "intent.clientManagementWorkspace.createClientCmd.form.field.name.label": "Nome",
    "intent.clientManagementWorkspace.createClientCmd.form.field.email.label": "Email",
    "intent.clientManagementWorkspace.createClientCmd.form.field.company.label": "Empresa",
    "intent.clientManagementWorkspace.createClientCmd.form.field.phone.label": "Telefone",
    "intent.clientManagementWorkspace.createClientCmd.form.field.address.label": "Endereço",
    "organism.clientManagementWorkspace.updateClientCmd.title": "Atualizar cliente",
    "intent.clientManagementWorkspace.updateClientCmd.form.title": "Atualizar cliente",
    "intent.clientManagementWorkspace.updateClientCmd.form.action.updateClientCmd": "Atualizar cliente",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.name.label": "Nome",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.company.label": "Empresa",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.email.label": "Email",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.phone.label": "Telefone",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.address.label": "Endereço",
    "organism.clientManagementWorkspace.deleteClientCmd.title": "Excluir cliente",
    "intent.clientManagementWorkspace.deleteClientCmd.form.title": "Excluir cliente",
    "intent.clientManagementWorkspace.deleteClientCmd.form.action.deleteClientCmd": "Excluir cliente",
    "organism.clientManagementWorkspace.summary-first10.title": "Resumo inicial",
    "intent.clientManagementWorkspace.summary-first10.content.title": "Resumo inicial"
};
const message_es = {
    "section.clientManagementWorkspace.clientListSection.title": "Directorio de Clientes",
    "organism.clientManagementWorkspace.listClients.title": "Explorar clientes",
    "intent.clientManagementWorkspace.listClients.list.title": "Explorar clientes",
    "intent.clientManagementWorkspace.listClients.list.empty": "No se encontraron registros",
    "intent.clientManagementWorkspace.listClients.list.column.clients.label": "Clientes",
    "intent.clientManagementWorkspace.listClients.list.column.total.label": "Total",
    "intent.clientManagementWorkspace.listClients.list.filter.name.label": "Nombre",
    "intent.clientManagementWorkspace.listClients.list.filter.company.label": "Empresa",
    "intent.clientManagementWorkspace.listClients.list.filter.email.label": "Correo electrónico",
    "intent.clientManagementWorkspace.listClients.list.filter.page.label": "Página",
    "intent.clientManagementWorkspace.listClients.list.filter.pageSize.label": "Tamaño de página",
    "organism.clientManagementWorkspace.createClientCmd.title": "Crear cliente",
    "intent.clientManagementWorkspace.createClientCmd.form.title": "Crear cliente",
    "intent.clientManagementWorkspace.createClientCmd.form.action.createClientCmd": "Crear cliente",
    "intent.clientManagementWorkspace.createClientCmd.form.field.name.label": "Nombre",
    "intent.clientManagementWorkspace.createClientCmd.form.field.email.label": "Correo electrónico",
    "intent.clientManagementWorkspace.createClientCmd.form.field.company.label": "Empresa",
    "intent.clientManagementWorkspace.createClientCmd.form.field.phone.label": "Teléfono",
    "intent.clientManagementWorkspace.createClientCmd.form.field.address.label": "Dirección",
    "organism.clientManagementWorkspace.updateClientCmd.title": "Actualizar cliente",
    "intent.clientManagementWorkspace.updateClientCmd.form.title": "Actualizar cliente",
    "intent.clientManagementWorkspace.updateClientCmd.form.action.updateClientCmd": "Actualizar cliente",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.name.label": "Nombre",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.company.label": "Empresa",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.email.label": "Correo electrónico",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.phone.label": "Teléfono",
    "intent.clientManagementWorkspace.updateClientCmd.form.field.address.label": "Dirección",
    "organism.clientManagementWorkspace.deleteClientCmd.title": "Eliminar cliente",
    "intent.clientManagementWorkspace.deleteClientCmd.form.title": "Eliminar cliente",
    "intent.clientManagementWorkspace.deleteClientCmd.form.action.deleteClientCmd": "Eliminar cliente",
    "organism.clientManagementWorkspace.summary-first10.title": "Resumen inicial",
    "intent.clientManagementWorkspace.summary-first10.content.title": "Resumen inicial"
};
const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
export class BuildFlowFsmClientManagementWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state listClientsState — actionStatus, values: idle|loading|success|error */
        this.listClientsState = 'idle';
        /** state listClientsName — input */
        this.listClientsName = '';
        /** state listClientsCompany — input */
        this.listClientsCompany = '';
        /** state listClientsEmail — input */
        this.listClientsEmail = '';
        /** state listClientsPage — input */
        this.listClientsPage = '';
        /** state listClientsPageSize — input */
        this.listClientsPageSize = '';
        /** state listClientsData — queryResult, outputShape: paginated */
        this.listClientsData = { clients: [], total: 0 };
        /** state createClientCmdState — actionStatus, values: idle|loading|success|error */
        this.createClientCmdState = 'idle';
        /** state createClientCmdName — input */
        this.createClientCmdName = '';
        /** state createClientCmdEmail — input */
        this.createClientCmdEmail = '';
        /** state createClientCmdCompany — input */
        this.createClientCmdCompany = '';
        /** state createClientCmdPhone — input */
        this.createClientCmdPhone = '';
        /** state createClientCmdAddress — input */
        this.createClientCmdAddress = '';
        /** state createClientCmdOutput — commandOutput */
        this.createClientCmdOutput = null;
        /** state createClientCmdError — actionError */
        this.createClientCmdError = '';
        /** state updateClientCmdState — actionStatus, values: idle|loading|success|error */
        this.updateClientCmdState = 'idle';
        /** state updateClientCmdClientId — input, presentation: route */
        this.updateClientCmdClientId = '';
        /** state updateClientCmdName — input */
        this.updateClientCmdName = '';
        /** state updateClientCmdCompany — input */
        this.updateClientCmdCompany = '';
        /** state updateClientCmdEmail — input */
        this.updateClientCmdEmail = '';
        /** state updateClientCmdPhone — input */
        this.updateClientCmdPhone = '';
        /** state updateClientCmdAddress — input */
        this.updateClientCmdAddress = '';
        /** state updateClientCmdOutput — commandOutput */
        this.updateClientCmdOutput = null;
        /** state updateClientCmdError — actionError */
        this.updateClientCmdError = '';
        /** state deleteClientCmdState — actionStatus, values: idle|loading|success|error */
        this.deleteClientCmdState = 'idle';
        /** state deleteClientCmdClientId — input, presentation: selection */
        this.deleteClientCmdClientId = '';
        /** state deleteClientCmdOutput — commandOutput */
        this.deleteClientCmdOutput = null;
        /** state deleteClientCmdError — actionError */
        this.deleteClientCmdError = '';
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    /**
     * Parse the route pattern against the current URL pathname and return
     * extracted route parameters as a key/value record.
     */
    parseRouteParams() {
        const pattern = '/buildFlowFsm/clientManagementWorkspace/:clientId?';
        const path = window.location.pathname;
        const patternParts = pattern.split('/').filter(Boolean);
        const pathParts = path.split('/').filter(Boolean);
        const result = {};
        for (let i = 0; i < patternParts.length; i++) {
            const pPart = patternParts[i];
            if (pPart.startsWith(':')) {
                const paramName = pPart.replace(':', '').replace('?', '');
                if (pathParts[i]) {
                    result[paramName] = decodeURIComponent(pathParts[i]);
                }
            }
        }
        return result;
    }
    /** action listClients (query) — route buildFlowFsm.clientManagementWorkspace.listClients; inputs: name, company, email, page, pageSize; writes listClientsData; status listClientsState */
    async loadListClients() {
        this.listClientsState = 'loading';
        setState('ui.clientManagementWorkspace.action.listClients.status', 'loading');
        const params = {
            name: this.listClientsName || undefined,
            company: this.listClientsCompany || undefined,
            email: this.listClientsEmail || undefined,
            page: this.listClientsPage ? Number(this.listClientsPage) : undefined,
            pageSize: this.listClientsPageSize ? Number(this.listClientsPageSize) : undefined,
        };
        const options = { mode: 'silent' };
        const response = await execBff(listClientsRoute, params, options);
        if (response.ok) {
            const data = response.data ?? { clients: [], total: 0 };
            this.listClientsData = data;
            setState('ui.clientManagementWorkspace.data.listClients', data);
            this.listClientsState = 'success';
            setState('ui.clientManagementWorkspace.action.listClients.status', 'success');
        }
        else {
            this.listClientsState = 'error';
            setState('ui.clientManagementWorkspace.action.listClients.status', 'error');
        }
    }
    /** handler for action listClients — bind UI events here */
    handleListClientsClick() {
        this.loadListClients();
    }
    /** action createClientCmd (command) — route buildFlowFsm.clientManagementWorkspace.createClientCmd; inputs: name, email, company, phone, address; writes createClientCmdOutput; status createClientCmdState; feedback keys action.createClientCmd.success / action.createClientCmd.error */
    async createClientCmd(signal) {
        this.createClientCmdState = 'loading';
        setState('ui.clientManagementWorkspace.action.createClientCmd.status', 'loading');
        const params = {
            name: this.createClientCmdName,
            email: this.createClientCmdEmail,
            company: this.createClientCmdCompany || undefined,
            phone: this.createClientCmdPhone || undefined,
            address: this.createClientCmdAddress || undefined,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff(createClientCmdRoute, params, options);
        if (response.ok) {
            this.createClientCmdOutput = response.data ?? null;
            setState('ui.clientManagementWorkspace.output.createClientCmd', response.data ?? null);
            await this.loadListClients();
            if (this.listClientsState === 'error') {
                this.createClientCmdState = 'error';
                setState('ui.clientManagementWorkspace.action.createClientCmd.status', 'error');
                return;
            }
            this.createClientCmdName = '';
            setState('ui.clientManagementWorkspace.input.createClientCmd.name', '');
            this.createClientCmdEmail = '';
            setState('ui.clientManagementWorkspace.input.createClientCmd.email', '');
            this.createClientCmdCompany = '';
            setState('ui.clientManagementWorkspace.input.createClientCmd.company', '');
            this.createClientCmdPhone = '';
            setState('ui.clientManagementWorkspace.input.createClientCmd.phone', '');
            this.createClientCmdAddress = '';
            setState('ui.clientManagementWorkspace.input.createClientCmd.address', '');
            this.createClientCmdState = 'success';
            setState('ui.clientManagementWorkspace.action.createClientCmd.status', 'success');
        }
        else {
            const errorObj = response.error;
            const errorMsg = errorObj?.message ?? '';
            this.createClientCmdError = errorMsg;
            setState('ui.clientManagementWorkspace.action.createClientCmd.error', errorMsg);
            this.createClientCmdState = 'error';
            setState('ui.clientManagementWorkspace.action.createClientCmd.status', 'error');
        }
    }
    /** handler for action createClientCmd — bind UI events here */
    handleCreateClientCmdClick() {
        runBlockingUiAction(async (signal) => {
            await this.createClientCmd(signal);
        });
    }
    /** action updateClientCmd (command) — route buildFlowFsm.clientManagementWorkspace.updateClientCmd; inputs: clientId, name, company, email, phone, address; writes updateClientCmdOutput; status updateClientCmdState; feedback keys action.updateClientCmd.success / action.updateClientCmd.error */
    async updateClientCmd(signal) {
        const routeParams = this.parseRouteParams();
        const routeClientId = routeParams['clientId'];
        if (routeClientId) {
            this.updateClientCmdClientId = routeClientId;
            setState('ui.clientManagementWorkspace.input.updateClientCmd.clientId', routeClientId);
        }
        if (!this.updateClientCmdClientId) {
            this.updateClientCmdState = 'idle';
            setState('ui.clientManagementWorkspace.action.updateClientCmd.status', 'idle');
            return;
        }
        this.updateClientCmdState = 'loading';
        setState('ui.clientManagementWorkspace.action.updateClientCmd.status', 'loading');
        const params = {
            clientId: this.updateClientCmdClientId,
            name: this.updateClientCmdName,
            company: this.updateClientCmdCompany || undefined,
            email: this.updateClientCmdEmail,
            phone: this.updateClientCmdPhone || undefined,
            address: this.updateClientCmdAddress || undefined,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff(updateClientCmdRoute, params, options);
        if (response.ok) {
            this.updateClientCmdOutput = response.data ?? null;
            setState('ui.clientManagementWorkspace.output.updateClientCmd', response.data ?? null);
            await this.loadListClients();
            if (this.listClientsState === 'error') {
                this.updateClientCmdState = 'error';
                setState('ui.clientManagementWorkspace.action.updateClientCmd.status', 'error');
                return;
            }
            this.updateClientCmdName = '';
            setState('ui.clientManagementWorkspace.input.updateClientCmd.name', '');
            this.updateClientCmdCompany = '';
            setState('ui.clientManagementWorkspace.input.updateClientCmd.company', '');
            this.updateClientCmdEmail = '';
            setState('ui.clientManagementWorkspace.input.updateClientCmd.email', '');
            this.updateClientCmdPhone = '';
            setState('ui.clientManagementWorkspace.input.updateClientCmd.phone', '');
            this.updateClientCmdAddress = '';
            setState('ui.clientManagementWorkspace.input.updateClientCmd.address', '');
            this.updateClientCmdState = 'success';
            setState('ui.clientManagementWorkspace.action.updateClientCmd.status', 'success');
        }
        else {
            const errorObj = response.error;
            const errorMsg = errorObj?.message ?? '';
            this.updateClientCmdError = errorMsg;
            setState('ui.clientManagementWorkspace.action.updateClientCmd.error', errorMsg);
            this.updateClientCmdState = 'error';
            setState('ui.clientManagementWorkspace.action.updateClientCmd.status', 'error');
        }
    }
    /** handler for action updateClientCmd — bind UI events here */
    handleUpdateClientCmdClick() {
        runBlockingUiAction(async (signal) => {
            await this.updateClientCmd(signal);
        });
    }
    /** action deleteClientCmd (command) — route buildFlowFsm.clientManagementWorkspace.deleteClientCmd; inputs: clientId; writes deleteClientCmdOutput; status deleteClientCmdState; feedback keys action.deleteClientCmd.success / action.deleteClientCmd.error */
    async deleteClientCmd(signal) {
        if (!this.deleteClientCmdClientId) {
            this.deleteClientCmdState = 'idle';
            setState('ui.clientManagementWorkspace.action.deleteClientCmd.status', 'idle');
            return;
        }
        this.deleteClientCmdState = 'loading';
        setState('ui.clientManagementWorkspace.action.deleteClientCmd.status', 'loading');
        const params = {
            clientId: this.deleteClientCmdClientId,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff(deleteClientCmdRoute, params, options);
        if (response.ok) {
            this.deleteClientCmdOutput = response.data ?? null;
            setState('ui.clientManagementWorkspace.output.deleteClientCmd', response.data ?? null);
            await this.loadListClients();
            if (this.listClientsState === 'error') {
                this.deleteClientCmdState = 'error';
                setState('ui.clientManagementWorkspace.action.deleteClientCmd.status', 'error');
                return;
            }
            this.deleteClientCmdClientId = '';
            setState('ui.clientManagementWorkspace.input.deleteClientCmd.clientId', '');
            this.deleteClientCmdState = 'success';
            setState('ui.clientManagementWorkspace.action.deleteClientCmd.status', 'success');
        }
        else {
            const errorObj = response.error;
            const errorMsg = errorObj?.message ?? '';
            this.deleteClientCmdError = errorMsg;
            setState('ui.clientManagementWorkspace.action.deleteClientCmd.error', errorMsg);
            this.deleteClientCmdState = 'error';
            setState('ui.clientManagementWorkspace.action.deleteClientCmd.status', 'error');
        }
    }
    /** handler for action deleteClientCmd — bind UI events here */
    handleDeleteClientCmdClick() {
        runBlockingUiAction(async (signal) => {
            await this.deleteClientCmd(signal);
        });
    }
    /** setter for state listClientsName */
    setListClientsName(value) {
        this.listClientsName = value;
        setState('ui.clientManagementWorkspace.input.listClients.name', value);
        this.requestUpdate();
    }
    /** handler for action set.listClientsName — bind UI events here */
    handleListClientsNameChange(e) {
        const value = e.target.value;
        this.setListClientsName(value);
    }
    /** setter for state listClientsCompany */
    setListClientsCompany(value) {
        this.listClientsCompany = value;
        setState('ui.clientManagementWorkspace.input.listClients.company', value);
        this.requestUpdate();
    }
    /** handler for action set.listClientsCompany — bind UI events here */
    handleListClientsCompanyChange(e) {
        const value = e.target.value;
        this.setListClientsCompany(value);
    }
    /** setter for state listClientsEmail */
    setListClientsEmail(value) {
        this.listClientsEmail = value;
        setState('ui.clientManagementWorkspace.input.listClients.email', value);
        this.requestUpdate();
    }
    /** handler for action set.listClientsEmail — bind UI events here */
    handleListClientsEmailChange(e) {
        const value = e.target.value;
        this.setListClientsEmail(value);
    }
    /** setter for state listClientsPage */
    setListClientsPage(value) {
        this.listClientsPage = value;
        setState('ui.clientManagementWorkspace.input.listClients.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listClientsPage — bind UI events here */
    handleListClientsPageChange(e) {
        const value = e.target.value;
        this.setListClientsPage(value);
    }
    /** setter for state listClientsPageSize */
    setListClientsPageSize(value) {
        this.listClientsPageSize = value;
        setState('ui.clientManagementWorkspace.input.listClients.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listClientsPageSize — bind UI events here */
    handleListClientsPageSizeChange(e) {
        const value = e.target.value;
        this.setListClientsPageSize(value);
    }
    /** setter for state createClientCmdName */
    setCreateClientCmdName(value) {
        this.createClientCmdName = value;
        setState('ui.clientManagementWorkspace.input.createClientCmd.name', value);
        this.requestUpdate();
    }
    /** handler for action set.createClientCmdName — bind UI events here */
    handleCreateClientCmdNameChange(e) {
        const value = e.target.value;
        this.setCreateClientCmdName(value);
    }
    /** setter for state createClientCmdEmail */
    setCreateClientCmdEmail(value) {
        this.createClientCmdEmail = value;
        setState('ui.clientManagementWorkspace.input.createClientCmd.email', value);
        this.requestUpdate();
    }
    /** handler for action set.createClientCmdEmail — bind UI events here */
    handleCreateClientCmdEmailChange(e) {
        const value = e.target.value;
        this.setCreateClientCmdEmail(value);
    }
    /** setter for state createClientCmdCompany */
    setCreateClientCmdCompany(value) {
        this.createClientCmdCompany = value;
        setState('ui.clientManagementWorkspace.input.createClientCmd.company', value);
        this.requestUpdate();
    }
    /** handler for action set.createClientCmdCompany — bind UI events here */
    handleCreateClientCmdCompanyChange(e) {
        const value = e.target.value;
        this.setCreateClientCmdCompany(value);
    }
    /** setter for state createClientCmdPhone */
    setCreateClientCmdPhone(value) {
        this.createClientCmdPhone = value;
        setState('ui.clientManagementWorkspace.input.createClientCmd.phone', value);
        this.requestUpdate();
    }
    /** handler for action set.createClientCmdPhone — bind UI events here */
    handleCreateClientCmdPhoneChange(e) {
        const value = e.target.value;
        this.setCreateClientCmdPhone(value);
    }
    /** setter for state createClientCmdAddress */
    setCreateClientCmdAddress(value) {
        this.createClientCmdAddress = value;
        setState('ui.clientManagementWorkspace.input.createClientCmd.address', value);
        this.requestUpdate();
    }
    /** handler for action set.createClientCmdAddress — bind UI events here */
    handleCreateClientCmdAddressChange(e) {
        const value = e.target.value;
        this.setCreateClientCmdAddress(value);
    }
    /** setter for state updateClientCmdClientId */
    setUpdateClientCmdClientId(value) {
        this.updateClientCmdClientId = value;
        setState('ui.clientManagementWorkspace.input.updateClientCmd.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.updateClientCmdClientId — bind UI events here */
    handleUpdateClientCmdClientIdChange(e) {
        const value = e.target.value;
        this.setUpdateClientCmdClientId(value);
    }
    /** setter for state updateClientCmdName */
    setUpdateClientCmdName(value) {
        this.updateClientCmdName = value;
        setState('ui.clientManagementWorkspace.input.updateClientCmd.name', value);
        this.requestUpdate();
    }
    /** handler for action set.updateClientCmdName — bind UI events here */
    handleUpdateClientCmdNameChange(e) {
        const value = e.target.value;
        this.setUpdateClientCmdName(value);
    }
    /** setter for state updateClientCmdCompany */
    setUpdateClientCmdCompany(value) {
        this.updateClientCmdCompany = value;
        setState('ui.clientManagementWorkspace.input.updateClientCmd.company', value);
        this.requestUpdate();
    }
    /** handler for action set.updateClientCmdCompany — bind UI events here */
    handleUpdateClientCmdCompanyChange(e) {
        const value = e.target.value;
        this.setUpdateClientCmdCompany(value);
    }
    /** setter for state updateClientCmdEmail */
    setUpdateClientCmdEmail(value) {
        this.updateClientCmdEmail = value;
        setState('ui.clientManagementWorkspace.input.updateClientCmd.email', value);
        this.requestUpdate();
    }
    /** handler for action set.updateClientCmdEmail — bind UI events here */
    handleUpdateClientCmdEmailChange(e) {
        const value = e.target.value;
        this.setUpdateClientCmdEmail(value);
    }
    /** setter for state updateClientCmdPhone */
    setUpdateClientCmdPhone(value) {
        this.updateClientCmdPhone = value;
        setState('ui.clientManagementWorkspace.input.updateClientCmd.phone', value);
        this.requestUpdate();
    }
    /** handler for action set.updateClientCmdPhone — bind UI events here */
    handleUpdateClientCmdPhoneChange(e) {
        const value = e.target.value;
        this.setUpdateClientCmdPhone(value);
    }
    /** setter for state updateClientCmdAddress */
    setUpdateClientCmdAddress(value) {
        this.updateClientCmdAddress = value;
        setState('ui.clientManagementWorkspace.input.updateClientCmd.address', value);
        this.requestUpdate();
    }
    /** handler for action set.updateClientCmdAddress — bind UI events here */
    handleUpdateClientCmdAddressChange(e) {
        const value = e.target.value;
        this.setUpdateClientCmdAddress(value);
    }
    /** setter for state deleteClientCmdClientId */
    setDeleteClientCmdClientId(value) {
        this.deleteClientCmdClientId = value;
        setState('ui.clientManagementWorkspace.input.deleteClientCmd.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.deleteClientCmdClientId — bind UI events here */
    handleDeleteClientCmdClientIdChange(e) {
        const value = e.target.value;
        this.setDeleteClientCmdClientId(value);
    }
    /**
     * collabState notify contract — assigns incoming state values to mapped
     * class fields and requests a re-render.
     */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.clientManagementWorkspace.status':
                this.status = value;
                break;
            case 'ui.clientManagementWorkspace.action.listClients.status':
                this.listClientsState = value;
                break;
            case 'ui.clientManagementWorkspace.input.listClients.name':
                this.listClientsName = value;
                break;
            case 'ui.clientManagementWorkspace.input.listClients.company':
                this.listClientsCompany = value;
                break;
            case 'ui.clientManagementWorkspace.input.listClients.email':
                this.listClientsEmail = value;
                break;
            case 'ui.clientManagementWorkspace.input.listClients.page':
                this.listClientsPage = value;
                break;
            case 'ui.clientManagementWorkspace.input.listClients.pageSize':
                this.listClientsPageSize = value;
                break;
            case 'ui.clientManagementWorkspace.data.listClients':
                this.listClientsData = value;
                break;
            case 'ui.clientManagementWorkspace.action.createClientCmd.status':
                this.createClientCmdState = value;
                break;
            case 'ui.clientManagementWorkspace.input.createClientCmd.name':
                this.createClientCmdName = value;
                break;
            case 'ui.clientManagementWorkspace.input.createClientCmd.email':
                this.createClientCmdEmail = value;
                break;
            case 'ui.clientManagementWorkspace.input.createClientCmd.company':
                this.createClientCmdCompany = value;
                break;
            case 'ui.clientManagementWorkspace.input.createClientCmd.phone':
                this.createClientCmdPhone = value;
                break;
            case 'ui.clientManagementWorkspace.input.createClientCmd.address':
                this.createClientCmdAddress = value;
                break;
            case 'ui.clientManagementWorkspace.output.createClientCmd':
                this.createClientCmdOutput = value;
                break;
            case 'ui.clientManagementWorkspace.action.createClientCmd.error':
                this.createClientCmdError = value;
                break;
            case 'ui.clientManagementWorkspace.action.updateClientCmd.status':
                this.updateClientCmdState = value;
                break;
            case 'ui.clientManagementWorkspace.input.updateClientCmd.clientId':
                this.updateClientCmdClientId = value;
                break;
            case 'ui.clientManagementWorkspace.input.updateClientCmd.name':
                this.updateClientCmdName = value;
                break;
            case 'ui.clientManagementWorkspace.input.updateClientCmd.company':
                this.updateClientCmdCompany = value;
                break;
            case 'ui.clientManagementWorkspace.input.updateClientCmd.email':
                this.updateClientCmdEmail = value;
                break;
            case 'ui.clientManagementWorkspace.input.updateClientCmd.phone':
                this.updateClientCmdPhone = value;
                break;
            case 'ui.clientManagementWorkspace.input.updateClientCmd.address':
                this.updateClientCmdAddress = value;
                break;
            case 'ui.clientManagementWorkspace.output.updateClientCmd':
                this.updateClientCmdOutput = value;
                break;
            case 'ui.clientManagementWorkspace.action.updateClientCmd.error':
                this.updateClientCmdError = value;
                break;
            case 'ui.clientManagementWorkspace.action.deleteClientCmd.status':
                this.deleteClientCmdState = value;
                break;
            case 'ui.clientManagementWorkspace.input.deleteClientCmd.clientId':
                this.deleteClientCmdClientId = value;
                break;
            case 'ui.clientManagementWorkspace.output.deleteClientCmd':
                this.deleteClientCmdOutput = value;
                break;
            case 'ui.clientManagementWorkspace.action.deleteClientCmd.error':
                this.deleteClientCmdError = value;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.clientManagementWorkspace.status') ?? '';
        this.listClientsState = getState('ui.clientManagementWorkspace.action.listClients.status') ?? 'idle';
        this.listClientsName = getState('ui.clientManagementWorkspace.input.listClients.name') ?? '';
        this.listClientsCompany = getState('ui.clientManagementWorkspace.input.listClients.company') ?? '';
        this.listClientsEmail = getState('ui.clientManagementWorkspace.input.listClients.email') ?? '';
        this.listClientsPage = getState('ui.clientManagementWorkspace.input.listClients.page') ?? '';
        this.listClientsPageSize = getState('ui.clientManagementWorkspace.input.listClients.pageSize') ?? '';
        const storedListClientsData = getState('ui.clientManagementWorkspace.data.listClients');
        this.listClientsData = storedListClientsData ?? { clients: [], total: 0 };
        this.createClientCmdState = getState('ui.clientManagementWorkspace.action.createClientCmd.status') ?? 'idle';
        this.createClientCmdName = getState('ui.clientManagementWorkspace.input.createClientCmd.name') ?? '';
        this.createClientCmdEmail = getState('ui.clientManagementWorkspace.input.createClientCmd.email') ?? '';
        this.createClientCmdCompany = getState('ui.clientManagementWorkspace.input.createClientCmd.company') ?? '';
        this.createClientCmdPhone = getState('ui.clientManagementWorkspace.input.createClientCmd.phone') ?? '';
        this.createClientCmdAddress = getState('ui.clientManagementWorkspace.input.createClientCmd.address') ?? '';
        this.createClientCmdOutput = getState('ui.clientManagementWorkspace.output.createClientCmd') ?? null;
        this.createClientCmdError = getState('ui.clientManagementWorkspace.action.createClientCmd.error') ?? '';
        this.updateClientCmdState = getState('ui.clientManagementWorkspace.action.updateClientCmd.status') ?? 'idle';
        this.updateClientCmdName = getState('ui.clientManagementWorkspace.input.updateClientCmd.name') ?? '';
        this.updateClientCmdCompany = getState('ui.clientManagementWorkspace.input.updateClientCmd.company') ?? '';
        this.updateClientCmdEmail = getState('ui.clientManagementWorkspace.input.updateClientCmd.email') ?? '';
        this.updateClientCmdPhone = getState('ui.clientManagementWorkspace.input.updateClientCmd.phone') ?? '';
        this.updateClientCmdAddress = getState('ui.clientManagementWorkspace.input.updateClientCmd.address') ?? '';
        this.updateClientCmdOutput = getState('ui.clientManagementWorkspace.output.updateClientCmd') ?? null;
        this.updateClientCmdError = getState('ui.clientManagementWorkspace.action.updateClientCmd.error') ?? '';
        this.deleteClientCmdState = getState('ui.clientManagementWorkspace.action.deleteClientCmd.status') ?? 'idle';
        this.deleteClientCmdClientId = getState('ui.clientManagementWorkspace.input.deleteClientCmd.clientId') ?? '';
        this.deleteClientCmdOutput = getState('ui.clientManagementWorkspace.output.deleteClientCmd') ?? null;
        this.deleteClientCmdError = getState('ui.clientManagementWorkspace.action.deleteClientCmd.error') ?? '';
        const routeParams = this.parseRouteParams();
        const routeClientId = routeParams['clientId'];
        if (routeClientId) {
            this.updateClientCmdClientId = routeClientId;
            setState('ui.clientManagementWorkspace.input.updateClientCmd.clientId', routeClientId);
        }
        subscribe([...BuildFlowFsmClientManagementWorkspaceBase.allStateKeys], this);
        this.loadListClients();
    }
    disconnectedCallback() {
        unsubscribe([...BuildFlowFsmClientManagementWorkspaceBase.allStateKeys], this);
        super.disconnectedCallback();
    }
}
BuildFlowFsmClientManagementWorkspaceBase.allStateKeys = [
    'ui.clientManagementWorkspace.status',
    'ui.clientManagementWorkspace.action.listClients.status',
    'ui.clientManagementWorkspace.input.listClients.name',
    'ui.clientManagementWorkspace.input.listClients.company',
    'ui.clientManagementWorkspace.input.listClients.email',
    'ui.clientManagementWorkspace.input.listClients.page',
    'ui.clientManagementWorkspace.input.listClients.pageSize',
    'ui.clientManagementWorkspace.data.listClients',
    'ui.clientManagementWorkspace.action.createClientCmd.status',
    'ui.clientManagementWorkspace.input.createClientCmd.name',
    'ui.clientManagementWorkspace.input.createClientCmd.email',
    'ui.clientManagementWorkspace.input.createClientCmd.company',
    'ui.clientManagementWorkspace.input.createClientCmd.phone',
    'ui.clientManagementWorkspace.input.createClientCmd.address',
    'ui.clientManagementWorkspace.output.createClientCmd',
    'ui.clientManagementWorkspace.action.createClientCmd.error',
    'ui.clientManagementWorkspace.action.updateClientCmd.status',
    'ui.clientManagementWorkspace.input.updateClientCmd.clientId',
    'ui.clientManagementWorkspace.input.updateClientCmd.name',
    'ui.clientManagementWorkspace.input.updateClientCmd.company',
    'ui.clientManagementWorkspace.input.updateClientCmd.email',
    'ui.clientManagementWorkspace.input.updateClientCmd.phone',
    'ui.clientManagementWorkspace.input.updateClientCmd.address',
    'ui.clientManagementWorkspace.output.updateClientCmd',
    'ui.clientManagementWorkspace.action.updateClientCmd.error',
    'ui.clientManagementWorkspace.action.deleteClientCmd.status',
    'ui.clientManagementWorkspace.input.deleteClientCmd.clientId',
    'ui.clientManagementWorkspace.output.deleteClientCmd',
    'ui.clientManagementWorkspace.action.deleteClientCmd.error',
];
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "listClientsState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "listClientsName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "listClientsCompany", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "listClientsEmail", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "listClientsPage", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "listClientsPageSize", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "listClientsData", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "createClientCmdState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "createClientCmdName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "createClientCmdEmail", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "createClientCmdCompany", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "createClientCmdPhone", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "createClientCmdAddress", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "createClientCmdOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "createClientCmdError", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "updateClientCmdState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "updateClientCmdClientId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "updateClientCmdName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "updateClientCmdCompany", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "updateClientCmdEmail", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "updateClientCmdPhone", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "updateClientCmdAddress", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "updateClientCmdOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "updateClientCmdError", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "deleteClientCmdState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "deleteClientCmdClientId", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "deleteClientCmdOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementWorkspaceBase.prototype, "deleteClientCmdError", void 0);
