/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/invoiceWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { listInvoicesRoute, createInvoiceCmdRoute, sendInvoiceCmdRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/invoiceWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    'section.invoiceWorkspace.invoiceListSection.title': 'Invoice Pipeline',
    'organism.invoiceWorkspace.listInvoices.title': 'Browse invoices',
    'intent.invoiceWorkspace.listInvoices.list.title': 'Browse invoices',
    'intent.invoiceWorkspace.listInvoices.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceWorkspace.listInvoices.list.column.invoices.label': 'Invoices',
    'intent.invoiceWorkspace.listInvoices.list.column.total.label': 'Total',
    'intent.invoiceWorkspace.listInvoices.list.filter.status.label': 'Status',
    'intent.invoiceWorkspace.listInvoices.list.filter.projectId.label': 'Project Id',
    'intent.invoiceWorkspace.listInvoices.list.filter.clientId.label': 'Client Id',
    'intent.invoiceWorkspace.listInvoices.list.filter.page.label': 'Page',
    'intent.invoiceWorkspace.listInvoices.list.filter.pageSize.label': 'Page Size',
    'organism.invoiceWorkspace.sendInvoiceCmd.title': 'Send invoice to client',
    'intent.invoiceWorkspace.sendInvoiceCmd.form.title': 'Send invoice to client',
    'intent.invoiceWorkspace.sendInvoiceCmd.form.action.sendInvoiceCmd': 'Send invoice to client',
    'section.invoiceWorkspace.createInvoiceSection.title': 'Create Invoice',
    'organism.invoiceWorkspace.createInvoiceCmd.title': 'Create invoice',
    'intent.invoiceWorkspace.createInvoiceCmd.form.title': 'Create invoice',
    'intent.invoiceWorkspace.createInvoiceCmd.form.action.createInvoiceCmd': 'Create invoice',
    'intent.invoiceWorkspace.createInvoiceCmd.form.field.invoiceNumber.label': 'Invoice Number',
    'action.createInvoiceCmd.success': 'Create invoice: OK',
    'action.createInvoiceCmd.error': 'Create invoice: falhou',
    'action.sendInvoiceCmd.success': 'Send invoice to client: OK',
    'action.sendInvoiceCmd.error': 'Send invoice to client: falhou',
    'section.invoiceWorkspace.sec-invoice-list.title': 'Invoice List',
    'organism.invoiceWorkspace.summary-first10.title': 'Summary first',
    'intent.invoiceWorkspace.summary-first10.content.title': 'Summary first',
    'section.invoiceWorkspace.sec-create-invoice.title': 'Create Invoice',
};
const message_pt_br = {
    'section.invoiceWorkspace.invoiceListSection.title': 'Invoice Pipeline',
    'organism.invoiceWorkspace.listInvoices.title': 'Browse invoices',
    'intent.invoiceWorkspace.listInvoices.list.title': 'Browse invoices',
    'intent.invoiceWorkspace.listInvoices.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceWorkspace.listInvoices.list.column.invoices.label': 'Invoices',
    'intent.invoiceWorkspace.listInvoices.list.column.total.label': 'Total',
    'intent.invoiceWorkspace.listInvoices.list.filter.status.label': 'Status',
    'intent.invoiceWorkspace.listInvoices.list.filter.projectId.label': 'Project Id',
    'intent.invoiceWorkspace.listInvoices.list.filter.clientId.label': 'Client Id',
    'intent.invoiceWorkspace.listInvoices.list.filter.page.label': 'Page',
    'intent.invoiceWorkspace.listInvoices.list.filter.pageSize.label': 'Page Size',
    'organism.invoiceWorkspace.sendInvoiceCmd.title': 'Send invoice to client',
    'intent.invoiceWorkspace.sendInvoiceCmd.form.title': 'Send invoice to client',
    'intent.invoiceWorkspace.sendInvoiceCmd.form.action.sendInvoiceCmd': 'Send invoice to client',
    'section.invoiceWorkspace.createInvoiceSection.title': 'Create Invoice',
    'organism.invoiceWorkspace.createInvoiceCmd.title': 'Create invoice',
    'intent.invoiceWorkspace.createInvoiceCmd.form.title': 'Create invoice',
    'intent.invoiceWorkspace.createInvoiceCmd.form.action.createInvoiceCmd': 'Create invoice',
    'intent.invoiceWorkspace.createInvoiceCmd.form.field.invoiceNumber.label': 'Invoice Number',
    'action.createInvoiceCmd.success': 'Create invoice: OK',
    'action.createInvoiceCmd.error': 'Create invoice: falhou',
    'action.sendInvoiceCmd.success': 'Send invoice to client: OK',
    'action.sendInvoiceCmd.error': 'Send invoice to client: falhou',
    'section.invoiceWorkspace.sec-invoice-list.title': 'Invoice List',
    'organism.invoiceWorkspace.summary-first10.title': 'Summary first',
    'intent.invoiceWorkspace.summary-first10.content.title': 'Summary first',
    'section.invoiceWorkspace.sec-create-invoice.title': 'Create Invoice',
};
const message_es = {
    'section.invoiceWorkspace.invoiceListSection.title': 'Invoice Pipeline',
    'organism.invoiceWorkspace.listInvoices.title': 'Browse invoices',
    'intent.invoiceWorkspace.listInvoices.list.title': 'Browse invoices',
    'intent.invoiceWorkspace.listInvoices.list.empty': 'Nenhum registro encontrado',
    'intent.invoiceWorkspace.listInvoices.list.column.invoices.label': 'Invoices',
    'intent.invoiceWorkspace.listInvoices.list.column.total.label': 'Total',
    'intent.invoiceWorkspace.listInvoices.list.filter.status.label': 'Status',
    'intent.invoiceWorkspace.listInvoices.list.filter.projectId.label': 'Project Id',
    'intent.invoiceWorkspace.listInvoices.list.filter.clientId.label': 'Client Id',
    'intent.invoiceWorkspace.listInvoices.list.filter.page.label': 'Page',
    'intent.invoiceWorkspace.listInvoices.list.filter.pageSize.label': 'Page Size',
    'organism.invoiceWorkspace.sendInvoiceCmd.title': 'Send invoice to client',
    'intent.invoiceWorkspace.sendInvoiceCmd.form.title': 'Send invoice to client',
    'intent.invoiceWorkspace.sendInvoiceCmd.form.action.sendInvoiceCmd': 'Send invoice to client',
    'section.invoiceWorkspace.createInvoiceSection.title': 'Create Invoice',
    'organism.invoiceWorkspace.createInvoiceCmd.title': 'Create invoice',
    'intent.invoiceWorkspace.createInvoiceCmd.form.title': 'Create invoice',
    'intent.invoiceWorkspace.createInvoiceCmd.form.action.createInvoiceCmd': 'Create invoice',
    'intent.invoiceWorkspace.createInvoiceCmd.form.field.invoiceNumber.label': 'Invoice Number',
    'action.createInvoiceCmd.success': 'Create invoice: OK',
    'action.createInvoiceCmd.error': 'Create invoice: falhou',
    'action.sendInvoiceCmd.success': 'Send invoice to client: OK',
    'action.sendInvoiceCmd.error': 'Send invoice to client: falhou',
    'section.invoiceWorkspace.sec-invoice-list.title': 'Invoice List',
    'organism.invoiceWorkspace.summary-first10.title': 'Summary first',
    'intent.invoiceWorkspace.summary-first10.content.title': 'Summary first',
    'section.invoiceWorkspace.sec-create-invoice.title': 'Create Invoice',
};
export const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
const LIST_INVOICES_DATA_DEFAULT = { invoices: [], total: 0 };
const SUBSCRIBED_STATE_KEYS = [
    'ui.invoiceWorkspace.status',
    'ui.invoiceWorkspace.action.listInvoices.status',
    'ui.invoiceWorkspace.input.listInvoices.status',
    'ui.invoiceWorkspace.input.listInvoices.projectId',
    'ui.invoiceWorkspace.input.listInvoices.clientId',
    'ui.invoiceWorkspace.input.listInvoices.page',
    'ui.invoiceWorkspace.input.listInvoices.pageSize',
    'ui.invoiceWorkspace.data.listInvoices',
    'ui.invoiceWorkspace.action.createInvoiceCmd.status',
    'ui.invoiceWorkspace.input.createInvoiceCmd.projectId',
    'ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber',
    'ui.invoiceWorkspace.input.createInvoiceCmd.clientId',
    'ui.invoiceWorkspace.output.createInvoiceCmd',
    'ui.invoiceWorkspace.action.createInvoiceCmd.error',
    'ui.invoiceWorkspace.action.sendInvoiceCmd.status',
    'ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId',
    'ui.invoiceWorkspace.output.sendInvoiceCmd',
    'ui.invoiceWorkspace.action.sendInvoiceCmd.error',
];
export class BuildFlowFsmInvoiceWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state listInvoicesState — actionStatus, values: idle|loading|success|error */
        this.listInvoicesState = 'idle';
        /** state listInvoicesStatus — input */
        this.listInvoicesStatus = '';
        /** state listInvoicesProjectId — input */
        this.listInvoicesProjectId = '';
        /** state listInvoicesClientId — input */
        this.listInvoicesClientId = '';
        /** state listInvoicesPage — input */
        this.listInvoicesPage = '';
        /** state listInvoicesPageSize — input */
        this.listInvoicesPageSize = '';
        /** state listInvoicesData — queryResult, outputShape: paginated */
        this.listInvoicesData = LIST_INVOICES_DATA_DEFAULT;
        /** state createInvoiceCmdState — actionStatus, values: idle|loading|success|error */
        this.createInvoiceCmdState = 'idle';
        /** state createInvoiceCmdProjectId — input */
        this.createInvoiceCmdProjectId = '';
        /** state createInvoiceCmdInvoiceNumber — input */
        this.createInvoiceCmdInvoiceNumber = '';
        /** state createInvoiceCmdClientId — input */
        this.createInvoiceCmdClientId = '';
        /** state createInvoiceCmdOutput — commandOutput */
        this.createInvoiceCmdOutput = null;
        /** state createInvoiceCmdError — actionError */
        this.createInvoiceCmdError = '';
        /** state sendInvoiceCmdState — actionStatus, values: idle|loading|success|error */
        this.sendInvoiceCmdState = 'idle';
        /** state sendInvoiceCmdInvoiceId — input */
        this.sendInvoiceCmdInvoiceId = '';
        /** state sendInvoiceCmdOutput — commandOutput */
        this.sendInvoiceCmdOutput = null;
        /** state sendInvoiceCmdError — actionError */
        this.sendInvoiceCmdError = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.invoiceWorkspace.status', '');
        this.initStateValue('ui.invoiceWorkspace.action.listInvoices.status', 'idle');
        this.initStateValue('ui.invoiceWorkspace.input.listInvoices.status', '');
        this.initStateValue('ui.invoiceWorkspace.input.listInvoices.projectId', '');
        this.initStateValue('ui.invoiceWorkspace.input.listInvoices.clientId', '');
        this.initStateValue('ui.invoiceWorkspace.input.listInvoices.page', '');
        this.initStateValue('ui.invoiceWorkspace.input.listInvoices.pageSize', '');
        this.initStateValue('ui.invoiceWorkspace.data.listInvoices', LIST_INVOICES_DATA_DEFAULT);
        this.initStateValue('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'idle');
        this.initStateValue('ui.invoiceWorkspace.input.createInvoiceCmd.projectId', '');
        this.initStateValue('ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber', '');
        this.initStateValue('ui.invoiceWorkspace.input.createInvoiceCmd.clientId', '');
        this.initStateValue('ui.invoiceWorkspace.output.createInvoiceCmd', null);
        this.initStateValue('ui.invoiceWorkspace.action.createInvoiceCmd.error', '');
        this.initStateValue('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'idle');
        this.initStateValue('ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId', '');
        this.initStateValue('ui.invoiceWorkspace.output.sendInvoiceCmd', null);
        this.initStateValue('ui.invoiceWorkspace.action.sendInvoiceCmd.error', '');
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadListInvoices();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.invoiceWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.invoiceWorkspace.action.listInvoices.status':
                this.listInvoicesState = value ?? 'idle';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.status':
                this.listInvoicesStatus = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.projectId':
                this.listInvoicesProjectId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.clientId':
                this.listInvoicesClientId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.page':
                this.listInvoicesPage = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.pageSize':
                this.listInvoicesPageSize = value ?? '';
                break;
            case 'ui.invoiceWorkspace.data.listInvoices':
                this.listInvoicesData = value ?? LIST_INVOICES_DATA_DEFAULT;
                break;
            case 'ui.invoiceWorkspace.action.createInvoiceCmd.status':
                this.createInvoiceCmdState = value ?? 'idle';
                break;
            case 'ui.invoiceWorkspace.input.createInvoiceCmd.projectId':
                this.createInvoiceCmdProjectId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber':
                this.createInvoiceCmdInvoiceNumber = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.createInvoiceCmd.clientId':
                this.createInvoiceCmdClientId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.output.createInvoiceCmd':
                this.createInvoiceCmdOutput = value ?? null;
                break;
            case 'ui.invoiceWorkspace.action.createInvoiceCmd.error':
                this.createInvoiceCmdError = value ?? '';
                break;
            case 'ui.invoiceWorkspace.action.sendInvoiceCmd.status':
                this.sendInvoiceCmdState = value ?? 'idle';
                break;
            case 'ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId':
                this.sendInvoiceCmdInvoiceId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.output.sendInvoiceCmd':
                this.sendInvoiceCmdOutput = value ?? null;
                break;
            case 'ui.invoiceWorkspace.action.sendInvoiceCmd.error':
                this.sendInvoiceCmdError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.invoiceWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.invoiceWorkspace.action.listInvoices.status':
                this.listInvoicesState = value ?? 'idle';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.status':
                this.listInvoicesStatus = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.projectId':
                this.listInvoicesProjectId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.clientId':
                this.listInvoicesClientId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.page':
                this.listInvoicesPage = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.pageSize':
                this.listInvoicesPageSize = value ?? '';
                break;
            case 'ui.invoiceWorkspace.data.listInvoices':
                this.listInvoicesData = value ?? LIST_INVOICES_DATA_DEFAULT;
                break;
            case 'ui.invoiceWorkspace.action.createInvoiceCmd.status':
                this.createInvoiceCmdState = value ?? 'idle';
                break;
            case 'ui.invoiceWorkspace.input.createInvoiceCmd.projectId':
                this.createInvoiceCmdProjectId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber':
                this.createInvoiceCmdInvoiceNumber = value ?? '';
                break;
            case 'ui.invoiceWorkspace.input.createInvoiceCmd.clientId':
                this.createInvoiceCmdClientId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.output.createInvoiceCmd':
                this.createInvoiceCmdOutput = value ?? null;
                break;
            case 'ui.invoiceWorkspace.action.createInvoiceCmd.error':
                this.createInvoiceCmdError = value ?? '';
                break;
            case 'ui.invoiceWorkspace.action.sendInvoiceCmd.status':
                this.sendInvoiceCmdState = value ?? 'idle';
                break;
            case 'ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId':
                this.sendInvoiceCmdInvoiceId = value ?? '';
                break;
            case 'ui.invoiceWorkspace.output.sendInvoiceCmd':
                this.sendInvoiceCmdOutput = value ?? null;
                break;
            case 'ui.invoiceWorkspace.action.sendInvoiceCmd.error':
                this.sendInvoiceCmdError = value ?? '';
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action listInvoices (query) — route buildFlowFsm.invoiceWorkspace.listInvoices; inputs: status, projectId, clientId, page, pageSize; writes ui.invoiceWorkspace.data.listInvoices; status ui.invoiceWorkspace.action.listInvoices.status */
    async loadListInvoices() {
        this.listInvoicesState = 'loading';
        setState('ui.invoiceWorkspace.action.listInvoices.status', 'loading');
        const params = {};
        if (this.listInvoicesStatus) {
            params.status = this.listInvoicesStatus;
        }
        if (this.listInvoicesProjectId) {
            params.projectId = this.listInvoicesProjectId;
        }
        if (this.listInvoicesClientId) {
            params.clientId = this.listInvoicesClientId;
        }
        if (this.listInvoicesPage !== '') {
            const pageNum = Number(this.listInvoicesPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.listInvoicesPageSize !== '') {
            const pageSizeNum = Number(this.listInvoicesPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(listInvoicesRoute, params, options);
        if (response.ok) {
            const data = response.data ?? LIST_INVOICES_DATA_DEFAULT;
            this.listInvoicesData = data;
            setState('ui.invoiceWorkspace.data.listInvoices', data);
            this.listInvoicesState = 'success';
            setState('ui.invoiceWorkspace.action.listInvoices.status', 'success');
        }
        else {
            this.listInvoicesState = 'error';
            setState('ui.invoiceWorkspace.action.listInvoices.status', 'error');
            if (response.error) {
                console.error('listInvoices failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action listInvoices — bind UI events here */
    handleListInvoicesClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadListInvoices();
    }
    /** action createInvoiceCmd (command) — route buildFlowFsm.invoiceWorkspace.createInvoiceCmd; inputs: projectId, invoiceNumber, clientId; writes ui.invoiceWorkspace.output.createInvoiceCmd; status ui.invoiceWorkspace.action.createInvoiceCmd.status; feedback keys action.createInvoiceCmd.success / action.createInvoiceCmd.error */
    async createInvoiceCmd() {
        if (!this.createInvoiceCmdProjectId) {
            this.createInvoiceCmdState = 'idle';
            setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'idle');
            this.requestUpdate();
            return;
        }
        if (!this.createInvoiceCmdClientId) {
            this.createInvoiceCmdState = 'idle';
            setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.createInvoiceCmdState = 'loading';
        setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'loading');
        this.createInvoiceCmdError = '';
        setState('ui.invoiceWorkspace.action.createInvoiceCmd.error', '');
        const params = {
            projectId: this.createInvoiceCmdProjectId,
            invoiceNumber: this.createInvoiceCmdInvoiceNumber,
            clientId: this.createInvoiceCmdClientId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(createInvoiceCmdRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.createInvoiceCmd.error');
            this.createInvoiceCmdError = errMsg;
            setState('ui.invoiceWorkspace.action.createInvoiceCmd.error', errMsg);
            this.createInvoiceCmdState = 'error';
            setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.createInvoiceCmdOutput = data;
        setState('ui.invoiceWorkspace.output.createInvoiceCmd', data);
        try {
            await this.loadListInvoices();
            if (this.listInvoicesState === 'error') {
                this.createInvoiceCmdState = 'error';
                setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('createInvoiceCmd refresh failed', refreshError);
            this.createInvoiceCmdState = 'error';
            setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'error');
            this.requestUpdate();
            return;
        }
        this.createInvoiceCmdProjectId = '';
        setState('ui.invoiceWorkspace.input.createInvoiceCmd.projectId', '');
        this.createInvoiceCmdInvoiceNumber = '';
        setState('ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber', '');
        this.createInvoiceCmdClientId = '';
        setState('ui.invoiceWorkspace.input.createInvoiceCmd.clientId', '');
        this.createInvoiceCmdState = 'success';
        setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'success');
        this.requestUpdate();
    }
    /** handler for action createInvoiceCmd — bind UI events here */
    handleCreateInvoiceCmdClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.createInvoiceCmd();
        });
    }
    /** action sendInvoiceCmd (command) — route buildFlowFsm.invoiceWorkspace.sendInvoiceCmd; inputs: invoiceId; writes ui.invoiceWorkspace.output.sendInvoiceCmd; status ui.invoiceWorkspace.action.sendInvoiceCmd.status; feedback keys action.sendInvoiceCmd.success / action.sendInvoiceCmd.error */
    async sendInvoiceCmd() {
        if (!this.sendInvoiceCmdInvoiceId) {
            this.sendInvoiceCmdState = 'idle';
            setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.sendInvoiceCmdState = 'loading';
        setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'loading');
        this.sendInvoiceCmdError = '';
        setState('ui.invoiceWorkspace.action.sendInvoiceCmd.error', '');
        const params = {
            invoiceId: this.sendInvoiceCmdInvoiceId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(sendInvoiceCmdRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.sendInvoiceCmd.error');
            this.sendInvoiceCmdError = errMsg;
            setState('ui.invoiceWorkspace.action.sendInvoiceCmd.error', errMsg);
            this.sendInvoiceCmdState = 'error';
            setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.sendInvoiceCmdOutput = data;
        setState('ui.invoiceWorkspace.output.sendInvoiceCmd', data);
        try {
            await this.loadListInvoices();
            if (this.listInvoicesState === 'error') {
                this.sendInvoiceCmdState = 'error';
                setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('sendInvoiceCmd refresh failed', refreshError);
            this.sendInvoiceCmdState = 'error';
            setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'error');
            this.requestUpdate();
            return;
        }
        this.sendInvoiceCmdInvoiceId = '';
        setState('ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId', '');
        this.sendInvoiceCmdState = 'success';
        setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'success');
        this.requestUpdate();
    }
    /** handler for action sendInvoiceCmd — bind UI events here */
    handleSendInvoiceCmdClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.sendInvoiceCmd();
        });
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.status */
    setListInvoicesStatus(value) {
        this.listInvoicesStatus = value;
        setState('ui.invoiceWorkspace.input.listInvoices.status', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesStatus — bind UI events here */
    handleListInvoicesStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListInvoicesStatus(value);
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.projectId */
    setListInvoicesProjectId(value) {
        this.listInvoicesProjectId = value;
        setState('ui.invoiceWorkspace.input.listInvoices.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesProjectId — bind UI events here */
    handleListInvoicesProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListInvoicesProjectId(value);
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.clientId */
    setListInvoicesClientId(value) {
        this.listInvoicesClientId = value;
        setState('ui.invoiceWorkspace.input.listInvoices.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesClientId — bind UI events here */
    handleListInvoicesClientIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListInvoicesClientId(value);
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.page */
    setListInvoicesPage(value) {
        this.listInvoicesPage = value;
        setState('ui.invoiceWorkspace.input.listInvoices.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesPage — bind UI events here */
    handleListInvoicesPageChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListInvoicesPage(value);
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.pageSize */
    setListInvoicesPageSize(value) {
        this.listInvoicesPageSize = value;
        setState('ui.invoiceWorkspace.input.listInvoices.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesPageSize — bind UI events here */
    handleListInvoicesPageSizeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListInvoicesPageSize(value);
    }
    /** setter for state ui.invoiceWorkspace.input.createInvoiceCmd.projectId */
    setCreateInvoiceCmdProjectId(value) {
        this.createInvoiceCmdProjectId = value;
        setState('ui.invoiceWorkspace.input.createInvoiceCmd.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.createInvoiceCmdProjectId — bind UI events here */
    handleCreateInvoiceCmdProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCreateInvoiceCmdProjectId(value);
    }
    /** setter for state ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber */
    setCreateInvoiceCmdInvoiceNumber(value) {
        this.createInvoiceCmdInvoiceNumber = value;
        setState('ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber', value);
        this.requestUpdate();
    }
    /** handler for action set.createInvoiceCmdInvoiceNumber — bind UI events here */
    handleCreateInvoiceCmdInvoiceNumberChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCreateInvoiceCmdInvoiceNumber(value);
    }
    /** setter for state ui.invoiceWorkspace.input.createInvoiceCmd.clientId */
    setCreateInvoiceCmdClientId(value) {
        this.createInvoiceCmdClientId = value;
        setState('ui.invoiceWorkspace.input.createInvoiceCmd.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.createInvoiceCmdClientId — bind UI events here */
    handleCreateInvoiceCmdClientIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCreateInvoiceCmdClientId(value);
    }
    /** setter for state ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId */
    setSendInvoiceCmdInvoiceId(value) {
        this.sendInvoiceCmdInvoiceId = value;
        setState('ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId', value);
        this.requestUpdate();
    }
    /** handler for action set.sendInvoiceCmdInvoiceId — bind UI events here */
    handleSendInvoiceCmdInvoiceIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setSendInvoiceCmdInvoiceId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesStatus", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesClientId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesPage", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesData", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdInvoiceNumber", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdClientId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdOutput", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdError", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "sendInvoiceCmdState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "sendInvoiceCmdInvoiceId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "sendInvoiceCmdOutput", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "sendInvoiceCmdError", void 0);
