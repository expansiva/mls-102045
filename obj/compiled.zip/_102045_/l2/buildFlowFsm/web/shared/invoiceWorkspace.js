/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/invoiceWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { listInvoicesRoute, createInvoiceCmdRoute, sendInvoiceCmdRoute } from '/_102045_/l2/buildFlowFsm/web/contracts/invoiceWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    "section.invoiceWorkspace.invoiceListSection.title": "Invoice Pipeline",
    "organism.invoiceWorkspace.inline-row-command10.title": "Inline row command",
    "intent.invoiceWorkspace.inline-row-command10.content.title": "Inline row command",
    "organism.invoiceWorkspace.listInvoices.title": "Browse invoices",
    "intent.invoiceWorkspace.listInvoices.list.title": "Browse invoices",
    "intent.invoiceWorkspace.listInvoices.list.empty": "Nenhum registro encontrado",
    "intent.invoiceWorkspace.listInvoices.list.column.invoices.label": "Invoices",
    "intent.invoiceWorkspace.listInvoices.list.column.total.label": "Total",
    "intent.invoiceWorkspace.listInvoices.list.filter.status.label": "Status",
    "intent.invoiceWorkspace.listInvoices.list.filter.projectId.label": "Project Id",
    "intent.invoiceWorkspace.listInvoices.list.filter.clientId.label": "Client Id",
    "intent.invoiceWorkspace.listInvoices.list.filter.page.label": "Page",
    "intent.invoiceWorkspace.listInvoices.list.filter.pageSize.label": "Page Size",
    "organism.invoiceWorkspace.sendInvoiceCmd.title": "Send invoice to client",
    "intent.invoiceWorkspace.sendInvoiceCmd.form.title": "Send invoice to client",
    "intent.invoiceWorkspace.sendInvoiceCmd.form.action.sendInvoiceCmd": "Send invoice to client",
    "section.invoiceWorkspace.createInvoiceSection.title": "Create Invoice",
    "organism.invoiceWorkspace.createInvoiceCmd.title": "Create invoice",
    "intent.invoiceWorkspace.createInvoiceCmd.form.title": "Create invoice",
    "intent.invoiceWorkspace.createInvoiceCmd.form.action.createInvoiceCmd": "Create invoice",
    "intent.invoiceWorkspace.createInvoiceCmd.form.field.invoiceNumber.label": "Invoice Number",
    "section.invoiceWorkspace.sec-invoice-list.title": "Invoice List",
    "organism.invoiceWorkspace.summary-first10.title": "Summary first",
    "intent.invoiceWorkspace.summary-first10.content.title": "Summary first",
    "section.invoiceWorkspace.sec-create-invoice.title": "Create Invoice"
};
const message_pt_br = {
    "section.invoiceWorkspace.invoiceListSection.title": "Pipeline de Faturas",
    "organism.invoiceWorkspace.inline-row-command10.title": "Comando de linha embutida",
    "intent.invoiceWorkspace.inline-row-command10.content.title": "Comando de linha embutida",
    "organism.invoiceWorkspace.listInvoices.title": "Navegar faturas",
    "intent.invoiceWorkspace.listInvoices.list.title": "Navegar faturas",
    "intent.invoiceWorkspace.listInvoices.list.empty": "Nenhum registro encontrado",
    "intent.invoiceWorkspace.listInvoices.list.column.invoices.label": "Faturas",
    "intent.invoiceWorkspace.listInvoices.list.column.total.label": "Total",
    "intent.invoiceWorkspace.listInvoices.list.filter.status.label": "Status",
    "intent.invoiceWorkspace.listInvoices.list.filter.projectId.label": "ID do Projeto",
    "intent.invoiceWorkspace.listInvoices.list.filter.clientId.label": "ID do Cliente",
    "intent.invoiceWorkspace.listInvoices.list.filter.page.label": "Página",
    "intent.invoiceWorkspace.listInvoices.list.filter.pageSize.label": "Tamanho da Página",
    "organism.invoiceWorkspace.sendInvoiceCmd.title": "Enviar fatura para o cliente",
    "intent.invoiceWorkspace.sendInvoiceCmd.form.title": "Enviar fatura para o cliente",
    "intent.invoiceWorkspace.sendInvoiceCmd.form.action.sendInvoiceCmd": "Enviar fatura para o cliente",
    "section.invoiceWorkspace.createInvoiceSection.title": "Criar Fatura",
    "organism.invoiceWorkspace.createInvoiceCmd.title": "Criar fatura",
    "intent.invoiceWorkspace.createInvoiceCmd.form.title": "Criar fatura",
    "intent.invoiceWorkspace.createInvoiceCmd.form.action.createInvoiceCmd": "Criar fatura",
    "intent.invoiceWorkspace.createInvoiceCmd.form.field.invoiceNumber.label": "Número da Fatura",
    "section.invoiceWorkspace.sec-invoice-list.title": "Lista de Faturas",
    "organism.invoiceWorkspace.summary-first10.title": "Resumo inicial",
    "intent.invoiceWorkspace.summary-first10.content.title": "Resumo inicial",
    "section.invoiceWorkspace.sec-create-invoice.title": "Criar Fatura"
};
const message_es = {
    "section.invoiceWorkspace.invoiceListSection.title": "Flujo de Facturas",
    "organism.invoiceWorkspace.inline-row-command10.title": "Comando de fila en línea",
    "intent.invoiceWorkspace.inline-row-command10.content.title": "Comando de fila en línea",
    "organism.invoiceWorkspace.listInvoices.title": "Explorar facturas",
    "intent.invoiceWorkspace.listInvoices.list.title": "Explorar facturas",
    "intent.invoiceWorkspace.listInvoices.list.empty": "No se encontraron registros",
    "intent.invoiceWorkspace.listInvoices.list.column.invoices.label": "Facturas",
    "intent.invoiceWorkspace.listInvoices.list.column.total.label": "Total",
    "intent.invoiceWorkspace.listInvoices.list.filter.status.label": "Estado",
    "intent.invoiceWorkspace.listInvoices.list.filter.projectId.label": "ID del Proyecto",
    "intent.invoiceWorkspace.listInvoices.list.filter.clientId.label": "ID del Cliente",
    "intent.invoiceWorkspace.listInvoices.list.filter.page.label": "Página",
    "intent.invoiceWorkspace.listInvoices.list.filter.pageSize.label": "Tamaño de Página",
    "organism.invoiceWorkspace.sendInvoiceCmd.title": "Enviar factura al cliente",
    "intent.invoiceWorkspace.sendInvoiceCmd.form.title": "Enviar factura al cliente",
    "intent.invoiceWorkspace.sendInvoiceCmd.form.action.sendInvoiceCmd": "Enviar factura al cliente",
    "section.invoiceWorkspace.createInvoiceSection.title": "Crear Factura",
    "organism.invoiceWorkspace.createInvoiceCmd.title": "Crear factura",
    "intent.invoiceWorkspace.createInvoiceCmd.form.title": "Crear factura",
    "intent.invoiceWorkspace.createInvoiceCmd.form.action.createInvoiceCmd": "Crear factura",
    "intent.invoiceWorkspace.createInvoiceCmd.form.field.invoiceNumber.label": "Número de Factura",
    "section.invoiceWorkspace.sec-invoice-list.title": "Lista de Facturas",
    "organism.invoiceWorkspace.summary-first10.title": "Resumen inicial",
    "intent.invoiceWorkspace.summary-first10.content.title": "Resumen inicial",
    "section.invoiceWorkspace.sec-create-invoice.title": "Crear Factura"
};
const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
export class BuildFlowFsmInvoiceWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state ui.invoiceWorkspace.status — pageStatus */
        this.status = '';
        /** state ui.invoiceWorkspace.action.listInvoices.status — actionStatus, values: idle|loading|success|error */
        this.listInvoicesState = 'idle';
        /** state ui.invoiceWorkspace.input.listInvoices.status — input, form */
        this.listInvoicesStatus = '';
        /** state ui.invoiceWorkspace.input.listInvoices.projectId — input, form */
        this.listInvoicesProjectId = '';
        /** state ui.invoiceWorkspace.input.listInvoices.clientId — input, form */
        this.listInvoicesClientId = '';
        /** state ui.invoiceWorkspace.input.listInvoices.page — input, form */
        this.listInvoicesPage = '';
        /** state ui.invoiceWorkspace.input.listInvoices.pageSize — input, form */
        this.listInvoicesPageSize = '';
        /** state ui.invoiceWorkspace.data.listInvoices — queryResult, outputShape: paginated */
        this.listInvoicesData = { invoices: [], total: 0 };
        /** state ui.invoiceWorkspace.action.createInvoiceCmd.status — actionStatus, values: idle|loading|success|error */
        this.createInvoiceCmdState = 'idle';
        /** state ui.invoiceWorkspace.input.createInvoiceCmd.projectId — input, selection */
        this.createInvoiceCmdProjectId = '';
        /** state ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber — input, form */
        this.createInvoiceCmdInvoiceNumber = '';
        /** state ui.invoiceWorkspace.input.createInvoiceCmd.clientId — input, selection */
        this.createInvoiceCmdClientId = '';
        /** state ui.invoiceWorkspace.output.createInvoiceCmd — commandOutput, outputShape: object */
        this.createInvoiceCmdOutput = null;
        /** state ui.invoiceWorkspace.action.createInvoiceCmd.error — actionError */
        this.createInvoiceCmdError = '';
        /** state ui.invoiceWorkspace.action.sendInvoiceCmd.status — actionStatus, values: idle|loading|success|error */
        this.sendInvoiceCmdState = 'idle';
        /** state ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId — input, selection */
        this.sendInvoiceCmdInvoiceId = '';
        /** state ui.invoiceWorkspace.output.sendInvoiceCmd — commandOutput, outputShape: object */
        this.sendInvoiceCmdOutput = null;
        /** state ui.invoiceWorkspace.action.sendInvoiceCmd.error — actionError */
        this.sendInvoiceCmdError = '';
        this.subscribedKeys = [
            'ui.invoiceWorkspace.status',
            'ui.invoiceWorkspace.action.listInvoices.status',
            'ui.invoiceWorkspace.input.listInvoices.status',
            'ui.invoiceWorkspace.input.listInvoices.projectId',
            'ui.invoiceWorkspace.input.listInvoices.clientId',
            'ui.invoiceWorkspace.input.listInvoices.page',
            'ui.invoiceWorkspace.input.listInvoices.pageSize',
            'ui.invoiceWorkspace.data.listInvoices',
            'ui.invoiceWorkspace.action.createInvoiceCmd.status',
            'ui.invoiceWorkspace.input.createInvoiceCmd.projectId',
            'ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber',
            'ui.invoiceWorkspace.input.createInvoiceCmd.clientId',
            'ui.invoiceWorkspace.output.createInvoiceCmd',
            'ui.invoiceWorkspace.action.createInvoiceCmd.error',
            'ui.invoiceWorkspace.action.sendInvoiceCmd.status',
            'ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId',
            'ui.invoiceWorkspace.output.sendInvoiceCmd',
            'ui.invoiceWorkspace.action.sendInvoiceCmd.error'
        ];
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    /** handler for action listInvoices — bind UI events here */
    handleListInvoicesClick(_e) {
        this.loadListInvoices();
    }
    /** action listInvoices (query) — route buildFlowFsm.invoiceWorkspace.listInvoices; inputs: status, projectId, clientId, page, pageSize; writes ui.invoiceWorkspace.data.listInvoices; status ui.invoiceWorkspace.action.listInvoices.status */
    async loadListInvoices() {
        this.listInvoicesState = 'loading';
        setState('ui.invoiceWorkspace.action.listInvoices.status', 'loading');
        this.requestUpdate();
        const params = {
            status: this.listInvoicesStatus || undefined,
            projectId: this.listInvoicesProjectId || undefined,
            clientId: this.listInvoicesClientId || undefined,
            page: this.listInvoicesPage ? Number(this.listInvoicesPage) : undefined,
            pageSize: this.listInvoicesPageSize ? Number(this.listInvoicesPageSize) : undefined
        };
        const options = { mode: 'silent' };
        const response = await execBff(listInvoicesRoute, params, options);
        if (response.ok) {
            const data = response.data ?? { invoices: [], total: 0 };
            this.listInvoicesData = data;
            setState('ui.invoiceWorkspace.data.listInvoices', data);
            this.listInvoicesState = 'success';
            setState('ui.invoiceWorkspace.action.listInvoices.status', 'success');
        }
        else {
            this.listInvoicesState = 'error';
            setState('ui.invoiceWorkspace.action.listInvoices.status', 'error');
            if (response.error) {
                console.error('listInvoices error:', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action createInvoiceCmd — bind UI events here */
    handleCreateInvoiceCmdClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.createInvoiceCmd();
        });
    }
    /** action createInvoiceCmd (command) — route buildFlowFsm.invoiceWorkspace.createInvoiceCmd; inputs: projectId, invoiceNumber, clientId; writes ui.invoiceWorkspace.output.createInvoiceCmd; status ui.invoiceWorkspace.action.createInvoiceCmd.status; feedback keys action.createInvoiceCmd.success / action.createInvoiceCmd.error */
    async createInvoiceCmd() {
        this.createInvoiceCmdState = 'loading';
        setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'loading');
        this.createInvoiceCmdError = '';
        setState('ui.invoiceWorkspace.action.createInvoiceCmd.error', '');
        this.requestUpdate();
        const params = {
            projectId: this.createInvoiceCmdProjectId,
            invoiceNumber: this.createInvoiceCmdInvoiceNumber,
            clientId: this.createInvoiceCmdClientId
        };
        const options = { mode: 'blocking' };
        const response = await execBff(createInvoiceCmdRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.createInvoiceCmdOutput = data;
            setState('ui.invoiceWorkspace.output.createInvoiceCmd', data);
            // Refresh listInvoices before declaring success
            await this.loadListInvoices();
            if (this.listInvoicesState === 'error') {
                this.createInvoiceCmdState = 'error';
                setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'error');
                this.requestUpdate();
                return;
            }
            // Clear form inputs
            this.createInvoiceCmdProjectId = '';
            setState('ui.invoiceWorkspace.input.createInvoiceCmd.projectId', '');
            this.createInvoiceCmdInvoiceNumber = '';
            setState('ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber', '');
            this.createInvoiceCmdClientId = '';
            setState('ui.invoiceWorkspace.input.createInvoiceCmd.clientId', '');
            this.createInvoiceCmdState = 'success';
            setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? '';
            this.createInvoiceCmdError = errorMsg;
            setState('ui.invoiceWorkspace.action.createInvoiceCmd.error', errorMsg);
            this.createInvoiceCmdState = 'error';
            setState('ui.invoiceWorkspace.action.createInvoiceCmd.status', 'error');
        }
        this.requestUpdate();
    }
    /** handler for action sendInvoiceCmd — bind UI events here */
    handleSendInvoiceCmdClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.sendInvoiceCmd();
        });
    }
    /** action sendInvoiceCmd (command) — route buildFlowFsm.invoiceWorkspace.sendInvoiceCmd; inputs: invoiceId; writes ui.invoiceWorkspace.output.sendInvoiceCmd; status ui.invoiceWorkspace.action.sendInvoiceCmd.status; feedback keys action.sendInvoiceCmd.success / action.sendInvoiceCmd.error */
    async sendInvoiceCmd() {
        this.sendInvoiceCmdState = 'loading';
        setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'loading');
        this.sendInvoiceCmdError = '';
        setState('ui.invoiceWorkspace.action.sendInvoiceCmd.error', '');
        this.requestUpdate();
        const params = {
            invoiceId: this.sendInvoiceCmdInvoiceId
        };
        const options = { mode: 'blocking' };
        const response = await execBff(sendInvoiceCmdRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.sendInvoiceCmdOutput = data;
            setState('ui.invoiceWorkspace.output.sendInvoiceCmd', data);
            // Refresh listInvoices before declaring success
            await this.loadListInvoices();
            if (this.listInvoicesState === 'error') {
                this.sendInvoiceCmdState = 'error';
                setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'error');
                this.requestUpdate();
                return;
            }
            // Clear selection input
            this.sendInvoiceCmdInvoiceId = '';
            setState('ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId', '');
            this.sendInvoiceCmdState = 'success';
            setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? '';
            this.sendInvoiceCmdError = errorMsg;
            setState('ui.invoiceWorkspace.action.sendInvoiceCmd.error', errorMsg);
            this.sendInvoiceCmdState = 'error';
            setState('ui.invoiceWorkspace.action.sendInvoiceCmd.status', 'error');
        }
        this.requestUpdate();
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.status */
    setListInvoicesStatus(value) {
        this.listInvoicesStatus = value;
        setState('ui.invoiceWorkspace.input.listInvoices.status', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesStatus — bind UI events here */
    handleListInvoicesStatusChange(e) {
        const target = e.target;
        if (target) {
            this.setListInvoicesStatus(target.value);
        }
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.projectId */
    setListInvoicesProjectId(value) {
        this.listInvoicesProjectId = value;
        setState('ui.invoiceWorkspace.input.listInvoices.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesProjectId — bind UI events here */
    handleListInvoicesProjectIdChange(e) {
        const target = e.target;
        if (target) {
            this.setListInvoicesProjectId(target.value);
        }
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.clientId */
    setListInvoicesClientId(value) {
        this.listInvoicesClientId = value;
        setState('ui.invoiceWorkspace.input.listInvoices.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesClientId — bind UI events here */
    handleListInvoicesClientIdChange(e) {
        const target = e.target;
        if (target) {
            this.setListInvoicesClientId(target.value);
        }
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.page */
    setListInvoicesPage(value) {
        this.listInvoicesPage = value;
        setState('ui.invoiceWorkspace.input.listInvoices.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesPage — bind UI events here */
    handleListInvoicesPageChange(e) {
        const target = e.target;
        if (target) {
            this.setListInvoicesPage(target.value);
        }
    }
    /** setter for state ui.invoiceWorkspace.input.listInvoices.pageSize */
    setListInvoicesPageSize(value) {
        this.listInvoicesPageSize = value;
        setState('ui.invoiceWorkspace.input.listInvoices.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listInvoicesPageSize — bind UI events here */
    handleListInvoicesPageSizeChange(e) {
        const target = e.target;
        if (target) {
            this.setListInvoicesPageSize(target.value);
        }
    }
    /** setter for state ui.invoiceWorkspace.input.createInvoiceCmd.projectId */
    setCreateInvoiceCmdProjectId(value) {
        this.createInvoiceCmdProjectId = value;
        setState('ui.invoiceWorkspace.input.createInvoiceCmd.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.createInvoiceCmdProjectId — bind UI events here */
    handleCreateInvoiceCmdProjectIdChange(e) {
        const target = e.target;
        if (target) {
            this.setCreateInvoiceCmdProjectId(target.value);
        }
    }
    /** setter for state ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber */
    setCreateInvoiceCmdInvoiceNumber(value) {
        this.createInvoiceCmdInvoiceNumber = value;
        setState('ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber', value);
        this.requestUpdate();
    }
    /** handler for action set.createInvoiceCmdInvoiceNumber — bind UI events here */
    handleCreateInvoiceCmdInvoiceNumberChange(e) {
        const target = e.target;
        if (target) {
            this.setCreateInvoiceCmdInvoiceNumber(target.value);
        }
    }
    /** setter for state ui.invoiceWorkspace.input.createInvoiceCmd.clientId */
    setCreateInvoiceCmdClientId(value) {
        this.createInvoiceCmdClientId = value;
        setState('ui.invoiceWorkspace.input.createInvoiceCmd.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.createInvoiceCmdClientId — bind UI events here */
    handleCreateInvoiceCmdClientIdChange(e) {
        const target = e.target;
        if (target) {
            this.setCreateInvoiceCmdClientId(target.value);
        }
    }
    /** setter for state ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId */
    setSendInvoiceCmdInvoiceId(value) {
        this.sendInvoiceCmdInvoiceId = value;
        setState('ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId', value);
        this.requestUpdate();
    }
    /** handler for action set.sendInvoiceCmdInvoiceId — bind UI events here */
    handleSendInvoiceCmdInvoiceIdChange(e) {
        const target = e.target;
        if (target) {
            this.setSendInvoiceCmdInvoiceId(target.value);
        }
    }
    /** collabState notify handler — assigns external state changes to mapped class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.invoiceWorkspace.status':
                this.status = value;
                break;
            case 'ui.invoiceWorkspace.action.listInvoices.status':
                this.listInvoicesState = value;
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.status':
                this.listInvoicesStatus = value;
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.projectId':
                this.listInvoicesProjectId = value;
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.clientId':
                this.listInvoicesClientId = value;
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.page':
                this.listInvoicesPage = value;
                break;
            case 'ui.invoiceWorkspace.input.listInvoices.pageSize':
                this.listInvoicesPageSize = value;
                break;
            case 'ui.invoiceWorkspace.data.listInvoices':
                this.listInvoicesData = value;
                break;
            case 'ui.invoiceWorkspace.action.createInvoiceCmd.status':
                this.createInvoiceCmdState = value;
                break;
            case 'ui.invoiceWorkspace.input.createInvoiceCmd.projectId':
                this.createInvoiceCmdProjectId = value;
                break;
            case 'ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber':
                this.createInvoiceCmdInvoiceNumber = value;
                break;
            case 'ui.invoiceWorkspace.input.createInvoiceCmd.clientId':
                this.createInvoiceCmdClientId = value;
                break;
            case 'ui.invoiceWorkspace.output.createInvoiceCmd':
                this.createInvoiceCmdOutput = value;
                break;
            case 'ui.invoiceWorkspace.action.createInvoiceCmd.error':
                this.createInvoiceCmdError = value;
                break;
            case 'ui.invoiceWorkspace.action.sendInvoiceCmd.status':
                this.sendInvoiceCmdState = value;
                break;
            case 'ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId':
                this.sendInvoiceCmdInvoiceId = value;
                break;
            case 'ui.invoiceWorkspace.output.sendInvoiceCmd':
                this.sendInvoiceCmdOutput = value;
                break;
            case 'ui.invoiceWorkspace.action.sendInvoiceCmd.error':
                this.sendInvoiceCmdError = value;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    connectedCallback() {
        super.connectedCallback();
        // Initialize state from collabState where useful
        this.status = getState('ui.invoiceWorkspace.status') ?? '';
        this.listInvoicesState = getState('ui.invoiceWorkspace.action.listInvoices.status') ?? 'idle';
        this.listInvoicesStatus = getState('ui.invoiceWorkspace.input.listInvoices.status') ?? '';
        this.listInvoicesProjectId = getState('ui.invoiceWorkspace.input.listInvoices.projectId') ?? '';
        this.listInvoicesClientId = getState('ui.invoiceWorkspace.input.listInvoices.clientId') ?? '';
        this.listInvoicesPage = getState('ui.invoiceWorkspace.input.listInvoices.page') ?? '';
        this.listInvoicesPageSize = getState('ui.invoiceWorkspace.input.listInvoices.pageSize') ?? '';
        const storedListInvoicesData = getState('ui.invoiceWorkspace.data.listInvoices');
        this.listInvoicesData = storedListInvoicesData ?? { invoices: [], total: 0 };
        this.createInvoiceCmdState = getState('ui.invoiceWorkspace.action.createInvoiceCmd.status') ?? 'idle';
        this.createInvoiceCmdProjectId = getState('ui.invoiceWorkspace.input.createInvoiceCmd.projectId') ?? '';
        this.createInvoiceCmdInvoiceNumber = getState('ui.invoiceWorkspace.input.createInvoiceCmd.invoiceNumber') ?? '';
        this.createInvoiceCmdClientId = getState('ui.invoiceWorkspace.input.createInvoiceCmd.clientId') ?? '';
        this.createInvoiceCmdOutput = getState('ui.invoiceWorkspace.output.createInvoiceCmd') ?? null;
        this.createInvoiceCmdError = getState('ui.invoiceWorkspace.action.createInvoiceCmd.error') ?? '';
        this.sendInvoiceCmdState = getState('ui.invoiceWorkspace.action.sendInvoiceCmd.status') ?? 'idle';
        this.sendInvoiceCmdInvoiceId = getState('ui.invoiceWorkspace.input.sendInvoiceCmd.invoiceId') ?? '';
        this.sendInvoiceCmdOutput = getState('ui.invoiceWorkspace.output.sendInvoiceCmd') ?? null;
        this.sendInvoiceCmdError = getState('ui.invoiceWorkspace.action.sendInvoiceCmd.error') ?? '';
        // Subscribe to shared states
        subscribe(this.subscribedKeys, this);
        // Run initial loads
        this.loadListInvoices();
    }
    disconnectedCallback() {
        unsubscribe(this.subscribedKeys, this);
        super.disconnectedCallback();
    }
}
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesStatus", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesClientId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesPage", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "listInvoicesData", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdInvoiceNumber", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdClientId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdOutput", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "createInvoiceCmdError", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "sendInvoiceCmdState", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "sendInvoiceCmdInvoiceId", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "sendInvoiceCmdOutput", void 0);
__decorate([
    property()
], BuildFlowFsmInvoiceWorkspaceBase.prototype, "sendInvoiceCmdError", void 0);
