/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/taskBoardWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
import { cmdCreateWorkTaskRoute, cmdUpdateWorkTaskRoute, cmdUpdateWorkTaskStatusRoute } from '/_102045_/l2/buildFlowFsm/web/contracts/taskBoardWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    "section.taskBoardWorkspace.createTaskSection.title": "Create Work Task",
    "organism.taskBoardWorkspace.cmdCreateWorkTask.title": "Create work task",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.title": "Create work task",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.action.cmdCreateWorkTask": "Create work task",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.title.label": "Title",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.description.label": "Description",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.assignedWorkerId.label": "Assigned Worker Id",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.dueDate.label": "Due Date",
    "section.taskBoardWorkspace.editTaskSection.title": "Edit Work Task",
    "organism.taskBoardWorkspace.cmdUpdateWorkTask.title": "Update work task assignment and details",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.title": "Update work task assignment and details",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask": "Update work task assignment and details",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.title.label": "Title",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.description.label": "Description",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.assignedWorkerId.label": "Assigned Worker Id",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.dueDate.label": "Due Date",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.status.label": "Status",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.cancellationReason.label": "Cancellation Reason",
    "section.taskBoardWorkspace.fieldStatusSection.title": "Update Task Status",
    "organism.taskBoardWorkspace.cmdUpdateWorkTaskStatus.title": "Update work task status",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.title": "Update work task status",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.action.cmdUpdateWorkTaskStatus": "Update work task status",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.status.label": "Status",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.cancellationReason.label": "Cancellation Reason",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.completedAt.label": "Completed At",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.actorId.label": "Actor Id",
    "section.taskBoardWorkspace.sec-board.title": "Task Board",
    "organism.taskBoardWorkspace.card-board10.title": "Card board",
    "intent.taskBoardWorkspace.card-board10.content.title": "Card board",
    "section.taskBoardWorkspace.sec-task-detail.title": "Task Detail & Edit",
    "section.taskBoardWorkspace.sec-create-task.title": "Create Task"
};
const message_pt_br = {
    "section.taskBoardWorkspace.createTaskSection.title": "Criar Tarefa de Trabalho",
    "organism.taskBoardWorkspace.cmdCreateWorkTask.title": "Criar tarefa de trabalho",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.title": "Criar tarefa de trabalho",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.action.cmdCreateWorkTask": "Criar tarefa de trabalho",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.title.label": "Título",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.description.label": "Descrição",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.assignedWorkerId.label": "ID do Trabalhador Designado",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.dueDate.label": "Data de Vencimento",
    "section.taskBoardWorkspace.editTaskSection.title": "Editar Tarefa de Trabalho",
    "organism.taskBoardWorkspace.cmdUpdateWorkTask.title": "Atualizar atribuição e detalhes da tarefa de trabalho",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.title": "Atualizar atribuição e detalhes da tarefa de trabalho",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask": "Atualizar atribuição e detalhes da tarefa de trabalho",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.title.label": "Título",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.description.label": "Descrição",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.assignedWorkerId.label": "ID do Trabalhador Designado",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.dueDate.label": "Data de Vencimento",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.status.label": "Status",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.cancellationReason.label": "Motivo do Cancelamento",
    "section.taskBoardWorkspace.fieldStatusSection.title": "Atualizar Status da Tarefa",
    "organism.taskBoardWorkspace.cmdUpdateWorkTaskStatus.title": "Atualizar status da tarefa de trabalho",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.title": "Atualizar status da tarefa de trabalho",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.action.cmdUpdateWorkTaskStatus": "Atualizar status da tarefa de trabalho",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.status.label": "Status",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.cancellationReason.label": "Motivo do Cancelamento",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.completedAt.label": "Concluído Em",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.actorId.label": "ID do Ator",
    "section.taskBoardWorkspace.sec-board.title": "Quadro de Tarefas",
    "organism.taskBoardWorkspace.card-board10.title": "Quadro de Cartões",
    "intent.taskBoardWorkspace.card-board10.content.title": "Quadro de Cartões",
    "section.taskBoardWorkspace.sec-task-detail.title": "Detalhes e Edição da Tarefa",
    "section.taskBoardWorkspace.sec-create-task.title": "Criar Tarefa"
};
const message_es = {
    "section.taskBoardWorkspace.createTaskSection.title": "Crear Tarea de Trabajo",
    "organism.taskBoardWorkspace.cmdCreateWorkTask.title": "Crear tarea de trabajo",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.title": "Crear tarea de trabajo",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.action.cmdCreateWorkTask": "Crear tarea de trabajo",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.title.label": "Título",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.description.label": "Descripción",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.assignedWorkerId.label": "ID del Trabajador Asignado",
    "intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.dueDate.label": "Fecha de Vencimiento",
    "section.taskBoardWorkspace.editTaskSection.title": "Editar Tarea de Trabajo",
    "organism.taskBoardWorkspace.cmdUpdateWorkTask.title": "Actualizar asignación y detalles de la tarea de trabajo",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.title": "Actualizar asignación y detalles de la tarea de trabajo",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask": "Actualizar asignación y detalles de la tarea de trabajo",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.title.label": "Título",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.description.label": "Descripción",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.assignedWorkerId.label": "ID del Trabajador Asignado",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.dueDate.label": "Fecha de Vencimiento",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.status.label": "Estado",
    "intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.cancellationReason.label": "Razón de Cancelación",
    "section.taskBoardWorkspace.fieldStatusSection.title": "Actualizar Estado de la Tarea",
    "organism.taskBoardWorkspace.cmdUpdateWorkTaskStatus.title": "Actualizar estado de la tarea de trabajo",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.title": "Actualizar estado de la tarea de trabajo",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.action.cmdUpdateWorkTaskStatus": "Actualizar estado de la tarea de trabajo",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.status.label": "Estado",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.cancellationReason.label": "Razón de Cancelación",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.completedAt.label": "Completado En",
    "intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.actorId.label": "ID del Actor",
    "section.taskBoardWorkspace.sec-board.title": "Tablero de Tareas",
    "organism.taskBoardWorkspace.card-board10.title": "Tablero de Tarjetas",
    "intent.taskBoardWorkspace.card-board10.content.title": "Tablero de Tarjetas",
    "section.taskBoardWorkspace.sec-task-detail.title": "Detalle y Edición de la Tarea",
    "section.taskBoardWorkspace.sec-create-task.title": "Crear Tarea"
};
const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
export class BuildFlowFsmTaskBoardWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state ui.taskBoardWorkspace.status — pageStatus */
        this.status = '';
        /** state ui.taskBoardWorkspace.action.cmdCreateWorkTask.status — actionStatus, values: idle|loading|success|error */
        this.cmdCreateWorkTaskState = 'idle';
        /** state ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId — input, selection */
        this.cmdCreateWorkTaskProjectId = '';
        /** state ui.taskBoardWorkspace.input.cmdCreateWorkTask.title — input, form */
        this.cmdCreateWorkTaskTitle = '';
        /** state ui.taskBoardWorkspace.input.cmdCreateWorkTask.description — input, form */
        this.cmdCreateWorkTaskDescription = '';
        /** state ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId — input, form */
        this.cmdCreateWorkTaskAssignedWorkerId = '';
        /** state ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate — input, form */
        this.cmdCreateWorkTaskDueDate = '';
        /** state ui.taskBoardWorkspace.output.cmdCreateWorkTask — commandOutput, outputShape: object */
        this.cmdCreateWorkTaskOutput = null;
        /** state ui.taskBoardWorkspace.action.cmdCreateWorkTask.error — actionError */
        this.cmdCreateWorkTaskError = '';
        /** state ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateWorkTaskState = 'idle';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId — input, route */
        this.cmdUpdateWorkTaskWorkTaskId = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title — input, form */
        this.cmdUpdateWorkTaskTitle = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description — input, form */
        this.cmdUpdateWorkTaskDescription = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId — input, form */
        this.cmdUpdateWorkTaskAssignedWorkerId = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate — input, form */
        this.cmdUpdateWorkTaskDueDate = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status — input, form */
        this.cmdUpdateWorkTaskStatusValue = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason — input, form */
        this.cmdUpdateWorkTaskCancellationReason = '';
        /** state ui.taskBoardWorkspace.output.cmdUpdateWorkTask — commandOutput, outputShape: object */
        this.cmdUpdateWorkTaskOutput = null;
        /** state ui.taskBoardWorkspace.action.cmdUpdateWorkTask.error — actionError */
        this.cmdUpdateWorkTaskError = '';
        /** state ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateWorkTaskStatusState = 'idle';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId — input, selection */
        this.cmdUpdateWorkTaskStatusWorkTaskId = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status — input, form */
        this.cmdUpdateWorkTaskStatusStatus = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason — input, form */
        this.cmdUpdateWorkTaskStatusCancellationReason = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt — input, form */
        this.cmdUpdateWorkTaskStatusCompletedAt = '';
        /** state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId — input, form */
        this.cmdUpdateWorkTaskStatusActorId = '';
        /** state ui.taskBoardWorkspace.output.cmdUpdateWorkTaskStatus — commandOutput, outputShape: object */
        this.cmdUpdateWorkTaskStatusOutput = null;
        /** state ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.error — actionError */
        this.cmdUpdateWorkTaskStatusError = '';
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    /**
     * Parse the route pattern `/buildFlowFsm/taskBoardWorkspace/:workTaskId?`
     * against the current window.location.pathname and return a map of param name to decoded value.
     */
    parseRouteParams() {
        const pattern = '/buildFlowFsm/taskBoardWorkspace/:workTaskId?';
        const path = window.location.pathname;
        const patternParts = pattern.split('/').filter((p) => p.length > 0);
        const pathParts = path.split('/').filter((p) => p.length > 0);
        const result = {};
        for (let i = 0; i < patternParts.length; i++) {
            const pPart = patternParts[i];
            if (pPart.startsWith(':')) {
                const isOptional = pPart.endsWith('?');
                const paramName = isOptional ? pPart.slice(1, -1) : pPart.slice(1);
                if (i < pathParts.length) {
                    try {
                        result[paramName] = decodeURIComponent(pathParts[i]);
                    }
                    catch {
                        result[paramName] = pathParts[i];
                    }
                }
            }
        }
        return result;
    }
    /** action cmdCreateWorkTask (command) — route buildFlowFsm.taskBoardWorkspace.cmdCreateWorkTask; inputs: projectId, title, description, assignedWorkerId, dueDate; writes cmdCreateWorkTaskOutput; status cmdCreateWorkTaskState; feedback keys action.cmdCreateWorkTask.success / action.cmdCreateWorkTask.error */
    async cmdCreateWorkTask(signal) {
        this.cmdCreateWorkTaskState = 'loading';
        setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.status', 'loading');
        const params = {
            projectId: this.cmdCreateWorkTaskProjectId,
            title: this.cmdCreateWorkTaskTitle,
            description: this.cmdCreateWorkTaskDescription,
            assignedWorkerId: this.cmdCreateWorkTaskAssignedWorkerId,
            dueDate: this.cmdCreateWorkTaskDueDate,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff(cmdCreateWorkTaskRoute, params, options);
        if (response.ok) {
            this.cmdCreateWorkTaskOutput = response.data ?? null;
            setState('ui.taskBoardWorkspace.output.cmdCreateWorkTask', this.cmdCreateWorkTaskOutput);
            // Clear input state keys
            this.cmdCreateWorkTaskProjectId = '';
            setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId', '');
            this.cmdCreateWorkTaskTitle = '';
            setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.title', '');
            this.cmdCreateWorkTaskDescription = '';
            setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.description', '');
            this.cmdCreateWorkTaskAssignedWorkerId = '';
            setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId', '');
            this.cmdCreateWorkTaskDueDate = '';
            setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate', '');
            this.cmdCreateWorkTaskError = '';
            setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.error', '');
            this.cmdCreateWorkTaskState = 'success';
            setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? '';
            this.cmdCreateWorkTaskError = errorMsg;
            setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.error', errorMsg);
            this.cmdCreateWorkTaskState = 'error';
            setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.status', 'error');
        }
        this.requestUpdate();
    }
    /** handler for action cmdCreateWorkTask — bind UI events here */
    handleCmdCreateWorkTaskClick() {
        runBlockingUiAction(async (signal) => {
            await this.cmdCreateWorkTask(signal);
        }, { mode: 'blocking' });
    }
    /** action cmdUpdateWorkTask (command) — route buildFlowFsm.taskBoardWorkspace.cmdUpdateWorkTask; inputs: workTaskId, title, description, assignedWorkerId, dueDate, status, cancellationReason; writes cmdUpdateWorkTaskOutput; status cmdUpdateWorkTaskState; feedback keys action.cmdUpdateWorkTask.success / action.cmdUpdateWorkTask.error */
    async cmdUpdateWorkTask(signal) {
        // Parse route params for workTaskId
        const routeParams = this.parseRouteParams();
        const routeWorkTaskId = routeParams['workTaskId'] ?? '';
        if (routeWorkTaskId) {
            this.cmdUpdateWorkTaskWorkTaskId = routeWorkTaskId;
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId', routeWorkTaskId);
        }
        // If required route param is absent, do not call execBff
        if (!this.cmdUpdateWorkTaskWorkTaskId) {
            this.cmdUpdateWorkTaskState = 'idle';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateWorkTaskState = 'loading';
        setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status', 'loading');
        const params = {
            workTaskId: this.cmdUpdateWorkTaskWorkTaskId,
            title: this.cmdUpdateWorkTaskTitle,
            description: this.cmdUpdateWorkTaskDescription,
            assignedWorkerId: this.cmdUpdateWorkTaskAssignedWorkerId,
            dueDate: this.cmdUpdateWorkTaskDueDate,
            status: this.cmdUpdateWorkTaskStatusValue,
            cancellationReason: this.cmdUpdateWorkTaskCancellationReason,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff(cmdUpdateWorkTaskRoute, params, options);
        if (response.ok) {
            this.cmdUpdateWorkTaskOutput = response.data ?? null;
            setState('ui.taskBoardWorkspace.output.cmdUpdateWorkTask', this.cmdUpdateWorkTaskOutput);
            // Clear input state keys (not workTaskId — it is a route param)
            this.cmdUpdateWorkTaskTitle = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title', '');
            this.cmdUpdateWorkTaskDescription = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description', '');
            this.cmdUpdateWorkTaskAssignedWorkerId = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId', '');
            this.cmdUpdateWorkTaskDueDate = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate', '');
            this.cmdUpdateWorkTaskStatusValue = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status', '');
            this.cmdUpdateWorkTaskCancellationReason = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason', '');
            this.cmdUpdateWorkTaskError = '';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.error', '');
            this.cmdUpdateWorkTaskState = 'success';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? '';
            this.cmdUpdateWorkTaskError = errorMsg;
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.error', errorMsg);
            this.cmdUpdateWorkTaskState = 'error';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status', 'error');
        }
        this.requestUpdate();
    }
    /** handler for action cmdUpdateWorkTask — bind UI events here */
    handleCmdUpdateWorkTaskClick() {
        runBlockingUiAction(async (signal) => {
            await this.cmdUpdateWorkTask(signal);
        }, { mode: 'blocking' });
    }
    /** action cmdUpdateWorkTaskStatus (command) — route buildFlowFsm.taskBoardWorkspace.cmdUpdateWorkTaskStatus; inputs: workTaskId, status, cancellationReason, completedAt, actorId; writes cmdUpdateWorkTaskStatusOutput; status cmdUpdateWorkTaskStatusState; feedback keys action.cmdUpdateWorkTaskStatus.success / action.cmdUpdateWorkTaskStatus.error */
    async cmdUpdateWorkTaskStatus(signal) {
        this.cmdUpdateWorkTaskStatusState = 'loading';
        setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status', 'loading');
        const params = {
            workTaskId: this.cmdUpdateWorkTaskStatusWorkTaskId,
            status: this.cmdUpdateWorkTaskStatusStatus,
            cancellationReason: this.cmdUpdateWorkTaskStatusCancellationReason,
            completedAt: this.cmdUpdateWorkTaskStatusCompletedAt,
            actorId: this.cmdUpdateWorkTaskStatusActorId,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff(cmdUpdateWorkTaskStatusRoute, params, options);
        if (response.ok) {
            this.cmdUpdateWorkTaskStatusOutput = response.data ?? null;
            setState('ui.taskBoardWorkspace.output.cmdUpdateWorkTaskStatus', this.cmdUpdateWorkTaskStatusOutput);
            // Clear input state keys
            this.cmdUpdateWorkTaskStatusWorkTaskId = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId', '');
            this.cmdUpdateWorkTaskStatusStatus = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status', '');
            this.cmdUpdateWorkTaskStatusCancellationReason = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason', '');
            this.cmdUpdateWorkTaskStatusCompletedAt = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt', '');
            this.cmdUpdateWorkTaskStatusActorId = '';
            setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId', '');
            this.cmdUpdateWorkTaskStatusError = '';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.error', '');
            this.cmdUpdateWorkTaskStatusState = 'success';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? '';
            this.cmdUpdateWorkTaskStatusError = errorMsg;
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.error', errorMsg);
            this.cmdUpdateWorkTaskStatusState = 'error';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status', 'error');
        }
        this.requestUpdate();
    }
    /** handler for action cmdUpdateWorkTaskStatus — bind UI events here */
    handleCmdUpdateWorkTaskStatusClick() {
        runBlockingUiAction(async (signal) => {
            await this.cmdUpdateWorkTaskStatus(signal);
        }, { mode: 'blocking' });
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId */
    setCmdCreateWorkTaskProjectId(value) {
        this.cmdCreateWorkTaskProjectId = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskProjectId — bind UI events here */
    handleCmdCreateWorkTaskProjectIdChange(e) {
        const target = e.target;
        this.setCmdCreateWorkTaskProjectId(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.title */
    setCmdCreateWorkTaskTitle(value) {
        this.cmdCreateWorkTaskTitle = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.title', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskTitle — bind UI events here */
    handleCmdCreateWorkTaskTitleChange(e) {
        const target = e.target;
        this.setCmdCreateWorkTaskTitle(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.description */
    setCmdCreateWorkTaskDescription(value) {
        this.cmdCreateWorkTaskDescription = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskDescription — bind UI events here */
    handleCmdCreateWorkTaskDescriptionChange(e) {
        const target = e.target;
        this.setCmdCreateWorkTaskDescription(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId */
    setCmdCreateWorkTaskAssignedWorkerId(value) {
        this.cmdCreateWorkTaskAssignedWorkerId = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskAssignedWorkerId — bind UI events here */
    handleCmdCreateWorkTaskAssignedWorkerIdChange(e) {
        const target = e.target;
        this.setCmdCreateWorkTaskAssignedWorkerId(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate */
    setCmdCreateWorkTaskDueDate(value) {
        this.cmdCreateWorkTaskDueDate = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskDueDate — bind UI events here */
    handleCmdCreateWorkTaskDueDateChange(e) {
        const target = e.target;
        this.setCmdCreateWorkTaskDueDate(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId */
    setCmdUpdateWorkTaskWorkTaskId(value) {
        this.cmdUpdateWorkTaskWorkTaskId = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskWorkTaskId — bind UI events here */
    handleCmdUpdateWorkTaskWorkTaskIdChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskWorkTaskId(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title */
    setCmdUpdateWorkTaskTitle(value) {
        this.cmdUpdateWorkTaskTitle = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskTitle — bind UI events here */
    handleCmdUpdateWorkTaskTitleChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskTitle(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description */
    setCmdUpdateWorkTaskDescription(value) {
        this.cmdUpdateWorkTaskDescription = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskDescription — bind UI events here */
    handleCmdUpdateWorkTaskDescriptionChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskDescription(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId */
    setCmdUpdateWorkTaskAssignedWorkerId(value) {
        this.cmdUpdateWorkTaskAssignedWorkerId = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskAssignedWorkerId — bind UI events here */
    handleCmdUpdateWorkTaskAssignedWorkerIdChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskAssignedWorkerId(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate */
    setCmdUpdateWorkTaskDueDate(value) {
        this.cmdUpdateWorkTaskDueDate = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskDueDate — bind UI events here */
    handleCmdUpdateWorkTaskDueDateChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskDueDate(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status */
    setCmdUpdateWorkTaskStatusValue(value) {
        this.cmdUpdateWorkTaskStatusValue = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusValue — bind UI events here */
    handleCmdUpdateWorkTaskStatusValueChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskStatusValue(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason */
    setCmdUpdateWorkTaskCancellationReason(value) {
        this.cmdUpdateWorkTaskCancellationReason = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskCancellationReason — bind UI events here */
    handleCmdUpdateWorkTaskCancellationReasonChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskCancellationReason(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId */
    setCmdUpdateWorkTaskStatusWorkTaskId(value) {
        this.cmdUpdateWorkTaskStatusWorkTaskId = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusWorkTaskId — bind UI events here */
    handleCmdUpdateWorkTaskStatusWorkTaskIdChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskStatusWorkTaskId(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status */
    setCmdUpdateWorkTaskStatusStatus(value) {
        this.cmdUpdateWorkTaskStatusStatus = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusStatus — bind UI events here */
    handleCmdUpdateWorkTaskStatusStatusChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskStatusStatus(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason */
    setCmdUpdateWorkTaskStatusCancellationReason(value) {
        this.cmdUpdateWorkTaskStatusCancellationReason = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusCancellationReason — bind UI events here */
    handleCmdUpdateWorkTaskStatusCancellationReasonChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskStatusCancellationReason(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt */
    setCmdUpdateWorkTaskStatusCompletedAt(value) {
        this.cmdUpdateWorkTaskStatusCompletedAt = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusCompletedAt — bind UI events here */
    handleCmdUpdateWorkTaskStatusCompletedAtChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskStatusCompletedAt(target.value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId */
    setCmdUpdateWorkTaskStatusActorId(value) {
        this.cmdUpdateWorkTaskStatusActorId = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusActorId — bind UI events here */
    handleCmdUpdateWorkTaskStatusActorIdChange(e) {
        const target = e.target;
        this.setCmdUpdateWorkTaskStatusActorId(target.value);
    }
    connectedCallback() {
        super.connectedCallback();
        // Initialize state from getState where useful, falling back to defaultValue
        const savedStatus = getState('ui.taskBoardWorkspace.status');
        if (savedStatus !== undefined) {
            this.status = savedStatus;
        }
        // No initialLoads to run; no shared state subscriptions needed
    }
    disconnectedCallback() {
        // No subscriptions to unsubscribe
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskProjectId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskTitle", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskDescription", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskAssignedWorkerId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskDueDate", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskError", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskWorkTaskId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskTitle", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskDescription", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskAssignedWorkerId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskDueDate", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusValue", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskCancellationReason", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskError", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusWorkTaskId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusStatus", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusCancellationReason", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusCompletedAt", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusActorId", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusError", void 0);
