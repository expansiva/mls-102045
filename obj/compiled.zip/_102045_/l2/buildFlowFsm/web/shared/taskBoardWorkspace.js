/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/taskBoardWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { cmdCreateWorkTaskRoute, cmdUpdateWorkTaskRoute, cmdUpdateWorkTaskStatusRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/taskBoardWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    'section.taskBoardWorkspace.createTaskSection.title': 'Create Work Task',
    'organism.taskBoardWorkspace.cmdCreateWorkTask.title': 'Create work task',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.title': 'Create work task',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.action.cmdCreateWorkTask': 'Create work task',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.title.label': 'Title',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.description.label': 'Description',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.dueDate.label': 'Due Date',
    'section.taskBoardWorkspace.editTaskSection.title': 'Edit Work Task',
    'organism.taskBoardWorkspace.cmdUpdateWorkTask.title': 'Update work task assignment and details',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.title': 'Update work task assignment and details',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask': 'Update work task assignment and details',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.title.label': 'Title',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.description.label': 'Description',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.dueDate.label': 'Due Date',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.status.label': 'Status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.cancellationReason.label': 'Cancellation Reason',
    'section.taskBoardWorkspace.fieldStatusSection.title': 'Update Task Status',
    'organism.taskBoardWorkspace.cmdUpdateWorkTaskStatus.title': 'Update work task status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.title': 'Update work task status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.action.cmdUpdateWorkTaskStatus': 'Update work task status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.status.label': 'Status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.cancellationReason.label': 'Cancellation Reason',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.completedAt.label': 'Completed At',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.actorId.label': 'Actor Id',
    'action.cmdCreateWorkTask.success': 'Create work task: OK',
    'action.cmdCreateWorkTask.error': 'Create work task: falhou',
    'action.cmdUpdateWorkTask.success': 'Update work task assignment and details: OK',
    'action.cmdUpdateWorkTask.error': 'Update work task assignment and details: falhou',
    'action.cmdUpdateWorkTaskStatus.success': 'Update work task status: OK',
    'action.cmdUpdateWorkTaskStatus.error': 'Update work task status: falhou',
    'section.taskBoardWorkspace.sec-task-board.title': 'Task Board',
    'organism.taskBoardWorkspace.card-board10.title': 'Card board',
    'intent.taskBoardWorkspace.card-board10.content.title': 'Card board',
    'section.taskBoardWorkspace.sec-task-detail.title': 'Task Detail Panel',
    'organism.taskBoardWorkspace.summary-first10.title': 'Summary first',
    'intent.taskBoardWorkspace.summary-first10.content.title': 'Summary first',
    'section.taskBoardWorkspace.sec-create-task.title': 'Create New Task',
    'section.taskBoardWorkspace.sec-board-toolbar.title': 'Board Toolbar',
};
const message_pt_br = {
    'section.taskBoardWorkspace.createTaskSection.title': 'Create Work Task',
    'organism.taskBoardWorkspace.cmdCreateWorkTask.title': 'Create work task',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.title': 'Create work task',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.action.cmdCreateWorkTask': 'Create work task',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.title.label': 'Title',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.description.label': 'Description',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.dueDate.label': 'Due Date',
    'section.taskBoardWorkspace.editTaskSection.title': 'Edit Work Task',
    'organism.taskBoardWorkspace.cmdUpdateWorkTask.title': 'Update work task assignment and details',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.title': 'Update work task assignment and details',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask': 'Update work task assignment and details',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.title.label': 'Title',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.description.label': 'Description',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.dueDate.label': 'Due Date',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.status.label': 'Status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.cancellationReason.label': 'Cancellation Reason',
    'section.taskBoardWorkspace.fieldStatusSection.title': 'Update Task Status',
    'organism.taskBoardWorkspace.cmdUpdateWorkTaskStatus.title': 'Update work task status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.title': 'Update work task status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.action.cmdUpdateWorkTaskStatus': 'Update work task status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.status.label': 'Status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.cancellationReason.label': 'Cancellation Reason',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.completedAt.label': 'Completed At',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.actorId.label': 'Actor Id',
    'action.cmdCreateWorkTask.success': 'Create work task: OK',
    'action.cmdCreateWorkTask.error': 'Create work task: falhou',
    'action.cmdUpdateWorkTask.success': 'Update work task assignment and details: OK',
    'action.cmdUpdateWorkTask.error': 'Update work task assignment and details: falhou',
    'action.cmdUpdateWorkTaskStatus.success': 'Update work task status: OK',
    'action.cmdUpdateWorkTaskStatus.error': 'Update work task status: falhou',
    'section.taskBoardWorkspace.sec-task-board.title': 'Task Board',
    'organism.taskBoardWorkspace.card-board10.title': 'Card board',
    'intent.taskBoardWorkspace.card-board10.content.title': 'Card board',
    'section.taskBoardWorkspace.sec-task-detail.title': 'Task Detail Panel',
    'organism.taskBoardWorkspace.summary-first10.title': 'Summary first',
    'intent.taskBoardWorkspace.summary-first10.content.title': 'Summary first',
    'section.taskBoardWorkspace.sec-create-task.title': 'Create New Task',
    'section.taskBoardWorkspace.sec-board-toolbar.title': 'Board Toolbar',
};
const message_es = {
    'section.taskBoardWorkspace.createTaskSection.title': 'Create Work Task',
    'organism.taskBoardWorkspace.cmdCreateWorkTask.title': 'Create work task',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.title': 'Create work task',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.action.cmdCreateWorkTask': 'Create work task',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.title.label': 'Title',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.description.label': 'Description',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.taskBoardWorkspace.cmdCreateWorkTask.form.field.dueDate.label': 'Due Date',
    'section.taskBoardWorkspace.editTaskSection.title': 'Edit Work Task',
    'organism.taskBoardWorkspace.cmdUpdateWorkTask.title': 'Update work task assignment and details',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.title': 'Update work task assignment and details',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.action.cmdUpdateWorkTask': 'Update work task assignment and details',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.title.label': 'Title',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.description.label': 'Description',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.dueDate.label': 'Due Date',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.status.label': 'Status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTask.form.field.cancellationReason.label': 'Cancellation Reason',
    'section.taskBoardWorkspace.fieldStatusSection.title': 'Update Task Status',
    'organism.taskBoardWorkspace.cmdUpdateWorkTaskStatus.title': 'Update work task status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.title': 'Update work task status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.action.cmdUpdateWorkTaskStatus': 'Update work task status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.status.label': 'Status',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.cancellationReason.label': 'Cancellation Reason',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.completedAt.label': 'Completed At',
    'intent.taskBoardWorkspace.cmdUpdateWorkTaskStatus.form.field.actorId.label': 'Actor Id',
    'action.cmdCreateWorkTask.success': 'Create work task: OK',
    'action.cmdCreateWorkTask.error': 'Create work task: falhou',
    'action.cmdUpdateWorkTask.success': 'Update work task assignment and details: OK',
    'action.cmdUpdateWorkTask.error': 'Update work task assignment and details: falhou',
    'action.cmdUpdateWorkTaskStatus.success': 'Update work task status: OK',
    'action.cmdUpdateWorkTaskStatus.error': 'Update work task status: falhou',
    'section.taskBoardWorkspace.sec-task-board.title': 'Task Board',
    'organism.taskBoardWorkspace.card-board10.title': 'Card board',
    'intent.taskBoardWorkspace.card-board10.content.title': 'Card board',
    'section.taskBoardWorkspace.sec-task-detail.title': 'Task Detail Panel',
    'organism.taskBoardWorkspace.summary-first10.title': 'Summary first',
    'intent.taskBoardWorkspace.summary-first10.content.title': 'Summary first',
    'section.taskBoardWorkspace.sec-create-task.title': 'Create New Task',
    'section.taskBoardWorkspace.sec-board-toolbar.title': 'Board Toolbar',
};
export const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.taskBoardWorkspace.status',
    'ui.taskBoardWorkspace.action.cmdCreateWorkTask.status',
    'ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId',
    'ui.taskBoardWorkspace.input.cmdCreateWorkTask.title',
    'ui.taskBoardWorkspace.input.cmdCreateWorkTask.description',
    'ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId',
    'ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate',
    'ui.taskBoardWorkspace.output.cmdCreateWorkTask',
    'ui.taskBoardWorkspace.action.cmdCreateWorkTask.error',
    'ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason',
    'ui.taskBoardWorkspace.output.cmdUpdateWorkTask',
    'ui.taskBoardWorkspace.action.cmdUpdateWorkTask.error',
    'ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt',
    'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId',
    'ui.taskBoardWorkspace.output.cmdUpdateWorkTaskStatus',
    'ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.error',
];
export class BuildFlowFsmTaskBoardWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state cmdCreateWorkTaskState — actionStatus, values: idle|loading|success|error */
        this.cmdCreateWorkTaskState = 'idle';
        /** state cmdCreateWorkTaskProjectId — input */
        this.cmdCreateWorkTaskProjectId = '';
        /** state cmdCreateWorkTaskTitle — input */
        this.cmdCreateWorkTaskTitle = '';
        /** state cmdCreateWorkTaskDescription — input */
        this.cmdCreateWorkTaskDescription = '';
        /** state cmdCreateWorkTaskAssignedWorkerId — input */
        this.cmdCreateWorkTaskAssignedWorkerId = '';
        /** state cmdCreateWorkTaskDueDate — input */
        this.cmdCreateWorkTaskDueDate = '';
        /** state cmdCreateWorkTaskOutput — commandOutput */
        this.cmdCreateWorkTaskOutput = null;
        /** state cmdCreateWorkTaskError — actionError */
        this.cmdCreateWorkTaskError = '';
        /** state cmdUpdateWorkTaskState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateWorkTaskState = 'idle';
        /** state cmdUpdateWorkTaskWorkTaskId — input */
        this.cmdUpdateWorkTaskWorkTaskId = '';
        /** state cmdUpdateWorkTaskTitle — input */
        this.cmdUpdateWorkTaskTitle = '';
        /** state cmdUpdateWorkTaskDescription — input */
        this.cmdUpdateWorkTaskDescription = '';
        /** state cmdUpdateWorkTaskAssignedWorkerId — input */
        this.cmdUpdateWorkTaskAssignedWorkerId = '';
        /** state cmdUpdateWorkTaskDueDate — input */
        this.cmdUpdateWorkTaskDueDate = '';
        /** state cmdUpdateWorkTaskStatusValue — input */
        this.cmdUpdateWorkTaskStatusValue = '';
        /** state cmdUpdateWorkTaskCancellationReason — input */
        this.cmdUpdateWorkTaskCancellationReason = '';
        /** state cmdUpdateWorkTaskOutput — commandOutput */
        this.cmdUpdateWorkTaskOutput = null;
        /** state cmdUpdateWorkTaskError — actionError */
        this.cmdUpdateWorkTaskError = '';
        /** state cmdUpdateWorkTaskStatusState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateWorkTaskStatusState = 'idle';
        /** state cmdUpdateWorkTaskStatusWorkTaskId — input */
        this.cmdUpdateWorkTaskStatusWorkTaskId = '';
        /** state cmdUpdateWorkTaskStatusStatus — input */
        this.cmdUpdateWorkTaskStatusStatus = '';
        /** state cmdUpdateWorkTaskStatusCancellationReason — input */
        this.cmdUpdateWorkTaskStatusCancellationReason = '';
        /** state cmdUpdateWorkTaskStatusCompletedAt — input */
        this.cmdUpdateWorkTaskStatusCompletedAt = '';
        /** state cmdUpdateWorkTaskStatusActorId — input */
        this.cmdUpdateWorkTaskStatusActorId = '';
        /** state cmdUpdateWorkTaskStatusOutput — commandOutput */
        this.cmdUpdateWorkTaskStatusOutput = null;
        /** state cmdUpdateWorkTaskStatusError — actionError */
        this.cmdUpdateWorkTaskStatusError = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.taskBoardWorkspace.status', '');
        this.initStateValue('ui.taskBoardWorkspace.action.cmdCreateWorkTask.status', 'idle');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdCreateWorkTask.title', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdCreateWorkTask.description', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate', '');
        this.initStateValue('ui.taskBoardWorkspace.output.cmdCreateWorkTask', null);
        this.initStateValue('ui.taskBoardWorkspace.action.cmdCreateWorkTask.error', '');
        this.initStateValue('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status', 'idle');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason', '');
        this.initStateValue('ui.taskBoardWorkspace.output.cmdUpdateWorkTask', null);
        this.initStateValue('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.error', '');
        this.initStateValue('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status', 'idle');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt', '');
        this.initStateValue('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId', '');
        this.initStateValue('ui.taskBoardWorkspace.output.cmdUpdateWorkTaskStatus', null);
        this.initStateValue('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.error', '');
        this.syncRouteParams();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.taskBoardWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.action.cmdCreateWorkTask.status':
                this.cmdCreateWorkTaskState = value ?? 'idle';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId':
                this.cmdCreateWorkTaskProjectId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.title':
                this.cmdCreateWorkTaskTitle = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.description':
                this.cmdCreateWorkTaskDescription = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId':
                this.cmdCreateWorkTaskAssignedWorkerId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate':
                this.cmdCreateWorkTaskDueDate = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.output.cmdCreateWorkTask':
                this.cmdCreateWorkTaskOutput = value ?? null;
                break;
            case 'ui.taskBoardWorkspace.action.cmdCreateWorkTask.error':
                this.cmdCreateWorkTaskError = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status':
                this.cmdUpdateWorkTaskState = value ?? 'idle';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId':
                this.cmdUpdateWorkTaskWorkTaskId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title':
                this.cmdUpdateWorkTaskTitle = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description':
                this.cmdUpdateWorkTaskDescription = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId':
                this.cmdUpdateWorkTaskAssignedWorkerId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate':
                this.cmdUpdateWorkTaskDueDate = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status':
                this.cmdUpdateWorkTaskStatusValue = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason':
                this.cmdUpdateWorkTaskCancellationReason = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.output.cmdUpdateWorkTask':
                this.cmdUpdateWorkTaskOutput = value ?? null;
                break;
            case 'ui.taskBoardWorkspace.action.cmdUpdateWorkTask.error':
                this.cmdUpdateWorkTaskError = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status':
                this.cmdUpdateWorkTaskStatusState = value ?? 'idle';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId':
                this.cmdUpdateWorkTaskStatusWorkTaskId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status':
                this.cmdUpdateWorkTaskStatusStatus = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason':
                this.cmdUpdateWorkTaskStatusCancellationReason = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt':
                this.cmdUpdateWorkTaskStatusCompletedAt = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId':
                this.cmdUpdateWorkTaskStatusActorId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.output.cmdUpdateWorkTaskStatus':
                this.cmdUpdateWorkTaskStatusOutput = value ?? null;
                break;
            case 'ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.error':
                this.cmdUpdateWorkTaskStatusError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.taskBoardWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.action.cmdCreateWorkTask.status':
                this.cmdCreateWorkTaskState = value ?? 'idle';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId':
                this.cmdCreateWorkTaskProjectId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.title':
                this.cmdCreateWorkTaskTitle = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.description':
                this.cmdCreateWorkTaskDescription = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId':
                this.cmdCreateWorkTaskAssignedWorkerId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate':
                this.cmdCreateWorkTaskDueDate = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.output.cmdCreateWorkTask':
                this.cmdCreateWorkTaskOutput = value ?? null;
                break;
            case 'ui.taskBoardWorkspace.action.cmdCreateWorkTask.error':
                this.cmdCreateWorkTaskError = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status':
                this.cmdUpdateWorkTaskState = value ?? 'idle';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId':
                this.cmdUpdateWorkTaskWorkTaskId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title':
                this.cmdUpdateWorkTaskTitle = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description':
                this.cmdUpdateWorkTaskDescription = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId':
                this.cmdUpdateWorkTaskAssignedWorkerId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate':
                this.cmdUpdateWorkTaskDueDate = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status':
                this.cmdUpdateWorkTaskStatusValue = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason':
                this.cmdUpdateWorkTaskCancellationReason = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.output.cmdUpdateWorkTask':
                this.cmdUpdateWorkTaskOutput = value ?? null;
                break;
            case 'ui.taskBoardWorkspace.action.cmdUpdateWorkTask.error':
                this.cmdUpdateWorkTaskError = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status':
                this.cmdUpdateWorkTaskStatusState = value ?? 'idle';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId':
                this.cmdUpdateWorkTaskStatusWorkTaskId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status':
                this.cmdUpdateWorkTaskStatusStatus = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason':
                this.cmdUpdateWorkTaskStatusCancellationReason = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt':
                this.cmdUpdateWorkTaskStatusCompletedAt = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId':
                this.cmdUpdateWorkTaskStatusActorId = value ?? '';
                break;
            case 'ui.taskBoardWorkspace.output.cmdUpdateWorkTaskStatus':
                this.cmdUpdateWorkTaskStatusOutput = value ?? null;
                break;
            case 'ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.error':
                this.cmdUpdateWorkTaskStatusError = value ?? '';
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    syncRouteParams() {
        const pathname = window.location.pathname;
        const match = pathname.match(/^\/buildFlowFsm\/taskBoardWorkspace(?:\/([^/]+))?\/?$/);
        const rawWorkTaskId = match && match[1] ? match[1] : '';
        let workTaskId = '';
        if (rawWorkTaskId) {
            try {
                workTaskId = decodeURIComponent(rawWorkTaskId);
            }
            catch {
                workTaskId = rawWorkTaskId;
            }
        }
        if (workTaskId) {
            if (!this.cmdUpdateWorkTaskWorkTaskId) {
                this.cmdUpdateWorkTaskWorkTaskId = workTaskId;
                setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId', workTaskId);
            }
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action cmdCreateWorkTask (command) — route buildFlowFsm.taskBoardWorkspace.cmdCreateWorkTask; inputs: projectId, title, description, assignedWorkerId, dueDate; writes ui.taskBoardWorkspace.output.cmdCreateWorkTask; status ui.taskBoardWorkspace.action.cmdCreateWorkTask.status; feedback keys action.cmdCreateWorkTask.success / action.cmdCreateWorkTask.error */
    async cmdCreateWorkTask() {
        this.syncRouteParams();
        if (!this.cmdCreateWorkTaskProjectId) {
            this.cmdCreateWorkTaskState = 'idle';
            setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdCreateWorkTaskState = 'loading';
        setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.status', 'loading');
        this.cmdCreateWorkTaskError = '';
        setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.error', '');
        const params = {
            projectId: this.cmdCreateWorkTaskProjectId,
            title: this.cmdCreateWorkTaskTitle,
            assignedWorkerId: this.cmdCreateWorkTaskAssignedWorkerId,
            dueDate: this.cmdCreateWorkTaskDueDate,
        };
        if (this.cmdCreateWorkTaskDescription) {
            params.description = this.cmdCreateWorkTaskDescription;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateWorkTaskRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdCreateWorkTask.error');
            this.cmdCreateWorkTaskError = errMsg;
            setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.error', errMsg);
            this.cmdCreateWorkTaskState = 'error';
            setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdCreateWorkTaskOutput = data;
        setState('ui.taskBoardWorkspace.output.cmdCreateWorkTask', data);
        this.cmdCreateWorkTaskProjectId = '';
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId', '');
        this.cmdCreateWorkTaskTitle = '';
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.title', '');
        this.cmdCreateWorkTaskDescription = '';
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.description', '');
        this.cmdCreateWorkTaskAssignedWorkerId = '';
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId', '');
        this.cmdCreateWorkTaskDueDate = '';
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate', '');
        this.cmdCreateWorkTaskState = 'success';
        setState('ui.taskBoardWorkspace.action.cmdCreateWorkTask.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdCreateWorkTask — bind UI events here */
    handleCmdCreateWorkTaskClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdCreateWorkTask();
        });
    }
    /** action cmdUpdateWorkTask (command) — route buildFlowFsm.taskBoardWorkspace.cmdUpdateWorkTask; inputs: workTaskId, title, description, assignedWorkerId, dueDate, status, cancellationReason; writes ui.taskBoardWorkspace.output.cmdUpdateWorkTask; status ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status; feedback keys action.cmdUpdateWorkTask.success / action.cmdUpdateWorkTask.error */
    async cmdUpdateWorkTask() {
        this.syncRouteParams();
        if (!this.cmdUpdateWorkTaskWorkTaskId) {
            this.cmdUpdateWorkTaskState = 'idle';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateWorkTaskState = 'loading';
        setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status', 'loading');
        this.cmdUpdateWorkTaskError = '';
        setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.error', '');
        const params = {
            workTaskId: this.cmdUpdateWorkTaskWorkTaskId,
        };
        if (this.cmdUpdateWorkTaskTitle) {
            params.title = this.cmdUpdateWorkTaskTitle;
        }
        if (this.cmdUpdateWorkTaskDescription) {
            params.description = this.cmdUpdateWorkTaskDescription;
        }
        if (this.cmdUpdateWorkTaskAssignedWorkerId) {
            params.assignedWorkerId = this.cmdUpdateWorkTaskAssignedWorkerId;
        }
        if (this.cmdUpdateWorkTaskDueDate) {
            params.dueDate = this.cmdUpdateWorkTaskDueDate;
        }
        if (this.cmdUpdateWorkTaskStatusValue) {
            params.status = this.cmdUpdateWorkTaskStatusValue;
        }
        if (this.cmdUpdateWorkTaskCancellationReason) {
            params.cancellationReason = this.cmdUpdateWorkTaskCancellationReason;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateWorkTaskRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateWorkTask.error');
            this.cmdUpdateWorkTaskError = errMsg;
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.error', errMsg);
            this.cmdUpdateWorkTaskState = 'error';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateWorkTaskOutput = data;
        setState('ui.taskBoardWorkspace.output.cmdUpdateWorkTask', data);
        this.cmdUpdateWorkTaskTitle = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title', '');
        this.cmdUpdateWorkTaskDescription = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description', '');
        this.cmdUpdateWorkTaskAssignedWorkerId = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId', '');
        this.cmdUpdateWorkTaskDueDate = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate', '');
        this.cmdUpdateWorkTaskStatusValue = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status', '');
        this.cmdUpdateWorkTaskCancellationReason = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason', '');
        this.cmdUpdateWorkTaskState = 'success';
        setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTask.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateWorkTask — bind UI events here */
    handleCmdUpdateWorkTaskClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateWorkTask();
        });
    }
    /** action cmdUpdateWorkTaskStatus (command) — route buildFlowFsm.taskBoardWorkspace.cmdUpdateWorkTaskStatus; inputs: workTaskId, status, cancellationReason, completedAt, actorId; writes ui.taskBoardWorkspace.output.cmdUpdateWorkTaskStatus; status ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status; feedback keys action.cmdUpdateWorkTaskStatus.success / action.cmdUpdateWorkTaskStatus.error */
    async cmdUpdateWorkTaskStatus() {
        this.syncRouteParams();
        if (!this.cmdUpdateWorkTaskStatusWorkTaskId) {
            this.cmdUpdateWorkTaskStatusState = 'idle';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateWorkTaskStatusState = 'loading';
        setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status', 'loading');
        this.cmdUpdateWorkTaskStatusError = '';
        setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.error', '');
        const params = {
            workTaskId: this.cmdUpdateWorkTaskStatusWorkTaskId,
            status: this.cmdUpdateWorkTaskStatusStatus,
            actorId: this.cmdUpdateWorkTaskStatusActorId,
        };
        if (this.cmdUpdateWorkTaskStatusCancellationReason) {
            params.cancellationReason = this.cmdUpdateWorkTaskStatusCancellationReason;
        }
        if (this.cmdUpdateWorkTaskStatusCompletedAt) {
            params.completedAt = this.cmdUpdateWorkTaskStatusCompletedAt;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateWorkTaskStatusRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateWorkTaskStatus.error');
            this.cmdUpdateWorkTaskStatusError = errMsg;
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.error', errMsg);
            this.cmdUpdateWorkTaskStatusState = 'error';
            setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateWorkTaskStatusOutput = data;
        setState('ui.taskBoardWorkspace.output.cmdUpdateWorkTaskStatus', data);
        this.cmdUpdateWorkTaskStatusWorkTaskId = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId', '');
        this.cmdUpdateWorkTaskStatusStatus = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status', '');
        this.cmdUpdateWorkTaskStatusCancellationReason = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason', '');
        this.cmdUpdateWorkTaskStatusCompletedAt = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt', '');
        this.cmdUpdateWorkTaskStatusActorId = '';
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId', '');
        this.cmdUpdateWorkTaskStatusState = 'success';
        setState('ui.taskBoardWorkspace.action.cmdUpdateWorkTaskStatus.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateWorkTaskStatus — bind UI events here */
    handleCmdUpdateWorkTaskStatusClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateWorkTaskStatus();
        });
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId */
    setCmdCreateWorkTaskProjectId(value) {
        this.cmdCreateWorkTaskProjectId = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskProjectId — bind UI events here */
    handleCmdCreateWorkTaskProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateWorkTaskProjectId(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.title */
    setCmdCreateWorkTaskTitle(value) {
        this.cmdCreateWorkTaskTitle = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.title', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskTitle — bind UI events here */
    handleCmdCreateWorkTaskTitleChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateWorkTaskTitle(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.description */
    setCmdCreateWorkTaskDescription(value) {
        this.cmdCreateWorkTaskDescription = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskDescription — bind UI events here */
    handleCmdCreateWorkTaskDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateWorkTaskDescription(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId */
    setCmdCreateWorkTaskAssignedWorkerId(value) {
        this.cmdCreateWorkTaskAssignedWorkerId = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.assignedWorkerId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskAssignedWorkerId — bind UI events here */
    handleCmdCreateWorkTaskAssignedWorkerIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateWorkTaskAssignedWorkerId(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate */
    setCmdCreateWorkTaskDueDate(value) {
        this.cmdCreateWorkTaskDueDate = value;
        setState('ui.taskBoardWorkspace.input.cmdCreateWorkTask.dueDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateWorkTaskDueDate — bind UI events here */
    handleCmdCreateWorkTaskDueDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateWorkTaskDueDate(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId */
    setCmdUpdateWorkTaskWorkTaskId(value) {
        this.cmdUpdateWorkTaskWorkTaskId = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.workTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskWorkTaskId — bind UI events here */
    handleCmdUpdateWorkTaskWorkTaskIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskWorkTaskId(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title */
    setCmdUpdateWorkTaskTitle(value) {
        this.cmdUpdateWorkTaskTitle = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.title', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskTitle — bind UI events here */
    handleCmdUpdateWorkTaskTitleChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskTitle(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description */
    setCmdUpdateWorkTaskDescription(value) {
        this.cmdUpdateWorkTaskDescription = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskDescription — bind UI events here */
    handleCmdUpdateWorkTaskDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskDescription(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId */
    setCmdUpdateWorkTaskAssignedWorkerId(value) {
        this.cmdUpdateWorkTaskAssignedWorkerId = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.assignedWorkerId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskAssignedWorkerId — bind UI events here */
    handleCmdUpdateWorkTaskAssignedWorkerIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskAssignedWorkerId(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate */
    setCmdUpdateWorkTaskDueDate(value) {
        this.cmdUpdateWorkTaskDueDate = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.dueDate', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskDueDate — bind UI events here */
    handleCmdUpdateWorkTaskDueDateChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskDueDate(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status */
    setCmdUpdateWorkTaskStatusValue(value) {
        this.cmdUpdateWorkTaskStatusValue = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusValue — bind UI events here */
    handleCmdUpdateWorkTaskStatusValueChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskStatusValue(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason */
    setCmdUpdateWorkTaskCancellationReason(value) {
        this.cmdUpdateWorkTaskCancellationReason = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTask.cancellationReason', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskCancellationReason — bind UI events here */
    handleCmdUpdateWorkTaskCancellationReasonChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskCancellationReason(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId */
    setCmdUpdateWorkTaskStatusWorkTaskId(value) {
        this.cmdUpdateWorkTaskStatusWorkTaskId = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.workTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusWorkTaskId — bind UI events here */
    handleCmdUpdateWorkTaskStatusWorkTaskIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskStatusWorkTaskId(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status */
    setCmdUpdateWorkTaskStatusStatus(value) {
        this.cmdUpdateWorkTaskStatusStatus = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusStatus — bind UI events here */
    handleCmdUpdateWorkTaskStatusStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskStatusStatus(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason */
    setCmdUpdateWorkTaskStatusCancellationReason(value) {
        this.cmdUpdateWorkTaskStatusCancellationReason = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.cancellationReason', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusCancellationReason — bind UI events here */
    handleCmdUpdateWorkTaskStatusCancellationReasonChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskStatusCancellationReason(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt */
    setCmdUpdateWorkTaskStatusCompletedAt(value) {
        this.cmdUpdateWorkTaskStatusCompletedAt = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.completedAt', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusCompletedAt — bind UI events here */
    handleCmdUpdateWorkTaskStatusCompletedAtChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskStatusCompletedAt(value);
    }
    /** setter for state ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId */
    setCmdUpdateWorkTaskStatusActorId(value) {
        this.cmdUpdateWorkTaskStatusActorId = value;
        setState('ui.taskBoardWorkspace.input.cmdUpdateWorkTaskStatus.actorId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateWorkTaskStatusActorId — bind UI events here */
    handleCmdUpdateWorkTaskStatusActorIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateWorkTaskStatusActorId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskState", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskTitle", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskDescription", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskAssignedWorkerId", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskDueDate", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskOutput", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdCreateWorkTaskError", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskState", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskTitle", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskDescription", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskAssignedWorkerId", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskDueDate", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusValue", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskCancellationReason", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskOutput", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskError", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusState", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusStatus", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusCancellationReason", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusCompletedAt", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusActorId", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusOutput", void 0);
__decorate([
    property()
], BuildFlowFsmTaskBoardWorkspaceBase.prototype, "cmdUpdateWorkTaskStatusError", void 0);
