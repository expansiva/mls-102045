/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/myTasksWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { listMyWorkTasksRoute, getWorkTaskDetailRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/myTasksWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    'section.myTasksWorkspace.taskListSection.title': 'My Tasks',
    'organism.myTasksWorkspace.listMyWorkTasks.title': 'Browse my assigned tasks',
    'intent.myTasksWorkspace.listMyWorkTasks.list.title': 'Browse my assigned tasks',
    'intent.myTasksWorkspace.listMyWorkTasks.list.empty': 'Nenhum registro encontrado',
    'intent.myTasksWorkspace.listMyWorkTasks.list.column.workTasks.label': 'Work Tasks',
    'intent.myTasksWorkspace.listMyWorkTasks.list.column.total.label': 'Total',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.status.label': 'Status',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.page.label': 'Page',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.pageSize.label': 'Page Size',
    'organism.myTasksWorkspace.getWorkTaskDetail.title': 'View work task details',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.title': 'View work task details',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.empty': 'Nenhum registro encontrado',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.workTaskId.label': 'Work Task Id',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.projectId.label': 'Project Id',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.projectName.label': 'Project Name',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.title.label': 'Title',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.description.label': 'Description',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.status.label': 'Status',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.dueDate.label': 'Due Date',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.isOverdue.label': 'Is Overdue',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.completedAt.label': 'Completed At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.cancelledAt.label': 'Cancelled At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.cancellationReason.label': 'Cancellation Reason',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.createdAt.label': 'Created At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.updatedAt.label': 'Updated At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.filter.actorId.label': 'Actor Id',
    'organism.myTasksWorkspace.inline-row-command20.title': 'Inline row command',
    'intent.myTasksWorkspace.inline-row-command20.content.title': 'Inline row command',
    'organism.myTasksWorkspace.contextual-transition-actions20.title': 'Contextual transition actions',
    'intent.myTasksWorkspace.contextual-transition-actions20.content.title': 'Contextual transition actions',
};
const message_pt_br = {
    'section.myTasksWorkspace.taskListSection.title': 'My Tasks',
    'organism.myTasksWorkspace.listMyWorkTasks.title': 'Browse my assigned tasks',
    'intent.myTasksWorkspace.listMyWorkTasks.list.title': 'Browse my assigned tasks',
    'intent.myTasksWorkspace.listMyWorkTasks.list.empty': 'Nenhum registro encontrado',
    'intent.myTasksWorkspace.listMyWorkTasks.list.column.workTasks.label': 'Work Tasks',
    'intent.myTasksWorkspace.listMyWorkTasks.list.column.total.label': 'Total',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.status.label': 'Status',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.page.label': 'Page',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.pageSize.label': 'Page Size',
    'organism.myTasksWorkspace.getWorkTaskDetail.title': 'View work task details',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.title': 'View work task details',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.empty': 'Nenhum registro encontrado',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.workTaskId.label': 'Work Task Id',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.projectId.label': 'Project Id',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.projectName.label': 'Project Name',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.title.label': 'Title',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.description.label': 'Description',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.status.label': 'Status',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.dueDate.label': 'Due Date',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.isOverdue.label': 'Is Overdue',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.completedAt.label': 'Completed At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.cancelledAt.label': 'Cancelled At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.cancellationReason.label': 'Cancellation Reason',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.createdAt.label': 'Created At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.updatedAt.label': 'Updated At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.filter.actorId.label': 'Actor Id',
    'organism.myTasksWorkspace.inline-row-command20.title': 'Inline row command',
    'intent.myTasksWorkspace.inline-row-command20.content.title': 'Inline row command',
    'organism.myTasksWorkspace.contextual-transition-actions20.title': 'Contextual transition actions',
    'intent.myTasksWorkspace.contextual-transition-actions20.content.title': 'Contextual transition actions',
};
const message_es = {
    'section.myTasksWorkspace.taskListSection.title': 'My Tasks',
    'organism.myTasksWorkspace.listMyWorkTasks.title': 'Browse my assigned tasks',
    'intent.myTasksWorkspace.listMyWorkTasks.list.title': 'Browse my assigned tasks',
    'intent.myTasksWorkspace.listMyWorkTasks.list.empty': 'Nenhum registro encontrado',
    'intent.myTasksWorkspace.listMyWorkTasks.list.column.workTasks.label': 'Work Tasks',
    'intent.myTasksWorkspace.listMyWorkTasks.list.column.total.label': 'Total',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.status.label': 'Status',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.page.label': 'Page',
    'intent.myTasksWorkspace.listMyWorkTasks.list.filter.pageSize.label': 'Page Size',
    'organism.myTasksWorkspace.getWorkTaskDetail.title': 'View work task details',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.title': 'View work task details',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.empty': 'Nenhum registro encontrado',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.workTaskId.label': 'Work Task Id',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.projectId.label': 'Project Id',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.projectName.label': 'Project Name',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.title.label': 'Title',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.description.label': 'Description',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.assignedWorkerId.label': 'Assigned Worker Id',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.status.label': 'Status',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.dueDate.label': 'Due Date',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.isOverdue.label': 'Is Overdue',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.completedAt.label': 'Completed At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.cancelledAt.label': 'Cancelled At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.cancellationReason.label': 'Cancellation Reason',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.createdAt.label': 'Created At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.column.updatedAt.label': 'Updated At',
    'intent.myTasksWorkspace.getWorkTaskDetail.list.filter.actorId.label': 'Actor Id',
    'organism.myTasksWorkspace.inline-row-command20.title': 'Inline row command',
    'intent.myTasksWorkspace.inline-row-command20.content.title': 'Inline row command',
    'organism.myTasksWorkspace.contextual-transition-actions20.title': 'Contextual transition actions',
    'intent.myTasksWorkspace.contextual-transition-actions20.content.title': 'Contextual transition actions',
};
export const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
const LIST_MY_WORK_TASKS_DATA_DEFAULT = { workTasks: [], total: 0 };
const SUBSCRIBED_STATE_KEYS = [
    'ui.myTasksWorkspace.status',
    'ui.myTasksWorkspace.action.listMyWorkTasks.status',
    'ui.myTasksWorkspace.input.listMyWorkTasks.assignedWorkerId',
    'ui.myTasksWorkspace.input.listMyWorkTasks.status',
    'ui.myTasksWorkspace.input.listMyWorkTasks.page',
    'ui.myTasksWorkspace.input.listMyWorkTasks.pageSize',
    'ui.myTasksWorkspace.data.listMyWorkTasks',
    'ui.myTasksWorkspace.action.getWorkTaskDetail.status',
    'ui.myTasksWorkspace.input.getWorkTaskDetail.workTaskId',
    'ui.myTasksWorkspace.input.getWorkTaskDetail.actorId',
    'ui.myTasksWorkspace.data.getWorkTaskDetail',
];
export class BuildFlowFsmMyTasksWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state listMyWorkTasksState — actionStatus, values: idle|loading|success|error */
        this.listMyWorkTasksState = 'idle';
        /** state listMyWorkTasksAssignedWorkerId — input */
        this.listMyWorkTasksAssignedWorkerId = '';
        /** state listMyWorkTasksStatus — input */
        this.listMyWorkTasksStatus = '';
        /** state listMyWorkTasksPage — input */
        this.listMyWorkTasksPage = '';
        /** state listMyWorkTasksPageSize — input */
        this.listMyWorkTasksPageSize = '';
        /** state listMyWorkTasksData — queryResult, outputShape: paginated */
        this.listMyWorkTasksData = LIST_MY_WORK_TASKS_DATA_DEFAULT;
        /** state getWorkTaskDetailState — actionStatus, values: idle|loading|success|error */
        this.getWorkTaskDetailState = 'idle';
        /** state getWorkTaskDetailWorkTaskId — input */
        this.getWorkTaskDetailWorkTaskId = '';
        /** state getWorkTaskDetailActorId — input */
        this.getWorkTaskDetailActorId = '';
        /** state getWorkTaskDetailData — queryResult, outputShape: object */
        this.getWorkTaskDetailData = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.myTasksWorkspace.status', '');
        this.initStateValue('ui.myTasksWorkspace.action.listMyWorkTasks.status', 'idle');
        this.initStateValue('ui.myTasksWorkspace.input.listMyWorkTasks.assignedWorkerId', '');
        this.initStateValue('ui.myTasksWorkspace.input.listMyWorkTasks.status', '');
        this.initStateValue('ui.myTasksWorkspace.input.listMyWorkTasks.page', '');
        this.initStateValue('ui.myTasksWorkspace.input.listMyWorkTasks.pageSize', '');
        this.initStateValue('ui.myTasksWorkspace.data.listMyWorkTasks', LIST_MY_WORK_TASKS_DATA_DEFAULT);
        this.initStateValue('ui.myTasksWorkspace.action.getWorkTaskDetail.status', 'idle');
        this.initStateValue('ui.myTasksWorkspace.input.getWorkTaskDetail.workTaskId', '');
        this.initStateValue('ui.myTasksWorkspace.input.getWorkTaskDetail.actorId', '');
        this.initStateValue('ui.myTasksWorkspace.data.getWorkTaskDetail', null);
        this.syncRouteParams();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.myTasksWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.myTasksWorkspace.action.listMyWorkTasks.status':
                this.listMyWorkTasksState = value ?? 'idle';
                break;
            case 'ui.myTasksWorkspace.input.listMyWorkTasks.assignedWorkerId':
                this.listMyWorkTasksAssignedWorkerId = value ?? '';
                break;
            case 'ui.myTasksWorkspace.input.listMyWorkTasks.status':
                this.listMyWorkTasksStatus = value ?? '';
                break;
            case 'ui.myTasksWorkspace.input.listMyWorkTasks.page':
                this.listMyWorkTasksPage = value ?? '';
                break;
            case 'ui.myTasksWorkspace.input.listMyWorkTasks.pageSize':
                this.listMyWorkTasksPageSize = value ?? '';
                break;
            case 'ui.myTasksWorkspace.data.listMyWorkTasks':
                this.listMyWorkTasksData = value ?? LIST_MY_WORK_TASKS_DATA_DEFAULT;
                break;
            case 'ui.myTasksWorkspace.action.getWorkTaskDetail.status':
                this.getWorkTaskDetailState = value ?? 'idle';
                break;
            case 'ui.myTasksWorkspace.input.getWorkTaskDetail.workTaskId':
                this.getWorkTaskDetailWorkTaskId = value ?? '';
                break;
            case 'ui.myTasksWorkspace.input.getWorkTaskDetail.actorId':
                this.getWorkTaskDetailActorId = value ?? '';
                break;
            case 'ui.myTasksWorkspace.data.getWorkTaskDetail':
                this.getWorkTaskDetailData = value ?? null;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.myTasksWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.myTasksWorkspace.action.listMyWorkTasks.status':
                this.listMyWorkTasksState = value ?? 'idle';
                break;
            case 'ui.myTasksWorkspace.input.listMyWorkTasks.assignedWorkerId':
                this.listMyWorkTasksAssignedWorkerId = value ?? '';
                break;
            case 'ui.myTasksWorkspace.input.listMyWorkTasks.status':
                this.listMyWorkTasksStatus = value ?? '';
                break;
            case 'ui.myTasksWorkspace.input.listMyWorkTasks.page':
                this.listMyWorkTasksPage = value ?? '';
                break;
            case 'ui.myTasksWorkspace.input.listMyWorkTasks.pageSize':
                this.listMyWorkTasksPageSize = value ?? '';
                break;
            case 'ui.myTasksWorkspace.data.listMyWorkTasks':
                this.listMyWorkTasksData = value ?? LIST_MY_WORK_TASKS_DATA_DEFAULT;
                break;
            case 'ui.myTasksWorkspace.action.getWorkTaskDetail.status':
                this.getWorkTaskDetailState = value ?? 'idle';
                break;
            case 'ui.myTasksWorkspace.input.getWorkTaskDetail.workTaskId':
                this.getWorkTaskDetailWorkTaskId = value ?? '';
                break;
            case 'ui.myTasksWorkspace.input.getWorkTaskDetail.actorId':
                this.getWorkTaskDetailActorId = value ?? '';
                break;
            case 'ui.myTasksWorkspace.data.getWorkTaskDetail':
                this.getWorkTaskDetailData = value ?? null;
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    syncRouteParams() {
        const pathname = window.location.pathname;
        const match = pathname.match(/^\/buildFlowFsm\/myTasksWorkspace(?:\/([^/]+))?\/?$/);
        const rawWorkTaskId = match && match[1] ? match[1] : '';
        let workTaskId = '';
        if (rawWorkTaskId) {
            try {
                workTaskId = decodeURIComponent(rawWorkTaskId);
            }
            catch {
                workTaskId = rawWorkTaskId;
            }
        }
        if (workTaskId) {
            if (!this.getWorkTaskDetailWorkTaskId) {
                this.getWorkTaskDetailWorkTaskId = workTaskId;
                setState('ui.myTasksWorkspace.input.getWorkTaskDetail.workTaskId', workTaskId);
            }
        }
    }
    /** action listMyWorkTasks (query) — route buildFlowFsm.myTasksWorkspace.listMyWorkTasks; inputs: assignedWorkerId, status, page, pageSize; writes ui.myTasksWorkspace.data.listMyWorkTasks; status ui.myTasksWorkspace.action.listMyWorkTasks.status */
    async loadListMyWorkTasks() {
        this.syncRouteParams();
        this.listMyWorkTasksState = 'loading';
        setState('ui.myTasksWorkspace.action.listMyWorkTasks.status', 'loading');
        const params = {
            assignedWorkerId: this.listMyWorkTasksAssignedWorkerId,
        };
        if (this.listMyWorkTasksStatus) {
            params.status = this.listMyWorkTasksStatus;
        }
        if (this.listMyWorkTasksPage !== '') {
            const pageNum = Number(this.listMyWorkTasksPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.listMyWorkTasksPageSize !== '') {
            const pageSizeNum = Number(this.listMyWorkTasksPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(listMyWorkTasksRoute, params, options);
        if (response.ok) {
            const data = response.data ?? LIST_MY_WORK_TASKS_DATA_DEFAULT;
            this.listMyWorkTasksData = data;
            setState('ui.myTasksWorkspace.data.listMyWorkTasks', data);
            this.listMyWorkTasksState = 'success';
            setState('ui.myTasksWorkspace.action.listMyWorkTasks.status', 'success');
        }
        else {
            this.listMyWorkTasksState = 'error';
            setState('ui.myTasksWorkspace.action.listMyWorkTasks.status', 'error');
            if (response.error) {
                console.error('listMyWorkTasks failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action listMyWorkTasks — bind UI events here */
    handleListMyWorkTasksClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadListMyWorkTasks();
    }
    /** action getWorkTaskDetail (query) — route buildFlowFsm.myTasksWorkspace.getWorkTaskDetail; inputs: workTaskId, actorId; writes ui.myTasksWorkspace.data.getWorkTaskDetail; status ui.myTasksWorkspace.action.getWorkTaskDetail.status */
    async loadGetWorkTaskDetail() {
        this.syncRouteParams();
        if (!this.getWorkTaskDetailWorkTaskId) {
            this.getWorkTaskDetailState = 'idle';
            setState('ui.myTasksWorkspace.action.getWorkTaskDetail.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.getWorkTaskDetailState = 'loading';
        setState('ui.myTasksWorkspace.action.getWorkTaskDetail.status', 'loading');
        const params = {
            workTaskId: this.getWorkTaskDetailWorkTaskId,
            actorId: this.getWorkTaskDetailActorId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(getWorkTaskDetailRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.getWorkTaskDetailData = data;
            setState('ui.myTasksWorkspace.data.getWorkTaskDetail', data);
            this.getWorkTaskDetailState = 'success';
            setState('ui.myTasksWorkspace.action.getWorkTaskDetail.status', 'success');
        }
        else {
            this.getWorkTaskDetailState = 'error';
            setState('ui.myTasksWorkspace.action.getWorkTaskDetail.status', 'error');
            if (response.error) {
                console.error('getWorkTaskDetail failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action getWorkTaskDetail — bind UI events here */
    handleGetWorkTaskDetailClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadGetWorkTaskDetail();
    }
    /** setter for state ui.myTasksWorkspace.input.listMyWorkTasks.assignedWorkerId */
    setListMyWorkTasksAssignedWorkerId(value) {
        this.listMyWorkTasksAssignedWorkerId = value;
        setState('ui.myTasksWorkspace.input.listMyWorkTasks.assignedWorkerId', value);
        this.requestUpdate();
    }
    /** handler for action set.listMyWorkTasksAssignedWorkerId — bind UI events here */
    handleListMyWorkTasksAssignedWorkerIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListMyWorkTasksAssignedWorkerId(value);
    }
    /** setter for state ui.myTasksWorkspace.input.listMyWorkTasks.status */
    setListMyWorkTasksStatus(value) {
        this.listMyWorkTasksStatus = value;
        setState('ui.myTasksWorkspace.input.listMyWorkTasks.status', value);
        this.requestUpdate();
    }
    /** handler for action set.listMyWorkTasksStatus — bind UI events here */
    handleListMyWorkTasksStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListMyWorkTasksStatus(value);
    }
    /** setter for state ui.myTasksWorkspace.input.listMyWorkTasks.page */
    setListMyWorkTasksPage(value) {
        this.listMyWorkTasksPage = value;
        setState('ui.myTasksWorkspace.input.listMyWorkTasks.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listMyWorkTasksPage — bind UI events here */
    handleListMyWorkTasksPageChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListMyWorkTasksPage(value);
    }
    /** setter for state ui.myTasksWorkspace.input.listMyWorkTasks.pageSize */
    setListMyWorkTasksPageSize(value) {
        this.listMyWorkTasksPageSize = value;
        setState('ui.myTasksWorkspace.input.listMyWorkTasks.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listMyWorkTasksPageSize — bind UI events here */
    handleListMyWorkTasksPageSizeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListMyWorkTasksPageSize(value);
    }
    /** setter for state ui.myTasksWorkspace.input.getWorkTaskDetail.workTaskId */
    setGetWorkTaskDetailWorkTaskId(value) {
        this.getWorkTaskDetailWorkTaskId = value;
        setState('ui.myTasksWorkspace.input.getWorkTaskDetail.workTaskId', value);
        this.requestUpdate();
    }
    /** handler for action set.getWorkTaskDetailWorkTaskId — bind UI events here */
    handleGetWorkTaskDetailWorkTaskIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetWorkTaskDetailWorkTaskId(value);
    }
    /** setter for state ui.myTasksWorkspace.input.getWorkTaskDetail.actorId */
    setGetWorkTaskDetailActorId(value) {
        this.getWorkTaskDetailActorId = value;
        setState('ui.myTasksWorkspace.input.getWorkTaskDetail.actorId', value);
        this.requestUpdate();
    }
    /** handler for action set.getWorkTaskDetailActorId — bind UI events here */
    handleGetWorkTaskDetailActorIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setGetWorkTaskDetailActorId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "listMyWorkTasksState", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "listMyWorkTasksAssignedWorkerId", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "listMyWorkTasksStatus", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "listMyWorkTasksPage", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "listMyWorkTasksPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "listMyWorkTasksData", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "getWorkTaskDetailState", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "getWorkTaskDetailWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "getWorkTaskDetailActorId", void 0);
__decorate([
    property()
], BuildFlowFsmMyTasksWorkspaceBase.prototype, "getWorkTaskDetailData", void 0);
