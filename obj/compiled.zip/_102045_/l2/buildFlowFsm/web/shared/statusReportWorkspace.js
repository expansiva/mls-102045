/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/statusReportWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { setState } from '/_102029_/l2/collabState.js';
import { generateReportRoute, updateReportContentRoute, updateReportStatusRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/statusReportWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    "section.statusReportWorkspace.sec-generate.title": "Generate Report",
    "organism.statusReportWorkspace.generateReport.title": "Generate status report",
    "intent.statusReportWorkspace.generateReport.form.title": "Generate status report",
    "intent.statusReportWorkspace.generateReport.form.action.generateReport": "Generate status report",
    "intent.statusReportWorkspace.generateReport.form.field.reportPeriodStart.label": "Report Period Start",
    "intent.statusReportWorkspace.generateReport.form.field.reportPeriodEnd.label": "Report Period End",
    "section.statusReportWorkspace.sec-review-share.title": "Review & Share Report",
    "organism.statusReportWorkspace.updateReportContent.title": "Edit status report content",
    "intent.statusReportWorkspace.updateReportContent.form.title": "Edit status report content",
    "intent.statusReportWorkspace.updateReportContent.form.action.updateReportContent": "Edit status report content",
    "intent.statusReportWorkspace.updateReportContent.form.field.summary.label": "Summary",
    "intent.statusReportWorkspace.updateReportContent.form.field.tasksOverview.label": "Tasks Overview",
    "intent.statusReportWorkspace.updateReportContent.form.field.timeLogsOverview.label": "Time Logs Overview",
    "intent.statusReportWorkspace.updateReportContent.form.field.materialsOverview.label": "Materials Overview",
    "intent.statusReportWorkspace.updateReportContent.form.field.delayRiskAssessment.label": "Delay Risk Assessment",
    "intent.statusReportWorkspace.updateReportContent.form.field.pmNotes.label": "Pm Notes",
    "organism.statusReportWorkspace.updateReportStatus.title": "Update status report status",
    "intent.statusReportWorkspace.updateReportStatus.form.title": "Update status report status",
    "intent.statusReportWorkspace.updateReportStatus.form.action.updateReportStatus": "Update status report status",
    "intent.statusReportWorkspace.updateReportStatus.form.field.status.label": "Status"
};
const message_pt_br = {
    "section.statusReportWorkspace.sec-generate.title": "Gerar Relatório",
    "organism.statusReportWorkspace.generateReport.title": "Gerar relatório de status",
    "intent.statusReportWorkspace.generateReport.form.title": "Gerar relatório de status",
    "intent.statusReportWorkspace.generateReport.form.action.generateReport": "Gerar relatório de status",
    "intent.statusReportWorkspace.generateReport.form.field.reportPeriodStart.label": "Início do Período do Relatório",
    "intent.statusReportWorkspace.generateReport.form.field.reportPeriodEnd.label": "Fim do Período do Relatório",
    "section.statusReportWorkspace.sec-review-share.title": "Revisar e Compartilhar Relatório",
    "organism.statusReportWorkspace.updateReportContent.title": "Editar conteúdo do relatório de status",
    "intent.statusReportWorkspace.updateReportContent.form.title": "Editar conteúdo do relatório de status",
    "intent.statusReportWorkspace.updateReportContent.form.action.updateReportContent": "Editar conteúdo do relatório de status",
    "intent.statusReportWorkspace.updateReportContent.form.field.summary.label": "Resumo",
    "intent.statusReportWorkspace.updateReportContent.form.field.tasksOverview.label": "Visão Geral das Tarefas",
    "intent.statusReportWorkspace.updateReportContent.form.field.timeLogsOverview.label": "Visão Geral dos Registros de Tempo",
    "intent.statusReportWorkspace.updateReportContent.form.field.materialsOverview.label": "Visão Geral dos Materiais",
    "intent.statusReportWorkspace.updateReportContent.form.field.delayRiskAssessment.label": "Avaliação de Risco de Atraso",
    "intent.statusReportWorkspace.updateReportContent.form.field.pmNotes.label": "Notas do Gerente de Projeto",
    "organism.statusReportWorkspace.updateReportStatus.title": "Atualizar status do relatório",
    "intent.statusReportWorkspace.updateReportStatus.form.title": "Atualizar status do relatório",
    "intent.statusReportWorkspace.updateReportStatus.form.action.updateReportStatus": "Atualizar status do relatório",
    "intent.statusReportWorkspace.updateReportStatus.form.field.status.label": "Status"
};
const message_es = {
    "section.statusReportWorkspace.sec-generate.title": "Generar Informe",
    "organism.statusReportWorkspace.generateReport.title": "Generar informe de estado",
    "intent.statusReportWorkspace.generateReport.form.title": "Generar informe de estado",
    "intent.statusReportWorkspace.generateReport.form.action.generateReport": "Generar informe de estado",
    "intent.statusReportWorkspace.generateReport.form.field.reportPeriodStart.label": "Inicio del Período del Informe",
    "intent.statusReportWorkspace.generateReport.form.field.reportPeriodEnd.label": "Fin del Período del Informe",
    "section.statusReportWorkspace.sec-review-share.title": "Revisar y Compartir Informe",
    "organism.statusReportWorkspace.updateReportContent.title": "Editar contenido del informe de estado",
    "intent.statusReportWorkspace.updateReportContent.form.title": "Editar contenido del informe de estado",
    "intent.statusReportWorkspace.updateReportContent.form.action.updateReportContent": "Editar contenido del informe de estado",
    "intent.statusReportWorkspace.updateReportContent.form.field.summary.label": "Resumen",
    "intent.statusReportWorkspace.updateReportContent.form.field.tasksOverview.label": "Resumen de Tareas",
    "intent.statusReportWorkspace.updateReportContent.form.field.timeLogsOverview.label": "Resumen de Registros de Tiempo",
    "intent.statusReportWorkspace.updateReportContent.form.field.materialsOverview.label": "Resumen de Materiales",
    "intent.statusReportWorkspace.updateReportContent.form.field.delayRiskAssessment.label": "Evaluación de Riesgo de Retraso",
    "intent.statusReportWorkspace.updateReportContent.form.field.pmNotes.label": "Notas del PM",
    "organism.statusReportWorkspace.updateReportStatus.title": "Actualizar estado del informe",
    "intent.statusReportWorkspace.updateReportStatus.form.title": "Actualizar estado del informe",
    "intent.statusReportWorkspace.updateReportStatus.form.action.updateReportStatus": "Actualizar estado del informe",
    "intent.statusReportWorkspace.updateReportStatus.form.field.status.label": "Estado"
};
const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
export class BuildFlowFsmStatusReportWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state generateReportState — actionStatus, values: idle|loading|success|error */
        this.generateReportState = 'idle';
        /** state generateReportProjectId — input, selection */
        this.generateReportProjectId = '';
        /** state generateReportReportPeriodStart — input, form */
        this.generateReportReportPeriodStart = '';
        /** state generateReportReportPeriodEnd — input, form */
        this.generateReportReportPeriodEnd = '';
        /** state generateReportOutput — commandOutput, outputShape: object */
        this.generateReportOutput = null;
        /** state generateReportError — actionError */
        this.generateReportError = '';
        /** state updateReportContentState — actionStatus, values: idle|loading|success|error */
        this.updateReportContentState = 'idle';
        /** state updateReportContentStatusReportId — input, route */
        this.updateReportContentStatusReportId = '';
        /** state updateReportContentSummary — input, form */
        this.updateReportContentSummary = '';
        /** state updateReportContentTasksOverview — input, form */
        this.updateReportContentTasksOverview = '';
        /** state updateReportContentTimeLogsOverview — input, form */
        this.updateReportContentTimeLogsOverview = '';
        /** state updateReportContentMaterialsOverview — input, form */
        this.updateReportContentMaterialsOverview = '';
        /** state updateReportContentDelayRiskAssessment — input, form */
        this.updateReportContentDelayRiskAssessment = '';
        /** state updateReportContentPmNotes — input, form */
        this.updateReportContentPmNotes = '';
        /** state updateReportContentOutput — commandOutput, outputShape: object */
        this.updateReportContentOutput = null;
        /** state updateReportContentError — actionError */
        this.updateReportContentError = '';
        /** state updateReportStatusState — actionStatus, values: idle|loading|success|error */
        this.updateReportStatusState = 'idle';
        /** state updateReportStatusStatusReportId — input, route */
        this.updateReportStatusStatusReportId = '';
        /** state updateReportStatusStatus — input, form */
        this.updateReportStatusStatus = '';
        /** state updateReportStatusOutput — commandOutput, outputShape: object */
        this.updateReportStatusOutput = null;
        /** state updateReportStatusError — actionError */
        this.updateReportStatusError = '';
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        const routeParams = this.parseRouteParams();
        const statusReportId = routeParams['statusReportId'] ?? '';
        if (statusReportId) {
            this.updateReportContentStatusReportId = statusReportId;
            setState('ui.statusReportWorkspace.input.updateReportContent.statusReportId', statusReportId);
            this.updateReportStatusStatusReportId = statusReportId;
            setState('ui.statusReportWorkspace.input.updateReportStatus.statusReportId', statusReportId);
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    parseRouteParams() {
        const pattern = '/buildFlowFsm/statusReportWorkspace/:statusReportId?';
        const patternParts = pattern.split('/');
        const pathParts = window.location.pathname.split('/');
        const params = {};
        for (let i = 0; i < patternParts.length; i++) {
            const pPart = patternParts[i];
            if (pPart.startsWith(':')) {
                const paramName = pPart.replace(/[:?]/g, '');
                const isOptional = pPart.endsWith('?');
                const rawValue = pathParts[i] ?? '';
                const value = rawValue ? decodeURIComponent(rawValue) : '';
                if (value || !isOptional) {
                    params[paramName] = value;
                }
            }
        }
        return params;
    }
    /** action generateReport (command) — route buildFlowFsm.statusReportWorkspace.generateReport; inputs: projectId, reportPeriodStart, reportPeriodEnd; writes generateReportOutput; status generateReportState; feedback keys action.generateReport.success / action.generateReport.error */
    async generateReport(signal) {
        this.generateReportState = 'loading';
        setState('ui.statusReportWorkspace.action.generateReport.status', 'loading');
        this.requestUpdate();
        const params = {
            projectId: this.generateReportProjectId,
            reportPeriodStart: this.generateReportReportPeriodStart,
            reportPeriodEnd: this.generateReportReportPeriodEnd,
        };
        const options = { mode: 'blocking' };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff(generateReportRoute, params, options);
        if (response.ok) {
            this.generateReportOutput = response.data ?? null;
            setState('ui.statusReportWorkspace.output.generateReport', this.generateReportOutput);
            this.generateReportProjectId = '';
            setState('ui.statusReportWorkspace.input.generateReport.projectId', '');
            this.generateReportReportPeriodStart = '';
            setState('ui.statusReportWorkspace.input.generateReport.reportPeriodStart', '');
            this.generateReportReportPeriodEnd = '';
            setState('ui.statusReportWorkspace.input.generateReport.reportPeriodEnd', '');
            this.generateReportState = 'success';
            setState('ui.statusReportWorkspace.action.generateReport.status', 'success');
        }
        else {
            this.generateReportError = response.error?.message ?? '';
            setState('ui.statusReportWorkspace.action.generateReport.error', this.generateReportError);
            this.generateReportState = 'error';
            setState('ui.statusReportWorkspace.action.generateReport.status', 'error');
        }
        this.requestUpdate();
    }
    /** handler for action generateReport — bind UI events here */
    handleGenerateReportClick() {
        runBlockingUiAction(async (signal) => {
            await this.generateReport(signal);
        });
    }
    /** action updateReportContent (command) — route buildFlowFsm.statusReportWorkspace.updateReportContent; inputs: statusReportId, summary, tasksOverview, timeLogsOverview, materialsOverview, delayRiskAssessment, pmNotes; writes updateReportContentOutput; status updateReportContentState; feedback keys action.updateReportContent.success / action.updateReportContent.error */
    async updateReportContent(signal) {
        const routeParams = this.parseRouteParams();
        const routeStatusReportId = routeParams['statusReportId'] ?? '';
        if (routeStatusReportId) {
            this.updateReportContentStatusReportId = routeStatusReportId;
            setState('ui.statusReportWorkspace.input.updateReportContent.statusReportId', routeStatusReportId);
        }
        const statusReportId = this.updateReportContentStatusReportId;
        if (!statusReportId) {
            this.updateReportContentState = 'idle';
            setState('ui.statusReportWorkspace.action.updateReportContent.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.updateReportContentState = 'loading';
        setState('ui.statusReportWorkspace.action.updateReportContent.status', 'loading');
        this.requestUpdate();
        const params = {
            statusReportId,
            summary: this.updateReportContentSummary,
            tasksOverview: this.updateReportContentTasksOverview,
            timeLogsOverview: this.updateReportContentTimeLogsOverview,
            materialsOverview: this.updateReportContentMaterialsOverview,
            delayRiskAssessment: this.updateReportContentDelayRiskAssessment,
            pmNotes: this.updateReportContentPmNotes,
        };
        const options = { mode: 'blocking' };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff(updateReportContentRoute, params, options);
        if (response.ok) {
            this.updateReportContentOutput = response.data ?? null;
            setState('ui.statusReportWorkspace.output.updateReportContent', this.updateReportContentOutput);
            this.updateReportContentSummary = '';
            setState('ui.statusReportWorkspace.input.updateReportContent.summary', '');
            this.updateReportContentTasksOverview = '';
            setState('ui.statusReportWorkspace.input.updateReportContent.tasksOverview', '');
            this.updateReportContentTimeLogsOverview = '';
            setState('ui.statusReportWorkspace.input.updateReportContent.timeLogsOverview', '');
            this.updateReportContentMaterialsOverview = '';
            setState('ui.statusReportWorkspace.input.updateReportContent.materialsOverview', '');
            this.updateReportContentDelayRiskAssessment = '';
            setState('ui.statusReportWorkspace.input.updateReportContent.delayRiskAssessment', '');
            this.updateReportContentPmNotes = '';
            setState('ui.statusReportWorkspace.input.updateReportContent.pmNotes', '');
            this.updateReportContentState = 'success';
            setState('ui.statusReportWorkspace.action.updateReportContent.status', 'success');
        }
        else {
            this.updateReportContentError = response.error?.message ?? '';
            setState('ui.statusReportWorkspace.action.updateReportContent.error', this.updateReportContentError);
            this.updateReportContentState = 'error';
            setState('ui.statusReportWorkspace.action.updateReportContent.status', 'error');
        }
        this.requestUpdate();
    }
    /** handler for action updateReportContent — bind UI events here */
    handleUpdateReportContentClick() {
        runBlockingUiAction(async (signal) => {
            await this.updateReportContent(signal);
        });
    }
    /** action updateReportStatus (command) — route buildFlowFsm.statusReportWorkspace.updateReportStatus; inputs: statusReportId, status; writes updateReportStatusOutput; status updateReportStatusState; feedback keys action.updateReportStatus.success / action.updateReportStatus.error */
    async updateReportStatus(signal) {
        const routeParams = this.parseRouteParams();
        const routeStatusReportId = routeParams['statusReportId'] ?? '';
        if (routeStatusReportId) {
            this.updateReportStatusStatusReportId = routeStatusReportId;
            setState('ui.statusReportWorkspace.input.updateReportStatus.statusReportId', routeStatusReportId);
        }
        const statusReportId = this.updateReportStatusStatusReportId;
        if (!statusReportId) {
            this.updateReportStatusState = 'idle';
            setState('ui.statusReportWorkspace.action.updateReportStatus.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.updateReportStatusState = 'loading';
        setState('ui.statusReportWorkspace.action.updateReportStatus.status', 'loading');
        this.requestUpdate();
        const params = {
            statusReportId,
            status: this.updateReportStatusStatus,
        };
        const options = { mode: 'blocking' };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff(updateReportStatusRoute, params, options);
        if (response.ok) {
            this.updateReportStatusOutput = response.data ?? null;
            setState('ui.statusReportWorkspace.output.updateReportStatus', this.updateReportStatusOutput);
            this.updateReportStatusStatus = '';
            setState('ui.statusReportWorkspace.input.updateReportStatus.status', '');
            this.updateReportStatusState = 'success';
            setState('ui.statusReportWorkspace.action.updateReportStatus.status', 'success');
        }
        else {
            this.updateReportStatusError = response.error?.message ?? '';
            setState('ui.statusReportWorkspace.action.updateReportStatus.error', this.updateReportStatusError);
            this.updateReportStatusState = 'error';
            setState('ui.statusReportWorkspace.action.updateReportStatus.status', 'error');
        }
        this.requestUpdate();
    }
    /** handler for action updateReportStatus — bind UI events here */
    handleUpdateReportStatusClick() {
        runBlockingUiAction(async (signal) => {
            await this.updateReportStatus(signal);
        });
    }
    /** setter for state generateReportProjectId */
    setGenerateReportProjectId(value) {
        this.generateReportProjectId = value;
        setState('ui.statusReportWorkspace.input.generateReport.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.generateReportProjectId — bind UI events here */
    handleGenerateReportProjectIdChange(e) {
        const target = e.target;
        this.setGenerateReportProjectId(target.value);
    }
    /** setter for state generateReportReportPeriodStart */
    setGenerateReportReportPeriodStart(value) {
        this.generateReportReportPeriodStart = value;
        setState('ui.statusReportWorkspace.input.generateReport.reportPeriodStart', value);
        this.requestUpdate();
    }
    /** handler for action set.generateReportReportPeriodStart — bind UI events here */
    handleGenerateReportReportPeriodStartChange(e) {
        const target = e.target;
        this.setGenerateReportReportPeriodStart(target.value);
    }
    /** setter for state generateReportReportPeriodEnd */
    setGenerateReportReportPeriodEnd(value) {
        this.generateReportReportPeriodEnd = value;
        setState('ui.statusReportWorkspace.input.generateReport.reportPeriodEnd', value);
        this.requestUpdate();
    }
    /** handler for action set.generateReportReportPeriodEnd — bind UI events here */
    handleGenerateReportReportPeriodEndChange(e) {
        const target = e.target;
        this.setGenerateReportReportPeriodEnd(target.value);
    }
    /** setter for state updateReportContentStatusReportId */
    setUpdateReportContentStatusReportId(value) {
        this.updateReportContentStatusReportId = value;
        setState('ui.statusReportWorkspace.input.updateReportContent.statusReportId', value);
        this.requestUpdate();
    }
    /** handler for action set.updateReportContentStatusReportId — bind UI events here */
    handleUpdateReportContentStatusReportIdChange(e) {
        const target = e.target;
        this.setUpdateReportContentStatusReportId(target.value);
    }
    /** setter for state updateReportContentSummary */
    setUpdateReportContentSummary(value) {
        this.updateReportContentSummary = value;
        setState('ui.statusReportWorkspace.input.updateReportContent.summary', value);
        this.requestUpdate();
    }
    /** handler for action set.updateReportContentSummary — bind UI events here */
    handleUpdateReportContentSummaryChange(e) {
        const target = e.target;
        this.setUpdateReportContentSummary(target.value);
    }
    /** setter for state updateReportContentTasksOverview */
    setUpdateReportContentTasksOverview(value) {
        this.updateReportContentTasksOverview = value;
        setState('ui.statusReportWorkspace.input.updateReportContent.tasksOverview', value);
        this.requestUpdate();
    }
    /** handler for action set.updateReportContentTasksOverview — bind UI events here */
    handleUpdateReportContentTasksOverviewChange(e) {
        const target = e.target;
        this.setUpdateReportContentTasksOverview(target.value);
    }
    /** setter for state updateReportContentTimeLogsOverview */
    setUpdateReportContentTimeLogsOverview(value) {
        this.updateReportContentTimeLogsOverview = value;
        setState('ui.statusReportWorkspace.input.updateReportContent.timeLogsOverview', value);
        this.requestUpdate();
    }
    /** handler for action set.updateReportContentTimeLogsOverview — bind UI events here */
    handleUpdateReportContentTimeLogsOverviewChange(e) {
        const target = e.target;
        this.setUpdateReportContentTimeLogsOverview(target.value);
    }
    /** setter for state updateReportContentMaterialsOverview */
    setUpdateReportContentMaterialsOverview(value) {
        this.updateReportContentMaterialsOverview = value;
        setState('ui.statusReportWorkspace.input.updateReportContent.materialsOverview', value);
        this.requestUpdate();
    }
    /** handler for action set.updateReportContentMaterialsOverview — bind UI events here */
    handleUpdateReportContentMaterialsOverviewChange(e) {
        const target = e.target;
        this.setUpdateReportContentMaterialsOverview(target.value);
    }
    /** setter for state updateReportContentDelayRiskAssessment */
    setUpdateReportContentDelayRiskAssessment(value) {
        this.updateReportContentDelayRiskAssessment = value;
        setState('ui.statusReportWorkspace.input.updateReportContent.delayRiskAssessment', value);
        this.requestUpdate();
    }
    /** handler for action set.updateReportContentDelayRiskAssessment — bind UI events here */
    handleUpdateReportContentDelayRiskAssessmentChange(e) {
        const target = e.target;
        this.setUpdateReportContentDelayRiskAssessment(target.value);
    }
    /** setter for state updateReportContentPmNotes */
    setUpdateReportContentPmNotes(value) {
        this.updateReportContentPmNotes = value;
        setState('ui.statusReportWorkspace.input.updateReportContent.pmNotes', value);
        this.requestUpdate();
    }
    /** handler for action set.updateReportContentPmNotes — bind UI events here */
    handleUpdateReportContentPmNotesChange(e) {
        const target = e.target;
        this.setUpdateReportContentPmNotes(target.value);
    }
    /** setter for state updateReportStatusStatusReportId */
    setUpdateReportStatusStatusReportId(value) {
        this.updateReportStatusStatusReportId = value;
        setState('ui.statusReportWorkspace.input.updateReportStatus.statusReportId', value);
        this.requestUpdate();
    }
    /** handler for action set.updateReportStatusStatusReportId — bind UI events here */
    handleUpdateReportStatusStatusReportIdChange(e) {
        const target = e.target;
        this.setUpdateReportStatusStatusReportId(target.value);
    }
    /** setter for state updateReportStatusStatus */
    setUpdateReportStatusStatus(value) {
        this.updateReportStatusStatus = value;
        setState('ui.statusReportWorkspace.input.updateReportStatus.status', value);
        this.requestUpdate();
    }
    /** handler for action set.updateReportStatusStatus — bind UI events here */
    handleUpdateReportStatusStatusChange(e) {
        const target = e.target;
        this.setUpdateReportStatusStatus(target.value);
    }
}
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "generateReportState", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "generateReportProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "generateReportReportPeriodStart", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "generateReportReportPeriodEnd", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "generateReportOutput", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "generateReportError", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentState", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentStatusReportId", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentSummary", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentTasksOverview", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentTimeLogsOverview", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentMaterialsOverview", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentDelayRiskAssessment", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentPmNotes", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentOutput", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportContentError", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportStatusState", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportStatusStatusReportId", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportStatusStatus", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportStatusOutput", void 0);
__decorate([
    property()
], BuildFlowFsmStatusReportWorkspaceBase.prototype, "updateReportStatusError", void 0);
