/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/clientStatusWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { viewStatusReportRoute } from '/_102045_/l2/buildFlowFsm/web/contracts/clientStatusWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    "section.clientStatusWorkspace.sec-status-report-detail.title": "statusReportDetail",
    "organism.clientStatusWorkspace.viewStatusReport.title": "View status report",
    "intent.clientStatusWorkspace.viewStatusReport.list.title": "View status report",
    "intent.clientStatusWorkspace.viewStatusReport.list.empty": "Nenhum registro encontrado",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.statusReportId.label": "Status Report Id",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.projectId.label": "Project Id",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.projectName.label": "Project Name",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.status.label": "Status",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.reportPeriodStart.label": "Report Period Start",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.reportPeriodEnd.label": "Report Period End",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.summary.label": "Summary",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.tasksOverview.label": "Tasks Overview",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.timeLogsOverview.label": "Time Logs Overview",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.materialsOverview.label": "Materials Overview",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.delayRiskAssessment.label": "Delay Risk Assessment",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.pmNotes.label": "Pm Notes",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.generatedAt.label": "Generated At",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.sharedAt.label": "Shared At",
    "intent.clientStatusWorkspace.viewStatusReport.list.filter.clientId.label": "Client Id",
    "section.clientStatusWorkspace.sec-report-header.title": "Report Identity & Period",
    "section.clientStatusWorkspace.sec-report-summary.title": "Executive Summary",
    "section.clientStatusWorkspace.sec-report-overviews.title": "Progress Overviews",
    "section.clientStatusWorkspace.sec-risk-and-notes.title": "Risk & PM Notes",
    "section.clientStatusWorkspace.sec-report-body.title": "Status Report Detail"
};
const message_pt_br = {
    "section.clientStatusWorkspace.sec-status-report-detail.title": "statusReportDetail",
    "organism.clientStatusWorkspace.viewStatusReport.title": "View status report",
    "intent.clientStatusWorkspace.viewStatusReport.list.title": "View status report",
    "intent.clientStatusWorkspace.viewStatusReport.list.empty": "Nenhum registro encontrado",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.statusReportId.label": "Status Report Id",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.projectId.label": "Project Id",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.projectName.label": "Project Name",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.status.label": "Status",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.reportPeriodStart.label": "Report Period Start",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.reportPeriodEnd.label": "Report Period End",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.summary.label": "Summary",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.tasksOverview.label": "Tasks Overview",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.timeLogsOverview.label": "Time Logs Overview",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.materialsOverview.label": "Materials Overview",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.delayRiskAssessment.label": "Delay Risk Assessment",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.pmNotes.label": "Pm Notes",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.generatedAt.label": "Generated At",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.sharedAt.label": "Shared At",
    "intent.clientStatusWorkspace.viewStatusReport.list.filter.clientId.label": "Client Id",
    "section.clientStatusWorkspace.sec-report-header.title": "Report Identity & Period",
    "section.clientStatusWorkspace.sec-report-summary.title": "Executive Summary",
    "section.clientStatusWorkspace.sec-report-overviews.title": "Progress Overviews",
    "section.clientStatusWorkspace.sec-risk-and-notes.title": "Risk & PM Notes",
    "section.clientStatusWorkspace.sec-report-body.title": "Status Report Detail"
};
const message_es = {
    "section.clientStatusWorkspace.sec-status-report-detail.title": "statusReportDetail",
    "organism.clientStatusWorkspace.viewStatusReport.title": "View status report",
    "intent.clientStatusWorkspace.viewStatusReport.list.title": "View status report",
    "intent.clientStatusWorkspace.viewStatusReport.list.empty": "Nenhum registro encontrado",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.statusReportId.label": "Status Report Id",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.projectId.label": "Project Id",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.projectName.label": "Project Name",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.status.label": "Status",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.reportPeriodStart.label": "Report Period Start",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.reportPeriodEnd.label": "Report Period End",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.summary.label": "Summary",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.tasksOverview.label": "Tasks Overview",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.timeLogsOverview.label": "Time Logs Overview",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.materialsOverview.label": "Materials Overview",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.delayRiskAssessment.label": "Delay Risk Assessment",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.pmNotes.label": "Pm Notes",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.generatedAt.label": "Generated At",
    "intent.clientStatusWorkspace.viewStatusReport.list.column.sharedAt.label": "Shared At",
    "intent.clientStatusWorkspace.viewStatusReport.list.filter.clientId.label": "Client Id",
    "section.clientStatusWorkspace.sec-report-header.title": "Report Identity & Period",
    "section.clientStatusWorkspace.sec-report-summary.title": "Executive Summary",
    "section.clientStatusWorkspace.sec-report-overviews.title": "Progress Overviews",
    "section.clientStatusWorkspace.sec-risk-and-notes.title": "Risk & PM Notes",
    "section.clientStatusWorkspace.sec-report-body.title": "Status Report Detail"
};
export const messages = {
    'en': message_en,
    'pt-br': message_pt_br,
    'es': message_es
};
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.clientStatusWorkspace.status',
    'ui.clientStatusWorkspace.action.viewStatusReport.status',
    'ui.clientStatusWorkspace.input.viewStatusReport.statusReportId',
    'ui.clientStatusWorkspace.input.viewStatusReport.clientId',
    'ui.clientStatusWorkspace.data.viewStatusReport'
];
export class BuildFlowFsmClientStatusWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state viewStatusReportState — actionStatus, values: idle|loading|success|error */
        this.viewStatusReportState = 'idle';
        /** state viewStatusReportStatusReportId — input */
        this.viewStatusReportStatusReportId = '';
        /** state viewStatusReportClientId — input */
        this.viewStatusReportClientId = '';
        /** state viewStatusReportData — queryResult, outputShape: object */
        this.viewStatusReportData = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.clientStatusWorkspace.status') ?? '';
        this.viewStatusReportState = getState('ui.clientStatusWorkspace.action.viewStatusReport.status') ?? 'idle';
        this.viewStatusReportStatusReportId = getState('ui.clientStatusWorkspace.input.viewStatusReport.statusReportId') ?? '';
        this.viewStatusReportClientId = getState('ui.clientStatusWorkspace.input.viewStatusReport.clientId') ?? '';
        this.viewStatusReportData = getState('ui.clientStatusWorkspace.data.viewStatusReport') ?? null;
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        this.applyRouteParamsFromLocation();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.clientStatusWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.clientStatusWorkspace.action.viewStatusReport.status':
                this.viewStatusReportState = value ?? 'idle';
                break;
            case 'ui.clientStatusWorkspace.input.viewStatusReport.statusReportId':
                this.viewStatusReportStatusReportId = value ?? '';
                break;
            case 'ui.clientStatusWorkspace.input.viewStatusReport.clientId':
                this.viewStatusReportClientId = value ?? '';
                break;
            case 'ui.clientStatusWorkspace.data.viewStatusReport':
                this.viewStatusReportData = value ?? null;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    applyRouteParamsFromLocation() {
        const patternParts = '/buildFlowFsm/clientStatusWorkspace/:statusReportId?'.split('/').filter(Boolean);
        const pathParts = (window.location.pathname || '').split('/').filter(Boolean);
        const params = {};
        for (let i = 0; i < patternParts.length; i++) {
            const part = patternParts[i];
            if (part.startsWith(':')) {
                const optional = part.endsWith('?');
                const name = optional ? part.slice(1, -1) : part.slice(1);
                const raw = pathParts[i];
                if (raw !== undefined && raw !== '') {
                    try {
                        params[name] = decodeURIComponent(raw);
                    }
                    catch {
                        params[name] = raw;
                    }
                }
            }
        }
        if (params['statusReportId'] !== undefined && params['statusReportId'] !== '') {
            this.viewStatusReportStatusReportId = params['statusReportId'];
            setState('ui.clientStatusWorkspace.input.viewStatusReport.statusReportId', this.viewStatusReportStatusReportId);
        }
    }
    /** action viewStatusReport (query) — route buildFlowFsm.clientStatusWorkspace.viewStatusReport; inputs: statusReportId, clientId; writes ui.clientStatusWorkspace.data.viewStatusReport; status ui.clientStatusWorkspace.action.viewStatusReport.status */
    async loadViewStatusReport() {
        this.applyRouteParamsFromLocation();
        if (!this.viewStatusReportStatusReportId) {
            this.viewStatusReportState = 'idle';
            setState('ui.clientStatusWorkspace.action.viewStatusReport.status', 'idle');
            this.viewStatusReportData = null;
            setState('ui.clientStatusWorkspace.data.viewStatusReport', null);
            return;
        }
        this.viewStatusReportState = 'loading';
        setState('ui.clientStatusWorkspace.action.viewStatusReport.status', 'loading');
        const params = {
            statusReportId: this.viewStatusReportStatusReportId,
            clientId: this.viewStatusReportClientId
        };
        const options = { mode: 'silent' };
        const response = await execBff(viewStatusReportRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.viewStatusReportData = data;
            setState('ui.clientStatusWorkspace.data.viewStatusReport', data);
            this.viewStatusReportState = 'success';
            setState('ui.clientStatusWorkspace.action.viewStatusReport.status', 'success');
        }
        else {
            if (response.error) {
                console.error('viewStatusReport failed', response.error);
            }
            this.viewStatusReportState = 'error';
            setState('ui.clientStatusWorkspace.action.viewStatusReport.status', 'error');
        }
    }
    /** handler for action viewStatusReport — bind UI events here */
    handleViewStatusReportClick(_event) {
        void this.loadViewStatusReport();
    }
    /** setter for state ui.clientStatusWorkspace.input.viewStatusReport.statusReportId */
    setViewStatusReportStatusReportId(value) {
        this.viewStatusReportStatusReportId = value;
        setState('ui.clientStatusWorkspace.input.viewStatusReport.statusReportId', value);
        this.requestUpdate();
    }
    /** handler for action set.viewStatusReportStatusReportId — bind UI events here */
    handleViewStatusReportStatusReportIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setViewStatusReportStatusReportId(value);
    }
    /** setter for state ui.clientStatusWorkspace.input.viewStatusReport.clientId */
    setViewStatusReportClientId(value) {
        this.viewStatusReportClientId = value;
        setState('ui.clientStatusWorkspace.input.viewStatusReport.clientId', value);
        this.requestUpdate();
    }
    /** handler for action set.viewStatusReportClientId — bind UI events here */
    handleViewStatusReportClientIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setViewStatusReportClientId(value);
    }
}
__decorate([
    property()
], BuildFlowFsmClientStatusWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmClientStatusWorkspaceBase.prototype, "viewStatusReportState", void 0);
__decorate([
    property()
], BuildFlowFsmClientStatusWorkspaceBase.prototype, "viewStatusReportStatusReportId", void 0);
__decorate([
    property()
], BuildFlowFsmClientStatusWorkspaceBase.prototype, "viewStatusReportClientId", void 0);
__decorate([
    property()
], BuildFlowFsmClientStatusWorkspaceBase.prototype, "viewStatusReportData", void 0);
