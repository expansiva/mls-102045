/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/changeOrderWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { setState } from '/_102029_/l2/collabState.js';
import { cmdCreateChangeOrderRoute, cmdUpdateChangeOrderRoute, cmdUpdateChangeOrderStatusRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/changeOrderWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    "section.changeOrderWorkspace.sec-create-change-order.title": "New Change Order",
    "organism.changeOrderWorkspace.cmdCreateChangeOrder.title": "Create change order",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.title": "Create change order",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.action.cmdCreateChangeOrder": "Create change order",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.title.label": "Title",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.description.label": "Description",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.impactType.label": "Impact Type",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.costAdjustment.label": "Cost Adjustment",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.scheduleAdjustmentDays.label": "Schedule Adjustment Days",
    "section.changeOrderWorkspace.sec-edit-change-order.title": "Edit Change Order",
    "organism.changeOrderWorkspace.cmdUpdateChangeOrder.title": "Update change order details",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.title": "Update change order details",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.action.cmdUpdateChangeOrder": "Update change order details",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.title.label": "Title",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.description.label": "Description",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.impactType.label": "Impact Type",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.costAdjustment.label": "Cost Adjustment",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.scheduleAdjustmentDays.label": "Schedule Adjustment Days",
    "section.changeOrderWorkspace.sec-review-change-order.title": "Review & Approve Change Order",
    "organism.changeOrderWorkspace.cmdUpdateChangeOrderStatus.title": "Update change order status",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.title": "Update change order status",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.action.cmdUpdateChangeOrderStatus": "Update change order status",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.field.status.label": "Status",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.field.rejectionReason.label": "Rejection Reason",
    "section.changeOrderWorkspace.sec-change-order-master.title": "Change Orders",
    "organism.changeOrderWorkspace.summary-first10.title": "Summary first",
    "intent.changeOrderWorkspace.summary-first10.content.title": "Summary first"
};
const message_pt_br = {
    "section.changeOrderWorkspace.sec-create-change-order.title": "Nova Ordem de Mudança",
    "organism.changeOrderWorkspace.cmdCreateChangeOrder.title": "Criar ordem de mudança",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.title": "Criar ordem de mudança",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.action.cmdCreateChangeOrder": "Criar ordem de mudança",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.title.label": "Título",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.description.label": "Descrição",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.impactType.label": "Tipo de Impacto",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.costAdjustment.label": "Ajuste de Custo",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.scheduleAdjustmentDays.label": "Dias de Ajuste de Cronograma",
    "section.changeOrderWorkspace.sec-edit-change-order.title": "Editar Ordem de Mudança",
    "organism.changeOrderWorkspace.cmdUpdateChangeOrder.title": "Atualizar detalhes da ordem de mudança",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.title": "Atualizar detalhes da ordem de mudança",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.action.cmdUpdateChangeOrder": "Atualizar detalhes da ordem de mudança",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.title.label": "Título",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.description.label": "Descrição",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.impactType.label": "Tipo de Impacto",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.costAdjustment.label": "Ajuste de Custo",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.scheduleAdjustmentDays.label": "Dias de Ajuste de Cronograma",
    "section.changeOrderWorkspace.sec-review-change-order.title": "Revisar e Aprovar Ordem de Mudança",
    "organism.changeOrderWorkspace.cmdUpdateChangeOrderStatus.title": "Atualizar status da ordem de mudança",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.title": "Atualizar status da ordem de mudança",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.action.cmdUpdateChangeOrderStatus": "Atualizar status da ordem de mudança",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.field.status.label": "Status",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.field.rejectionReason.label": "Motivo da Rejeição",
    "section.changeOrderWorkspace.sec-change-order-master.title": "Ordens de Mudança",
    "organism.changeOrderWorkspace.summary-first10.title": "Resumo inicial",
    "intent.changeOrderWorkspace.summary-first10.content.title": "Resumo inicial"
};
const message_es = {
    "section.changeOrderWorkspace.sec-create-change-order.title": "Nueva Orden de Cambio",
    "organism.changeOrderWorkspace.cmdCreateChangeOrder.title": "Crear orden de cambio",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.title": "Crear orden de cambio",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.action.cmdCreateChangeOrder": "Crear orden de cambio",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.title.label": "Título",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.description.label": "Descripción",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.impactType.label": "Tipo de Impacto",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.costAdjustment.label": "Ajuste de Costos",
    "intent.changeOrderWorkspace.cmdCreateChangeOrder.form.field.scheduleAdjustmentDays.label": "Días de Ajuste de Cronograma",
    "section.changeOrderWorkspace.sec-edit-change-order.title": "Editar Orden de Cambio",
    "organism.changeOrderWorkspace.cmdUpdateChangeOrder.title": "Actualizar detalles de la orden de cambio",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.title": "Actualizar detalles de la orden de cambio",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.action.cmdUpdateChangeOrder": "Actualizar detalles de la orden de cambio",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.title.label": "Título",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.description.label": "Descripción",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.impactType.label": "Tipo de Impacto",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.costAdjustment.label": "Ajuste de Costos",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrder.form.field.scheduleAdjustmentDays.label": "Días de Ajuste de Cronograma",
    "section.changeOrderWorkspace.sec-review-change-order.title": "Revisar y Aprobar Orden de Cambio",
    "organism.changeOrderWorkspace.cmdUpdateChangeOrderStatus.title": "Actualizar estado de la orden de cambio",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.title": "Actualizar estado de la orden de cambio",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.action.cmdUpdateChangeOrderStatus": "Actualizar estado de la orden de cambio",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.field.status.label": "Estado",
    "intent.changeOrderWorkspace.cmdUpdateChangeOrderStatus.form.field.rejectionReason.label": "Motivo de Rechazo",
    "section.changeOrderWorkspace.sec-change-order-master.title": "Órdenes de Cambio",
    "organism.changeOrderWorkspace.summary-first10.title": "Resumen inicial",
    "intent.changeOrderWorkspace.summary-first10.content.title": "Resumen inicial"
};
const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
export class BuildFlowFsmChangeOrderWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state ui.changeOrderWorkspace.status — pageStatus */
        this.status = '';
        /** state ui.changeOrderWorkspace.action.cmdCreateChangeOrder.status — actionStatus, values: idle|loading|success|error */
        this.cmdCreateChangeOrderState = 'idle';
        /** state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.projectId — input, presentation: selection */
        this.cmdCreateChangeOrderProjectId = '';
        /** state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.title — input, presentation: form */
        this.cmdCreateChangeOrderTitle = '';
        /** state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.description — input, presentation: form */
        this.cmdCreateChangeOrderDescription = '';
        /** state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.impactType — input, presentation: form */
        this.cmdCreateChangeOrderImpactType = '';
        /** state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.costAdjustment — input, presentation: form */
        this.cmdCreateChangeOrderCostAdjustment = '';
        /** state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.scheduleAdjustmentDays — input, presentation: form */
        this.cmdCreateChangeOrderScheduleAdjustmentDays = '';
        /** state ui.changeOrderWorkspace.output.cmdCreateChangeOrder — commandOutput, outputShape: object */
        this.cmdCreateChangeOrderOutput = null;
        /** state ui.changeOrderWorkspace.action.cmdCreateChangeOrder.error — actionError */
        this.cmdCreateChangeOrderError = '';
        /** state ui.changeOrderWorkspace.action.cmdUpdateChangeOrder.status — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateChangeOrderState = 'idle';
        /** state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.changeOrderId — input, presentation: route */
        this.cmdUpdateChangeOrderChangeOrderId = '';
        /** state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.title — input, presentation: form */
        this.cmdUpdateChangeOrderTitle = '';
        /** state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.description — input, presentation: form */
        this.cmdUpdateChangeOrderDescription = '';
        /** state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.impactType — input, presentation: form */
        this.cmdUpdateChangeOrderImpactType = '';
        /** state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.costAdjustment — input, presentation: form */
        this.cmdUpdateChangeOrderCostAdjustment = '';
        /** state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.scheduleAdjustmentDays — input, presentation: form */
        this.cmdUpdateChangeOrderScheduleAdjustmentDays = '';
        /** state ui.changeOrderWorkspace.output.cmdUpdateChangeOrder — commandOutput, outputShape: object */
        this.cmdUpdateChangeOrderOutput = null;
        /** state ui.changeOrderWorkspace.action.cmdUpdateChangeOrder.error — actionError */
        this.cmdUpdateChangeOrderError = '';
        /** state ui.changeOrderWorkspace.action.cmdUpdateChangeOrderStatus.status — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateChangeOrderStatusState = 'idle';
        /** state ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.changeOrderId — input, presentation: route */
        this.cmdUpdateChangeOrderStatusChangeOrderId = '';
        /** state ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.status — input, presentation: form */
        this.cmdUpdateChangeOrderStatusStatus = '';
        /** state ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.rejectionReason — input, presentation: form */
        this.cmdUpdateChangeOrderStatusRejectionReason = '';
        /** state ui.changeOrderWorkspace.output.cmdUpdateChangeOrderStatus — commandOutput, outputShape: object */
        this.cmdUpdateChangeOrderStatusOutput = null;
        /** state ui.changeOrderWorkspace.action.cmdUpdateChangeOrderStatus.error — actionError */
        this.cmdUpdateChangeOrderStatusError = '';
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.parseRouteParams();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    parseRouteParams() {
        const path = window.location.pathname;
        const segments = path.split('/').filter((s) => s.length > 0);
        // Expected: ['buildFlowFsm', 'changeOrderWorkspace', changeOrderId?]
        if (segments.length >= 3) {
            const raw = segments[2];
            if (raw) {
                const changeOrderId = decodeURIComponent(raw);
                if (changeOrderId) {
                    this.cmdUpdateChangeOrderChangeOrderId = changeOrderId;
                    setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.changeOrderId', changeOrderId);
                    this.cmdUpdateChangeOrderStatusChangeOrderId = changeOrderId;
                    setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.changeOrderId', changeOrderId);
                }
            }
        }
    }
    /** action cmdCreateChangeOrder (command) — route buildFlowFsm.changeOrderWorkspace.cmdCreateChangeOrder; inputs: projectId, title, description, impactType, costAdjustment, scheduleAdjustmentDays; writes cmdCreateChangeOrderOutput; status cmdCreateChangeOrderState; feedback keys action.cmdCreateChangeOrder.success / action.cmdCreateChangeOrder.error */
    async cmdCreateChangeOrder() {
        this.cmdCreateChangeOrderState = 'loading';
        setState('ui.changeOrderWorkspace.action.cmdCreateChangeOrder.status', 'loading');
        const params = {
            projectId: this.cmdCreateChangeOrderProjectId,
            title: this.cmdCreateChangeOrderTitle,
            description: this.cmdCreateChangeOrderDescription,
            impactType: this.cmdCreateChangeOrderImpactType,
            costAdjustment: this.cmdCreateChangeOrderCostAdjustment ? Number(this.cmdCreateChangeOrderCostAdjustment) : 0,
            scheduleAdjustmentDays: this.cmdCreateChangeOrderScheduleAdjustmentDays ? Number(this.cmdCreateChangeOrderScheduleAdjustmentDays) : undefined,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateChangeOrderRoute, params, options);
        if (response.ok) {
            this.cmdCreateChangeOrderOutput = response.data ?? null;
            setState('ui.changeOrderWorkspace.output.cmdCreateChangeOrder', response.data ?? null);
            // Clear form inputs
            this.cmdCreateChangeOrderProjectId = '';
            setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.projectId', '');
            this.cmdCreateChangeOrderTitle = '';
            setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.title', '');
            this.cmdCreateChangeOrderDescription = '';
            setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.description', '');
            this.cmdCreateChangeOrderImpactType = '';
            setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.impactType', '');
            this.cmdCreateChangeOrderCostAdjustment = '';
            setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.costAdjustment', '');
            this.cmdCreateChangeOrderScheduleAdjustmentDays = '';
            setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.scheduleAdjustmentDays', '');
            this.cmdCreateChangeOrderError = '';
            setState('ui.changeOrderWorkspace.action.cmdCreateChangeOrder.error', '');
            this.cmdCreateChangeOrderState = 'success';
            setState('ui.changeOrderWorkspace.action.cmdCreateChangeOrder.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? '';
            this.cmdCreateChangeOrderError = errorMsg;
            setState('ui.changeOrderWorkspace.action.cmdCreateChangeOrder.error', errorMsg);
            this.cmdCreateChangeOrderState = 'error';
            setState('ui.changeOrderWorkspace.action.cmdCreateChangeOrder.status', 'error');
        }
    }
    /** handler for action cmdCreateChangeOrder — bind UI events here */
    handleCmdCreateChangeOrderClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.cmdCreateChangeOrder();
        });
    }
    /** action cmdUpdateChangeOrder (command) — route buildFlowFsm.changeOrderWorkspace.cmdUpdateChangeOrder; inputs: changeOrderId, title, description, impactType, costAdjustment, scheduleAdjustmentDays; writes cmdUpdateChangeOrderOutput; status cmdUpdateChangeOrderState; feedback keys action.cmdUpdateChangeOrder.success / action.cmdUpdateChangeOrder.error */
    async cmdUpdateChangeOrder() {
        // Parse route params before calling
        this.parseRouteParams();
        if (!this.cmdUpdateChangeOrderChangeOrderId) {
            this.cmdUpdateChangeOrderState = 'idle';
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrder.status', 'idle');
            return;
        }
        this.cmdUpdateChangeOrderState = 'loading';
        setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrder.status', 'loading');
        const params = {
            changeOrderId: this.cmdUpdateChangeOrderChangeOrderId,
            title: this.cmdUpdateChangeOrderTitle,
            description: this.cmdUpdateChangeOrderDescription,
            impactType: this.cmdUpdateChangeOrderImpactType,
            costAdjustment: this.cmdUpdateChangeOrderCostAdjustment ? Number(this.cmdUpdateChangeOrderCostAdjustment) : 0,
            scheduleAdjustmentDays: this.cmdUpdateChangeOrderScheduleAdjustmentDays ? Number(this.cmdUpdateChangeOrderScheduleAdjustmentDays) : undefined,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateChangeOrderRoute, params, options);
        if (response.ok) {
            this.cmdUpdateChangeOrderOutput = response.data ?? null;
            setState('ui.changeOrderWorkspace.output.cmdUpdateChangeOrder', response.data ?? null);
            // Clear form inputs (not changeOrderId)
            this.cmdUpdateChangeOrderTitle = '';
            setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.title', '');
            this.cmdUpdateChangeOrderDescription = '';
            setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.description', '');
            this.cmdUpdateChangeOrderImpactType = '';
            setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.impactType', '');
            this.cmdUpdateChangeOrderCostAdjustment = '';
            setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.costAdjustment', '');
            this.cmdUpdateChangeOrderScheduleAdjustmentDays = '';
            setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.scheduleAdjustmentDays', '');
            this.cmdUpdateChangeOrderError = '';
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrder.error', '');
            this.cmdUpdateChangeOrderState = 'success';
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrder.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? '';
            this.cmdUpdateChangeOrderError = errorMsg;
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrder.error', errorMsg);
            this.cmdUpdateChangeOrderState = 'error';
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrder.status', 'error');
        }
    }
    /** handler for action cmdUpdateChangeOrder — bind UI events here */
    handleCmdUpdateChangeOrderClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateChangeOrder();
        });
    }
    /** action cmdUpdateChangeOrderStatus (command) — route buildFlowFsm.changeOrderWorkspace.cmdUpdateChangeOrderStatus; inputs: changeOrderId, status, rejectionReason; writes cmdUpdateChangeOrderStatusOutput; status cmdUpdateChangeOrderStatusState; feedback keys action.cmdUpdateChangeOrderStatus.success / action.cmdUpdateChangeOrderStatus.error */
    async cmdUpdateChangeOrderStatus() {
        // Parse route params before calling
        this.parseRouteParams();
        if (!this.cmdUpdateChangeOrderStatusChangeOrderId) {
            this.cmdUpdateChangeOrderStatusState = 'idle';
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrderStatus.status', 'idle');
            return;
        }
        this.cmdUpdateChangeOrderStatusState = 'loading';
        setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrderStatus.status', 'loading');
        const params = {
            changeOrderId: this.cmdUpdateChangeOrderStatusChangeOrderId,
            status: this.cmdUpdateChangeOrderStatusStatus,
            rejectionReason: this.cmdUpdateChangeOrderStatusRejectionReason || undefined,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateChangeOrderStatusRoute, params, options);
        if (response.ok) {
            this.cmdUpdateChangeOrderStatusOutput = response.data ?? null;
            setState('ui.changeOrderWorkspace.output.cmdUpdateChangeOrderStatus', response.data ?? null);
            // Clear form inputs (not changeOrderId)
            this.cmdUpdateChangeOrderStatusStatus = '';
            setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.status', '');
            this.cmdUpdateChangeOrderStatusRejectionReason = '';
            setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.rejectionReason', '');
            this.cmdUpdateChangeOrderStatusError = '';
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrderStatus.error', '');
            this.cmdUpdateChangeOrderStatusState = 'success';
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrderStatus.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? '';
            this.cmdUpdateChangeOrderStatusError = errorMsg;
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrderStatus.error', errorMsg);
            this.cmdUpdateChangeOrderStatusState = 'error';
            setState('ui.changeOrderWorkspace.action.cmdUpdateChangeOrderStatus.status', 'error');
        }
    }
    /** handler for action cmdUpdateChangeOrderStatus — bind UI events here */
    handleCmdUpdateChangeOrderStatusClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateChangeOrderStatus();
        });
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.projectId */
    setCmdCreateChangeOrderProjectId(value) {
        this.cmdCreateChangeOrderProjectId = value;
        setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderProjectId — bind UI events here */
    handleCmdCreateChangeOrderProjectIdChange(e) {
        const value = e.target.value;
        this.setCmdCreateChangeOrderProjectId(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.title */
    setCmdCreateChangeOrderTitle(value) {
        this.cmdCreateChangeOrderTitle = value;
        setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.title', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderTitle — bind UI events here */
    handleCmdCreateChangeOrderTitleChange(e) {
        const value = e.target.value;
        this.setCmdCreateChangeOrderTitle(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.description */
    setCmdCreateChangeOrderDescription(value) {
        this.cmdCreateChangeOrderDescription = value;
        setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderDescription — bind UI events here */
    handleCmdCreateChangeOrderDescriptionChange(e) {
        const value = e.target.value;
        this.setCmdCreateChangeOrderDescription(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.impactType */
    setCmdCreateChangeOrderImpactType(value) {
        this.cmdCreateChangeOrderImpactType = value;
        setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.impactType', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderImpactType — bind UI events here */
    handleCmdCreateChangeOrderImpactTypeChange(e) {
        const value = e.target.value;
        this.setCmdCreateChangeOrderImpactType(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.costAdjustment */
    setCmdCreateChangeOrderCostAdjustment(value) {
        this.cmdCreateChangeOrderCostAdjustment = value;
        setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.costAdjustment', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderCostAdjustment — bind UI events here */
    handleCmdCreateChangeOrderCostAdjustmentChange(e) {
        const value = e.target.value;
        this.setCmdCreateChangeOrderCostAdjustment(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdCreateChangeOrder.scheduleAdjustmentDays */
    setCmdCreateChangeOrderScheduleAdjustmentDays(value) {
        this.cmdCreateChangeOrderScheduleAdjustmentDays = value;
        setState('ui.changeOrderWorkspace.input.cmdCreateChangeOrder.scheduleAdjustmentDays', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateChangeOrderScheduleAdjustmentDays — bind UI events here */
    handleCmdCreateChangeOrderScheduleAdjustmentDaysChange(e) {
        const value = e.target.value;
        this.setCmdCreateChangeOrderScheduleAdjustmentDays(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.changeOrderId */
    setCmdUpdateChangeOrderChangeOrderId(value) {
        this.cmdUpdateChangeOrderChangeOrderId = value;
        setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.changeOrderId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderChangeOrderId — bind UI events here */
    handleCmdUpdateChangeOrderChangeOrderIdChange(e) {
        const value = e.target.value;
        this.setCmdUpdateChangeOrderChangeOrderId(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.title */
    setCmdUpdateChangeOrderTitle(value) {
        this.cmdUpdateChangeOrderTitle = value;
        setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.title', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderTitle — bind UI events here */
    handleCmdUpdateChangeOrderTitleChange(e) {
        const value = e.target.value;
        this.setCmdUpdateChangeOrderTitle(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.description */
    setCmdUpdateChangeOrderDescription(value) {
        this.cmdUpdateChangeOrderDescription = value;
        setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderDescription — bind UI events here */
    handleCmdUpdateChangeOrderDescriptionChange(e) {
        const value = e.target.value;
        this.setCmdUpdateChangeOrderDescription(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.impactType */
    setCmdUpdateChangeOrderImpactType(value) {
        this.cmdUpdateChangeOrderImpactType = value;
        setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.impactType', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderImpactType — bind UI events here */
    handleCmdUpdateChangeOrderImpactTypeChange(e) {
        const value = e.target.value;
        this.setCmdUpdateChangeOrderImpactType(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.costAdjustment */
    setCmdUpdateChangeOrderCostAdjustment(value) {
        this.cmdUpdateChangeOrderCostAdjustment = value;
        setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.costAdjustment', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderCostAdjustment — bind UI events here */
    handleCmdUpdateChangeOrderCostAdjustmentChange(e) {
        const value = e.target.value;
        this.setCmdUpdateChangeOrderCostAdjustment(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.scheduleAdjustmentDays */
    setCmdUpdateChangeOrderScheduleAdjustmentDays(value) {
        this.cmdUpdateChangeOrderScheduleAdjustmentDays = value;
        setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrder.scheduleAdjustmentDays', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderScheduleAdjustmentDays — bind UI events here */
    handleCmdUpdateChangeOrderScheduleAdjustmentDaysChange(e) {
        const value = e.target.value;
        this.setCmdUpdateChangeOrderScheduleAdjustmentDays(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.changeOrderId */
    setCmdUpdateChangeOrderStatusChangeOrderId(value) {
        this.cmdUpdateChangeOrderStatusChangeOrderId = value;
        setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.changeOrderId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderStatusChangeOrderId — bind UI events here */
    handleCmdUpdateChangeOrderStatusChangeOrderIdChange(e) {
        const value = e.target.value;
        this.setCmdUpdateChangeOrderStatusChangeOrderId(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.status */
    setCmdUpdateChangeOrderStatusStatus(value) {
        this.cmdUpdateChangeOrderStatusStatus = value;
        setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderStatusStatus — bind UI events here */
    handleCmdUpdateChangeOrderStatusStatusChange(e) {
        const value = e.target.value;
        this.setCmdUpdateChangeOrderStatusStatus(value);
    }
    /** setter for state ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.rejectionReason */
    setCmdUpdateChangeOrderStatusRejectionReason(value) {
        this.cmdUpdateChangeOrderStatusRejectionReason = value;
        setState('ui.changeOrderWorkspace.input.cmdUpdateChangeOrderStatus.rejectionReason', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateChangeOrderStatusRejectionReason — bind UI events here */
    handleCmdUpdateChangeOrderStatusRejectionReasonChange(e) {
        const value = e.target.value;
        this.setCmdUpdateChangeOrderStatusRejectionReason(value);
    }
}
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdCreateChangeOrderState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdCreateChangeOrderProjectId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdCreateChangeOrderTitle", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdCreateChangeOrderDescription", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdCreateChangeOrderImpactType", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdCreateChangeOrderCostAdjustment", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdCreateChangeOrderScheduleAdjustmentDays", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdCreateChangeOrderOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdCreateChangeOrderError", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderChangeOrderId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderTitle", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderDescription", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderImpactType", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderCostAdjustment", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderScheduleAdjustmentDays", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderError", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderStatusState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderStatusChangeOrderId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderStatusStatus", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderStatusRejectionReason", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderStatusOutput", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderWorkspaceBase.prototype, "cmdUpdateChangeOrderStatusError", void 0);
