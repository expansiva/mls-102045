/// <mls fileReference="_102045_/l2/buildFlowFsm/web/shared/billingSummaryWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { listBillingSummariesRoute, createBillingSummaryCmdRoute, shareBillingSummaryCmdRoute, } from '/_102045_/l2/buildFlowFsm/web/contracts/billingSummaryWorkspace.js';
/// **collab_i18n_start**
const message_en = {
    'section.billingSummaryWorkspace.sec-billing-summary-list.title': 'Billing Summaries Pipeline',
    'organism.billingSummaryWorkspace.inline-row-command10.title': 'Inline row command',
    'intent.billingSummaryWorkspace.inline-row-command10.content.title': 'Inline row command',
    'organism.billingSummaryWorkspace.listBillingSummaries.title': 'Browse billing summaries',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.title': 'Browse billing summaries',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.empty': 'Nenhum registro encontrado',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.column.billingSummaries.label': 'Billing Summaries',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.column.total.label': 'Total',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.projectId.label': 'Project Id',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.status.label': 'Status',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.page.label': 'Page',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.pageSize.label': 'Page Size',
    'organism.billingSummaryWorkspace.createBillingSummaryCmd.title': 'Create billing summary',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.title': 'Create billing summary',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.action.createBillingSummaryCmd': 'Create billing summary',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.field.periodStart.label': 'Period Start',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.field.periodEnd.label': 'Period End',
    'organism.billingSummaryWorkspace.shareBillingSummaryCmd.title': 'Share billing summary with client',
    'intent.billingSummaryWorkspace.shareBillingSummaryCmd.form.title': 'Share billing summary with client',
    'intent.billingSummaryWorkspace.shareBillingSummaryCmd.form.action.shareBillingSummaryCmd': 'Share billing summary with client',
    'intent.billingSummaryWorkspace.shareBillingSummaryCmd.form.field.status.label': 'Status',
    'action.createBillingSummaryCmd.success': 'Create billing summary: OK',
    'action.createBillingSummaryCmd.error': 'Create billing summary: falhou',
    'action.shareBillingSummaryCmd.success': 'Share billing summary with client: OK',
    'action.shareBillingSummaryCmd.error': 'Share billing summary with client: falhou',
    'section.billingSummaryWorkspace.sec-billing-list.title': 'Billing Summaries',
    'section.billingSummaryWorkspace.sec-create-billing.title': 'Create Billing Summary',
    'section.billingSummaryWorkspace.sec-billing-summary-workspace.title': 'Billing Summary Workspace',
};
const message_pt_br = {
    'section.billingSummaryWorkspace.sec-billing-summary-list.title': 'Billing Summaries Pipeline',
    'organism.billingSummaryWorkspace.inline-row-command10.title': 'Inline row command',
    'intent.billingSummaryWorkspace.inline-row-command10.content.title': 'Inline row command',
    'organism.billingSummaryWorkspace.listBillingSummaries.title': 'Browse billing summaries',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.title': 'Browse billing summaries',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.empty': 'Nenhum registro encontrado',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.column.billingSummaries.label': 'Billing Summaries',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.column.total.label': 'Total',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.projectId.label': 'Project Id',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.status.label': 'Status',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.page.label': 'Page',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.pageSize.label': 'Page Size',
    'organism.billingSummaryWorkspace.createBillingSummaryCmd.title': 'Create billing summary',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.title': 'Create billing summary',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.action.createBillingSummaryCmd': 'Create billing summary',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.field.periodStart.label': 'Period Start',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.field.periodEnd.label': 'Period End',
    'organism.billingSummaryWorkspace.shareBillingSummaryCmd.title': 'Share billing summary with client',
    'intent.billingSummaryWorkspace.shareBillingSummaryCmd.form.title': 'Share billing summary with client',
    'intent.billingSummaryWorkspace.shareBillingSummaryCmd.form.action.shareBillingSummaryCmd': 'Share billing summary with client',
    'intent.billingSummaryWorkspace.shareBillingSummaryCmd.form.field.status.label': 'Status',
    'action.createBillingSummaryCmd.success': 'Create billing summary: OK',
    'action.createBillingSummaryCmd.error': 'Create billing summary: falhou',
    'action.shareBillingSummaryCmd.success': 'Share billing summary with client: OK',
    'action.shareBillingSummaryCmd.error': 'Share billing summary with client: falhou',
    'section.billingSummaryWorkspace.sec-billing-list.title': 'Billing Summaries',
    'section.billingSummaryWorkspace.sec-create-billing.title': 'Create Billing Summary',
    'section.billingSummaryWorkspace.sec-billing-summary-workspace.title': 'Billing Summary Workspace',
};
const message_es = {
    'section.billingSummaryWorkspace.sec-billing-summary-list.title': 'Billing Summaries Pipeline',
    'organism.billingSummaryWorkspace.inline-row-command10.title': 'Inline row command',
    'intent.billingSummaryWorkspace.inline-row-command10.content.title': 'Inline row command',
    'organism.billingSummaryWorkspace.listBillingSummaries.title': 'Browse billing summaries',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.title': 'Browse billing summaries',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.empty': 'Nenhum registro encontrado',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.column.billingSummaries.label': 'Billing Summaries',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.column.total.label': 'Total',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.projectId.label': 'Project Id',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.status.label': 'Status',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.page.label': 'Page',
    'intent.billingSummaryWorkspace.listBillingSummaries.list.filter.pageSize.label': 'Page Size',
    'organism.billingSummaryWorkspace.createBillingSummaryCmd.title': 'Create billing summary',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.title': 'Create billing summary',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.action.createBillingSummaryCmd': 'Create billing summary',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.field.periodStart.label': 'Period Start',
    'intent.billingSummaryWorkspace.createBillingSummaryCmd.form.field.periodEnd.label': 'Period End',
    'organism.billingSummaryWorkspace.shareBillingSummaryCmd.title': 'Share billing summary with client',
    'intent.billingSummaryWorkspace.shareBillingSummaryCmd.form.title': 'Share billing summary with client',
    'intent.billingSummaryWorkspace.shareBillingSummaryCmd.form.action.shareBillingSummaryCmd': 'Share billing summary with client',
    'intent.billingSummaryWorkspace.shareBillingSummaryCmd.form.field.status.label': 'Status',
    'action.createBillingSummaryCmd.success': 'Create billing summary: OK',
    'action.createBillingSummaryCmd.error': 'Create billing summary: falhou',
    'action.shareBillingSummaryCmd.success': 'Share billing summary with client: OK',
    'action.shareBillingSummaryCmd.error': 'Share billing summary with client: falhou',
    'section.billingSummaryWorkspace.sec-billing-list.title': 'Billing Summaries',
    'section.billingSummaryWorkspace.sec-create-billing.title': 'Create Billing Summary',
    'section.billingSummaryWorkspace.sec-billing-summary-workspace.title': 'Billing Summary Workspace',
};
export const messages = { 'en': message_en, 'pt-br': message_pt_br, 'es': message_es };
/// **collab_i18n_end**
const LIST_BILLING_SUMMARIES_DATA_DEFAULT = { billingSummaries: [], total: 0 };
const SUBSCRIBED_STATE_KEYS = [
    'ui.billingSummaryWorkspace.status',
    'ui.billingSummaryWorkspace.action.listBillingSummaries.status',
    'ui.billingSummaryWorkspace.input.listBillingSummaries.projectId',
    'ui.billingSummaryWorkspace.input.listBillingSummaries.status',
    'ui.billingSummaryWorkspace.input.listBillingSummaries.page',
    'ui.billingSummaryWorkspace.input.listBillingSummaries.pageSize',
    'ui.billingSummaryWorkspace.data.listBillingSummaries',
    'ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status',
    'ui.billingSummaryWorkspace.input.createBillingSummaryCmd.projectId',
    'ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodStart',
    'ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodEnd',
    'ui.billingSummaryWorkspace.output.createBillingSummaryCmd',
    'ui.billingSummaryWorkspace.action.createBillingSummaryCmd.error',
    'ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status',
    'ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.billingSummaryId',
    'ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.status',
    'ui.billingSummaryWorkspace.output.shareBillingSummaryCmd',
    'ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.error',
];
export class BuildFlowFsmBillingSummaryWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state listBillingSummariesState — actionStatus, values: idle|loading|success|error */
        this.listBillingSummariesState = 'idle';
        /** state listBillingSummariesProjectId — input */
        this.listBillingSummariesProjectId = '';
        /** state listBillingSummariesStatus — input */
        this.listBillingSummariesStatus = '';
        /** state listBillingSummariesPage — input */
        this.listBillingSummariesPage = '';
        /** state listBillingSummariesPageSize — input */
        this.listBillingSummariesPageSize = '';
        /** state listBillingSummariesData — queryResult, outputShape: paginated */
        this.listBillingSummariesData = LIST_BILLING_SUMMARIES_DATA_DEFAULT;
        /** state createBillingSummaryCmdState — actionStatus, values: idle|loading|success|error */
        this.createBillingSummaryCmdState = 'idle';
        /** state createBillingSummaryCmdProjectId — input */
        this.createBillingSummaryCmdProjectId = '';
        /** state createBillingSummaryCmdPeriodStart — input */
        this.createBillingSummaryCmdPeriodStart = '';
        /** state createBillingSummaryCmdPeriodEnd — input */
        this.createBillingSummaryCmdPeriodEnd = '';
        /** state createBillingSummaryCmdOutput — commandOutput */
        this.createBillingSummaryCmdOutput = null;
        /** state createBillingSummaryCmdError — actionError */
        this.createBillingSummaryCmdError = '';
        /** state shareBillingSummaryCmdState — actionStatus, values: idle|loading|success|error */
        this.shareBillingSummaryCmdState = 'idle';
        /** state shareBillingSummaryCmdBillingSummaryId — input */
        this.shareBillingSummaryCmdBillingSummaryId = '';
        /** state shareBillingSummaryCmdStatus — input */
        this.shareBillingSummaryCmdStatus = '';
        /** state shareBillingSummaryCmdOutput — commandOutput */
        this.shareBillingSummaryCmdOutput = null;
        /** state shareBillingSummaryCmdError — actionError */
        this.shareBillingSummaryCmdError = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.billingSummaryWorkspace.status', '');
        this.initStateValue('ui.billingSummaryWorkspace.action.listBillingSummaries.status', 'idle');
        this.initStateValue('ui.billingSummaryWorkspace.input.listBillingSummaries.projectId', '');
        this.initStateValue('ui.billingSummaryWorkspace.input.listBillingSummaries.status', '');
        this.initStateValue('ui.billingSummaryWorkspace.input.listBillingSummaries.page', '');
        this.initStateValue('ui.billingSummaryWorkspace.input.listBillingSummaries.pageSize', '');
        this.initStateValue('ui.billingSummaryWorkspace.data.listBillingSummaries', LIST_BILLING_SUMMARIES_DATA_DEFAULT);
        this.initStateValue('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status', 'idle');
        this.initStateValue('ui.billingSummaryWorkspace.input.createBillingSummaryCmd.projectId', '');
        this.initStateValue('ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodStart', '');
        this.initStateValue('ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodEnd', '');
        this.initStateValue('ui.billingSummaryWorkspace.output.createBillingSummaryCmd', null);
        this.initStateValue('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.error', '');
        this.initStateValue('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status', 'idle');
        this.initStateValue('ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.billingSummaryId', '');
        this.initStateValue('ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.status', '');
        this.initStateValue('ui.billingSummaryWorkspace.output.shareBillingSummaryCmd', null);
        this.initStateValue('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.error', '');
        this.syncRouteParams();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadListBillingSummaries();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.billingSummaryWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.action.listBillingSummaries.status':
                this.listBillingSummariesState = value ?? 'idle';
                break;
            case 'ui.billingSummaryWorkspace.input.listBillingSummaries.projectId':
                this.listBillingSummariesProjectId = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.listBillingSummaries.status':
                this.listBillingSummariesStatus = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.listBillingSummaries.page':
                this.listBillingSummariesPage = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.listBillingSummaries.pageSize':
                this.listBillingSummariesPageSize = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.data.listBillingSummaries':
                this.listBillingSummariesData = value ?? LIST_BILLING_SUMMARIES_DATA_DEFAULT;
                break;
            case 'ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status':
                this.createBillingSummaryCmdState = value ?? 'idle';
                break;
            case 'ui.billingSummaryWorkspace.input.createBillingSummaryCmd.projectId':
                this.createBillingSummaryCmdProjectId = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodStart':
                this.createBillingSummaryCmdPeriodStart = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodEnd':
                this.createBillingSummaryCmdPeriodEnd = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.output.createBillingSummaryCmd':
                this.createBillingSummaryCmdOutput = value ?? null;
                break;
            case 'ui.billingSummaryWorkspace.action.createBillingSummaryCmd.error':
                this.createBillingSummaryCmdError = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status':
                this.shareBillingSummaryCmdState = value ?? 'idle';
                break;
            case 'ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.billingSummaryId':
                this.shareBillingSummaryCmdBillingSummaryId = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.status':
                this.shareBillingSummaryCmdStatus = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.output.shareBillingSummaryCmd':
                this.shareBillingSummaryCmdOutput = value ?? null;
                break;
            case 'ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.error':
                this.shareBillingSummaryCmdError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.billingSummaryWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.action.listBillingSummaries.status':
                this.listBillingSummariesState = value ?? 'idle';
                break;
            case 'ui.billingSummaryWorkspace.input.listBillingSummaries.projectId':
                this.listBillingSummariesProjectId = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.listBillingSummaries.status':
                this.listBillingSummariesStatus = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.listBillingSummaries.page':
                this.listBillingSummariesPage = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.listBillingSummaries.pageSize':
                this.listBillingSummariesPageSize = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.data.listBillingSummaries':
                this.listBillingSummariesData = value ?? LIST_BILLING_SUMMARIES_DATA_DEFAULT;
                break;
            case 'ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status':
                this.createBillingSummaryCmdState = value ?? 'idle';
                break;
            case 'ui.billingSummaryWorkspace.input.createBillingSummaryCmd.projectId':
                this.createBillingSummaryCmdProjectId = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodStart':
                this.createBillingSummaryCmdPeriodStart = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodEnd':
                this.createBillingSummaryCmdPeriodEnd = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.output.createBillingSummaryCmd':
                this.createBillingSummaryCmdOutput = value ?? null;
                break;
            case 'ui.billingSummaryWorkspace.action.createBillingSummaryCmd.error':
                this.createBillingSummaryCmdError = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status':
                this.shareBillingSummaryCmdState = value ?? 'idle';
                break;
            case 'ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.billingSummaryId':
                this.shareBillingSummaryCmdBillingSummaryId = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.status':
                this.shareBillingSummaryCmdStatus = value ?? '';
                break;
            case 'ui.billingSummaryWorkspace.output.shareBillingSummaryCmd':
                this.shareBillingSummaryCmdOutput = value ?? null;
                break;
            case 'ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.error':
                this.shareBillingSummaryCmdError = value ?? '';
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    syncRouteParams() {
        const pathname = window.location.pathname;
        const match = pathname.match(/^\/buildFlowFsm\/billingSummaryWorkspace(?:\/([^/]+))?(?:\/([^/]+))?\/?$/);
        const rawProjectId = match && match[1] ? match[1] : '';
        let projectId = '';
        if (rawProjectId) {
            try {
                projectId = decodeURIComponent(rawProjectId);
            }
            catch {
                projectId = rawProjectId;
            }
        }
        if (projectId) {
            if (!this.createBillingSummaryCmdProjectId) {
                this.createBillingSummaryCmdProjectId = projectId;
                setState('ui.billingSummaryWorkspace.input.createBillingSummaryCmd.projectId', projectId);
            }
        }
        const rawBillingSummaryId = match && match[2] ? match[2] : '';
        let billingSummaryId = '';
        if (rawBillingSummaryId) {
            try {
                billingSummaryId = decodeURIComponent(rawBillingSummaryId);
            }
            catch {
                billingSummaryId = rawBillingSummaryId;
            }
        }
        if (billingSummaryId) {
            if (!this.shareBillingSummaryCmdBillingSummaryId) {
                this.shareBillingSummaryCmdBillingSummaryId = billingSummaryId;
                setState('ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.billingSummaryId', billingSummaryId);
            }
        }
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action listBillingSummaries (query) — route buildFlowFsm.billingSummaryWorkspace.listBillingSummaries; inputs: projectId, status, page, pageSize; writes ui.billingSummaryWorkspace.data.listBillingSummaries; status ui.billingSummaryWorkspace.action.listBillingSummaries.status */
    async loadListBillingSummaries() {
        this.syncRouteParams();
        this.listBillingSummariesState = 'loading';
        setState('ui.billingSummaryWorkspace.action.listBillingSummaries.status', 'loading');
        const params = {};
        if (this.listBillingSummariesProjectId) {
            params.projectId = this.listBillingSummariesProjectId;
        }
        if (this.listBillingSummariesStatus) {
            params.status = this.listBillingSummariesStatus;
        }
        if (this.listBillingSummariesPage !== '') {
            const pageNum = Number(this.listBillingSummariesPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.listBillingSummariesPageSize !== '') {
            const pageSizeNum = Number(this.listBillingSummariesPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(listBillingSummariesRoute, params, options);
        if (response.ok) {
            const data = response.data ?? LIST_BILLING_SUMMARIES_DATA_DEFAULT;
            this.listBillingSummariesData = data;
            setState('ui.billingSummaryWorkspace.data.listBillingSummaries', data);
            this.listBillingSummariesState = 'success';
            setState('ui.billingSummaryWorkspace.action.listBillingSummaries.status', 'success');
        }
        else {
            this.listBillingSummariesState = 'error';
            setState('ui.billingSummaryWorkspace.action.listBillingSummaries.status', 'error');
            if (response.error) {
                console.error('listBillingSummaries failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action listBillingSummaries — bind UI events here */
    handleListBillingSummariesClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadListBillingSummaries();
    }
    /** action createBillingSummaryCmd (command) — route buildFlowFsm.billingSummaryWorkspace.createBillingSummaryCmd; inputs: projectId, periodStart, periodEnd; writes ui.billingSummaryWorkspace.output.createBillingSummaryCmd; status ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status; feedback keys action.createBillingSummaryCmd.success / action.createBillingSummaryCmd.error */
    async createBillingSummaryCmd() {
        this.syncRouteParams();
        if (!this.createBillingSummaryCmdProjectId) {
            this.createBillingSummaryCmdState = 'idle';
            setState('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.createBillingSummaryCmdState = 'loading';
        setState('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status', 'loading');
        this.createBillingSummaryCmdError = '';
        setState('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.error', '');
        const params = {
            projectId: this.createBillingSummaryCmdProjectId,
            periodStart: this.createBillingSummaryCmdPeriodStart,
            periodEnd: this.createBillingSummaryCmdPeriodEnd,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(createBillingSummaryCmdRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.createBillingSummaryCmd.error');
            this.createBillingSummaryCmdError = errMsg;
            setState('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.error', errMsg);
            this.createBillingSummaryCmdState = 'error';
            setState('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.createBillingSummaryCmdOutput = data;
        setState('ui.billingSummaryWorkspace.output.createBillingSummaryCmd', data);
        try {
            await this.loadListBillingSummaries();
            if (this.listBillingSummariesState === 'error') {
                this.createBillingSummaryCmdState = 'error';
                setState('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('createBillingSummaryCmd refresh failed', refreshError);
            this.createBillingSummaryCmdState = 'error';
            setState('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status', 'error');
            this.requestUpdate();
            return;
        }
        this.createBillingSummaryCmdPeriodStart = '';
        setState('ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodStart', '');
        this.createBillingSummaryCmdPeriodEnd = '';
        setState('ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodEnd', '');
        this.createBillingSummaryCmdState = 'success';
        setState('ui.billingSummaryWorkspace.action.createBillingSummaryCmd.status', 'success');
        this.requestUpdate();
    }
    /** handler for action createBillingSummaryCmd — bind UI events here */
    handleCreateBillingSummaryCmdClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.createBillingSummaryCmd();
        });
    }
    /** action shareBillingSummaryCmd (command) — route buildFlowFsm.billingSummaryWorkspace.shareBillingSummaryCmd; inputs: billingSummaryId, status; writes ui.billingSummaryWorkspace.output.shareBillingSummaryCmd; status ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status; feedback keys action.shareBillingSummaryCmd.success / action.shareBillingSummaryCmd.error */
    async shareBillingSummaryCmd() {
        this.syncRouteParams();
        if (!this.shareBillingSummaryCmdBillingSummaryId) {
            this.shareBillingSummaryCmdState = 'idle';
            setState('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.shareBillingSummaryCmdState = 'loading';
        setState('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status', 'loading');
        this.shareBillingSummaryCmdError = '';
        setState('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.error', '');
        const params = {
            billingSummaryId: this.shareBillingSummaryCmdBillingSummaryId,
            status: this.shareBillingSummaryCmdStatus,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(shareBillingSummaryCmdRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.shareBillingSummaryCmd.error');
            this.shareBillingSummaryCmdError = errMsg;
            setState('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.error', errMsg);
            this.shareBillingSummaryCmdState = 'error';
            setState('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.shareBillingSummaryCmdOutput = data;
        setState('ui.billingSummaryWorkspace.output.shareBillingSummaryCmd', data);
        try {
            await this.loadListBillingSummaries();
            if (this.listBillingSummariesState === 'error') {
                this.shareBillingSummaryCmdState = 'error';
                setState('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('shareBillingSummaryCmd refresh failed', refreshError);
            this.shareBillingSummaryCmdState = 'error';
            setState('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status', 'error');
            this.requestUpdate();
            return;
        }
        this.shareBillingSummaryCmdStatus = '';
        setState('ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.status', '');
        this.shareBillingSummaryCmdState = 'success';
        setState('ui.billingSummaryWorkspace.action.shareBillingSummaryCmd.status', 'success');
        this.requestUpdate();
    }
    /** handler for action shareBillingSummaryCmd — bind UI events here */
    handleShareBillingSummaryCmdClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.shareBillingSummaryCmd();
        });
    }
    /** setter for state ui.billingSummaryWorkspace.input.listBillingSummaries.projectId */
    setListBillingSummariesProjectId(value) {
        this.listBillingSummariesProjectId = value;
        setState('ui.billingSummaryWorkspace.input.listBillingSummaries.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.listBillingSummariesProjectId — bind UI events here */
    handleListBillingSummariesProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListBillingSummariesProjectId(value);
    }
    /** setter for state ui.billingSummaryWorkspace.input.listBillingSummaries.status */
    setListBillingSummariesStatus(value) {
        this.listBillingSummariesStatus = value;
        setState('ui.billingSummaryWorkspace.input.listBillingSummaries.status', value);
        this.requestUpdate();
    }
    /** handler for action set.listBillingSummariesStatus — bind UI events here */
    handleListBillingSummariesStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListBillingSummariesStatus(value);
    }
    /** setter for state ui.billingSummaryWorkspace.input.listBillingSummaries.page */
    setListBillingSummariesPage(value) {
        this.listBillingSummariesPage = value;
        setState('ui.billingSummaryWorkspace.input.listBillingSummaries.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listBillingSummariesPage — bind UI events here */
    handleListBillingSummariesPageChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListBillingSummariesPage(value);
    }
    /** setter for state ui.billingSummaryWorkspace.input.listBillingSummaries.pageSize */
    setListBillingSummariesPageSize(value) {
        this.listBillingSummariesPageSize = value;
        setState('ui.billingSummaryWorkspace.input.listBillingSummaries.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listBillingSummariesPageSize — bind UI events here */
    handleListBillingSummariesPageSizeChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setListBillingSummariesPageSize(value);
    }
    /** setter for state ui.billingSummaryWorkspace.input.createBillingSummaryCmd.projectId */
    setCreateBillingSummaryCmdProjectId(value) {
        this.createBillingSummaryCmdProjectId = value;
        setState('ui.billingSummaryWorkspace.input.createBillingSummaryCmd.projectId', value);
        this.requestUpdate();
    }
    /** handler for action set.createBillingSummaryCmdProjectId — bind UI events here */
    handleCreateBillingSummaryCmdProjectIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCreateBillingSummaryCmdProjectId(value);
    }
    /** setter for state ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodStart */
    setCreateBillingSummaryCmdPeriodStart(value) {
        this.createBillingSummaryCmdPeriodStart = value;
        setState('ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodStart', value);
        this.requestUpdate();
    }
    /** handler for action set.createBillingSummaryCmdPeriodStart — bind UI events here */
    handleCreateBillingSummaryCmdPeriodStartChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCreateBillingSummaryCmdPeriodStart(value);
    }
    /** setter for state ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodEnd */
    setCreateBillingSummaryCmdPeriodEnd(value) {
        this.createBillingSummaryCmdPeriodEnd = value;
        setState('ui.billingSummaryWorkspace.input.createBillingSummaryCmd.periodEnd', value);
        this.requestUpdate();
    }
    /** handler for action set.createBillingSummaryCmdPeriodEnd — bind UI events here */
    handleCreateBillingSummaryCmdPeriodEndChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCreateBillingSummaryCmdPeriodEnd(value);
    }
    /** setter for state ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.billingSummaryId */
    setShareBillingSummaryCmdBillingSummaryId(value) {
        this.shareBillingSummaryCmdBillingSummaryId = value;
        setState('ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.billingSummaryId', value);
        this.requestUpdate();
    }
    /** handler for action set.shareBillingSummaryCmdBillingSummaryId — bind UI events here */
    handleShareBillingSummaryCmdBillingSummaryIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setShareBillingSummaryCmdBillingSummaryId(value);
    }
    /** setter for state ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.status */
    setShareBillingSummaryCmdStatus(value) {
        this.shareBillingSummaryCmdStatus = value;
        setState('ui.billingSummaryWorkspace.input.shareBillingSummaryCmd.status', value);
        this.requestUpdate();
    }
    /** handler for action set.shareBillingSummaryCmdStatus — bind UI events here */
    handleShareBillingSummaryCmdStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setShareBillingSummaryCmdStatus(value);
    }
}
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "listBillingSummariesState", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "listBillingSummariesProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "listBillingSummariesStatus", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "listBillingSummariesPage", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "listBillingSummariesPageSize", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "listBillingSummariesData", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "createBillingSummaryCmdState", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "createBillingSummaryCmdProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "createBillingSummaryCmdPeriodStart", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "createBillingSummaryCmdPeriodEnd", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "createBillingSummaryCmdOutput", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "createBillingSummaryCmdError", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "shareBillingSummaryCmdState", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "shareBillingSummaryCmdBillingSummaryId", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "shareBillingSummaryCmdStatus", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "shareBillingSummaryCmdOutput", void 0);
__decorate([
    property()
], BuildFlowFsmBillingSummaryWorkspaceBase.prototype, "shareBillingSummaryCmdError", void 0);
